"""Portable, CPU-only self-check. Does not install, download, or execute models."""
from pathlib import Path
import hashlib, importlib.util, json, math, sys
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def main():
    release=ROOT/'provenance/release_files.json'
    if release.exists():
        for row in load(release)['files']:
            assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    sources=load(ROOT/'provenance/frozen_sources.json')['files']
    for row in sources:
        path=ROOT/row['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']==row['source_sha256'],row['path']
    code=list(ROOT.rglob('*.py'))
    for path in code:
        if not any(part in ('_work','.venv','__pycache__') for part in path.parts):compile(path.read_bytes(),path.name,'exec')
    for case in load(ROOT/'fixtures/toy_rankings.json')['cases']:
        ranking=case['ranking'];positive=set(case['positives']);ranks=[i+1 for i,t in enumerate(ranking) if t in positive]
        assert math.isclose(1/min(ranks),case['expected_mrr'])
        assert math.isclose(len(set(ranking[:1])&positive)/len(positive),case['expected_recall_at_1'])
    from rebuild_primary_tables import rows_and_labels
    rows,labels=rows_and_labels()
    path=ROOT/'frozen/publication/extensions/publication_statistics.py'
    spec=importlib.util.spec_from_file_location('statistics_fixture',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    fixture=mod.self_test()
    configs=list((ROOT/'configs/training').glob('*.json'));assert len(configs)==78
    print(json.dumps({'status':'PASS_PORTABLE_CPU_CHECK','python':sys.version.split()[0],'frozen_sources_verified':len(sources),'training_configs':len(configs),'primary_rankings_validated':len(rows),'primary_queries':len(labels),'statistics_fixture':fixture,'gpu_training_performed':False}))
if __name__=='__main__':main()
