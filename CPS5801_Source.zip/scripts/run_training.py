"""Portable training adapter. No source edits and no evaluation on final data.

S0 calls the original engine for all six paired runs. S1-S5 call the unchanged
configurable engine with actual historical configurations and rebased paths.
This replays already selected recipes; it is not a new blind selection study.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
EXT=ROOT/'frozen/publication/extensions'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def verify_base_model(work,family):
    from download_assets import verify
    assets=read(ROOT/'configs/download_assets.json')['files']
    for item in assets:
        if item['group']==family:verify(work/item['destination'],item)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path);p.add_argument('--stage',required=True,choices=['S0','S1','S2','S3','S4','S5']);p.add_argument('--run-id');p.add_argument('--check-only',action='store_true');a=p.parse_args();work=a.workspace.resolve(strict=True)
    freeze=read(ROOT/'configs/original_freeze_manifest.json')
    for rel,h in freeze['files'].items():
        path=work/'reproduction'/rel
        if not path.is_file() or sha(path)!=h:raise ValueError('Missing/changed frozen input: '+rel)
    if a.stage=='S0':
        if a.run_id:p.error('S0 original engine always runs all six paired jobs')
        required=work/'reproduction/data/raw/model/model.safetensors'
        if not required.is_file():raise FileNotFoundError('Download E5 first: '+str(required))
        verify_base_model(work,'e5')
        out=work/'reproduction/results/main_20261025'
        if list(out.glob('M*')):raise ValueError('Prior S0 results present; use a fresh workspace')
        if a.check_only:print('READY_S0_6_JOBS_INPUTS_ONLY_NOT_GPU_VALIDATED');return
        subprocess.run([sys.executable,str(work/'reproduction/scripts/main_training_engine.py')],cwd=work/'reproduction',check=True);return
    configs=[read(path) for path in sorted((ROOT/'configs/training').glob('*.json'))]
    configs=[c for c in configs if c['stage']==a.stage and (not a.run_id or c['run_id']==a.run_id)]
    if not configs:raise ValueError('No matching historical run')
    verify_base_model(work,configs[0]['family'])
    for config in configs:
        for k in ['model_path','train_path','corpus_path','schedule_path','negatives_path','train_tool_ids_path','forbidden_path']:
            if k in config:
                config[k]=str((work/config[k]).resolve())
                if not Path(config[k]).exists():raise FileNotFoundError(config[k])
        if not (Path(config['model_path'])/'model.safetensors').exists():raise FileNotFoundError('Missing base-model weights')
        config['input_hashes']={str((work/k).resolve()):v for k,v in config['input_hashes'].items()}
        for path,h in config['input_hashes'].items():
            if sha(Path(path))!=h:raise ValueError('Frozen input changed: '+path)
        output=work/'new_runs'/config['run_id']
        if output.exists():raise ValueError('Never reuse existing attempt: '+str(output))
        if a.check_only:print('READY_INPUTS',config['run_id']);continue
        cfg=work/'portable_configs'/(config['run_id']+'.json');cfg.parent.mkdir(exist_ok=True)
        cfg.write_text(json.dumps(config,indent=2),encoding='utf8')
        subprocess.run([sys.executable,str(EXT/'train_configurable.py'),'--config',str(cfg),'--output',str(output)],cwd=work,check=True)
if __name__=='__main__':main()
