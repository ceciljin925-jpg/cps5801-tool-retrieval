"""Portable roots for unchanged schedule/signature/mining/negative functions."""
from pathlib import Path
import argparse, importlib.util, sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path);p.add_argument('--stage',required=True,choices=['schedules','signatures','mine','negatives']);p.add_argument('--output-dir',type=Path,help='Optional separate fresh policy directory; use the same directory for all four stages.');a=p.parse_args();work=a.workspace.resolve(strict=True)
    ext=ROOT/'frozen/publication/extensions';sys.path.insert(0,str(ext))
    spec=importlib.util.spec_from_file_location('frozen_policy_preparation',ext/'prepare_policies.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.ROOT=work/'publication';mod.SOURCE=work/'reproduction/data/main_20261025';mod.MODEL=work/'reproduction/data/raw/model';mod.DATA=a.output_dir.resolve() if a.output_dir else mod.ROOT/'data/training'
    mod.DATA.mkdir(parents=True,exist_ok=True)
    {'schedules':mod.shared_schedules,'signatures':mod.signatures,'mine':mod.mine_dense,'negatives':mod.prepare_negatives}[a.stage]()
if __name__=='__main__':main()
