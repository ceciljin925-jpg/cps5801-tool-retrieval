"""Download pinned official assets; verify SHA256 or Git blob SHA1 before use."""
from pathlib import Path
import argparse, hashlib, json, urllib.request
ROOT=Path(__file__).resolve().parents[1]
def verify(p,item):
    if p.stat().st_size!=item['bytes']:raise ValueError('Size mismatch: '+str(p))
    h=hashlib.sha256();g=hashlib.sha1();g.update(('blob '+str(p.stat().st_size)+'\0').encode())
    with p.open('rb') as stream:
        while block:=stream.read(4*1024*1024):h.update(block);g.update(block)
    if item.get('sha256') and h.hexdigest()!=item['sha256']:raise ValueError('SHA256 mismatch: '+str(p))
    if not item.get('sha256') and g.hexdigest()!=item['git_blob_sha1']:raise ValueError('Git blob mismatch: '+str(p))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--group',required=True,choices=['e5','bge','qwen','toolret','bfcl','toolhop']);p.add_argument('--workspace',type=Path);p.add_argument('--list',action='store_true');a=p.parse_args()
    if a.group in ('bfcl','toolhop'):
        raw=json.loads((ROOT/'configs/upstream'/f'{a.group}_download_manifest.json').read_text(encoding='utf8'))['files']
        items=[{'url':x['url'],'destination':'external_source_assets/'+a.group+'/'+x['path'],'bytes':x['size_bytes'],'sha256':x['sha256']} for x in raw]
    else:items=[x for x in json.loads((ROOT/'configs/download_assets.json').read_text())['files'] if x['group']==a.group]
    if a.list:print(json.dumps({'group':a.group,'files':len(items),'bytes':sum(x['bytes'] for x in items),'assets':items},indent=2));return
    if a.workspace is None:p.error('--workspace required unless --list')
    base=a.workspace.resolve();base.mkdir(parents=True,exist_ok=True)
    for item in items:
        dest=(base/item['destination']).resolve()
        if base not in dest.parents:raise ValueError('Destination escaped workspace')
        dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():
            partial=dest.with_suffix(dest.suffix+'.part')
            if partial.exists():raise ValueError('Preserved incomplete download exists; inspect or choose new workspace: '+str(partial))
            with urllib.request.urlopen(item['url'],timeout=120) as response,partial.open('xb') as stream:
                while chunk:=response.read(4*1024*1024):stream.write(chunk)
            verify(partial,item);partial.rename(dest)
        verify(dest,item);print('VERIFIED',item['destination'])
if __name__=='__main__':main()
