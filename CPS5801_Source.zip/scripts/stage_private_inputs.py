"""Copy only allowlisted, hash-verified historical inputs to a new local workspace.

Inputs can include historical review records. Keep the workspace private/ignored.
No result checkpoint, predictions, conversation, process log or secret is copied.
"""
from pathlib import Path
import argparse, hashlib, json, shutil
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bundle',required=True,type=Path);p.add_argument('--workspace',required=True,type=Path);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    bundle=a.bundle.resolve(strict=True);workspace=a.workspace.resolve()
    if workspace.exists():raise ValueError('Workspace must not exist; use a new directory')
    if bundle==workspace or bundle in workspace.parents or workspace in bundle.parents:raise ValueError('Source and destination must be separate')
    manifest=json.loads((ROOT/'configs/private_input_manifest.json').read_text(encoding='utf8'))
    for row in manifest['files']:
        path=(bundle/row['source']).resolve(strict=True)
        if bundle not in path.parents or digest(path)!=row['sha256']:raise ValueError('Input identity mismatch: '+row['source'])
    print('VERIFIED_INPUT_FILES',len(manifest['files']))
    if a.check_only:return
    workspace.mkdir()
    for row in manifest['files']:
        dest=workspace/row['destination'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(bundle/row['source'],dest)
    scripts=workspace/'reproduction/scripts';scripts.mkdir(parents=True,exist_ok=True)
    for src in (ROOT/'frozen/reproduction/scripts').glob('*.py'):
        dest=scripts/src.name
        if dest.exists() and digest(src)!=digest(dest):raise ValueError('Frozen source mismatch')
        if not dest.exists():shutil.copyfile(src,dest)
    (workspace/'reproduction/logs').mkdir(exist_ok=True)
    print('STAGED_FROZEN_INPUTS_NO_MODELS_OR_PREDICTIONS')
if __name__=='__main__':main()
