"""Packaging adapter: recompute primary tables from all 31,500 saved rankings.

No model inference, saved scalar metrics, or benchmark text is used as input.
The original statistical implementation is imported without modification.
"""
from pathlib import Path
import argparse, collections, csv, gzip, importlib.util, json, math, statistics

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'results/representative'

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def rows_and_labels():
    labels=load(DATA/'bfcl_live_labels.json')
    assert len(labels)==1050 and len({x['id'] for x in labels})==1050
    qmap={q['id']:q for q in labels}
    assert len({q['group_id'] for q in labels})==220
    rows=[];seen=set()
    with gzip.open(DATA/'bfcl_live_rankings.jsonl.gz','rt',encoding='utf8') as stream:
        for line in stream:
            row=json.loads(line);q=qmap[row['id']];order=row['ranking']
            key=(row['family'],row['policy'],row['seed'],row['id'])
            assert key not in seen;seen.add(key)
            assert row['family'] in ('e5','bge') and row['policy'] in ('R_ID','B_ID','B_UNIQUE')
            assert row['seed'] in (42,43,44,45,46)
            assert len(order)==len(set(order))==len(q['candidate_ids'])
            assert set(order)==set(q['candidate_ids'])
            assert q['positives'] and set(q['positives'])<=set(order)
            ranks=[order.index(t)+1 for t in q['positives']]
            row['metrics']={'mrr':1/min(ranks),'hit@1':float(min(ranks)==1)}
            rows.append(row)
    assert len(rows)==31500
    assert all(sum(r['family']==f and r['policy']==p and r['seed']==s for r in rows)==1050
               for f in ('e5','bge') for p in ('R_ID','B_ID','B_UNIQUE') for s in range(42,47))
    return rows,labels

def write_csv(path,rows):
    with path.open('w',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def build(output,bootstrap=True):
    if output.exists() and any(output.iterdir()):raise ValueError('Use a new empty output directory')
    rows,labels=rows_and_labels();output.mkdir(parents=True,exist_ok=True)
    expected=load(DATA/'expected_primary_results.json')
    summaries=[];effects=[]
    script=ROOT/'frozen/publication/extensions/publication_statistics.py'
    spec=importlib.util.spec_from_file_location('frozen_statistics',script)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for family in ('e5','bge'):
        records=[{'method':r['policy'],'seed':r['seed'],'query_id':r['id'],'metrics':r['metrics']} for r in rows if r['family']==family]
        if bootstrap:
            config=expected[family]['bootstrap']
            data={'evidence_stage':'confirmation','expected_seeds':[42,43,44,45,46],
                  'expected_query_ids':[q['id'] for q in labels],
                  'query_groups':{q['id']:q['group_id'] for q in labels},
                  'metrics':['mrr','hit@1'],'records':records,'bootstrap':config,
                  'contrasts':[{'contrast_id':family+':selected_minus_'+p,'coefficients':{'B_UNIQUE':1,p:-1}} for p in ['R_ID','B_ID']]}
            analysis=module.analyze(data)
            (output/(family+'_bootstrap.json')).write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf8')
            actual_methods=analysis['method_summary'];actual_effects=analysis['contrasts']
        else:
            actual_methods=[];actual_effects=[]
            lookup={(r['method'],r['seed'],r['query_id']):r['metrics'] for r in records}
            for p in ['B_ID','B_UNIQUE','R_ID']:
                for metric in ['mrr','hit@1']:
                    means=[math.fsum(lookup[(p,s,q['id'])][metric] for q in labels)/len(labels) for s in range(42,47)]
                    actual_methods.append({'method':p,'metric':metric,'mean':statistics.mean(means),'sample_sd':statistics.stdev(means)})
            for p in ['R_ID','B_ID']:
                for metric in ['mrr','hit@1']:
                    diffs=[math.fsum(lookup[('B_UNIQUE',s,q['id'])][metric]-lookup[(p,s,q['id'])][metric] for q in labels)/len(labels) for s in range(42,47)]
                    actual_effects.append({'contrast_id':family+':selected_minus_'+p,'metric':metric,'mean_paired_effect':statistics.mean(diffs),'sample_sd_across_seed_effects':statistics.stdev(diffs),'positive_seed_count':sum(d>0 for d in diffs),'negative_seed_count':sum(d<0 for d in diffs)})
        for m in actual_methods:
            ref=next(x for x in expected[family]['methods'] if x['method']==m['method'] and x['metric']==m['metric'])
            assert abs(ref['mean']-m['mean'])<1e-12 and abs(ref['sample_sd']-m['sample_sd'])<1e-12
            summaries.append({'family':family,'policy':m['method'],'metric':m['metric'],'mean':m['mean'],'seed_sample_sd':m['sample_sd'],'seeds':5,'queries_per_seed':1050,'proxy_groups':220})
        for c in actual_effects:
            ref=next(x for x in expected[family]['contrasts'] if x['contrast_id']==c['contrast_id'] and x['metric']==c['metric'])
            assert abs(ref['mean_paired_effect']-c['mean_paired_effect'])<1e-12
            interval=c.get('paired_query_weighted_cluster_bootstrap',{}).get('percentile_interval')
            if bootstrap:assert max(abs(a-b) for a,b in zip(interval,ref['cluster_interval']))<1e-12
            effects.append({'family':family,'contrast':c['contrast_id'],'metric':c['metric'],'mean_paired_effect':c['mean_paired_effect'],'seed_effect_sample_sd':c['sample_sd_across_seed_effects'],'cluster_ci_lower':interval[0] if interval else '', 'cluster_ci_upper':interval[1] if interval else '', 'positive_seeds':c['positive_seed_count'],'negative_seeds':c['negative_seed_count'],'interval_scope':'pointwise conditional on fitted models/fixed labels' if interval else 'not computed'})
    write_csv(output/'primary_methods.csv',summaries);write_csv(output/'primary_effects.csv',effects)
    status={'status':'PASS_PRIMARY_TABLE_REBUILD','rankings':len(rows),'queries':1050,'groups':220,'models':30,'summary_rows':len(summaries),'contrast_rows':len(effects),'group_bootstrap_recomputed':bootstrap,'model_inference':False,'original_official_label_projection_reaudited':False,'expected_scalar_comparison_tolerance':1e-12}
    (output/'validation.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8');print(json.dumps(status));return status

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--no-bootstrap',action='store_true',help='Standard-library-only summary regeneration; no intervals.')
    a=p.parse_args();build(a.output,not a.no_bootstrap)
