"""Run the frozen retriever with an explicit local config and new output folder.

External confirmation configs must retain external_final=true and a compatible
final lock; this adapter does not weaken the original access/hash gate.
"""
from pathlib import Path
import argparse, json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    config=json.loads(a.config.read_text(encoding='utf8'))
    for key in ['queries_path','corpus_path']+(['model_path'] if config['family']!='bm25' else []):
        if not Path(config[key]).exists():raise FileNotFoundError(config[key])
    if a.output.exists():raise ValueError('Use a new output path')
    if a.check_only:print('CONFIG_PATHS_EXIST_NOT_INFERENCE_VALIDATED');return
    subprocess.run([sys.executable,str(ROOT/'frozen/publication/extensions/evaluate_retrieval.py'),'--config',str(a.config.resolve()),'--output',str(a.output.resolve())],check=True)
if __name__=='__main__':main()
