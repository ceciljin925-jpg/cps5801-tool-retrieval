"""Optional complete CPU regeneration against a separately supplied local bundle.

Uses the canonical bundle analysis_tools adapter, not the old broken extensions
entry. No remote bundle URL exists here. Original inputs remain read-only.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bundle',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();bundle=a.bundle.resolve(strict=True);output=a.output.resolve()
    if output==bundle or bundle in output.parents or output in bundle.parents:raise ValueError('Output must be separate from bundle')
    records=json.loads((ROOT/'provenance/frozen_sources.json').read_text(encoding='utf8'))['files']
    for row in records:
        if not row['source_bundle_relative_path'].startswith('publication/'):continue
        path=bundle/row['source_bundle_relative_path']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['source_sha256']:raise ValueError('Unexpected source: '+row['source_bundle_relative_path'])
    subprocess.run([sys.executable,str(bundle/'publication/analysis_tools/rebuild_research.py'),'--input-root',str(bundle),'--output-dir',str(output)],check=True)
if __name__=='__main__':main()
