import csv
from pathlib import Path
from statistics import mean
from math import isclose


def records(name):
    with (Path(__file__).parent / 'results' / name).open(encoding='utf-8-sig', newline='') as source:
        return list(csv.DictReader(source))


scores = records('evaluations_100_recomputed.csv')
assert len(scores) == 100
live = {(int(row['seed']), row['objective'], row['policy']): float(row['mrr'])
        for row in scores if row['dataset'] == 'bfcl_live_multiple'}
assert len(live) == 20
expected = {int(row['seed']): float(row['effect']) for row in records('paired_seed_effects.csv')
            if row['dataset'] == 'bfcl_live_multiple' and row['contrast'] == 'interaction'}
effects = []
for seed in range(42, 47):
    gaps = {objective: live[seed, objective, 'B_ID'] - live[seed, objective, 'R_ID']
            for objective in {key[1] for key in live}}
    augmented, = set(gaps) - {'explicit_1p4'}
    effect = gaps[augmented] - gaps['explicit_1p4']
    assert isclose(effect, expected[seed], abs_tol=1e-12)
    effects.append(effect)
print(f'BFCL live interaction: {mean(effects):+.8f}; positive seeds: {sum(effect > 0 for effect in effects)}/5')
