"""Stdlib acceptance of complete625-step mask evidence against frozen CPU plans."""
from pathlib import Path
import json
from mask_core import summarize
from train_bridge import read, sha_file, HERE


def require(value,message):
    if not value:raise ValueError(message)


def jsonl(path):
    with Path(path).open(encoding='utf-8') as f:
        return [json.loads(line) for line in f]


def validate_mask_artifacts(path,conf):
    path=Path(path)
    frozen=read(HERE.parent/'verification/static_mask_expectations.json')
    require(frozen['mask_core_sha256']==sha_file(HERE/'mask_core.py'),'CPU mask rule identity changed')
    matches=[r for r in frozen['records'] if (r['policy'],r['seed'])==(conf['policy'],conf['seed'])]
    require(len(matches)==1,'Missing/ambiguous frozen mask expectation')
    expected=matches[0]
    for field in ('train_path','corpus_path','schedule_path','negatives_path','forbidden_path','input_signatures_path','train_tool_ids_path'):
        p=Path(conf[field])
        require(frozen['input_file_sha256'].get(p.name)==sha_file(p),'Frozen mask source differs: '+field)
    digest=sha_file(path/'mask_plan_microbatches.jsonl')
    require(digest==expected['mask_plan_sha256'],'Full mask plan differs from CPU frozen inputs')
    identity=read(path/'identity.json')
    require(identity['bridge']['mask_plan_sha256']==digest,'Training identity does not bind mask plan')
    enabled=conf['objective']=='explicit_1p4_plus_inbatch_positives'
    require(conf['objective'] in ('explicit_1p4','explicit_1p4_plus_inbatch_positives'),'Unknown objective')
    plans=jsonl(path/'mask_plan_microbatches.jsonl')
    actual=jsonl(path/'mask_microbatches.jsonl')
    require(len(plans)==len(actual)==2500,'Not exactly2500 executed microbatches')
    for i,(planned,observed) in enumerate(zip(plans,actual)):
        require(planned['step']==i//4+1 and planned['microbatch_in_update']==i%4,'Noncontiguous microbatch order')
        require(observed=={**planned,'objective_enabled':enabled},'Executed mask record differs from frozen plan')
    total,queries=summarize([r['plan'] for r in plans],enabled)
    for key in ('exposures','potential_extras','eligible_extras','microbatches','queries','eligible_count_histogram','removed_by_reason'):
        require(total[key]==expected[key],'Aggregate differs from CPU frozen expectation: '+key)
    total.update({'objective':conf['objective'],'logged_updates':625,'planned_updates':625,
                  'mask_plan_sha256':digest,
                  'coverage_basis':'durable contiguous loss rows; exact625 only when final status completed',
                  'status':'completed'})
    require(read(path/'mask_summary.json')==total,'Complete mask summary mismatch')
    require(read(path/'mask_query_summary.json')==queries,'Per-query mask summary mismatch')
    return {'status':'PASS','objective':conf['objective'],'policy':conf['policy'],'seed':conf['seed'],
            'microbatches':2500,'exposures':20000,'eligible_extras':total['eligible_extras'],
            'actual_added_extras':total['actual_added_extras'],'mask_plan_sha256':digest}


if __name__=='__main__':
    import argparse
    from train_bridge import load_config
    p=argparse.ArgumentParser();p.add_argument('--attempt',type=Path,required=True);p.add_argument('--config',type=Path,required=True);a=p.parse_args()
    print(json.dumps(validate_mask_artifacts(a.attempt,load_config(a.config)),indent=2))
