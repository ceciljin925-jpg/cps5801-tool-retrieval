"""Deterministic, dependency-free SVG figures rebuilt from bridge analysis rows."""
import html,json,pathlib

METHODS=['explicit_1p4__R_ID','explicit_1p4__B_ID','explicit_1p4_plus_inbatch_positives__R_ID','explicit_1p4_plus_inbatch_positives__B_ID']
COLORS=['#1b1b1b','#555555','#777777','#999999','#bbbbbb']

def label(x,y,text,size=14,anchor='start'):
    return f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" text-anchor="{anchor}">{html.escape(str(text))}</text>'
def line(x1,y1,x2,y2,color='#222',width=1,dash=''):
    return f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="{color}" stroke-width="{width}" stroke-dasharray="{dash}"/>'
def dot(x,y,color='#222',radius=4):return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{radius}" fill="{color}"/>'
def svg(path,width,height,body,title):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><title>{html.escape(title)}</title><rect width="100%" height="100%" fill="white"/><g font-family="Arial, sans-serif" fill="#111">'+''.join(body)+'</g></svg>',encoding='utf-8')

def cell_panel(rows,dataset,metric,*,x=75,y=100,width=780,height=290):
    cells={r['method']:r for r in rows if r['dataset']==dataset and r['metric']==metric}
    lower=min(min(min(json.loads(r['per_seed_json']).values()),r['mean']-r['seed_sample_sd']) for r in cells.values())
    upper=max(max(max(json.loads(r['per_seed_json']).values()),r['mean']+r['seed_sample_sd']) for r in cells.values())
    pad=max((upper-lower)*.18,.002);lo=max(0,lower-pad);hi=min(1,upper+pad)
    if hi==lo:hi=lo+.001
    yp=lambda value:y+height*(hi-value)/(hi-lo)
    xp=[x+width*(.1+.8*i/3) for i in range(4)];out=[]
    for i in range(5):
        value=lo+(hi-lo)*i/4;yy=yp(value)
        out.extend([line(x,yy,x+width,yy,'#ddd'),label(x-10,yy+4,f'{value:.4f}',12,'end')])
    for index,seed in enumerate(range(42,47)):
        pts=[(xx,yp(json.loads(cells[m]['per_seed_json'])[str(seed)])) for xx,m in zip(xp,METHODS)]
        for a,b in zip(pts,pts[1:]):out.append(line(*a,*b,COLORS[index],1,'3,3' if index%2 else ''))
        for xx,yy in pts:out.append(dot(xx,yy,COLORS[index],3))
        out.extend([line(x+index*150,y+height+80,x+index*150+20,y+height+80,COLORS[index],2),label(x+index*150+25,y+height+85,f'seed {seed}',12)])
    for i,(xx,m) in enumerate(zip(xp,METHODS)):
        r=cells[m];yy=yp(r['mean']);low=yp(r['mean']-r['seed_sample_sd']);high=yp(r['mean']+r['seed_sample_sd'])
        out.extend([line(xx,low,xx,high,'#000',3),line(xx-7,low,xx+7,low,'#000',2),line(xx-7,high,xx+7,high,'#000',2),dot(xx,yy,'#000',5),label(xx,y+height+27,'Random' if i%2==0 else 'BM25',13,'middle'),label(xx,y+height+46,'Explicit 1+4' if i<2 else '+ in-batch positives',12,'middle')])
    out.append(label(x,y-22,metric+'; black mean +/- sample seed SD; paired seed lines',14))
    return out

def interaction_panel(rows,intervals,dataset,metric,*,x=200,y=110,width=640,rowheight=47):
    mean=next(r for r in rows if r['dataset']==dataset and r['contrast']=='interaction')
    entries=[r for r in intervals if r['dataset']==dataset]
    entries=sorted(entries,key=lambda r:r['seed'])
    entries.append({'seed':'mean of 5 seeds','effect':mean['mean'],'group_ci_low':mean['group_ci_low'],'group_ci_high':mean['group_ci_high']})
    values=[v for r in entries for v in (r['effect'],r['group_ci_low'],r['group_ci_high'])]+[0]
    lo=min(values);hi=max(values);pad=max((hi-lo)*.1,.001);lo-=pad;hi+=pad
    xp=lambda value:x+width*(value-lo)/(hi-lo);out=[];bottom=y+rowheight*(len(entries)-1)
    out.append(line(xp(0),y-20,xp(0),bottom+20,'#aaa',1,'4,4'))
    for i,r in enumerate(entries):
        yy=y+i*rowheight;out.extend([label(x-12,yy+5,('seed '+str(r['seed'])) if isinstance(r['seed'],int) else r['seed'],13,'end'),line(xp(r['group_ci_low']),yy,xp(r['group_ci_high']),yy,'#222',2),dot(xp(r['effect']),yy,'#111',4),label(x+width+12,yy+5,f"{r['effect']:+.4f}",12)])
    for i in range(5):
        val=lo+(hi-lo)*i/4;out.extend([line(xp(val),bottom+27,xp(val),bottom+34),label(xp(val),bottom+52,f'{val:+.4f}',12,'middle')])
    out.append(label(x,y-43,metric+' interaction: (BM25 - Random) in-batch minus explicit',14))
    return out

def make_figures(out,cells,contrasts,seed_intervals):
    out=pathlib.Path(out)/'figures';note='Post hoc follow-up on previously observed evaluation data. All five seeds shown.'
    svg(out/'01_bfcl_live_four_cells.svg',980,555,[label(30,35,'BFCL live: fixed E5 2 x 2 comparison',20),label(30,62,note,12),*cell_panel(cells,'bfcl_live_multiple','mrr'),label(30,535,'Vertical scale is expanded; seed SD describes variation across these five fitted seeds.',12)],'BFCL live four cells')
    ci_note='Bars: pointwise 95% group bootstrap, 5,000 draws; conditional on fitted models, labels and groups.'
    svg(out/'02_bfcl_live_interaction.svg',1020,530,[label(30,35,'BFCL live: paired interactions and conditional intervals',20),label(30,62,note,12),*interaction_panel(contrasts,seed_intervals,'bfcl_live_multiple','mrr',y=140),label(30,480,ci_note,12),label(30,505,'These intervals do not measure full training or label uncertainty; they are not simultaneous intervals.',12)],'BFCL live interaction by seed')
    svg(out/'03_legacy_recall5.svg',1020,1045,[label(30,35,'Historical pooled catalogue: Recall@5 follow-up',20),label(30,62,note,12),*cell_panel(cells,'legacy_observed_test','recall@5'),*interaction_panel(contrasts,seed_intervals,'legacy_observed_test','recall@5',y=645),label(30,985,ci_note,12),label(30,1015,'Historical descriptive analysis; no fresh-test confirmation or duplicate-causality claim.',12)],'Historical Recall@5 four cells and interaction')
