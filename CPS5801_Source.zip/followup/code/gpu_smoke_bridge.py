"""Mandatory GPU engineering acceptance; never a scientific training cell.

Uses a formal explicit seed42 config, but interrupts the actual 625-step runner
after three updates. Its outputs are intentionally marked interrupted fixtures;
preflight_report.json is the only PASS/FAIL gate. No model/data substitution.
"""
from __future__ import annotations
import argparse
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys
import traceback

import train_bridge as bridge


class EngineeringStop(RuntimeError):
    pass


def state_digest(value, torch):
    """Stable tensor/state content digest; ignores storage addresses and file ZIP metadata."""
    h=hashlib.sha256()
    def add(x):
        h.update(type(x).__name__.encode()+b':')
        if torch.is_tensor(x):
            y=x.detach().cpu().contiguous()
            h.update(str(y.dtype).encode());h.update(str(tuple(y.shape)).encode())
            h.update(y.reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(x,dict):
            for k in sorted(x,key=lambda k:(type(k).__name__,str(k))):add(k);add(x[k])
        elif isinstance(x,(list,tuple)):
            for v in x:add(v)
        elif hasattr(x,'dtype') and hasattr(x,'tobytes'):
            h.update(str(x.dtype).encode());h.update(str(x.shape).encode());h.update(x.tobytes())
        else:h.update(repr(x).encode())
        h.update(b';')
    add(value);return h.hexdigest()


def capture(encoder,optimizer,e):
    return {'model_state_sha256':state_digest(encoder.model.state_dict(),e.torch),
            'optimizer_state_sha256':state_digest(optimizer.state_dict(),e.torch),
            'rng_state_sha256':state_digest(e.get_rng(),e.torch),
            'model_training':encoder.model.training,
            'encoder_forward_calls':encoder._bridge_forward_counter['calls']}


def run_slice(config,out,stop,e,resume=False):
    result={}
    def after(step,encoder,optimizer,row):
        if step==stop:
            result.update(capture(encoder,optimizer,e))
            result['last_step']=step
            raise EngineeringStop(f'ENGINEERING_ONLY intentional stop after update {stop}')
    try:
        bridge.run(config,out,resume=resume,after_update=after)
    except EngineeringStop:
        pass
    else:
        raise RuntimeError('Engineering stop did not occur')
    rows=[z for line,z in bridge.loss_prefix(out/'loss.jsonl')[0]]
    if len(rows)!=stop or not result:
        raise AssertionError('Smoke did not produce expected durable loss prefix')
    result['loss_grad_trace']=[{'step':r['step'],'loss':r['loss'],'grad_norm':r['grad_norm']} for r in rows]
    result['mask_summary']=bridge.read(out/'mask_summary.json')
    if result['mask_summary']['logged_updates']!=stop:
        raise AssertionError('Diagnostics/execution prefix mismatch')
    bridge.atomic_json(out/'engineering_fixture.json',{'scope':'ENGINEERING_ONLY_NOT_SCIENTIFIC_CELL',
        'intended_full_config_steps':625,'intentional_stop_at':stop,'resumed':resume,'capture':result})
    gc.collect();e.torch.cuda.empty_cache()
    return result


def same_training_state(a,b):
    keys=('model_state_sha256','optimizer_state_sha256','rng_state_sha256','model_training','loss_grad_trace')
    differences=[k for k in keys if a[k]!=b[k]]
    if differences:
        raise AssertionError('Exact replay differs: '+', '.join(differences))


def acceptance(config,out):
    bridge.validate_config(config)
    bridge.output_path({**config,'output_root':str(out/'attempts')},out/'attempts'/'guard_check')
    if config['objective']!='explicit_1p4' or config['seed']!=42 or config['policy']!='R_ID':
        raise ValueError('Preflight config must be formal explicit R_ID seed42')
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Preserve prior preflight; choose a NEW output directory')
    out.mkdir(parents=True,exist_ok=True)
    report={'schema':'bridge_preflight_v1','status':'RUNNING','scope':'ENGINEERING_ONLY_NOT_SCIENTIFIC_CELL',
        'source_hashes':bridge.code_identity(),
        'acceptance_source_hashes':{n:bridge.sha_file(bridge.HERE/n) for n in ('gpu_smoke_bridge.py','test_bridge_cpu.py')},
        'formal_config_sha256':bridge.sha_json(config), 'formal_config':config,
        'base_model_weight_sha256':bridge.sha_file(Path(config['model_path'])/'model.safetensors'),
        'tests':{},'fixture_design':{'real_runner_config_steps':625,'observed_prefix_steps':3,
            'resume_interrupt_after':2,'durable_optimizer_step_at_interrupt':1,
            'fixture_is_not_registered_or_evaluated':True,
            'boundary':'Initial three updates only; not a full625-step or epoch-boundary optimizer replay. Full625-step static mask plans are verified separately.'}}
    bridge.atomic_json(out/'preflight_report.json',report)
    v,e=bridge.load_vendor();e.setup_runtime('cuda')
    original_encoder=v.Encoder
    def counted_encoder(*args,**kwargs):
        encoder=original_encoder(*args,**kwargs)
        count={'calls':0}
        def hook(module,inputs):count['calls']+=1
        encoder.model.register_forward_pre_hook(hook)
        encoder._bridge_forward_counter=count
        return encoder
    v.Encoder=counted_encoder
    try:
        if not e.torch.cuda.is_bf16_supported():raise RuntimeError('CUDA bf16 unavailable')
        report['runtime']=e.runtime_record()
        from test_bridge_cpu import run_tests
        cpu=run_tests(require_torch=True)
        report['tests']['cpu_mask_math_and_torch_autograd']=cpu
        if cpu['status']!='PASS':raise AssertionError('CPU/Torch checks failed')
        snapshots={}
        for objective in bridge.OBJECTIVES:
            conf=copy.deepcopy(config)
            conf.update(objective=objective,resume_every=1,
                        run_id='ENGINEERING_'+objective,
                        output_root=str(out/'attempts'))
            direct=run_slice(conf,out/'attempts'/(objective+'_direct'),3,e)
            interrupted=out/'attempts'/(objective+'_resume')
            run_slice(conf,interrupted,2,e)
            # Exercise partial JSONL recovery and preservation of a future artifact.
            with (interrupted/'loss.jsonl').open('ab') as f:f.write(b'{"step": 999')
            future=interrupted/'checkpoints'/'step_0002';future.mkdir(parents=True)
            (future/'engineering_future_marker.txt').write_text('not model weights; recovery fixture\n')
            resumed=run_slice(conf,interrupted,3,e,resume=True)
            same_training_state(direct,resumed)
            if direct['encoder_forward_calls']!=24 or resumed['encoder_forward_calls']!=16:
                raise AssertionError('Unexpected number of encoder forwards; accumulation scope changed')
            preserved=list((interrupted/'interrupted_tails').glob('bridge_*/step_0002/engineering_future_marker.txt'))
            if len(preserved)!=1 or future.exists():raise AssertionError('Future checkpoint not preserved exactly once')
            snapshots[objective]=direct
            report['tests'][objective+'_resume_exact']={'status':'PASS','direct':direct,'resumed':resumed,
                                                        'partial_jsonl_recovered':True,'future_checkpoint_preserved':True}
            bridge.atomic_json(out/'preflight_report.json',report)
        # Reference uses the unmodified vendor function, same local base model/input order.
        e.seed_all(config['seed'])
        enc=counted_encoder('e5',config['model_path'],'cuda');enc.model.train()
        opt=v.optimizer_for(enc.model,config)
        initial=enc.model.get_input_embeddings().weight.detach().clone()
        train,corpus,schedule,neg,qt,dt=v.prepare_inputs(config,enc)
        trace=[]
        for step in range(1,4):
            loss,grad=v.train_update(enc,opt,schedule[(step-1)*32:step*32],neg,qt,dt,8,.05)
            trace.append({'step':step,'loss':loss,'grad_norm':grad})
        reference=capture(enc,opt,e);reference['loss_grad_trace']=trace
        same_training_state(snapshots['explicit_1p4'],reference)
        if reference['encoder_forward_calls']!=24:raise AssertionError('Vendor reference forward count differs')
        report['tests']['explicit_wrapper_equals_unchanged_vendor']={'status':'PASS','reference':reference}
        report['status']='PASS'
        report['scientific_cells_completed']=0
        report['meaning']='All mandatory local GPU engineering checks passed; no claim of completed bridge scientific training.'
        return report
    except Exception as error:
        report['status']='FAIL';report['error']=repr(error);report['traceback']=traceback.format_exc()
        raise
    finally:
        v.Encoder=original_encoder
        bridge.atomic_json(out/'preflight_report.json',report)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    try:
        report=acceptance(bridge.load_config(a.config),a.output.resolve())
    except Exception as error:
        report_path=a.output/'preflight_report.json'
        if report_path.exists():
            current=bridge.read(report_path)
            if current.get('status')=='RUNNING':
                current.update(status='FAIL',error=repr(error),traceback=traceback.format_exc())
                bridge.atomic_json(report_path,current)
        raise
    print(json.dumps({'status':report['status'],'report':str(a.output/'preflight_report.json')},indent=2))


if __name__=='__main__':main()
