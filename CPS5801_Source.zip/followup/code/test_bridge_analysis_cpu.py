"""Synthetic CPU fixtures only; never labels these temporary ranks as research results."""
import contextlib,copy,hashlib,io,json,math,pathlib,statistics,sys,tempfile,unittest
from unittest.mock import patch
import numpy as np
import bridge_eval_io as bio
from bridge_evaluate import sources
from bridge_eval_io import *
from bridge_analyze import METHODS,CONTRASTS,metrics_from_ranks,rebuild_prediction,paired_contrast,group_bootstrap,result_branches,analyze
from bridge_check_results import check,REQUIRED

def fake_prediction(q,corpus,order,menu):
    scores=[1.-i*.1 for i in range(len(order))]
    ranks=[{'id':p,'rank':order.index(p)+1,'score':scores[order.index(p)]} for p in q['positives']]
    r={'id':q['id'],'positives':q['positives'],'candidate_count':len(order),'query_text_sha256':hashlib.sha256(q['query'].encode()).hexdigest(),'top50':order,'scores':scores,'positive_ranks':ranks,**metrics_from_ranks([x['rank'] for x in ranks],len(order))}
    if menu:r['ranking']=order
    else:
        keys={c['id']:c['document_equivalence_key'] for c in corpus};collapsed=list(dict.fromkeys(keys[p] for p in order));gold=sorted({keys[p] for p in q['positives']});cr=[collapsed.index(g)+1 for g in gold]
        r['equivalence_sensitivity']={'gold_document_classes':gold,'positive_class_ranks':cr,'candidate_document_classes':len(collapsed),**metrics_from_ranks(cr,len(collapsed))}
    return r

class ArithmeticTests(unittest.TestCase):
    def test_model_identity_all_cells_and_changed_weights(self):
        self.assertNotIn('torch',sys.modules)
        with tempfile.TemporaryDirectory(prefix='bridge_SYNTHETIC_MODELS_') as temp:
            root=pathlib.Path(temp);cells=[];models=[]
            for i,(o,p,s) in enumerate((o,p,s) for o in OBJECTIVES for p in POLICIES for s in SEEDS):
                cell={'run_id':f'SYNTHETIC_{i}','objective':o,'policy':p,'seed':s};cells.append(cell)
                cp=root/'models'/cell['run_id'];cp.mkdir(parents=True);(cp/'model.safetensors').write_bytes(b'SYNTHETIC_NOT_A_MODEL_'+str(i).encode())
                manifest=directory_manifest(cp);mp=root/'identities'/f'{i}_files.json';pp=root/'identities'/f'{i}_provenance.json';dump(mp,manifest);dump(pp,{'SYNTHETIC_TEST_ONLY':True,'cell':cell})
                models.append({**cell,'checkpoint_path':str(cp.relative_to(root)),'checkpoint_manifest_path':str(mp.relative_to(root)),'checkpoint_manifest_file_sha256':sha(mp),'checkpoint_manifest_sha256':sha_json(manifest),'model_sha256':sha(cp/'model.safetensors'),'provenance_path':str(pp.relative_to(root)),'provenance_sha256':sha(pp)})
            registry=root/'models_ready.json';dump(registry,{'models':models})
            self.assertEqual(len(validate_models(root,{'cells':cells},registry)),20)
            dump(registry,{'models':models[:-1]})
            with self.assertRaisesRegex(ValueError,'20 model'):validate_models(root,{'cells':cells},registry)
            dump(registry,{'models':models});(root/models[0]['checkpoint_path']/'model.safetensors').write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError,'differs from its manifest'):validate_models(root,{'cells':cells},registry)

    def test_multirelevant_metrics_and_saved_ranks(self):
        m=metrics_from_ranks([2,4],5)
        self.assertEqual(m['recall@3'],.5);self.assertEqual(m['mrr'],.5);self.assertEqual(m['average_precision'],.5);self.assertEqual(m['complete@3'],0)
        q={'id':'q','query':'fixture','positives':['b','d'],'candidate_ids':list('abcd'),'candidate_tie_break_keys':{x:x for x in 'abcd'}}
        r=fake_prediction(q,[],list('abcd'),True)
        self.assertEqual(rebuild_prediction(r,q,list('abcd'),'menu')['mrr'],.5)
        bad=copy.deepcopy(r);bad['positive_ranks'][0]['rank']=1
        with self.assertRaises(ValueError):rebuild_prediction(bad,q,list('abcd'),'menu')
        bad=copy.deepcopy(r);bad['mrr']=1.
        with self.assertRaises(ValueError):rebuild_prediction(bad,q,list('abcd'),'menu')
        bad=copy.deepcopy(r);bad['positives']=['a','d']
        with self.assertRaises(ValueError):rebuild_prediction(bad,q,list('abcd'),'menu')
    def test_tie_order_is_frozen(self):
        q={'id':'q','query':'fixture','positives':['a'],'candidate_ids':['a','b'],'candidate_tie_break_keys':{'a':'02','b':'01'}}
        r=fake_prediction(q,[],['a','b'],True);r['scores']=[.5,.5];r['positive_ranks'][0]['score']=.5
        with self.assertRaisesRegex(ValueError,'tie order'):rebuild_prediction(r,q,['a','b'],'menu')
    def test_interaction_sign_pairing_seed_retention(self):
        matrix={m:{} for m in METHODS};qids=['q1','q2']
        for seed in SEEDS:
            # Explicit B-R = -.10; in-batch B-R = +.20: interaction +.30.
            for method,value in zip(METHODS,[.6,.5,.4,.6]):matrix[method][seed]={q:{'mrr':value+(seed-42)*.001} for q in reversed(qids)}
        ps,avg=paired_contrast(matrix,qids,list(SEEDS),CONTRASTS['interaction'],'mrr')
        for x in avg:self.assertAlmostEqual(x,.3)
        for seed in SEEDS:self.assertAlmostEqual(statistics.mean(ps[seed]),.3)
        with self.assertRaisesRegex(ValueError,'five'):paired_contrast(matrix,qids,list(SEEDS[:-1]),CONTRASTS['interaction'],'mrr')
        del matrix[METHODS[-1]][46]
        with self.assertRaisesRegex(ValueError,'Incomplete paired'):paired_contrast(matrix,qids,list(SEEDS),CONTRASTS['interaction'],'mrr')
    def test_group_weight_and_pcg64_draws(self):
        # One zero row vs three one rows: a two-group bootstrap must carry all
        # rows and divide by resampled row count, not average two group means.
        b=group_bootstrap([0,1,1,1],['a','b','b','b'],replicates=300,seed=17,fixture=True)
        draws=np.random.Generator(np.random.PCG64(17)).integers(0,2,size=(300,2),dtype=np.int64)
        den=np.asarray([1,3])[draws].sum(axis=1);expected=np.asarray([0.,3.])[draws].sum(axis=1)/den
        np.testing.assert_array_equal(b['replicate_n_queries'],den);np.testing.assert_array_equal(b['estimates'],expected)
        self.assertIn(.75,b['estimates']);self.assertNotIn(.5,b['estimates'])
        z=group_bootstrap([0,0,0],['a','b','b'],replicates=30,seed=17,fixture=True)
        self.assertEqual(z['pointwise95'],[0.,0.])
        with self.assertRaises(ValueError):group_bootstrap([0,1],['a','b'],replicates=300)
    def test_result_branches_never_authorize_expansion(self):
        for lo,hi,expected in [(.01,.03,'positive_conditional_interval'),(-.03,-.01,'negative_conditional_interval'),(-.01,.01,'interval_includes_zero')]:
            r=result_branches({'interaction':{'mean':(lo+hi)/2,'group_ci_low':lo,'group_ci_high':hi}},[])
            self.assertEqual(r['interaction_direction'],expected);self.assertFalse(r['additional_training_authorized']);self.assertTrue(r['all_branches_must_complete_report'])

def make_fixture(root):
    cells=[{'run_id':f'SYNTHETIC_{i}','objective':o,'policy':p,'seed':s} for i,(o,p,s) in enumerate((o,p,s) for o in OBJECTIVES for p in POLICIES for s in SEEDS)]
    ds=[];small_counts={};data={};corpus=[{'id':c,'text':'synthetic '+c,'document_equivalence_key':'x' if c in 'ab' else 'y'} for c in 'abcd']
    for name,(_,_,task) in DATASETS.items():
        queries=[{'id':f'q{i}','query':'synthetic query '+str(i),'positives':['b','d'],'group_id':'g1' if i==0 else 'g2',**({'candidate_ids':list('abcd'),'candidate_tie_break_keys':{x:x for x in 'abcd'}} if task=='menu' else {})} for i in range(3)]
        base=root/'inputs'/name;dump(base/'queries.json',queries);dump(base/'corpus.json',corpus);dump(base/'groups.json',{q['id']:q['group_id'] for q in queries})
        d={'dataset':name,'task_type':'native_menu' if task=='menu' else task}
        for key,fn in [('queries','queries.json'),('corpus','corpus.json'),('group_map','groups.json')]:d[key+'_path']=str((base/fn).relative_to(root));d[key+'_sha256']=sha(base/fn)
        ds.append(d);small_counts[name]=(3,2,task);data[name]=(queries,corpus,task)
    plan={'schema':'SYNTHETIC_TEST_ONLY','cells':cells,'datasets':ds,'analysis':{'bootstrap_resamples':5000,'bootstrap_seed':2026111402,'bootstrap_seed_legacy':2026111403}}
    pp=root/'bridge_plan.json';dump(pp,plan);batch=root/'run_state'/'evaluation_batch01';entries=[];jobs=[]
    for d in ds:
        queries,corpus,task=data[d['dataset']]
        for i,c in enumerate(cells):
            entry={**c,'dataset':d['dataset'],'evaluation_id':d['dataset']+'__'+c['run_id'],'checkpoint_manifest_sha256':'0'*64,**{k:d[k] for k in ('queries_sha256','corpus_sha256','group_map_sha256')}}
            entries.append(entry);out=batch/'evaluations'/d['dataset']/c['run_id']/'attempt_01'
            predictions=[fake_prediction(q,corpus,list('abcd')[(i+j)%4:]+list('abcd')[:(i+j)%4],task=='menu') for j,q in enumerate(queries)]
            metrics={k:statistics.mean(row[k] for row in predictions) for k in metrics_from_ranks([1],1)}
            report={'n':3,'metrics':metrics,'input_hashes':{'queries':d['queries_sha256'],'corpus':d['corpus_sha256']},'model_manifest_sha256':'0'*64}
            if d['dataset']=='toolhop':report['equivalence_sensitivity_metrics']={k:statistics.mean(row['equivalence_sensitivity'][k] for row in predictions) for k in metrics}
            dump(out/'predictions.json',predictions);dump(out/'metrics.json',report)
            for name in REQUIRED-{'predictions.json','metrics.json','embedding_manifest.json'}:dump(out/name,{'status':'completed','SYNTHETIC_TEST_ONLY':True})
            for name in ('corpus_embeddings.npy','query_embeddings.npy'):np.save(out/name,np.zeros((3,2),dtype=np.float32),allow_pickle=False)
            dump(out/'embedding_manifest.json',{name:{'bytes':(out/name).stat().st_size,'sha256':sha(out/name)} for name in ('corpus_embeddings.npy','query_embeddings.npy','embedding_mapping.json')})
            rel=str(out.relative_to(batch));jobs.append({**entry,'status':'completed','attempts':[{'relative_path':rel}],'output_relative_path':rel,'evidence_hashes':{name:sha(out/name) for name in REQUIRED}})
    dump(batch/'evaluation_lock.json',{'plan_sha256':sha(pp),'evidence_stage':'posthoc_followup','code':sources(),'evaluations':entries,'datasets':[{'old_machine_absolute_path':'Z:/does-not-exist'}]})
    locksha=sha(batch/'evaluation_lock.json');dump(batch/'evaluation_lock.sha256.json',{'sha256':locksha});dump(batch/'evaluation_registry.json',{'lock_sha256':locksha,'evaluations':jobs})
    dump(batch/'evaluation_complete.json',{'evaluations':100,'models':20,'registry_sha256':sha(batch/'evaluation_registry.json'),'lock_sha256':locksha})
    return pp,batch,small_counts

class EndToEndTests(unittest.TestCase):
    def test_all100_rebuild_portability_missing_seed_and_tampering(self):
        with tempfile.TemporaryDirectory(prefix='bridge_SYNTHETIC_') as temp:
            root=pathlib.Path(temp)/'package';root.mkdir();pp,batch,counts=make_fixture(root)
            with patch.dict(bio.DATASETS,counts),contextlib.redirect_stdout(io.StringIO()):
                analyze(pp,batch,'run_state/analysis01');result=check(pp,'run_state/evaluation_batch01','run_state/analysis01')
                self.assertEqual(result['evaluations'],100);self.assertEqual(result['embedding_files_verified'],200)
                self.assertEqual(len(list((root/'run_state/analysis01/figures').glob('*.svg'))),3)
                # Relocate the entire return package. No old absolute paths exist.
                moved=root.with_name('returned_package');root.rename(moved);pp=moved/'bridge_plan.json';batch=moved/'run_state/evaluation_batch01'
                self.assertEqual(check(pp,batch,'run_state/analysis01')['evaluations'],100)
                analyze(pp,batch,'run_state/analysis02')
                for name in ('four_cells_all_tasks.csv','contrasts_all_tasks.csv','paired_seed_effects.csv','results_triggered_next_steps.json','figures/02_bfcl_live_interaction.svg'):
                    self.assertEqual((moved/'run_state/analysis01'/name).read_bytes(),(moved/'run_state/analysis02'/name).read_bytes())
                reg=read(batch/'evaluation_registry.json');reg['evaluations'].pop();dump(batch/'evaluation_registry.json',reg)
                with self.assertRaisesRegex(ValueError,'100 evaluations'):analyze(pp,batch,'run_state/incomplete')
                # Restore registry and exercise analysis artifact corruption.
                pp2,batch2,counts2=make_fixture(moved/'second');analyze(pp2,batch2,'run_state/analysis01')
                target=pp2.parent/'run_state/analysis01/figures/01_bfcl_live_four_cells.svg';target.write_text('corrupt',encoding='utf-8')
                with self.assertRaisesRegex(ValueError,'output manifest'):check(pp2,batch2,'run_state/analysis01')

if __name__=='__main__':unittest.main(verbosity=2)
