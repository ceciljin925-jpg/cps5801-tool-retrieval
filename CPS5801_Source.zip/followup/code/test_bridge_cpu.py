"""CPU tests. Pure mask/math tests always run; --require-torch forbids skipping Torch.

No model is downloaded/loaded. NumPy finite differences check both query and every
candidate-vector derivative, including gradients through reused positive vectors.
"""
import argparse
import json
from pathlib import Path
import unittest
import tempfile
from types import SimpleNamespace
import numpy as np
from mask_core import plan_microbatch, summarize, REASONS


def fixture(n=8):
    batch=[{'query_id':f'q{i}','positive':f'p{i}','epoch':0} for i in range(n)]
    negatives={f'q{i}':[f'n{i}_{j}' for j in range(4)] for i in range(n)}
    known={f'q{i}':[f'p{i}'] for i in range(n)}
    forbidden={q:list(v) for q,v in known.items()}
    ids={r['positive'] for r in batch}|{t for v in negatives.values() for t in v}
    sig={x:x for x in ids}
    return batch,negatives,known,forbidden,sig


def numpy_loss_grad(q,d,plan,tau):
    b=q.shape[0]
    gq=np.zeros_like(q);gd=np.zeros_like(d);total=0.
    for i in range(b):
        refs=[(i,k) for k in range(5)]
        refs += [(j,0) for j,ok in zip(plan['anchors'][i]['source_rows'],plan['anchors'][i]['eligible']) if ok]
        docs=np.array([d[j,k] for j,k in refs])
        logits=docs@q[i]/tau
        shifted=logits-logits.max();prob=np.exp(shifted);prob/=prob.sum()
        total += (-shifted[0]+np.log(np.exp(shifted).sum()))/b
        coeff=prob.copy();coeff[0]-=1;coeff/=b*tau
        gq[i]+=coeff@docs
        for c,(j,k) in zip(coeff,refs):gd[j,k]+=c*q[i]
    return total,gq,gd


class MaskTests(unittest.TestCase):
    def test_actual_recovery_io_partial_tail_and_future_checkpoint(self):
        import train_bridge as t
        parent=Path(__file__).resolve().parent.parent/'verification'/'cpu_test_tmp'
        parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='recovery_',dir=parent) as directory:
            out=Path(directory).resolve()
            self.assertIn(parent.resolve(),out.parents)
            config={'model_path':str(out/'not_loaded_model')}
            identity={'bridge':{'source_hashes':t.code_identity()},'runtime':{},'model_files':{}}
            t.atomic_json(out/'config.json',config);t.atomic_json(out/'identity.json',identity)
            line1=b'{"step":1,"loss":0.2,"grad_norm":0.3}\n'
            original=line1+b'{"step":2,"loss":0.1,"grad_norm":0.2}\n'+b'{"step":'
            (out/'loss.jsonl').write_bytes(original)
            future=out/'checkpoints'/'step_0002';future.mkdir(parents=True)
            (future/'marker.txt').write_text('engineering fixture')
            state={'step':1,'identity_sha256':t.sha_json(identity)}
            e=SimpleNamespace(runtime_record=lambda:{},directory_manifest=lambda p:{},
                              torch=SimpleNamespace(load=lambda *a,**kw:state))
            t.recover_durable_prefix(config,out,None,e)
            self.assertEqual((out/'loss.jsonl').read_bytes(),line1)
            backups=list((out/'interrupted_tails').glob('bridge_*'))
            self.assertEqual(len(backups),1)
            self.assertEqual((backups[0]/'complete_pre_resume_loss.jsonl').read_bytes(),original)
            self.assertTrue((backups[0]/'step_0002'/'marker.txt').exists())
            self.assertFalse(future.exists())

    def test_all_reasons_and_order(self):
        batch,neg,known,forbidden,sig=fixture()
        known['q0'].append('p1')
        forbidden['q0'].append('p2')
        sig['p3']=sig['p0']
        sig['p4']=sig['p2']
        sig['p5']=sig[neg['q0'][0]]
        sig['p7']=sig['p6']
        p=plan_microbatch(batch,neg,known,forbidden,sig)
        a=p['anchors'][0]
        self.assertEqual(a['decisions'],list(REASONS[:5])+['eligible',REASONS[-1]])
        self.assertEqual(a['source_rows'],list(range(1,8)))
        self.assertEqual(a['eligible_count'],1)
        self.assertEqual(sum(a['removed_by_reason'].values()),6)
        self.assertEqual(neg['q0'],[f'n0_{j}' for j in range(4)])

    def test_max7_and_no_cross_microbatch(self):
        x=fixture();p=plan_microbatch(*x)
        self.assertEqual([a['eligible_count'] for a in p['anchors']],[7]*8)
        self.assertEqual(p['potential_extras'],56)
        other=fixture(1);s=plan_microbatch(*other)
        self.assertEqual(s['potential_extras'],0)
        self.assertEqual(s['anchors'][0]['source_rows'],[])
        total,rows=summarize([p,p,p,p],False)
        self.assertEqual(total['exposures'],32)
        self.assertEqual(total['eligible_extras'],224)
        self.assertEqual(total['actual_added_extras'],0)

    def test_alias_of_any_known_positive_not_just_scheduled(self):
        b,n,k,f,s=fixture(2)
        k['q0'].append('unpresented');s['unpresented']='alias';s['p1']='alias'
        p=plan_microbatch(b,n,k,f,s)
        self.assertEqual(p['anchors'][0]['decisions'],['known_positive_input_alias'])

    def test_missing_signature_fails_closed(self):
        b,n,k,f,s=fixture();del s['p7']
        with self.assertRaises(KeyError):plan_microbatch(b,n,k,f,s)

    def test_finite_difference_all_embeddings(self):
        x=fixture(3);p=plan_microbatch(*x)
        rng=np.random.default_rng(7);q=rng.normal(size=(3,2))*.1;d=rng.normal(size=(3,5,2))*.1
        loss,gq,gd=numpy_loss_grad(q,d,p,.05)
        for array,gradient in [(q,gq),(d,gd)]:
            for ix in np.ndindex(array.shape):
                initial=array[ix];h=1e-6
                array[ix]=initial+h;upper=numpy_loss_grad(q,d,p,.05)[0]
                array[ix]=initial-h;lower=numpy_loss_grad(q,d,p,.05)[0]
                array[ix]=initial
                self.assertAlmostEqual((upper-lower)/(2*h),gradient[ix],places=7)
        self.assertTrue(np.isfinite(loss))

    def test_batch1_equals_original_numpy(self):
        x=fixture(1);p=plan_microbatch(*x);q=np.array([[.2,-.1]]);d=np.arange(10).reshape(1,5,2)*.03
        logits=(q[:,None,:]*d).sum(-1)/.05
        expected=np.log(np.exp(logits-logits.max()).sum())-(logits[0,0]-logits.max())
        self.assertEqual(numpy_loss_grad(q,d,p,.05)[0],expected)


def torch_checks():
    import torch
    from bridge_losses import append_extra_logits
    x=fixture(3);x[2]['q0'].append('p1');p=plan_microbatch(*x)
    rng=np.random.default_rng(3);a=rng.normal(size=(3,3))*.1;b=rng.normal(size=(3,5,3))*.1
    expected,gq,gd=numpy_loss_grad(a,b,p,.05)
    q=torch.tensor(a,dtype=torch.float64,requires_grad=True)
    d=torch.tensor(b,dtype=torch.float64,requires_grad=True)
    base=(q[:,None,:]*d).sum(-1)/.05
    logits=append_extra_logits(q,d,base,p,.05)
    loss=torch.nn.functional.cross_entropy(logits,torch.zeros(3,dtype=torch.long));loss.backward()
    np.testing.assert_allclose(loss.item(),expected,rtol=1e-13,atol=1e-13)
    np.testing.assert_allclose(q.grad.numpy(),gq,rtol=1e-12,atol=1e-12)
    np.testing.assert_allclose(d.grad.numpy(),gd,rtol=1e-12,atol=1e-12)
    b1=plan_microbatch(*fixture(1));one=base[:1]
    assert append_extra_logits(q[:1],d[:1],one,b1,.05) is one
    # Fully masked extras preserve old loss and gradient exactly on CPU float64.
    q=torch.tensor(a,dtype=torch.float64,requires_grad=True)
    d=torch.tensor(b,dtype=torch.float64,requires_grad=True)
    base=(q[:,None,:]*d).sum(-1)/.05
    masked=plan_microbatch(*fixture(3))
    for row in masked['anchors']:row['eligible']=[False]*2
    old=torch.nn.functional.cross_entropy(base,torch.zeros(3,dtype=torch.long))
    new=torch.nn.functional.cross_entropy(append_extra_logits(q,d,base,masked,.05),torch.zeros(3,dtype=torch.long))
    assert torch.equal(old,new)
    og=torch.autograd.grad(old,(q,d),retain_graph=True)
    ng=torch.autograd.grad(new,(q,d))
    assert all(torch.equal(u,v) for u,v in zip(og,ng))
    return {'status':'PASS','torch':torch.__version__,'checks':['targets_zero','autograd_vs_finite_difference','batch1_returns_original','fully_masked_loss_and_gradient_exact']}


def run_tests(require_torch=False):
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(MaskTests))
    report={'math_mask':{'status':'PASS' if result.wasSuccessful() else 'FAIL','tests_run':result.testsRun}}
    try:report['torch']=torch_checks()
    except ImportError as error:
        report['torch']={'status':'UNAVAILABLE','reason':str(error)}
    report['status']='PASS' if result.wasSuccessful() and (not require_torch or report['torch']['status']=='PASS') else 'FAIL'
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--require-torch',action='store_true');p.add_argument('--report',type=Path);a=p.parse_args()
    report=run_tests(a.require_torch)
    print(json.dumps(report,indent=2))
    if a.report:
        a.report.parent.mkdir(parents=True,exist_ok=True)
        a.report.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    raise SystemExit(0 if report['status']=='PASS' else 1)
