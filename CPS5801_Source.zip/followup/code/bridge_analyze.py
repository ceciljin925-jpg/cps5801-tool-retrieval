"""CPU-only rebuild of all 100 bridge evaluations and paired interaction estimates.

No model loading, network access, label changes, checkpoint selection, or new
training. The main interaction is (BM25-Random)_inbatch-(BM25-Random)_explicit.
All evidence is post hoc follow-up on previously inspected evaluation data.
NumPy PCG64 is the fixed bootstrap engine; never silently change engines.
"""
from __future__ import annotations
import argparse,collections,csv,gzip,json,math,pathlib,statistics,sys
from bridge_eval_io import *

BASE='explicit_1p4';IB='explicit_1p4_plus_inbatch_positives'
METHODS=[o+'__'+p for o in OBJECTIVES for p in POLICIES]
CONTRASTS={
 'explicit_B_minus_R':{BASE+'__B_ID':1,BASE+'__R_ID':-1},
 'inbatch_B_minus_R':{IB+'__B_ID':1,IB+'__R_ID':-1},
 'R_inbatch_minus_explicit':{IB+'__R_ID':1,BASE+'__R_ID':-1},
 'B_inbatch_minus_explicit':{IB+'__B_ID':1,BASE+'__B_ID':-1},
 'interaction':{IB+'__B_ID':1,IB+'__R_ID':-1,BASE+'__B_ID':-1,BASE+'__R_ID':1},
}
BOOTSTRAP_REPS=5000
BOOTSTRAP_SEED=2026111402
BOOTSTRAP_SEED_LEGACY=2026111403
METRICS=('recall@1','recall@3','recall@5','recall@10','mrr@10','mrr','hit@1','average_precision')

def metrics_from_ranks(ranks,n):
    require(ranks and len(set(ranks))==len(ranks),'Missing or duplicated positive ranks')
    require(all(isinstance(r,int) and not isinstance(r,bool) and 1<=r<=n for r in ranks),'Invalid rank')
    ranks=sorted(ranks);m={};p=len(ranks)
    for k in (1,3,5,10,20,50):
        found=sum(r<=k for r in ranks)
        m.update({f'recall@{k}':found/p,f'coverage@{k}':found/p,f'hit@{k}':float(found>0),f'complete@{k}':float(found==p)})
    m.update({'mrr@10':1/ranks[0] if ranks[0]<=10 else 0.,'mrr':1/ranks[0],
              'average_precision':sum(i/r for i,r in enumerate(ranks,1))/p,'mean_positive_rank':sum(ranks)/p})
    return m

def finite(value):return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def result_branches(primary,seed_intervals,margin=.005):
    r=primary['interaction'];lo,hi=r['group_ci_low'],r['group_ci_high'];effect=r['mean']
    direction='positive_conditional_interval' if lo>0 else 'negative_conditional_interval' if hi<0 else 'interval_includes_zero'
    relevance='interval_within_reference_margin' if -margin<lo and hi<margin else 'interval_exceeds_reference_margin' if lo>margin or hi<-margin else 'practical_size_uncertain'
    return {'evidence_stage':'posthoc_followup','interaction_direction':direction,'practical_reference_mrr_margin':margin,'practical_size_pattern':relevance,
      'margin_is_descriptive_not_equivalence_test':True,'all_branches_must_complete_report':True,'additional_training_authorized':False,'select_or_drop_seeds_authorized':False,
      'seed_signs':{str(r['seed']):('positive' if r['effect']>0 else 'negative' if r['effect']<0 else 'zero') for r in seed_intervals if r['dataset']=='bfcl_live_multiple'},
      'required_for_every_branch':['Report all four cells, five paired seeds, two negative-source gaps, two objective effects and the interaction.','Rebuild all five dataset tables and all three figures; keep failed attempts and unchanged data/model hashes.','Summarize scheduled in-batch eligibility and actual masks from all completed training runs; treat associations with errors as descriptive, not causal.','Use frozen grouping and saved predictions to inspect query types, description similarity and relevance ambiguity without relabeling or tuning.','Complete the separate blinded human relevance review; record disagreement and uncertainty instead of treating model inference as a human judgment.','Retain the same tested-model, catalogue, budget and loss-definition scope regardless of direction.'],
      'direction_specific_cpu_interpretation':{
       'positive_conditional_interval':'Describe a positive loss-by-negative-source interaction conditional on this design. Inspect both objective effects: a relative BM25 gain may arise from Random degradation; do not infer BM25 absolute superiority.',
       'negative_conditional_interval':'Describe a negative interaction conditional on this design. Inspect both simple contrasts and objective effects; do not declare all in-batch or hard negatives harmful.',
       'interval_includes_zero':'Report the uncertain conditional interaction, its magnitude and seed variation. Preserve the null/ambiguous result; do not seek extra seeds or alternative checkpoints to obtain a preferred sign.'}[direction],
      'stop_rule':'No score-triggered GPU extension, seed replacement, checkpoint selection, new threshold tuning, or semantic causal claim. Technical evidence failure is diagnosed and rerun only under the unchanged recipe with all attempts retained.'}

def rebuild_equivalence(row,q,equivalence_keys):
    saved=row['equivalence_sensitivity'];gold=sorted({equivalence_keys[p] for p in q['positives']})
    require(saved['gold_document_classes']==gold,'ToolHop exact-document gold classes changed')
    require(saved['candidate_document_classes']==len(set(equivalence_keys.values())),'ToolHop class population changed')
    require(len(saved['positive_class_ranks'])==len(gold),'ToolHop positive class rank count changed')
    result=metrics_from_ranks(saved['positive_class_ranks'],saved['candidate_document_classes'])
    for key,value in result.items():require(finite(saved[key]) and abs(saved[key]-value)<=1e-12,'ToolHop class sensitivity metric differs from ranks: '+key)
    return result

def rebuild_prediction(row,q,corpus_ids,task_type):
    candidates=q['candidate_ids'] if task_type=='menu' else corpus_ids
    candidate_set=candidates if isinstance(candidates,(set,frozenset)) else set(candidates)
    n=len(candidates);gold=q['positives']
    require(row['id']==q['id'],'Query ID mismatch')
    require(set(row['positives'])==set(gold) and len(row['positives'])==len(gold),'Frozen gold differs from prediction')
    require(row['candidate_count']==n,'Candidate count changed')
    require(row.get('query_text_sha256')==hashlib.sha256(q['query'].encode()).hexdigest(),'Query-text identity differs')
    pr=row['positive_ranks'];require(len(pr)==len(gold) and {r['id'] for r in pr}==set(gold),'Positive-rank IDs do not match frozen labels')
    require(all(finite(r['score']) for r in pr),'Invalid positive score')
    top=row['top50'];scores=row['scores']
    require(len(top)==min(50,n) and len(scores)==len(top) and len(set(top))==len(top) and set(top)<=candidate_set,'Invalid top ranking')
    require(all(finite(s) for s in scores),'Invalid ranked score')
    tie=q['candidate_tie_break_keys'] if task_type=='menu' else None
    for i in range(1,len(top)):
        require(scores[i-1]>=scores[i],'Scores are not descending')
        if scores[i-1]==scores[i]:require((tie[top[i-1]] if tie else top[i-1])<(tie[top[i]] if tie else top[i]),'Frozen tie order violated')
    for r in pr:
        rank=r['rank']
        if rank<=len(top):require(top[rank-1]==r['id'] and abs(scores[rank-1]-r['score'])<=1e-12,'Positive rank/score disagrees with top list')
        else:require(r['id'] not in top,'Positive outside top50 appears in top50')
    if task_type=='menu':require(row.get('ranking')==top and len(top)==n,'Native menu ranking must be complete')
    result=metrics_from_ranks([r['rank'] for r in pr],n)
    for key,value in result.items():require(finite(row[key]) and abs(row[key]-value)<=1e-12,'Saved per-query metric disagrees with ranks: '+key)
    return result

def paired_contrast(matrix,qids,seeds,coefficients,metric):
    require(seeds==list(SEEDS),'All five predeclared seeds must be retained')
    require(set(coefficients)<=set(matrix),'Missing method')
    per_seed={}
    for s in seeds:
        vals=[]
        for q in qids:
            terms=[]
            for method,c in coefficients.items():
                require(s in matrix[method] and q in matrix[method][s],'Incomplete paired method/seed/query')
                value=matrix[method][s][q][metric]
                require(finite(value) and 0<=value<=1,'Invalid bounded metric value')
                terms.append(c*value)
            vals.append(math.fsum(terms))
        per_seed[s]=vals
    means=[math.fsum(per_seed[s][i] for s in seeds)/len(seeds) for i in range(len(qids))]
    return per_seed,means

def group_bootstrap(values,group_ids,*,replicates=BOOTSTRAP_REPS,seed=BOOTSTRAP_SEED,fixture=False):
    require(len(values)==len(group_ids)>0,'Group alignment mismatch')
    require(replicates==5000 or fixture,'Scientific bootstrap must use 5000 replicates')
    import numpy as np
    buckets={}
    for g,v in zip(group_ids,values):
        require(finite(v),'Invalid contrast value');buckets.setdefault(g,[]).append(v)
    sums=np.asarray([math.fsum(v) for v in buckets.values()],dtype=np.float64)
    sizes=np.asarray([len(v) for v in buckets.values()],dtype=np.int64)
    rng=np.random.Generator(np.random.PCG64(seed));estimates=[];denominators=[]
    for offset in range(0,replicates,128):
        ix=rng.integers(0,len(sums),size=(min(128,replicates-offset),len(sums)),dtype=np.int64)
        n=sizes[ix].sum(axis=1,dtype=np.int64)
        estimates.extend((sums[ix].sum(axis=1,dtype=np.float64)/n).tolist());denominators.extend(n.tolist())
    ci=np.quantile(np.asarray(estimates),[.025,.975],method='linear').tolist() if len(sums)>1 else None
    return {'engine':'numpy.PCG64','numpy_version':np.__version__,'seed':seed,'replicates':replicates,
            'unit':'frozen_dependency_proxy_group','n_groups':len(sums),'n_queries':len(values),
            'group_sizes':sizes.tolist(),'group_ids':list(buckets),'pointwise95':ci,
            'estimator':'query_weighted mean after uniform group draws with replacement',
            'quantile':'linear interpolation','estimates':estimates,'replicate_n_queries':denominators,
            'conditional_on':'These fitted models, frozen labels and grouping; excludes complete training, selection, provenance and label uncertainty.',
            'warning':'Not a simultaneous interval across all reported contrasts; no p-values or general hard-negative claim.'}

def csvwrite(path,rows,fields=None):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    if not rows:return
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=fields or list(rows[0]));wr.writeheader();wr.writerows(rows)

def resolve_attempt(batch,job):
    rel=job.get('output_relative_path') or job['attempts'][-1]['relative_path']
    out=(batch/rel).resolve(strict=True);require(batch in out.parents,'Evaluation attempt escaped batch directory')
    return out

def analyze(plan_path,batch,output):
    root,plan,data=validate_plan(plan_path);batch=pathlib.Path(batch).resolve(strict=True)
    settings=plan.get('analysis',{})
    require(settings.get('bootstrap_resamples',5000)==5000 and settings.get('bootstrap_seed',BOOTSTRAP_SEED)==BOOTSTRAP_SEED and settings.get('bootstrap_seed_legacy',BOOTSTRAP_SEED_LEGACY)==BOOTSTRAP_SEED_LEGACY,'Analysis bootstrap recipe differs from frozen bridge implementation')
    out=safe_output(root,output);require(not out.exists() or not any(out.iterdir()),'Use a new analysis directory; earlier analyses are evidence')
    lockpath=batch/'evaluation_lock.json';lock=read(lockpath);regpath=batch/'evaluation_registry.json';reg=read(regpath)
    require(reg['lock_sha256']==sha(lockpath),'Evaluation registry lock identity changed')
    require(lock['plan_sha256']==sha(plan_path),'Analysis plan differs from evaluation plan')
    require(lock.get('evidence_stage')=='posthoc_followup','Incorrect evidence-stage claim')
    for filename in ('bridge_analyze.py','bridge_eval_io.py','bridge_figures.py'):
        require(lock['code'][filename]==sha(pathlib.Path(__file__).parent/filename),'Analysis source differs from pre-scoring lock: '+filename)
    expected={(d['dataset'],c['run_id']) for d in data for c in plan['cells']}
    jobs=reg['evaluations'];require(len(jobs)==100 and {(j['dataset'],j['run_id']) for j in jobs}==expected,'All 100 evaluations required; cannot omit a task or seed')
    require(all(j['status']=='completed' for j in jobs),'An evaluation is missing/failed; do not compute complete-study conclusions')
    cm={c['run_id']:c for c in plan['cells']};source_files={str(plan_path):sha(plan_path),str(lockpath):sha(lockpath),str(regpath):sha(regpath)}
    out.mkdir(parents=True,exist_ok=True);metrics_rows=[];cell_rows=[];contrast_rows=[];paired_rows=[];conditional=[];seed_intervals=[];sensitivity_rows=[]
    identity_checks=[]
    for d in data:
        dataset=d['dataset'];qids=[q['id'] for q in d['_queries']];querymap={q['id']:q for q in d['_queries']}
        cids=frozenset(c['id'] for c in d['_corpus']);groups=d['_groups'];matrix={m:{} for m in METHODS}
        equivalence_keys={c['id']:c.get('document_equivalence_key',hashlib.sha256(c['text'].encode()).hexdigest()) for c in d['_corpus']} if dataset=='toolhop' else None
        for key in ('queries_path','corpus_path','group_map_path'):source_files[d[key]]=sha(d[key])
        qcsv=out/'per_query_recomputed'/f'{dataset}.csv.gz';qcsv.parent.mkdir(parents=True,exist_ok=True)
        with gzip.open(qcsv,'wt',encoding='utf-8',newline='') as qstream:
            writer=csv.DictWriter(qstream,fieldnames=['dataset','run_id','objective','policy','seed','query_id','group_id',*METRICS]);writer.writeheader()
            for job in [j for j in jobs if j['dataset']==dataset]:
                cell=cm[job['run_id']];require(cell_key(job)==cell_key(cell),'Job cell identity changed')
                frozen=next(e for e in lock['evaluations'] if e['evaluation_id']==job['evaluation_id'])
                require(all(job[k]==frozen[k] for k in ('run_id','dataset','objective','policy','seed','queries_sha256','corpus_sha256','group_map_sha256','checkpoint_manifest_sha256')),'Job differs from frozen evaluation entry')
                attempt=resolve_attempt(batch,job)
                for name,digest in job['evidence_hashes'].items():require(sha(attempt/name)==digest,'Evaluation evidence identity changed: '+name)
                pp=attempt/'predictions.json';mp=attempt/'metrics.json';pred=read(pp);report=read(mp)
                source_files[str(pp)]=sha(pp);source_files[str(mp)]=sha(mp)
                require(len(pred)==len(qids) and len({r['id'] for r in pred})==len(qids) and {r['id'] for r in pred}==set(qids),'Missing/duplicate/extra query predictions')
                require(report['n']==len(qids) and report['input_hashes']=={'queries':d['queries_sha256'],'corpus':d['corpus_sha256']},'Evaluation input identity mismatch')
                require(report['model_manifest_sha256']==job['checkpoint_manifest_sha256'],'Model identity differs from lock')
                method=method_key(cell);seed=cell['seed'];require(seed not in matrix[method],'Duplicate cell')
                recalculated={};sensitivity=[]
                for row in pred:
                    q=querymap[row['id']];m=rebuild_prediction(row,q,cids,d['task_type']);recalculated[q['id']]=m
                    if equivalence_keys is not None:sensitivity.append(rebuild_equivalence(row,q,equivalence_keys))
                    if 'group_id' in row:require(row['group_id']==groups[q['id']],'Prediction group changed')
                    writer.writerow({'dataset':dataset,'run_id':cell['run_id'],'objective':cell['objective'],'policy':cell['policy'],'seed':seed,'query_id':q['id'],'group_id':groups[q['id']],**{k:m[k] for k in METRICS}})
                matrix[method][seed]=recalculated
                means={k:math.fsum(recalculated[q][k] for q in qids)/len(qids) for k in metrics_from_ranks([1],1)}
                discrepancies={k:abs(means[k]-report['metrics'][k]) for k in means}
                require(all(v<=(1e-10 if k=='mean_positive_rank' else 1e-12) for k,v in discrepancies.items()),'Aggregate metrics disagree with saved positive ranks')
                if sensitivity:
                    sm={k:math.fsum(r[k] for r in sensitivity)/len(sensitivity) for k in sensitivity[0]}
                    require(all(abs(v-report['equivalence_sensitivity_metrics'][k])<=(1e-10 if k=='mean_positive_rank' else 1e-12) for k,v in sm.items()),'ToolHop sensitivity aggregate differs from ranks')
                    sensitivity_rows.append({'dataset':dataset,'run_id':cell['run_id'],'objective':cell['objective'],'policy':cell['policy'],'seed':seed,'n_queries':len(qids),**sm})
                metrics_rows.append({'dataset':dataset,'run_id':cell['run_id'],'objective':cell['objective'],'policy':cell['policy'],'seed':seed,'n_queries':len(qids),**means})
                identity_checks.append({'dataset':dataset,'run_id':cell['run_id'],'n_queries':len(pred),'max_abs_metric_discrepancy':max(discrepancies.values()),'predictions_sha256':sha(pp),'metrics_sha256':sha(mp)})
        for method in METHODS:
            require(set(matrix[method])==set(SEEDS),'Missing seed in method')
            for metric in METRICS:
                vals=[math.fsum(matrix[method][s][q][metric] for q in qids)/len(qids) for s in SEEDS]
                cell_rows.append({'dataset':dataset,'method':method,'metric':metric,'mean':statistics.mean(vals),'seed_sample_sd':statistics.stdev(vals),'n_seeds':5,'n_queries':len(qids),'seed_min':min(vals),'seed_max':max(vals),'per_seed_json':json.dumps(dict(zip(SEEDS,vals)))})
        metric='recall@5' if dataset in ('legacy_observed_test','toolhop') else 'mrr'
        for name,coef in CONTRASTS.items():
            ps,means=paired_contrast(matrix,qids,list(SEEDS),coef,metric)
            seedvals=[math.fsum(ps[s])/len(qids) for s in SEEDS]
            for s,value in zip(SEEDS,seedvals):paired_rows.append({'dataset':dataset,'metric':metric,'contrast':name,'seed':s,'effect':value})
            point=math.fsum(means)/len(means)
            row={'dataset':dataset,'metric':metric,'contrast':name,'mean':point,'seed_sample_sd':statistics.stdev(seedvals),'positive_seeds':sum(v>0 for v in seedvals),'negative_seeds':sum(v<0 for v in seedvals),'zero_seeds':sum(v==0 for v in seedvals),'seed_min':min(seedvals),'seed_max':max(seedvals),'n_queries':len(qids),'n_groups':len(set(groups.values())),'group_ci_low':None,'group_ci_high':None,'evidence_stage':'posthoc_followup','role':'primary_followup_interaction' if dataset=='bfcl_live_multiple' and name=='interaction' else 'secondary_or_descriptive'}
            if dataset in ('bfcl_live_multiple','legacy_observed_test'):
                seed=BOOTSTRAP_SEED if dataset=='bfcl_live_multiple' else BOOTSTRAP_SEED_LEGACY
                boot=group_bootstrap(means,[groups[q] for q in qids],seed=seed)
                row['group_ci_low'],row['group_ci_high']=boot['pointwise95']
                dest=out/'bootstrap'/f'{dataset}__{name}.json';dump(dest,boot)
                if name=='interaction':
                    for s in SEEDS:
                        sb=group_bootstrap(ps[s],[groups[q] for q in qids],seed=seed)
                        dump(out/'bootstrap'/f'{dataset}__interaction__seed{s}.json',sb)
                        seed_intervals.append({'dataset':dataset,'metric':metric,'seed':s,'effect':math.fsum(ps[s])/len(qids),'group_ci_low':sb['pointwise95'][0],'group_ci_high':sb['pointwise95'][1],'n_groups':sb['n_groups'],'replicates':sb['replicates'],'conditional_on':'fixed single fitted seed, frozen labels/groups'})
                conditional.append({'dataset':dataset,'metric':metric,'contrast':name,'coefficients':coef,**row,'bootstrap_relative_path':str(dest.relative_to(out)).replace('\\','/')})
            contrast_rows.append(row)
        perquery=out/'query_contrasts'/f'{dataset}.csv.gz';perquery.parent.mkdir(parents=True,exist_ok=True)
        with gzip.open(perquery,'wt',encoding='utf-8',newline='') as f:
            wr=csv.writer(f);wr.writerow(['query_id','group_id','metric',*CONTRASTS])
            values={k:paired_contrast(matrix,qids,list(SEEDS),v,metric)[1] for k,v in CONTRASTS.items()}
            for i,q in enumerate(qids):wr.writerow([q,groups[q],metric,*[values[k][i] for k in CONTRASTS]])
    csvwrite(out/'evaluations_100_recomputed.csv',metrics_rows)
    csvwrite(out/'four_cells_all_tasks.csv',cell_rows)
    csvwrite(out/'paired_seed_effects.csv',paired_rows)
    csvwrite(out/'contrasts_all_tasks.csv',contrast_rows)
    csvwrite(out/'interaction_seed_conditional_intervals.csv',seed_intervals)
    csvwrite(out/'toolhop_exact_document_sensitivity.csv',sensitivity_rows)
    dump(out/'conditional_intervals.json',conditional)
    primary={r['contrast']:r for r in contrast_rows if r['dataset']=='bfcl_live_multiple'}
    dump(out/'results_triggered_next_steps.json',result_branches(primary,seed_intervals,plan.get('analysis',{}).get('practical_reference_margin_mrr',.005)))
    from bridge_figures import make_figures
    make_figures(out,cell_rows,contrast_rows,seed_intervals)
    descriptive={'explicit_B_minus_R':primary['explicit_B_minus_R']['mean'],'inbatch_B_minus_R':primary['inbatch_B_minus_R']['mean'],'interaction':primary['interaction']['mean'],
       'ordering_reversal_in_point_means':primary['explicit_B_minus_R']['mean']*primary['inbatch_B_minus_R']['mean']<0,
       'no_automatic_additional_training':True,'interpretation':'Positive interaction means the BM25-minus-random gap moved toward BM25 under the added in-batch-positive objective. It need not mean BM25 itself improved or became better than Random. Report both simple contrasts and both objective effects. It does not identify a duplicate-input causal mechanism.'}
    dump(out/'summary.json',{'status':'COMPLETE_REBUILT','evidence_stage':'posthoc_followup','evaluations':100,'trained_or_reused_conditions':20,'datasets':5,'expected_seeds':list(SEEDS),'max_abs_aggregate_discrepancy':max(r['max_abs_metric_discrepancy'] for r in identity_checks),'primary':primary,'descriptive_pattern':descriptive,'limits':['All evaluation datasets were previously inspected; no unseen-test confirmation claim.','Bootstrap intervals condition on these fitted models and frozen labels/groups; seed SD is reported separately.','Five contrasts are reported pointwise; no simultaneous confidence or p-value claim.','In-batch-positive addition changes the loss denominator; no semantic-label or duplicate-causality conclusion.','No model, policy, seed, dataset or checkpoint is dropped or selected after observing scores.','Metrics reconstructed from saved positive ranks plus top rankings; full neural training and every full-catalogue score are not independently rerun by this program.']})
    dump(out/'metric_reconstruction_checks.json',identity_checks)
    dump(out/'source_manifest.json',{'files':source_files,'analysis_code':{p.name:sha(p) for p in (pathlib.Path(__file__).resolve(),pathlib.Path(__file__).with_name('bridge_eval_io.py'),pathlib.Path(__file__).with_name('bridge_figures.py'))}})
    dump(out/'output_manifest.json',directory_manifest(out))
    dump(out/'analysis_complete.json',{'completed_at':now(),'evaluations':100,'all_five_seeds_retained':True,'summary_sha256':sha(out/'summary.json'),'source_manifest_sha256':sha(out/'source_manifest.json'),'output_manifest_sha256':sha(out/'output_manifest.json')})
    print(json.dumps({'status':'COMPLETE_REBUILT','evaluations':100,'output':str(out)},ensure_ascii=True))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',required=True,type=pathlib.Path);p.add_argument('--evaluation-root',required=True,type=pathlib.Path);p.add_argument('--output',required=True)
    a=p.parse_args();a.plan=a.plan.resolve(strict=True)
    if not a.evaluation_root.is_absolute():a.evaluation_root=(a.plan.parent/a.evaluation_root).resolve(strict=True)
    analyze(a.plan,a.evaluation_root,a.output)
if __name__=='__main__':main()
