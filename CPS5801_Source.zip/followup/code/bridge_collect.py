"""Zip64 return artifact; includes all final weights, frozen inputs and predictions.

Optimizer recovery states and smoke-test weights stay on the GPU computer and
are listed with hashes. No original result file is moved, removed or modified.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib, time, zipfile
from bridge_eval_io import read,dump,sha,sha_json,require,now,validate_plan,validate_models,directory_manifest

def add_source(files,arc,path):
    arc=pathlib.PurePosixPath(arc)
    require(not arc.is_absolute() and '..' not in arc.parts,'Unsafe archive path')
    key=str(arc);require(key not in files,'Duplicate return path: '+key)
    path=pathlib.Path(path).resolve(strict=True);require(path.is_file(),'Not a regular file')
    files[key]=path

def collect(root,output,partial=False):
    root=pathlib.Path(root).resolve(strict=True);output=pathlib.Path(output).resolve()
    require(root not in output.parents and output!=root,'Return archive must be outside the package tree')
    require(not output.exists() and not output.with_suffix(output.suffix+'.partial').exists() and not output.with_suffix(output.suffix+'.sha256.txt').exists(),'Do not overwrite a return archive or checksum')
    state=root/'run_state';complete=state/'STUDY_COMPLETE.json'
    if (state/'execution_lock.json').exists():
        lock=read(state/'execution_lock.json')
        for key in ('gpu_work_root','model_path'):
            protected=pathlib.Path(lock[key]).resolve()
            require(output!=protected and protected not in output.parents,'Return output must not write inside old work/model tree')
    if not partial:
        require(complete.exists(),'Study incomplete; only --partial may package incomplete evidence')
        status=read(complete);require(status['scientific_cells']==20 and status['evaluations']==100,'Wrong study count')
        findings=state/'SESSION_FINDINGS.txt'
        require(findings.is_file() and findings.stat().st_size>0,'Complete the bounded CPU diagnosis in 03 and write run_state/SESSION_FINDINGS.txt before full collection')
        require(status['models_registry_sha256']==sha(state/'models_ready.json'),'Model registry changed since completion')
        require(status['analysis_complete_sha256']==sha(state/'analysis_batch01/analysis_complete.json'),'Analysis completion identity changed')
        require(status['evaluation_complete_sha256']==sha(state/'evaluation_batch01/evaluation_complete.json'),'Evaluation completion identity changed')
        from bridge_check_results import check
        check(root/'bridge_plan.json',state/'evaluation_batch01',state/'analysis_batch01')
        _,plan,_=validate_plan(root/'bridge_plan.json')
        models=validate_models(root,plan,state/'models_ready.json')
    elif (state/'models_ready.json').exists():models=read(state/'models_ready.json')['models']
    elif (state/'training_queue_progress.json').exists():models=read(state/'training_queue_progress.json')['ready_models']
    else:models=[]
    files={};retained=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(root);parts=rel.parts
        require(root in p.resolve().parents,'Unexpected external link inside package: '+str(p))
        if '__pycache__' in parts or p.suffix=='.pyc' or p.name=='runner_active.lock':continue
        # Include every prediction, embedding, log and code/input file. Checkpoint
        # copies are added once per final model below; engineering states stay put.
        if p.suffix in ('.pt','.safetensors') or p.name.endswith('.tmp'):
            retained.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'recovery_or_engineering_state; final weights separately exported'})
            continue
        add_source(files,str(rel).replace('\\','/'),p)
    portable=[];unexported=[]
    for m in models:
        try:
            cp=pathlib.Path(m['checkpoint_path']);cp=cp if cp.is_absolute() else root/cp
            manifest=directory_manifest(cp)
            require(sha_json(manifest)==m['checkpoint_manifest_sha256'],'Returned final checkpoint differs from locked model')
            target='returned_models/'+m['run_id']
            row={k:v for k,v in {**m,'checkpoint_path':target}.items() if k!='checkpoint_manifest'}
            for key in ('checkpoint_manifest_path','provenance_path'):
                p=pathlib.Path(row[key]);p=(p if p.is_absolute() else root/p).resolve(strict=True)
                require(root in p.parents,'Model evidence escaped return package')
                row[key]=str(p.relative_to(root)).replace('\\','/')
            for rel in manifest:add_source(files,target+'/'+rel,cp/rel)
            portable.append(row)
        except (OSError,ValueError,KeyError) as exc:
            if not partial:raise
            unexported.append({'run_id':m.get('run_id'),'error':repr(exc),'recorded_model':m,'status':'NOT_EXPORTED'})
    reuse_export=[];reuse_unexported=[]
    if (state/'reuse_decision.json').exists() and read(state/'reuse_decision.json').get('reused_controls'):
        exp=read(root/'reuse_expectations.json');old=pathlib.Path(read(state/'execution_lock.json')['gpu_work_root']).resolve(strict=True)
        records=list(exp['global_evidence'])
        for control in exp['controls']:
            records.extend(control['training_evidence']['files'].values())
            records.append(control['cross_stage_evidence']['per_update_file'])
        for record in records:
            try:
                rel=record['gpu_work_relative_path'];p=(old/rel).resolve(strict=True)
                require(old in p.parents and p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],'Old reused evidence changed')
                target='returned_reuse_evidence/'+rel
                if target not in files:add_source(files,target,p)
                reuse_export.append({'returned_path':target,**record})
            except (OSError,ValueError,KeyError) as exc:
                if not partial:raise
                reuse_unexported.append({'record':record,'error':repr(exc)})
    base_record=None
    if (state/'execution_lock.json').exists():
        base=pathlib.Path(read(state/'execution_lock.json')['model_path']);expected=read(root/'pretrained_model_identity.json')['expected_files']
        good=all((base/n).is_file() and sha(base/n)==v['sha256'] for n,v in expected.items())
        require(good or partial,'Frozen base model unavailable or changed')
        if good:
            for rel in expected:add_source(files,'returned_pretrained/e5-small-v2/'+rel,base/rel)
            base_record={'path':'returned_pretrained/e5-small-v2','files':expected}
        else:base_record={'status':'MISSING_OR_CHANGED','path_on_gpu':str(base),'partial_only':True}
    generated={
      'portable_models_ready.json':{'models':portable,'interpretation':'same weights as original registry; paths relocated for reading; original registry/locks retained unchanged'},
      'retained_on_gpu_manifest.json':{'files':retained,'delete_authorized':False},
      'returned_reuse_evidence_manifest.json':{'files':reuse_export,'unexported':reuse_unexported,
           'note':'Original mixed-policy negative JSON is not duplicated; bundled per-policy ordered lists and onsite canonical equality audit preserve the used inputs.'},
      'RETURN_STATUS.json':{'status':'PARTIAL_DO_NOT_TREAT_AS_COMPLETE' if partial else 'COMPLETE','created_at':now(),'final_weights_included':len(portable),'unexported_models':unexported,
          'expected_models':20,'expected_evaluations':100,'base_model':base_record,'source_root':str(root),
          'evidence_stage':'posthoc_followup','zero_human_labels_generated':True,
          'rebuild_command':'python code/bridge_analyze.py --plan bridge_plan.json --evaluation-root run_state/evaluation_batch01 --output run_state/analysis_return_rebuild01',
          'portable_model_validation_command':'python code/bridge_evaluate.py --plan bridge_plan.json --models portable_models_ready.json --output run_state/not_executed --validate-only'}
    }
    require(not set(files).intersection(set(generated)|{'RETURN_MANIFEST.json'}),'Reserved return filename already exists in source package; preserve it and use original execution package')
    raw={name:(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8') for name,value in generated.items()}
    identities={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
    identities.update({name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in raw.items()})
    manifest={'schema':'bridge_return_manifest_v1','files':identities,'archive_entry_count_including_manifest':len(identities)+1}
    raw['RETURN_MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    output.parent.mkdir(parents=True,exist_ok=True);temp=output.with_suffix(output.suffix+'.partial')
    with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for name,p in files.items():z.write(p,name)
        for name,data in raw.items():z.writestr(name,data)
    with zipfile.ZipFile(temp) as z:
        require(z.testzip() is None,'Return ZIP CRC failed')
        require(len(z.namelist())==len(set(z.namelist())),'Duplicate return archive entries')
        require(set(z.namelist())==set(identities)|{'RETURN_MANIFEST.json'},'Return archive entries differ')
        for name,rec in identities.items():
            with z.open(name) as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
            require(z.getinfo(name).file_size==rec['bytes'] and digest==rec['sha256'],'Return bytes differ: '+name)
    temp.replace(output);digest=sha(output)
    output.with_suffix(output.suffix+'.sha256.txt').write_text(digest+'  '+output.name+'\n',encoding='utf-8')
    return {'status':generated['RETURN_STATUS.json']['status'],'archive':str(output),'bytes':output.stat().st_size,'sha256':digest,
            'final_weights':len(portable),'files':len(identities)+1,'crc_and_sha_checks':'PASS'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=pathlib.Path);p.add_argument('--partial',action='store_true');a=p.parse_args()
    print(json.dumps(collect(pathlib.Path(__file__).resolve().parents[1],a.output,a.partial),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
