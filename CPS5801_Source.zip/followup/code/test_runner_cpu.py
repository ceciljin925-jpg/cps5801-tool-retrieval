"""CPU-only acceptance guards and complete real-input mask checks; no model runs."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import bridge_runner as runner
import train_bridge as trainer
from mask_core import plan_microbatch,summarize
from verify_mask_artifacts import validate_mask_artifacts

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'verification'/'cpu_test_tmp'


class RunnerTests(unittest.TestCase):
    def setUp(self):
        TMP.mkdir(parents=True,exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(prefix='runner_',dir=TMP)
        self.out=Path(self.tmp.name).resolve()
        self.assertIn(TMP.resolve(),self.out.parents)
    def tearDown(self):self.tmp.cleanup()

    def completed_fixture(self):
        out=self.out/'attempt';out.mkdir()
        conf={'run_id':'ENGINEERING_FAKE_CELL','objective':'explicit_1p4'}
        identity={'bridge':{'source_hashes':trainer.code_identity(),**conf}}
        checkpoint=out/'checkpoints/step_0625';checkpoint.mkdir(parents=True)
        (checkpoint/'model.safetensors').write_bytes(b'ENGINEERING FIXTURE NOT MODEL WEIGHTS')
        runner.dump(checkpoint/'checkpoint_provenance.json',{'identity_sha256':trainer.sha_json(identity),'run_id':conf['run_id'],'step':625})
        runner.dump(out/'checkpoint_manifest.json',{'step_0625':runner.directory_manifest(checkpoint)})
        runner.dump(out/'config.json',conf);runner.dump(out/'identity.json',identity)
        runner.dump(out/'status.json',{'status':'completed'})
        runner.dump(out/'training.json',{'steps':625,'exposures':20000,'identity_sha256':trainer.sha_json(identity)})
        rows=[{'step':i,'loss':.2,'grad_norm':.1} for i in range(1,626)]
        (out/'loss.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
        return out,conf,rows

    def test_complete_trace_guard_and_nan(self):
        out,conf,rows=self.completed_fixture()
        with patch('verify_mask_artifacts.validate_mask_artifacts',return_value={'status':'PASS'}) as mask:
            self.assertTrue(runner.completed_attempt(out,conf));mask.assert_called_once()
            (out/'loss.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows[:-1]))
            with self.assertRaisesRegex(ValueError,'625 contiguous'):runner.completed_attempt(out,conf)
            rows[100]['loss']=float('nan')
            (out/'loss.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
            with self.assertRaisesRegex(ValueError,'Nonfinite'):runner.completed_attempt(out,conf)

    def test_checkpoint_provenance_must_bind_identity(self):
        out,conf,rows=self.completed_fixture()
        checkpoint=out/'checkpoints/step_0625'
        cp=runner.read(checkpoint/'checkpoint_provenance.json');cp['identity_sha256']='0'*64
        runner.dump(checkpoint/'checkpoint_provenance.json',cp)
        runner.dump(out/'checkpoint_manifest.json',{'step_0625':runner.directory_manifest(checkpoint)})
        with self.assertRaisesRegex(ValueError,'provenance'):runner.completed_attempt(out,conf)

    def test_retry_guard_spans_all_attempts(self):
        state=self.out/'run_state';name=runner.read(ROOT/'bridge_plan.json')['cells'][0]['run_id']
        runner.dump(state/'configs'/(name+'.json'),{})
        parent=state/'train_runs'/name
        runner.dump(parent/'attempt_01/retry_record_01.json',{'scope':'ENGINEERING'})
        runner.dump(parent/'attempt_02/status.json',{'status':'failed','error':'engineering interruption'})
        note=self.out/'note.txt';note.write_text('engineering only')
        args=SimpleNamespace(retry_technical=True,failure_note=str(note))
        with patch.object(runner,'STATE',state),patch.object(runner,'run_child') as child:
            with self.assertRaisesRegex(ValueError,'Only one recovery'):runner.train_all(args,{'reused_controls':[]})
            child.assert_not_called()

    def test_retry_flag_required(self):
        state=self.out/'run_state';name=runner.read(ROOT/'bridge_plan.json')['cells'][0]['run_id']
        runner.dump(state/'configs'/(name+'.json'),{})
        runner.dump(state/'train_runs'/name/'attempt_01/status.json',{'status':'failed'})
        with patch.object(runner,'STATE',state),patch.object(runner,'run_child') as child:
            with self.assertRaisesRegex(ValueError,'retry-technical'):
                runner.train_all(SimpleNamespace(retry_technical=False,failure_note=None),{'reused_controls':[]})
            child.assert_not_called()

    def test_formal_config_hash_normalization(self):
        conf={field:str((ROOT/'inputs/training'/'train.json').resolve()) for field in trainer.DATA_FIELDS}
        conf.update(model_path=str((ROOT/'not_loaded_model').resolve()),output_root=str((ROOT/'run_state/train_runs').resolve()))
        conf['input_hashes']={conf['train_path']:'0'*64}
        path=self.out/'config.json';runner.dump(path,conf)
        self.assertEqual(runner.sha_json(runner.read(path)),trainer.sha_json(trainer.load_config(path)))
        self.assertTrue(runner.same_runtime({'created_at':'a','executable':'x','torch':'v'}, {'created_at':'b','executable':'y','torch':'v'}))
        self.assertFalse(runner.same_runtime({'torch':'v1'},{'torch':'v2'}))

    def test_all_ten_frozen_mask_cases_and_both_objective_artifacts(self):
        p=ROOT/'inputs/training';frozen=trainer.read(ROOT/'verification/static_mask_expectations.json')
        known={x['id']:x['positives'] for x in trainer.read(p/'train.json')}
        forbidden=trainer.read(p/'forbidden_ids.json');sig=trainer.read(p/'e5_input_signatures.json')
        for expected in frozen['records']:
            seed,policy=expected['seed'],expected['policy']
            schedule=trainer.read(p/f'schedule_seed{seed}.json')[:20000]
            neg=trainer.read(p/f'{policy}_seed{seed}.json');plans=[]
            for offset in range(0,20000,8):
                plans.append({'step':offset//32+1,'microbatch_in_update':offset%32//8,
                              'plan':plan_microbatch(schedule[offset:offset+8],neg,known,forbidden,sig)})
            raw=''.join(json.dumps(z,ensure_ascii=False,separators=(',',':'))+'\n' for z in plans).encode()
            self.assertEqual(hashlib.sha256(raw).hexdigest(),expected['mask_plan_sha256'])
            total,_=summarize([z['plan'] for z in plans],True)
            self.assertEqual(total['eligible_extras'],expected['eligible_extras'])
            if seed!=42:continue
            for objective in trainer.OBJECTIVES:
                out=self.out/(policy+'_'+objective);out.mkdir()
                conf={field:str(p/(field.removesuffix('_path')+'.json')) for field in trainer.DATA_FIELDS}
                conf.update(train_path=str(p/'train.json'),corpus_path=str(p/'corpus.json'),
                    train_tool_ids_path=str(p/'train_tool_ids.json'),forbidden_path=str(p/'forbidden_ids.json'),
                    input_signatures_path=str(p/'e5_input_signatures.json'),schedule_path=str(p/f'schedule_seed{seed}.json'),
                    negatives_path=str(p/f'{policy}_seed{seed}.json'),objective=objective,seed=seed,policy=policy)
                enabled=objective==trainer.OBJECTIVES[1]
                (out/'mask_plan_microbatches.jsonl').write_bytes(raw)
                (out/'mask_microbatches.jsonl').write_text(''.join(json.dumps({**z,'objective_enabled':enabled})+'\n' for z in plans))
                trainer.atomic_json(out/'identity.json',{'bridge':{'mask_plan_sha256':expected['mask_plan_sha256']}})
                total,queries=summarize([z['plan'] for z in plans],enabled)
                total.update(objective=objective,logged_updates=625,planned_updates=625,
                    mask_plan_sha256=expected['mask_plan_sha256'],
                    coverage_basis='durable contiguous loss rows; exact625 only when final status completed',status='completed')
                trainer.atomic_json(out/'mask_summary.json',total);trainer.atomic_json(out/'mask_query_summary.json',queries)
                result=validate_mask_artifacts(out,conf)
                self.assertEqual(result['actual_added_extras'],expected['eligible_extras'] if enabled else 0)
                total['actual_added_extras']+=1;trainer.atomic_json(out/'mask_summary.json',total)
                with self.assertRaisesRegex(ValueError,'summary mismatch'):validate_mask_artifacts(out,conf)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args()
    r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RunnerTests))
    report={'scope':'CPU engineering and real frozen-input masks; no GPU or model execution',
            'status':'PASS' if r.wasSuccessful() else 'FAIL','tests_run':r.testsRun,
            'mask_cases_recomputed':10,'full_objective_artifact_cases':4,
            'failures':len(r.failures),'errors':len(r.errors)}
    print(json.dumps(report,indent=2))
    if a.report:a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(0 if r.wasSuccessful() else 1)
