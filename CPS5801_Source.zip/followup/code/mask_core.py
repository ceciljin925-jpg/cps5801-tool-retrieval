"""Deterministic, dependency-free eligibility for real-microbatch positive extras.

No labels are inferred. Reasons are mutually exclusive and applied in RULE order.
The original five candidates are never edited. Repeated original negatives remain.
"""
from collections import Counter

RULE_VERSION = 'bridge_other_positive_mask_v1'
REASONS = ('known_positive_id', 'forbidden_id', 'known_positive_input_alias',
           'forbidden_input_alias', 'anchor_five_input', 'duplicate_extra_input')
RULE = {
    'version': RULE_VERSION,
    'source': 'scheduled positive of each other row in the same actual microbatch',
    'ordering': 'ascending other-row position, excluding self',
    'exclusive_reason_precedence': list(REASONS),
    'alias': 'exact frozen E5 prefixed capped token-ID signature',
    'duplicate_rule': 'reserve all anchor-five signatures, then retain first eligible extra signature',
    'cross_accumulation': False, 'all_gather': False,
    'original_candidates_unchanged': True,
}


def plan_microbatch(batch, negatives, known_positives, forbidden, signatures):
    """Return B x (B-1) source rows/masks and transparent per-anchor decisions."""
    anchors = []
    for i, row in enumerate(batch):
        qid = row['query_id']
        known = set(known_positives[qid])
        excluded = set(forbidden[qid])
        own = [row['positive']] + list(negatives[qid])
        if len(own) != 5 or row['positive'] not in known:
            raise ValueError('Invalid five-candidate/scheduled-positive mapping')
        positive_sigs = {signatures[x] for x in known}
        forbidden_sigs = {signatures[x] for x in excluded}
        own_sigs = {signatures[x] for x in own}
        extra_sigs = set()
        sources, accepted, decisions = [], [], []
        counts = Counter({reason: 0 for reason in REASONS})
        for j, other in enumerate(batch):
            if i == j:
                continue
            tid = other['positive']
            sig = signatures[tid]
            if tid in known:
                reason = 'known_positive_id'
            elif tid in excluded:
                reason = 'forbidden_id'
            elif sig in positive_sigs:
                reason = 'known_positive_input_alias'
            elif sig in forbidden_sigs:
                reason = 'forbidden_input_alias'
            elif sig in own_sigs:
                reason = 'anchor_five_input'
            elif sig in extra_sigs:
                reason = 'duplicate_extra_input'
            else:
                reason = 'eligible'
                extra_sigs.add(sig)
            sources.append(j)
            accepted.append(reason == 'eligible')
            decisions.append(reason)
            if reason != 'eligible':
                counts[reason] += 1
        n = sum(accepted)
        assert n + sum(counts.values()) == len(batch) - 1
        anchors.append({'query_id': qid, 'anchor_row': i, 'source_rows': sources,
                        'eligible': accepted, 'decisions': decisions,
                        'eligible_count': n, 'removed_by_reason': dict(counts)})
    return {'microbatch_size': len(batch), 'potential_extras': len(batch)*(len(batch)-1),
            'eligible_extras': sum(x['eligible_count'] for x in anchors), 'anchors': anchors}


def summarize(plans, enabled):
    """Aggregate a selected *executed* schedule prefix, not independent samples."""
    per_query = {}
    for p in plans:
        for a in p['anchors']:
            item = per_query.setdefault(a['query_id'], {
                'query_id': a['query_id'], 'exposures': 0, 'potential_extras': 0,
                'eligible_extras': 0, 'actual_added_extras': 0,
                'eligible_count_histogram': {str(k): 0 for k in range(8)},
                'removed_by_reason': {r: 0 for r in REASONS}})
            item['exposures'] += 1
            item['potential_extras'] += p['microbatch_size'] - 1
            item['eligible_extras'] += a['eligible_count']
            item['actual_added_extras'] += a['eligible_count'] if enabled else 0
            item['eligible_count_histogram'][str(a['eligible_count'])] += 1
            for reason in REASONS:
                item['removed_by_reason'][reason] += a['removed_by_reason'][reason]
    total = {key: sum(r[key] for r in per_query.values()) for key in
             ('exposures', 'potential_extras', 'eligible_extras', 'actual_added_extras')}
    total.update({'microbatches': len(plans), 'queries': len(per_query), 'enabled': enabled,
                  'eligible_count_histogram': {str(k): sum(r['eligible_count_histogram'][str(k)] for r in per_query.values()) for k in range(8)},
                  'removed_by_reason': {reason: sum(r['removed_by_reason'][reason] for r in per_query.values()) for reason in REASONS},
                  'interpretation': 'Repeated scheduled exposures; explicit arm records hypothetical eligibility but adds zero extras.'})
    return total, [per_query[k] for k in sorted(per_query)]
