"""New BRIDGE_2X2_V1 stage; frozen vendor files are never edited.

Usage: python code/train_bridge.py --config CONFIG --output NEW_ATTEMPT [--resume]
Data paths and output_root are absolute, or relative to CONFIG's directory.
No model download, development selection, or final-data evaluation occurs here.
"""
from __future__ import annotations
import argparse
import gc
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

from mask_core import RULE, plan_microbatch, summarize

HERE = Path(__file__).resolve().parent
STAGE = 'BRIDGE_2X2_V1'
OBJECTIVES = ('explicit_1p4', 'explicit_1p4_plus_inbatch_positives')
DATA_FIELDS = ('train_path', 'corpus_path', 'schedule_path', 'negatives_path',
               'train_tool_ids_path', 'forbidden_path', 'input_signatures_path')
VENDOR_HASHES = {
    'train_configurable.py': '52ea15d219848fc8a0df3b3ab3accb675286a5d37ed4d8b79ec5f64569b4ff77',
    'encoders.py': '2930b9fabf3fc91819d4a26a8980e5eeb5b926b90113fff40d3acc1b4cead6fe',
}
SCHEMA = {
    'stage': STAGE, 'family': 'e5', 'policies': ['R_ID', 'B_ID'], 'objectives': list(OBJECTIVES),
    'seeds': [42, 43, 44, 45, 46], 'steps': 625, 'lr': 2e-5, 'temperature': .05,
    'microbatch': 8, 'accumulation': 4, 'checkpoint_steps': [625],
    'required_paths': list(DATA_FIELDS) + ['model_path', 'output_root'],
    'required_other': ['run_id', 'input_hashes'],
    'input_hashes': 'Every DATA_FIELDS file must have its actual resolved path mapped to SHA256.',
    'mask': RULE, 'resume': 'Explicit only; same config, code, inputs, model and runtime identity required.',
}


def sha_file(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def sha_json(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    temporary.replace(path)


def code_identity():
    return {name: sha_file(HERE / name) for name in
            ('train_bridge.py', 'mask_core.py', 'bridge_losses.py',
             'vendor/train_configurable.py', 'vendor/encoders.py')}


def load_vendor():
    for name, digest in VENDOR_HASHES.items():
        if sha_file(HERE/'vendor'/name) != digest:
            raise ValueError('Frozen training vendor changed: '+name)
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(HERE/'vendor'))
    e = importlib.import_module('encoders')
    v = importlib.import_module('train_configurable')
    if Path(e.__file__).resolve() != HERE/'vendor'/'encoders.py' or Path(v.__file__).resolve() != HERE/'vendor'/'train_configurable.py':
        raise RuntimeError('Unexpected imported vendor module')
    return v, e


def load_config(path):
    path = Path(path).resolve(strict=True)
    config = read(path)
    for field in DATA_FIELDS + ('model_path', 'output_root'):
        p = Path(config[field])
        config[field] = str((p if p.is_absolute() else path.parent/p).resolve())
    config['input_hashes'] = {str((Path(p) if Path(p).is_absolute() else path.parent/p).resolve()): h
                              for p, h in config['input_hashes'].items()}
    return config


def validate_config(config):
    required = set(DATA_FIELDS) | {'model_path','output_root','input_hashes','run_id','stage','family','policy',
                                 'objective','seed','steps','lr','temperature','microbatch','accumulation'}
    allowed = required | {'checkpoint_steps','resume_every','device'}
    if required - config.keys() or config.keys() - allowed:
        raise ValueError(f'Config fields missing={sorted(required-config.keys())}; unknown={sorted(config.keys()-allowed)}')
    expected = {'stage': STAGE, 'family': 'e5', 'steps': 625, 'lr': 2e-5,
                'temperature': .05, 'microbatch': 8, 'accumulation': 4}
    for key, value in expected.items():
        if config[key] != value:
            raise ValueError(f'Frozen bridge {key} must be {value!r}')
    if config['policy'] not in ('R_ID','B_ID') or config['objective'] not in OBJECTIVES or config['seed'] not in range(42,47):
        raise ValueError('Policy/objective/seed outside bridge matrix')
    if config.get('checkpoint_steps',[625]) != [625] or config.get('device','cuda') != 'cuda':
        raise ValueError('Bridge only supports final step625 and CUDA')
    if type(config.get('resume_every',100)) is not int or not 1 <= config.get('resume_every',100) <= 625:
        raise ValueError('Invalid recovery interval')
    for field in DATA_FIELDS:
        p = str(Path(config[field]).resolve(strict=True))
        if config['input_hashes'].get(p) != sha_file(p):
            raise ValueError('Missing/wrong input hash: '+field)
    for p, expected_hash in config['input_hashes'].items():
        if sha_file(p) != expected_hash:
            raise ValueError('Changed bound input: '+p)
    if not Path(config['model_path']).is_dir():
        raise ValueError('Missing local frozen base model')
    expected_model = read(HERE.parent/'pretrained_model_identity.json')['expected_files']
    for name, record in expected_model.items():
        p = Path(config['model_path'])/name
        if not p.is_file() or p.stat().st_size != record['bytes'] or sha_file(p) != record['sha256']:
            raise ValueError('Frozen pretrained model mismatch: '+name)
    if not config['run_id'] or any(c in config['run_id'] for c in '/\\'):
        raise ValueError('run_id must be a nonempty single name')
    return 8, 4, [625]


def output_path(config, value):
    root = Path(config['output_root']).resolve()
    out = Path(value).resolve()
    if out == root or root not in out.parents:
        raise ValueError('Attempt must be inside dedicated output_root')
    protected = [HERE, Path(config['model_path']).resolve()] + [Path(config[f]).resolve() for f in DATA_FIELDS]
    for p in protected:
        if root == p or root in p.parents or p in root.parents:
            raise ValueError('output_root overlaps immutable source/data/model: '+str(p))
    return out


def loss_prefix(path):
    if not path.exists():
        return [], b''
    raw = path.read_bytes()
    valid = []
    for line in raw.splitlines(keepends=True):
        try:
            row = json.loads(line)
            if row['step'] != len(valid)+1:
                break
        except (ValueError, KeyError, TypeError):
            break
        valid.append((line,row))
    return valid, raw


def recover_durable_prefix(config, out, v, e):
    """Preserve interrupted tails before restoring the last atomic optimizer state.

This also handles a partial last JSONL line, which the unmodified vendor rejects.
Only trusted state written by this runner is deserialized; never external checkpoints.
"""
    if read(out/'config.json') != config:
        raise ValueError('Resume config differs; use a new attempt')
    identity = read(out/'identity.json')
    if identity['bridge']['source_hashes'] != code_identity():
        raise ValueError('Resume wrapper/vendor code changed')
    runtime = {k:w for k,w in e.runtime_record().items() if k not in ('created_at','executable')}
    if identity['runtime'] != runtime or identity['model_files'] != e.directory_manifest(config['model_path']):
        raise ValueError('Resume runtime/base-model identity changed')
    state = e.torch.load(out/'latest_resume.pt', map_location='cpu', weights_only=False)
    if state['identity_sha256'] != sha_json(identity):
        raise ValueError('Resume state is not bound to recorded scientific identity')
    committed = int(state['step'])
    del state
    gc.collect()
    valid, raw = loss_prefix(out/'loss.jsonl')
    if not 0 <= committed <= 625 or len(valid) < committed:
        raise ValueError('Durable loss evidence shorter than committed optimizer state')
    desired = b''.join(line for line,row in valid[:committed])
    future = [p for p in (out/'checkpoints').glob('step_*') if int(p.name.split('_')[-1]) > committed]
    if desired != raw or future:
        backup = out/'interrupted_tails'/('bridge_'+str(time.time_ns()))
        backup.mkdir(parents=True, exist_ok=False)
        (backup/'complete_pre_resume_loss.jsonl').write_bytes(raw)
        (backup/'uncommitted_loss_tail.bin').write_bytes(raw[len(desired):])
        for p in future:
            if out not in p.resolve().parents or out not in backup.resolve().parents:
                raise ValueError('Recovery move escaped attempt')
            p.rename(backup/p.name)
        temporary = out/'loss.jsonl.rollback.tmp'
        temporary.write_bytes(desired)
        temporary.replace(out/'loss.jsonl')
        atomic_json(backup/'recovery.json', {'committed_step':committed,'preserved_future_checkpoints':[p.name for p in future],
                    'original_loss_sha256':hashlib.sha256(raw).hexdigest(), 'action':'preserve then replay uncommitted tail'})


def run(config, output, resume=False, after_update=None):
    validate_config(config)
    out = output_path(config, output)
    if out.exists() and any(out.iterdir()) and not resume:
        raise FileExistsError('Nonempty attempt; use a NEW path or explicit --resume')
    if resume and (not (out/'latest_resume.pt').is_file() or read(out/'status.json').get('status')=='completed'):
        raise ValueError('Only interrupted attempts with committed recovery state may resume')
    v,e = load_vendor()
    e.setup_runtime('cuda')
    if resume:
        recover_durable_prefix(config,out,v,e)
    original = {name:getattr(v,name) for name in ('validate_config','prepare_inputs','scientific_identity','ensure_output','train_update')}
    context = {}

    def prepare(conf, encoder):
        data = original['prepare_inputs'](conf,encoder)
        train,corpus,schedule,negatives,qtokens,dtokens = data
        sig = read(conf['input_signatures_path'])
        if set(sig) != {d['id'] for d in corpus}:
            raise ValueError('Signature corpus IDs differ')
        docs = {d['id']:d['text'] for d in corpus}
        # Verify every frozen input signature, reusing tokens already prepared by vendor.
        for tid in sorted(docs):
            tokens = dtokens[tid] if tid in dtokens else encoder.tokenize(docs[tid],'document')
            actual = hashlib.sha256(json.dumps(tokens['input_ids'],separators=(',',':')).encode()).hexdigest()
            if actual != sig[tid]:
                raise ValueError('Actual E5 input signature mismatch: '+tid)
        known = {g['id']:g['positives'] for g in train}
        forbidden = read(conf['forbidden_path'])
        if set(forbidden) != set(known):
            raise ValueError('Forbidden-query coverage differs')
        plans=[]
        for offset in range(0,len(schedule),8):
            p=plan_microbatch(schedule[offset:offset+8],negatives,known,forbidden,sig)
            plans.append({'step':offset//32+1,'microbatch_in_update':(offset%32)//8,'plan':p})
        raw=''.join(json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n' for p in plans).encode()
        plan_path=out/'mask_plan_microbatches.jsonl'
        if plan_path.exists() and plan_path.read_bytes()!=raw:
            raise ValueError('Existing frozen mask plan differs')
        if not plan_path.exists():
            plan_path.write_bytes(raw)
        context.update(known=known,forbidden=forbidden,sig=sig,plans=plans,
                       plan_sha256=hashlib.sha256(raw).hexdigest(), cursor=0)
        if resume:
            context['cursor']=len(loss_prefix(out/'loss.jsonl')[0])
        return data

    def identity(conf,schedule,negatives):
        value=original['scientific_identity'](conf,schedule,negatives)
        value['bridge']={'stage':STAGE,'objective':conf['objective'],'run_id':conf['run_id'],
                         'input_signatures_sha256':sha_file(conf['input_signatures_path']),
                         'mask_rule':RULE,'mask_plan_sha256':context['plan_sha256'],
                         'source_hashes':code_identity(),
                         'explicit_branch':'direct call to unchanged vendor train_update',
                         'plus_branch':'same two pool calls; original logits plus other-row positive vectors; no detach'}
        return value

    def update(encoder,optimizer,batch,negatives,qtokens,dtokens,microbatch,temperature):
        cursor=context['cursor']
        expected=context['plans'][cursor*4:(cursor+1)*4]
        if len(expected)!=4 or [r['query_id'] for x in expected for r in x['plan']['anchors']] != [r['query_id'] for r in batch]:
            raise RuntimeError('Update/mask schedule cursor mismatch')
        if config['objective']=='explicit_1p4':
            result=original['train_update'](encoder,optimizer,batch,negatives,qtokens,dtokens,microbatch,temperature)
        else:
            from bridge_losses import update_with_extras
            result=update_with_extras(encoder,optimizer,batch,negatives,qtokens,dtokens,microbatch,temperature,
                                      context['known'],context['forbidden'],context['sig'],expected)
        context['cursor']+=1
        return result

    v.validate_config=validate_config
    v.prepare_inputs=prepare
    v.scientific_identity=identity
    v.ensure_output=lambda path:output_path(config,path)
    v.train_update=update
    out.mkdir(parents=True,exist_ok=True)
    try:
        result=v.train(config,out,resume=resume,after_update=after_update)
        return result
    except Exception as error:
        status=read(out/'status.json') if (out/'status.json').exists() else {}
        if status.get('status')!='completed':
            atomic_json(out/'status.json',{**status,'status':'failed','error':repr(error),'traceback':traceback.format_exc()})
        raise
    finally:
        for name,method in original.items():
            setattr(v,name,method)
        if context.get('plans'):
            logged,raw=loss_prefix(out/'loss.jsonl')
            n=len(logged)
            executed=context['plans'][:n*4]
            enabled=config['objective']==OBJECTIVES[1]
            total,queries=summarize([x['plan'] for x in executed],enabled)
            total.update({'objective':config['objective'],'logged_updates':n,'planned_updates':625,
                          'mask_plan_sha256':context['plan_sha256'],
                          'coverage_basis':'durable contiguous loss rows; exact625 only when final status completed',
                          'status':read(out/'status.json').get('status')})
            atomic_json(out/'mask_summary.json',total)
            atomic_json(out/'mask_query_summary.json',queries)
            tmp=out/'mask_microbatches.jsonl.tmp'
            tmp.write_text(''.join(json.dumps({**x,'objective_enabled':enabled},ensure_ascii=False,separators=(',',':'))+'\n' for x in executed),encoding='utf-8')
            tmp.replace(out/'mask_microbatches.jsonl')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--schema',action='store_true')
    args=p.parse_args()
    if args.schema:
        print(json.dumps(SCHEMA,ensure_ascii=False,indent=2));return
    if args.config is None or args.output is None:
        p.error('--config and --output are required')
    result=run(load_config(args.config),args.output,args.resume)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
