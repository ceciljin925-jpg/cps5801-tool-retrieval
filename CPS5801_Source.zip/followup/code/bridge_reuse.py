"""Read-only, stdlib-only all-or-none audit of six historical step625 controls.

Public API: inspect_reuse(package_root, gpu_work_root, current_runtime,
                         preflight_report) -> JSON-serializable dict.
No old file is written; no disk discovery outside explicitly bound directories.
An ineligible reuse report requests fresh20, but never authorizes bypassing a
failed mandatory GPU preflight (the orchestration layer must enforce that gate).
"""
from pathlib import Path
import hashlib
import json
import math


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha_file(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def sha_json(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def safe_join(root, relative):
    root = Path(root).resolve()
    relative = Path(relative)
    if relative.is_absolute():
        raise ValueError('Expected a relative path: ' + str(relative))
    result = (root / relative).resolve()
    if root not in result.parents:
        raise ValueError('Bound path escapes its root: ' + str(relative))
    return result


def directory_manifest(path):
    path = Path(path).resolve(strict=True)
    manifest = {}
    for item in sorted(path.rglob('*')):
        if item.is_file() and '__pycache__' not in item.parts and not item.name.endswith('.tmp'):
            if path not in item.resolve().parents:
                raise ValueError('Checkpoint file escapes its directory: ' + str(item))
            manifest[item.relative_to(path).as_posix()] = {'bytes': item.stat().st_size, 'sha256': sha_file(item)}
    return manifest


def inspect_reuse(package_root, gpu_work_root, current_runtime, preflight_report):
    package = Path(package_root).resolve()
    gpu = Path(gpu_work_root).resolve()
    report = {'schema': 'bridge_reuse_audit_v1', 'eligible': False, 'decision': 'FRESH20',
        'reasons': [], 'controls_verified': [], 'checks': [], 'package_root': str(package),
        'gpu_work_root': str(gpu), 'all_or_none': True,
        'scope': 'Six historical final625 controls only; preflight remains mandatory even when reuse is rejected.'}
    reasons, checks = report['reasons'], report['checks']
    cache = {}

    def check(name, ok, detail=None):
        entry = {'name': name, 'passed': bool(ok)}
        if detail is not None:
            entry['detail'] = detail
        checks.append(entry)
        if not ok:
            reasons.append(name + (': ' + str(detail) if detail is not None else ''))
        return bool(ok)

    def file_check(name, path, expected):
        key = str(path)
        try:
            if key not in cache:
                cache[key] = {'path': key, 'bytes': path.stat().st_size, 'sha256': sha_file(path)}
            actual = cache[key]
            ok = actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256']
            check(name, ok, {'path': key, 'expected': {'bytes': expected['bytes'], 'sha256': expected['sha256']}, 'actual': actual})
            return ok
        except Exception as error:
            return check(name, False, {'path': key, 'error': repr(error)})

    def old_ref(name, ref):
        return file_check(name, safe_join(gpu, ref['gpu_work_relative_path']), ref)

    try:
        expectation_path = package / 'reuse_expectations.json'
        expected = read(expectation_path)
        report['expectations_sha256'] = sha_file(expectation_path)
        controls = expected['controls']
        expected_slots = {(p, s) for s in (42, 43, 44) for p in ('R_ID', 'B_ID')}
        check('exact_six_expected_slots', len(controls) == 6 and {(x['policy'], x['seed']) for x in controls} == expected_slots)
        check('fixed625_recipe', expected['scientific_recipe']['steps'] == 625 and expected['scientific_recipe']['objective'] == 'explicit_1p4')
        runtime = expected['runtime_reference']
        required_runtime = ('python','torch','cuda','transformers','tokenizers','numpy','safetensors',
            'gpu','gpu_driver','platform','cublas_workspace_config','tf32','cudnn_benchmark','num_threads')
        for key in required_runtime:
            check('runtime.' + key, key in runtime and key in current_runtime and current_runtime[key] == runtime[key],
                {'expected': runtime.get(key), 'actual': current_runtime.get(key)})
        preflight = read(preflight_report) if isinstance(preflight_report, (str, Path)) else preflight_report
        check('preflight.PASS', isinstance(preflight, dict) and preflight.get('status') == 'PASS')
        if not isinstance(preflight, dict):
            preflight = {}
        for name in ('cpu_mask_math_and_torch_autograd', 'explicit_1p4_resume_exact',
                     'explicit_1p4_plus_inbatch_positives_resume_exact', 'explicit_wrapper_equals_unchanged_vendor'):
            check('preflight.' + name, preflight.get('tests', {}).get(name, {}).get('status') == 'PASS')
        check('preflight.not_scientific', preflight.get('scientific_cells_completed') == 0 and
            preflight.get('scope') == 'ENGINEERING_ONLY_NOT_SCIENTIFIC_CELL')
        for key in required_runtime:
            check('preflight.runtime.' + key, preflight.get('runtime', {}).get(key) == current_runtime.get(key))
        source_names = ('train_bridge.py', 'mask_core.py', 'bridge_losses.py', 'vendor/train_configurable.py', 'vendor/encoders.py')
        for name in source_names:
            p = safe_join(package / 'code', name)
            check('preflight.code.' + name, p.is_file() and sha_file(p) == preflight.get('source_hashes', {}).get(name))
        for name in ('gpu_smoke_bridge.py','test_bridge_cpu.py'):
            p = safe_join(package / 'code', name)
            check('preflight.acceptance_code.' + name, p.is_file() and sha_file(p) == preflight.get('acceptance_source_hashes', {}).get(name))
        base = safe_join(gpu, expected['initial_model']['gpu_relative_path'])
        try:
            actual_base = directory_manifest(base)
            check('initial_model.complete_manifest', actual_base == expected['initial_model']['files'],
                {'path': str(base), 'expected_manifest_sha256': sha_json(expected['initial_model']['files']),
                 'actual_manifest_sha256': sha_json(actual_base)})
        except Exception as error:
            check('initial_model.complete_manifest', False, repr(error))
        check('preflight.initial_weight', preflight.get('base_model_weight_sha256') == expected['initial_model']['files']['model.safetensors']['sha256'])
        formal = preflight.get('formal_config', {})
        check('preflight.formal_recipe', all(formal.get(k) == value for k, value in {
            'stage':'BRIDGE_2X2_V1','family':'e5','objective':'explicit_1p4','policy':'R_ID','seed':42,
            'steps':625,'lr':2e-5,'temperature':.05,'microbatch':8,'accumulation':4}.items()))
        check('preflight.formal_config_hash', sha_json(formal) == preflight.get('formal_config_sha256'))
        check('preflight.model_path', Path(formal.get('model_path','')).resolve() == base)
        for index, ref in enumerate(expected['global_evidence']):
            old_ref('global.' + str(index) + '.' + ref['gpu_work_relative_path'], ref)
        for name, ref in expected['frozen_inputs'].items():
            old_ref('frozen_input.' + name, ref)
        manifest = read(package / 'input_manifest.json')
        report['input_manifest_sha256'] = sha_file(package / 'input_manifest.json')
        copied_by_source = {}
        for ref in manifest['copied_files']:
            path = safe_join(package, ref['path'])
            file_check('package_input.' + ref['path'], path, ref)
            source = ref.get('source_archive_relative')
            if source:
                check('package_source_hash.' + ref['path'], ref['sha256'] == ref.get('source_sha256'))
                check('package_unique_source.' + source, source not in copied_by_source)
                copied_by_source[source] = ref
        plan = read(package / 'bridge_plan.json')
        formal_input_paths = dict(plan['training'])
        r42 = next(x for x in controls if x['policy'] == 'R_ID' and x['seed'] == 42)
        for key, evidence in [('schedule_path','schedule_evidence'),('negatives_path','negative_evidence')]:
            source = r42[evidence]['bridge_source_file']['archive_relative_path']
            if source in copied_by_source:
                formal_input_paths[key] = copied_by_source[source]['path']
        check('preflight.all_seven_input_fields', set(formal_input_paths) == {'train_path','corpus_path',
            'train_tool_ids_path','forbidden_path','input_signatures_path','schedule_path','negatives_path'})
        for field, relative in formal_input_paths.items():
            path = safe_join(package, relative)
            check('preflight.formal_input_path.' + field, Path(formal.get(field, '')).resolve() == path)
            check('preflight.formal_input_hash.' + field,
                path.is_file() and formal.get('input_hashes', {}).get(str(path)) == sha_file(path))
        for item in controls:
            first_reason = len(reasons)
            name = f"{item['policy']}_s{item['seed']}"
            checkpoint = safe_join(gpu, item['gpu_checkpoint_relative_path'])
            verified = {'policy': item['policy'], 'seed': item['seed'], 'legacy_run_id': item['legacy_run_id'],
                'legacyrunid': item['legacy_run_id'], 'checkpoint_path': str(checkpoint), 'verified': False,
                'expected_model_manifest_sha256': item['expected_model_manifest_sha256']}
            try:
                check(name + '.objective', item['objective'] == 'explicit_1p4')
                actual = directory_manifest(checkpoint)
                check(name + '.checkpoint.complete_manifest', actual == item['checkpoint_files'] and
                    sha_json(actual) == item['expected_model_manifest_sha256'],
                    {'actual_manifest_sha256': sha_json(actual), 'expected_manifest_sha256': item['expected_model_manifest_sha256'],
                     'expected_files': item['checkpoint_files'], 'actual_files': actual})
                training_evidence = item['training_evidence']
                for filename, ref in training_evidence['files'].items():
                    old_ref(name + '.training_file.' + filename, ref)
                training = read(safe_join(gpu, training_evidence['files']['training.json']['gpu_work_relative_path']))
                config = read(safe_join(gpu, training_evidence['files']['config.json']['gpu_work_relative_path']))
                expected_fields = training_evidence['expected_fields']
                check(name + '.training_fields', all(training.get(k) == v for k, v in expected_fields.items()))
                check(name + '.fixed625_final', training.get('steps') == 625 and training.get('epochs') == 2 and
                    training.get('checkpoint') == 'final epoch 2' and training.get('seed') == item['seed'] and
                    training.get('run_id') == item['legacy_run_id'])
                shared_keys = ('run_id','seed','policy','schedule_sha256','negative_manifest_sha256','snapshot_manifest_sha256',
                    'experiment_code_sha256','evaluation_code_sha256')
                check(name + '.config_training_binding', all(config.get(k) == training.get(k) == expected_fields.get(k) for k in shared_keys))
                trace_path = safe_join(gpu, training_evidence['files']['loss.jsonl']['gpu_work_relative_path'])
                trace = [json.loads(line) for line in trace_path.read_text(encoding='utf-8').splitlines() if line]
                check(name + '.contiguous_finite_trace', len(trace) == 625 and [x['step'] for x in trace] == list(range(1,626))
                    and all(math.isfinite(x['loss']) and math.isfinite(x['grad_norm']) for x in trace))
                for kind, bridge_key, old_key, canonical_key in [
                    ('schedule_evidence','bridge_source_file','old_file','canonical_prefix_sha256'),
                    ('negative_evidence','bridge_source_file','old_multi_policy_file','canonical_policy_sha256')]:
                    evidence = item[kind]
                    old_ref(name + '.' + kind + '.old', evidence[old_key])
                    # Source publication files also remain bound onGPU; package copies are checked separately.
                    old_ref(name + '.' + kind + '.publication_source', evidence[bridge_key])
                    source = evidence[bridge_key]['archive_relative_path']
                    ref = copied_by_source.get(source)
                    check(name + '.' + kind + '.copied_source_bound', ref is not None and
                        ref['sha256'] == evidence[bridge_key]['sha256'])
                    if ref is None:
                        continue
                    new_data = read(safe_join(package, ref['path']))
                    old_data = read(safe_join(gpu, evidence[old_key]['gpu_work_relative_path']))
                    if kind == 'schedule_evidence':
                        new_data = new_data[:20000]
                        check(name + '.schedule_length', len(old_data) == len(new_data) == 20000)
                    else:
                        old_policy = 'random' if item['policy'] == 'R_ID' else 'bm25'
                        old_data = {q: v[old_policy] for q,v in old_data.items()}
                        check(name + '.negative_count', len(old_data) == len(new_data) == 10000 and
                            all(len(v) == 4 and len(set(v)) == 4 for v in new_data.values()))
                    check(name + '.' + kind + '.ordered_identity', old_data == new_data and
                        sha_json(old_data) == sha_json(new_data) == evidence[canonical_key])
                cross = item['cross_stage_evidence']
                old_ref(name + '.per_update_prefix_proof', cross['per_update_file'])
                check(name + '.prior_prefix625_proof', cross['status'] == 'PASS_EXACT_OBSERVED' and
                    cross['trace']['exact'] is True and cross['trace']['compared_updates'] == 625 and
                    cross['all_preconditions_satisfied'] is True and cross['final_weights']['compared'] is False)
                check(name + '.historical_eval_bindings', len(item['corresponding_evaluations']) == 5 and
                    all(x['model_manifest_sha256'] == item['expected_model_manifest_sha256'] for x in item['corresponding_evaluations'].values()))
            except Exception as error:
                check(name + '.audit_exception', False, repr(error))
            verified['verified'] = len(reasons) == first_reason
            verified['reasons'] = reasons[first_reason:]
            report['controls_verified'].append(verified)
        report['eligible'] = not reasons and len(report['controls_verified']) == 6 and all(x['verified'] for x in report['controls_verified'])
        report['decision'] = 'REUSE6_TRAIN14' if report['eligible'] else 'FRESH20'
    except Exception as error:
        check('reuse_audit_exception', False, repr(error))
    report['checks_passed'] = sum(x['passed'] for x in checks)
    report['checks_total'] = len(checks)
    report['historical_limit'] = 'No individual full S0 runtime identity exists. Matching captured runtime, source/input/weight identities and short engineering checks do not establish an unsaved S3step625 parameter state.'
    return report
