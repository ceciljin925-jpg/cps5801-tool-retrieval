"""Synthetic integrity tests for fail-closed, all-or-none historical reuse.

Fixtures are intentionally fake tiny model files, never scientific evidence.
Run with stdlib Python: python code/test_reuse.py
"""
from pathlib import Path
import copy
import json
import tempfile
import unittest

import bridge_reuse as audit


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, bytes):
        path.write_bytes(value)
    else:
        path.write_text(json.dumps(value), encoding='utf-8')
    return path


def identity(path):
    return {'bytes': path.stat().st_size, 'sha256': audit.sha_file(path)}


def fixture(root):
    package, gpu = root/'package', root/'gpu'
    package.mkdir();gpu.mkdir()
    runtime = {k:'fake' for k in ('python','torch','cuda','transformers','tokenizers','numpy','safetensors','gpu','gpu_driver','platform')}
    runtime.update(cublas_workspace_config=':4096:8',tf32=False,cudnn_benchmark=False,num_threads=8)
    base = gpu/'repro/data/raw/model';write(base/'model.safetensors', b'FAKE_TEST_ONLY_BASE')
    source_names = ('train_bridge.py','mask_core.py','bridge_losses.py','vendor/train_configurable.py','vendor/encoders.py')
    for n in source_names + ('gpu_smoke_bridge.py','test_bridge_cpu.py'):
        write(package/'code'/n, b'FAKE_TEST_ONLY_CODE')
    formal = {'stage':'BRIDGE_2X2_V1','family':'e5','objective':'explicit_1p4','policy':'R_ID','seed':42,
        'steps':625,'lr':2e-5,'temperature':.05,'microbatch':8,'accumulation':4,'model_path':str(base)}
    preflight = {'status':'PASS','scope':'ENGINEERING_ONLY_NOT_SCIENTIFIC_CELL','scientific_cells_completed':0,
        'runtime':runtime.copy(), 'formal_config':formal, 'formal_config_sha256':audit.sha_json(formal),
        'base_model_weight_sha256':audit.sha_file(base/'model.safetensors'),
        'source_hashes':{n:audit.sha_file(package/'code'/n) for n in source_names},
        'acceptance_source_hashes':{n:audit.sha_file(package/'code'/n) for n in ('gpu_smoke_bridge.py','test_bridge_cpu.py')},
        'tests':{n:{'status':'PASS'} for n in ('cpu_mask_math_and_torch_autograd','explicit_1p4_resume_exact',
            'explicit_1p4_plus_inbatch_positives_resume_exact','explicit_wrapper_equals_unchanged_vendor')}}
    copied = {}
    def old_ref(relative, value):
        path = write(gpu/relative, value)
        archive = 'reproduction/' + relative[6:] if relative.startswith('repro/') else relative
        return {'gpu_work_relative_path':relative,'archive_relative_path':archive,**identity(path)}
    def package_copy(old, target):
        p = write(package/target, (gpu/old['gpu_work_relative_path']).read_bytes())
        copied[old['archive_relative_path']] = {'path':target,**identity(p),
            'source_archive_relative':old['archive_relative_path'],'source_sha256':old['sha256']}
    global_file = old_ref('publication/audit/proof.json', {'status':'SYNTHETIC_TEST_ONLY'})
    controls = []
    for seed in (42,43,44):
        schedule = [{'epoch':i//10000,'query_id':f'q{i%10000}','positive':'p'} for i in range(20000)]
        old_s = old_ref(f'repro/data/schedule{seed}.json', schedule)
        new_s = old_ref(f'publication/data/schedule{seed}.json', schedule*2)
        package_copy(new_s,f'inputs/schedule{seed}.json')
        negatives = {f'q{i}':['a','b','c','d'] for i in range(10000)}
        old_n = old_ref(f'repro/data/negatives{seed}.json', {q:{'random':v,'bm25':v} for q,v in negatives.items()})
        for policy in ('R_ID','B_ID'):
            name = f'{policy}_{seed}';run = f'M_{name}'
            new_n = old_ref(f'publication/data/{name}.json', negatives)
            package_copy(new_n,f'inputs/{name}.json')
            ckpt = gpu/'repro/results'/run/'checkpoint'
            write(ckpt/'model.safetensors', ('FAKE_TEST_ONLY_' + name).encode())
            model_files = audit.directory_manifest(ckpt);model_hash = audit.sha_json(model_files)
            fields = {'seed':seed,'run_id':run,'policy':'random' if policy=='R_ID' else 'bm25','steps':625,
                'epochs':2,'queries':10000,'checkpoint':'final epoch 2','schedule_sha256':old_s['sha256'],
                'negative_manifest_sha256':old_n['sha256'],'snapshot_manifest_sha256':'fake',
                'experiment_code_sha256':'fake','evaluation_code_sha256':'fake'}
            training = old_ref(f'repro/results/{run}/training.json', fields)
            config = old_ref(f'repro/results/{run}/config.json', fields)
            lines = ''.join(json.dumps({'step':i,'loss':.1,'grad_norm':1.})+'\n' for i in range(1,626)).encode()
            loss = old_ref(f'repro/results/{run}/loss.jsonl',lines)
            per_update = old_ref(f'publication/audit/{name}.csv', b'FAKE_TEST_ONLY\n')
            controls.append({'policy':policy,'seed':seed,'objective':'explicit_1p4','legacy_run_id':run,
                'gpu_checkpoint_relative_path':ckpt.relative_to(gpu).as_posix(),
                'checkpoint_files':model_files,'expected_model_manifest_sha256':model_hash,
                'training_evidence':{'expected_fields':fields,'files':{'training.json':training,'config.json':config,'loss.jsonl':loss}},
                'schedule_evidence':{'old_file':old_s,'bridge_source_file':new_s,'canonical_prefix_sha256':audit.sha_json(schedule)},
                'negative_evidence':{'old_multi_policy_file':old_n,'bridge_source_file':new_n,'canonical_policy_sha256':audit.sha_json(negatives)},
                'cross_stage_evidence':{'status':'PASS_EXACT_OBSERVED','trace':{'exact':True,'compared_updates':625},
                    'all_preconditions_satisfied':True,'final_weights':{'compared':False},'per_update_file':per_update},
                'corresponding_evaluations':{str(i):{'model_manifest_sha256':model_hash} for i in range(5)}})
    expectations = {'controls':controls,'scientific_recipe':{'steps':625,'objective':'explicit_1p4'},
        'runtime_reference':runtime, 'initial_model':{'gpu_relative_path':base.relative_to(gpu).as_posix(),
            'files':audit.directory_manifest(base)},'global_evidence':[global_file],'frozen_inputs':{}}
    training = {}
    for field in ('train_path','corpus_path','train_tool_ids_path','forbidden_path','input_signatures_path'):
        relative = 'inputs/' + field + '.json'
        write(package/relative, {'purpose':'FAKE_TEST_ONLY'})
        training[field] = relative
        formal[field] = str(package/relative)
    formal['schedule_path'] = str(package/'inputs/schedule42.json')
    formal['negatives_path'] = str(package/'inputs/R_ID_42.json')
    formal['input_hashes'] = {formal[k]:audit.sha_file(formal[k]) for k in list(training) + ['schedule_path','negatives_path']}
    preflight['formal_config_sha256'] = audit.sha_json(formal)
    write(package/'bridge_plan.json',{'training':training})
    write(package/'reuse_expectations.json',expectations)
    write(package/'input_manifest.json',{'copied_files':list(copied.values())})
    return package,gpu,runtime,preflight,expectations


class ReuseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.package,self.gpu,self.runtime,self.preflight,self.expected = fixture(Path(self.temp.name))

    def tearDown(self):
        self.temp.cleanup()

    def run_audit(self):
        return audit.inspect_reuse(self.package,self.gpu,self.runtime,self.preflight)

    def assert_reject(self, report, reason):
        self.assertFalse(report['eligible'])
        self.assertEqual(report['decision'],'FRESH20')
        self.assertTrue(any(reason in s for s in report['reasons']),report['reasons'])

    def test_all_six_pass(self):
        report=self.run_audit()
        self.assertTrue(report['eligible'],report['reasons'])
        self.assertEqual(report['decision'],'REUSE6_TRAIN14')
        self.assertEqual(len(report['controls_verified']),6)

    def test_one_weight_mutation_rejects_all(self):
        item=self.expected['controls'][0]
        write(self.gpu/item['gpu_checkpoint_relative_path']/'model.safetensors',b'WRONG')
        report=self.run_audit()
        self.assert_reject(report,'checkpoint.complete_manifest')
        self.assertEqual(sum(x['verified'] for x in report['controls_verified']),5)

    def test_extra_checkpoint_file_rejects(self):
        item=self.expected['controls'][0]
        write(self.gpu/item['gpu_checkpoint_relative_path']/'unbound.json',{})
        self.assert_reject(self.run_audit(),'checkpoint.complete_manifest')

    def test_runtime_mismatch(self):
        self.runtime['torch']='changed'
        self.assert_reject(self.run_audit(),'runtime.torch')

    def test_missing_mandatory_smoke(self):
        del self.preflight['tests']['explicit_wrapper_equals_unchanged_vendor']
        self.assert_reject(self.run_audit(),'preflight.explicit_wrapper')

    def test_stale_smoke_code(self):
        write(self.package/'code/mask_core.py',b'CHANGED')
        self.assert_reject(self.run_audit(),'preflight.code.mask_core.py')

    def test_smoke_input_not_bound_to_package(self):
        self.preflight['formal_config']['schedule_path'] = str(self.package/'inputs/schedule43.json')
        self.preflight['formal_config_sha256'] = audit.sha_json(self.preflight['formal_config'])
        self.assert_reject(self.run_audit(),'preflight.formal_input_path.schedule_path')

    def test_corrupt_ordered_package_input(self):
        p=self.package/'inputs/schedule42.json'
        rows=audit.read(p);rows[0],rows[1]=rows[1],rows[0];write(p,rows)
        self.assert_reject(self.run_audit(),'schedule_evidence.ordered_identity')

    def test_bound_path_cannot_escape(self):
        with self.assertRaises(ValueError):audit.safe_join(self.gpu,'../escaped')


if __name__=='__main__':
    unittest.main(verbosity=2)
