"""CPU-only packaging and queue-guard tests using explicitly fake artifacts.

No neural model is imported or executed. Temporary FAKE_TEST_ONLY weights test
transport and identity, never scientific accuracy or GPU acceptance.
"""
from pathlib import Path
import hashlib
import json
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import bridge_collect as collector
import bridge_runner as runner


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, bytes):
        path.write_bytes(value)
    else:
        path.write_text(json.dumps(value),encoding='utf-8')
    return path


def fixture(base):
    root=base/'new_package';root.mkdir()
    old=base/'old_gpu_work';checkpoint=old/'repro/results/FAKE_TEST_ONLY/checkpoint'
    write(checkpoint/'model.safetensors',b'FAKE_TEST_ONLY_FINAL_WEIGHTS')
    write(checkpoint/'config.json',{'purpose':'FAKE_TEST_ONLY'})
    write(root/'code/readme.txt',b'FAKE_TEST_ONLY_PACKAGE\n')
    write(root/'inputs/frozen.json',{'purpose':'FAKE_TEST_ONLY_INPUT'})
    write(root/'run_state/command_logs/failed.log',b'FAKE_TEST_ONLY_FAILURE_LOG\n')
    write(root/'run_state/train_runs/failed/latest_resume.pt',b'FAKE_TEST_ONLY_RECOVERY')
    manifest=collector.directory_manifest(checkpoint)
    mf=write(root/'run_state/model_manifests/FAKE_TEST_ONLY/files.json',manifest)
    pf=write(root/'run_state/model_manifests/FAKE_TEST_ONLY/provenance.json',{'origin':'FAKE_TEST_ONLY'})
    model={'run_id':'FAKE_TEST_ONLY','objective':'explicit_1p4','policy':'R_ID','seed':42,
        'checkpoint_path':str(checkpoint),'checkpoint_manifest_sha256':collector.sha_json(manifest),
        'checkpoint_manifest_path':mf.relative_to(root).as_posix(),'checkpoint_manifest_file_sha256':collector.sha(mf),
        'provenance_path':pf.relative_to(root).as_posix(),'provenance_sha256':collector.sha(pf),
        'model_sha256':collector.sha(checkpoint/'model.safetensors')}
    write(root/'run_state/training_queue_progress.json',{'ready':1,'expected':20,'ready_models':[model]})
    return root,old,checkpoint,model


class PackagingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.root,self.old,self.checkpoint,self.model=fixture(self.base)
        self.output=self.base/'return.zip'

    def tearDown(self):self.temp.cleanup()

    def add_fake_reuse_evidence(self):
        """Create 6 fake historical control records; no real scientific labels/results."""
        records=[]
        def record(relative, data):
            p=write(self.old/relative,data)
            value={'gpu_work_relative_path':relative,'bytes':p.stat().st_size,'sha256':collector.sha(p)}
            records.append(value);return value
        global_record=record('publication/audit/FAKE_TEST_ONLY.json',{'purpose':'FAKE_TEST_ONLY'})
        controls=[]
        for i in range(6):
            prefix=f'repro/results/FAKE_TEST_ONLY_{i}/'
            controls.append({'training_evidence':{'files':{n:record(prefix+n,b'FAKE_TEST_ONLY_OLD_EVIDENCE')
                for n in ('config.json','training.json','loss.jsonl')}},
                'cross_stage_evidence':{'per_update_file':record(f'publication/audit/FAKE_TEST_ONLY_{i}.csv',b'FAKE_TEST_ONLY_PREFIX')}})
        write(self.root/'reuse_expectations.json',{'global_evidence':[global_record],'controls':controls})
        write(self.root/'run_state/reuse_decision.json',{'reused_controls':[{'purpose':'FAKE_TEST_ONLY'}]*6})
        write(self.root/'run_state/execution_lock.json',{'gpu_work_root':str(self.old),'model_path':str(self.checkpoint)})
        write(self.root/'pretrained_model_identity.json',{'expected_files':collector.directory_manifest(self.checkpoint)})
        return records

    def test_partial_status_manifest_weight_transport_and_old_immutability(self):
        before=collector.directory_manifest(self.old)
        report=collector.collect(self.root,self.output,partial=True)
        self.assertEqual(report['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
        self.assertEqual(before,collector.directory_manifest(self.old))
        with zipfile.ZipFile(self.output) as z:
            status=json.loads(z.read('RETURN_STATUS.json'))
            self.assertEqual(status['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
            self.assertEqual(status['final_weights_included'],1)
            self.assertEqual(z.read('returned_models/FAKE_TEST_ONLY/model.safetensors'),b'FAKE_TEST_ONLY_FINAL_WEIGHTS')
            self.assertIn('run_state/command_logs/failed.log',z.namelist())
            self.assertNotIn('run_state/train_runs/failed/latest_resume.pt',z.namelist())
            self.assertTrue(any(r['path'].endswith('latest_resume.pt') for r in json.loads(z.read('retained_on_gpu_manifest.json'))['files']))
            manifest=json.loads(z.read('RETURN_MANIFEST.json'))
            self.assertEqual(len(z.namelist()),len(set(z.namelist())))
            self.assertEqual(set(z.namelist()),set(manifest['files'])|{'RETURN_MANIFEST.json'})
            for name,entry in manifest['files'].items():
                data=z.read(name)
                self.assertEqual(len(data),entry['bytes'])
                self.assertEqual(hashlib.sha256(data).hexdigest(),entry['sha256'])

    def test_incomplete_cannot_package_as_complete(self):
        with self.assertRaisesRegex(ValueError,'incomplete'):
            collector.collect(self.root,self.output,partial=False)
        self.assertFalse(self.output.exists())

    def test_forged_completion_count_rejected(self):
        write(self.root/'run_state/STUDY_COMPLETE.json',{'scientific_cells':19,'evaluations':99})
        with self.assertRaisesRegex(ValueError,'Wrong study count'):
            collector.collect(self.root,self.output,partial=False)
        self.assertFalse(self.output.exists())

    def test_existing_archive_is_not_overwritten(self):
        self.output.write_bytes(b'EXISTING_DO_NOT_OVERWRITE')
        with self.assertRaises(ValueError):collector.collect(self.root,self.output,partial=True)
        self.assertEqual(self.output.read_bytes(),b'EXISTING_DO_NOT_OVERWRITE')

    def test_existing_checksum_is_not_overwritten(self):
        checksum=self.output.with_suffix('.zip.sha256.txt')
        checksum.write_bytes(b'EXISTING_CHECKSUM_DO_NOT_OVERWRITE')
        with self.assertRaises(ValueError):collector.collect(self.root,self.output,partial=True)
        self.assertEqual(checksum.read_bytes(),b'EXISTING_CHECKSUM_DO_NOT_OVERWRITE')
        self.assertFalse(self.output.exists())

    def test_partial_corrupt_model_exports_logs_with_accurate_zero_count(self):
        (self.checkpoint/'model.safetensors').write_bytes(b'CHANGED_FAKE_WEIGHT')
        report=collector.collect(self.root,self.output,partial=True)
        self.assertEqual(report['final_weights'],0)
        with zipfile.ZipFile(self.output) as z:
            status=json.loads(z.read('RETURN_STATUS.json'))
            self.assertEqual(status['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
            self.assertEqual(status['final_weights_included'],0)
            self.assertEqual(len(status['unexported_models']),1)
            self.assertEqual(json.loads(z.read('portable_models_ready.json'))['models'],[])
            self.assertIn('run_state/command_logs/failed.log',z.namelist())

    def test_partial_missing_base_is_disclosed_without_discarding_logs(self):
        write(self.root/'run_state/execution_lock.json',{'gpu_work_root':str(self.old),'model_path':str(self.old/'missing_base')})
        write(self.root/'pretrained_model_identity.json',{'expected_files':{'model.safetensors':{'bytes':1,'sha256':'0'*64}}})
        result=collector.collect(self.root,self.output,partial=True)
        self.assertEqual(result['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
        with zipfile.ZipFile(self.output) as z:
            self.assertEqual(json.loads(z.read('RETURN_STATUS.json'))['base_model']['status'],'MISSING_OR_CHANGED')

    def test_output_cannot_enter_old_work_tree(self):
        write(self.root/'run_state/execution_lock.json',{'gpu_work_root':str(self.old),'model_path':str(self.old/'base')})
        target=self.old/'do_not_write.zip'
        with self.assertRaisesRegex(ValueError,'old work/model'):
            collector.collect(self.root,target,partial=True)
        self.assertFalse(target.exists())

    def test_portable_manifest_and_provenance_paths_are_relative(self):
        model=dict(self.model)
        for key in ('checkpoint_manifest_path','provenance_path'):
            model[key]=str((self.root/model[key]).resolve())
        write(self.root/'run_state/training_queue_progress.json',{'ready_models':[model]})
        collector.collect(self.root,self.output,partial=True)
        with zipfile.ZipFile(self.output) as z:
            portable=json.loads(z.read('portable_models_ready.json'))['models'][0]
            for key in ('checkpoint_path','checkpoint_manifest_path','provenance_path'):
                self.assertFalse(Path(portable[key]).is_absolute())
            self.assertIn(portable['checkpoint_manifest_path'],z.namelist())
            self.assertIn(portable['provenance_path'],z.namelist())

    def test_output_cannot_enter_package(self):
        with self.assertRaisesRegex(ValueError,'outside'):
            collector.collect(self.root,self.root/'new.zip',partial=True)

    def test_reserved_return_file_cannot_create_duplicate_zip_entries(self):
        write(self.root/'RETURN_STATUS.json',{'status':'FAKE_TEST_ONLY_COLLISION'})
        with self.assertRaises(ValueError):collector.collect(self.root,self.output,partial=True)
        self.assertFalse(self.output.exists())

    def test_manifest_does_not_include_running_lock_or_bytecode(self):
        write(self.root/'run_state/runner_active.lock',b'FAKE_TEST_ONLY_LOCK')
        write(self.root/'code/__pycache__/fake.pyc',b'FAKE_TEST_ONLY_BYTECODE')
        collector.collect(self.root,self.output,partial=True)
        with zipfile.ZipFile(self.output) as z:
            self.assertFalse(any('__pycache__' in n or n.endswith('runner_active.lock') for n in z.namelist()))

    def test_partial_with_no_ready_models_still_preserves_logs(self):
        (self.root/'run_state/training_queue_progress.json').unlink()
        result=collector.collect(self.root,self.output,partial=True)
        self.assertEqual(result['final_weights'],0)
        self.assertEqual(result['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
        with zipfile.ZipFile(self.output) as z:self.assertIn('run_state/command_logs/failed.log',z.namelist())

    def test_all_six_raw_reuse_evidence_sets_are_transported_unchanged(self):
        records=self.add_fake_reuse_evidence();before=collector.directory_manifest(self.old)
        collector.collect(self.root,self.output,partial=True)
        self.assertEqual(before,collector.directory_manifest(self.old))
        with zipfile.ZipFile(self.output) as z:
            manifest=json.loads(z.read('returned_reuse_evidence_manifest.json'))
            self.assertEqual(len(manifest['files']),25)
            self.assertEqual(manifest['unexported'],[])
            for r in records:
                data=z.read('returned_reuse_evidence/'+r['gpu_work_relative_path'])
                self.assertEqual(len(data),r['bytes'])
                self.assertEqual(hashlib.sha256(data).hexdigest(),r['sha256'])

    def test_missing_reuse_evidence_is_disclosed_partial_and_blocks_full(self):
        records=self.add_fake_reuse_evidence();missing=records[3]
        (self.old/missing['gpu_work_relative_path']).unlink()
        collector.collect(self.root,self.output,partial=True)
        with zipfile.ZipFile(self.output) as z:
            manifest=json.loads(z.read('returned_reuse_evidence_manifest.json'))
            self.assertEqual(len(manifest['files']),24)
            self.assertEqual(len(manifest['unexported']),1)
            self.assertEqual(manifest['unexported'][0]['record'],missing)
            self.assertEqual(json.loads(z.read('RETURN_STATUS.json'))['status'],'PARTIAL_DO_NOT_TREAT_AS_COMPLETE')
        # Isolate the collector's strict evidence-export branch. The expensive
        # scientific validators are mocked ONLY here; this never claims a valid
        # 20-model/100-evaluation synthetic scientific study.
        state=self.root/'run_state'
        models=write(state/'models_ready.json',{'models':[self.model],'purpose':'FAKE_TEST_ONLY'})
        ac=write(state/'analysis_batch01/analysis_complete.json',{'purpose':'FAKE_TEST_ONLY'})
        ec=write(state/'evaluation_batch01/evaluation_complete.json',{'purpose':'FAKE_TEST_ONLY'})
        write(state/'SESSION_FINDINGS.txt',b'FAKE_TEST_ONLY_FULL_BRANCH_TEST')
        write(state/'STUDY_COMPLETE.json',{'scientific_cells':20,'evaluations':100,
            'models_registry_sha256':collector.sha(models),'analysis_complete_sha256':collector.sha(ac),
            'evaluation_complete_sha256':collector.sha(ec),'purpose':'FAKE_TEST_ONLY_WITH_MOCKED_PREREQUISITES'})
        full_output=self.base/'full_should_not_exist.zip'
        with patch.dict(sys.modules,{'bridge_check_results':SimpleNamespace(check=lambda *a:None)}),\
             patch.object(collector,'validate_plan',return_value=(self.root,{},[])),\
             patch.object(collector,'validate_models',return_value=[self.model]):
            with self.assertRaises((FileNotFoundError,ValueError)):
                collector.collect(self.root,full_output,partial=False)
        self.assertFalse(full_output.exists())


class QueueGuardTests(unittest.TestCase):
    def test_prepare_rejects_package_inside_old_work_before_runtime(self):
        with tempfile.TemporaryDirectory() as folder:
            old=Path(folder)/'old';root=old/'nested_package';root.mkdir(parents=True)
            with patch.object(runner,'ROOT',root),patch.object(runner,'STATE',root/'run_state'),\
                 patch.object(runner,'inspect',return_value={'package_manifest_sha256':'fake'}),\
                 patch.object(runner,'read',return_value={'cells':[]}),\
                 patch.object(runner,'runtime',side_effect=AssertionError('Must stop before GPU runtime')):
                with self.assertRaisesRegex(ValueError,'old work tree'):
                    runner.prepare(SimpleNamespace(gpu_work_root=str(old),model_path=None))

    def test_prepare_rejects_old_work_nested_inside_package(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'package';old=root/'old_work';old.mkdir(parents=True)
            with patch.object(runner,'ROOT',root),patch.object(runner,'STATE',root/'run_state'),\
                 patch.object(runner,'inspect',return_value={'package_manifest_sha256':'fake'}),\
                 patch.object(runner,'read',return_value={'cells':[]}),\
                 patch.object(runner,'runtime',side_effect=AssertionError('Must stop before GPU runtime')):
                with self.assertRaisesRegex(ValueError,'old work tree'):
                    runner.prepare(SimpleNamespace(gpu_work_root=str(old),model_path=None))

    def test_prepare_rejects_old_work_equal_to_new_state(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'package';old=root/'run_state';old.mkdir(parents=True)
            with patch.object(runner,'ROOT',root),patch.object(runner,'STATE',old),\
                 patch.object(runner,'inspect',return_value={'package_manifest_sha256':'fake'}),\
                 patch.object(runner,'read',return_value={'cells':[]}),\
                 patch.object(runner,'runtime',side_effect=AssertionError('Must stop before GPU runtime')):
                with self.assertRaisesRegex(ValueError,'old work tree'):
                    runner.prepare(SimpleNamespace(gpu_work_root=str(old),model_path=None))

    def test_missing_or_failed_attempt_is_not_completed(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'attempt'
            self.assertFalse(runner.completed_attempt(p,{}))
            write(p/'status.json',{'status':'failed'})
            self.assertFalse(runner.completed_attempt(p,{}))

    def test_exclusive_lock_prevents_second_runner_and_keeps_existing_lock(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(runner,'STATE',Path(folder)/'state'):
            with runner.exclusive():
                original=(runner.STATE/'runner_active.lock').read_bytes()
                with self.assertRaises(FileExistsError):
                    with runner.exclusive():pass
                self.assertEqual((runner.STATE/'runner_active.lock').read_bytes(),original)
            self.assertFalse((runner.STATE/'runner_active.lock').exists())


if __name__=='__main__':unittest.main(verbosity=2)
