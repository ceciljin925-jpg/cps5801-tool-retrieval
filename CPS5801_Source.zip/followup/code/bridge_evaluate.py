"""Evaluate the complete, locked 20-cell bridge study on five frozen tasks.

The data were previously inspected. All results are post hoc follow-up evidence.
--validate-only imports no torch and writes nothing. Technical reruns preserve
failed attempt folders; use --retry-incomplete after documenting the diagnosis.
"""
from __future__ import annotations
import argparse,importlib,pathlib,sys,traceback,json
from bridge_eval_io import *

CODE=pathlib.Path(__file__).resolve().parent

def sources():
    names=['bridge_evaluate.py','bridge_eval_io.py','bridge_analyze.py','bridge_figures.py','bridge_check_results.py','vendor/evaluate_retrieval.py','vendor/encoders.py']
    return {name:sha(CODE/name) for name in names}

def public_dataset(d):return {k:v for k,v in d.items() if not k.startswith('_')}

def prepare_lock(plan_path,models_path,out,device='cuda'):
    root,plan,data=validate_plan(plan_path);models=validate_models(root,plan,models_path)
    evaluations=[]
    for d in data:
        for m in models:
            evaluations.append({'evaluation_id':d['dataset']+'__'+m['run_id'],'dataset':d['dataset'],
                'run_id':m['run_id'],'objective':m['objective'],'policy':m['policy'],'seed':m['seed'],
                'checkpoint_manifest_sha256':m['checkpoint_manifest_sha256'],
                'queries_sha256':d['queries_sha256'],'corpus_sha256':d['corpus_sha256'],
                'group_map_sha256':d['group_map_sha256']})
    lock={'schema':'bridge_evaluation_lock_v1','created_at':now(),'evidence_stage':'posthoc_followup',
          'previously_observed_evaluation_data':True,'no_fresh_confirmation_claim':True,
          'plan_sha256':sha(plan_path),'models_registry_sha256':sha(models_path),'code':sources(),
          'datasets':[public_dataset(d) for d in data], 'models':models,'evaluations':evaluations,
          'evaluation_recipe':{'family':'e5','device':device,'batch_size':64,'query_block_size':32,
              'save_embeddings':True,'latency_count':0,'latency_warmups':0,
              'precision':'float32;TF32 disabled','tie_break':'frozen menu tie keys; pooled corpus ID'},
          'scope':'20 predetermined models, all five tasks, no checkpoint/seed selection; no new Qwen/BGE baseline sweep.'}
    lockpath=out/'evaluation_lock.json'
    if lockpath.exists():
        old=read(lockpath)
        for k in ('plan_sha256','models_registry_sha256','code','evaluation_recipe','evaluations','models','datasets'):
            require(old[k]==lock[k],'Frozen evaluation identity changed: '+k)
        lock=old
    else:
        require(not out.exists() or not any(out.iterdir()),'Output exists without valid lock; preserve and choose new batch directory')
        out.mkdir(parents=True,exist_ok=True);dump(lockpath,lock)
        dump(out/'evaluation_lock.sha256.json',{'sha256':sha(lockpath),'created_at':now()})
    require(read(out/'evaluation_lock.sha256.json')['sha256']==sha(lockpath),'Evaluation lock bytes changed')
    return root,plan,data,models,lock

def run(plan_path,models_path,output,*,device='cuda',retry_incomplete=False):
    root=pathlib.Path(plan_path).resolve(strict=True).parent;out=safe_output(root,output)
    root,plan,data,models,lock=prepare_lock(plan_path,models_path,out,device)
    regpath=out/'evaluation_registry.json';lockpath=out/'evaluation_lock.json'
    if regpath.exists():
        reg=read(regpath);require(reg['lock_sha256']==sha(lockpath),'Registry lock mismatch')
    else:
        reg={'schema':'bridge_evaluation_registry_v1','evidence_stage':'posthoc_followup',
             'lock_sha256':sha(lockpath),'evaluations':[{**e,'status':'pending','attempts':[]} for e in lock['evaluations']]}
        dump(regpath,reg)
    require({j['evaluation_id'] for j in reg['evaluations']}=={j['evaluation_id'] for j in lock['evaluations']} and len(reg['evaluations'])==100,'Evaluation registry must retain all 100 jobs')
    sys.path.insert(0,str(CODE/'vendor'))
    vendor=importlib.import_module('evaluate_retrieval')
    dm={d['dataset']:d for d in data};mm={m['run_id']:m for m in models}
    for job in reg['evaluations']:
        for key in ('run_id','objective','policy','seed','dataset','checkpoint_manifest_sha256','queries_sha256','corpus_sha256','group_map_sha256'):
            original=next(e for e in lock['evaluations'] if e['evaluation_id']==job['evaluation_id'])
            require(job[key]==original[key],'Job identity changed: '+key)
        if job['status']=='completed':
            last=out/job['attempts'][-1]['relative_path']
            require(read(last/'status.json')['status']=='completed','Completed evaluation status changed')
            for name,digest in job['evidence_hashes'].items():require(sha(last/name)==digest,'Completed evidence changed: '+name)
            continue
        require(job['status']=='pending' or retry_incomplete,'Incomplete attempt requires explicit --retry-incomplete; preserve all failed evidence')
        require(len(job['attempts'])<2,'Two attempts already retained for this evaluation; no further automated retry is authorized')
        d,m=dm[job['dataset']],mm[job['run_id']]
        require(sha(d['queries_path'])==d['queries_sha256'] and sha(d['corpus_path'])==d['corpus_sha256'],'Dataset changed after lock')
        require(sha_json(directory_manifest(m['checkpoint_path']))==m['checkpoint_manifest_sha256'],'Checkpoint changed after lock')
        require(sources()==lock['code'],'Code changed after lock')
        index=len(job['attempts'])+1
        attempt=out/'evaluations'/d['dataset']/m['run_id']/f'attempt_{index:02d}'
        require(not attempt.exists(),'Attempt already exists; never overwrite')
        config={'run_id':m['run_id'],'family':'e5','model_path':m['checkpoint_path'],
            'queries_path':d['queries_path'],'corpus_path':d['corpus_path'],'task_type':d['task_type'],
            'external_final':True,'evaluation_id':job['evaluation_id'],'final_lock_path':str(lockpath),
            'access_log_path':str(out/'model_scoring_access.jsonl'),'device':device,'batch_size':64,
            'query_block_size':32,'save_embeddings':True,'latency_count':0,'latency_warmups':0,
            'document_equivalence_sensitivity':d['dataset']=='toolhop',
            'allowed_empty_query_ids':['mnms_query_17'] if d['dataset']=='legacy_observed_test' else [],
            'evidence_stage':'posthoc_followup','previously_observed_evaluation_data':True,
            'objective':m['objective'],'policy':m['policy'],'seed':m['seed'],
            'bridge_lock_sha256':sha(lockpath),'group_map_sha256':d['group_map_sha256']}
        job['attempts'].append({'number':index,'relative_path':str(attempt.relative_to(out)).replace('\\','/'),'started_at':now()})
        job['status']='running';dump(regpath,reg)
        try:
            report=vendor.evaluate(config,attempt)
            require(report['n']==len(d['_queries']),'Query count differs from frozen data')
            hashes={name:sha(attempt/name) for name in ('predictions.json','metrics.json','config.json','status.json','environment.json','tokenization.json','embedding_mapping.json','embedding_manifest.json')}
            job.update(status='completed',completed_at=now(),evidence_hashes=hashes,
                       predictions_sha256=hashes['predictions.json'],metrics_sha256=hashes['metrics.json'],
                       output_relative_path=str(attempt.relative_to(out)).replace('\\','/'))
        except BaseException as exc:
            job.update(status='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed',error=repr(exc),traceback=traceback.format_exc(),failed_at=now())
            dump(regpath,reg);raise
        dump(regpath,reg);print('BRIDGE_EVALUATED',job['evaluation_id'],flush=True)
    dump(out/'evaluation_complete.json',{'completed_at':now(),'evaluations':100,'models':20,
         'lock_sha256':sha(lockpath),'registry_sha256':sha(regpath),'evidence_stage':'posthoc_followup'})

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',required=True,type=pathlib.Path)
    p.add_argument('--models',required=True,type=pathlib.Path);p.add_argument('--output',default='run_state/evaluation_batch01')
    p.add_argument('--device',default='cuda');p.add_argument('--validate-only',action='store_true');p.add_argument('--retry-incomplete',action='store_true')
    a=p.parse_args();a.plan=a.plan.resolve(strict=True)
    if not a.models.is_absolute():a.models=(a.plan.parent/a.models).resolve(strict=True)
    if a.validate_only:
        root,plan,data=validate_plan(a.plan);models=validate_models(root,plan,a.models)
        print(json.dumps({'status':'VALIDATED_NO_EVALUATION_RUN','models':len(models),'datasets':len(data),'evaluations':100,'evidence_stage':'posthoc_followup'}));return
    require(a.device.startswith('cuda'),'Scientific bridge inference uses the locked CUDA FP32 path')
    run(a.plan,a.models,a.output,device=a.device,retry_incomplete=a.retry_incomplete)
if __name__=='__main__':main()
