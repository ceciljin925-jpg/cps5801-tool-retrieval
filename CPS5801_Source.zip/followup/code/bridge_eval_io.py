"""Standard-library identity and plan checks shared by bridge evaluation/rebuild."""
from __future__ import annotations
import hashlib,json,math,pathlib,datetime

OBJECTIVES=('explicit_1p4','explicit_1p4_plus_inbatch_positives')
POLICIES=('R_ID','B_ID')
SEEDS=(42,43,44,45,46)
DATASETS={'legacy_observed_test':(7961,7408,'pooled'),
          'bfcl_live_multiple':(1050,220,'menu'),
          'bfcl_multiple':(199,195,'menu'),
          'bfcl_parallel_multiple':(22,22,'menu'),
          'toolhop':(994,984,'pooled')}

def require(value,message):
    if not value: raise ValueError(message)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))
def sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def sha_json(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def dump(path,value):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');temp.replace(p)
def resolve(root,path):
    p=pathlib.Path(path);return (p if p.is_absolute() else root/p).resolve(strict=True)
def directory_manifest(path):
    p=pathlib.Path(path).resolve(strict=True)
    return {str(f.relative_to(p)).replace('\\','/'):{'bytes':f.stat().st_size,'sha256':sha(f)}
            for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and not f.name.endswith('.tmp')}
def checked_file(root,path,expected,label):
    require(isinstance(expected,str) and len(expected)==64,'Missing SHA256 for '+label)
    p=resolve(root,path);require(sha(p)==expected,'Input identity changed: '+label);return p
def safe_output(root,path):
    p=pathlib.Path(path)
    if not p.is_absolute():p=root/p
    p=p.resolve();require(p!=root and root in p.parents,'Output must be under the new bridge package: '+str(root))
    require(not any(x in ('inputs','assets','code','reference','source_evidence') for x in p.relative_to(root).parts),'Output path overlaps immutable inputs/code')
    return p
def cell_key(row):return (row['objective'],row['policy'],row['seed'])
def method_key(row):return row['objective']+'__'+row['policy']
def validate_plan(path,*,fixture=False):
    path=pathlib.Path(path).resolve(strict=True);root=path.parent;plan=read(path)
    expected={(o,p,s) for o in OBJECTIVES for p in POLICIES for s in SEEDS}
    cells=plan.get('cells',[])
    require(len(cells)==20 and {cell_key(c) for c in cells}==expected,'Plan must contain all 20 predetermined cells')
    require(len({c['run_id'] for c in cells})==20,'Duplicate run ID')
    ds=plan.get('datasets',[]);require({d['dataset'] for d in ds}==set(DATASETS) and len(ds)==5,'Exactly five frozen evaluation datasets required')
    checked=[]
    for d in ds:
        name=d['dataset'];n,ng,task=DATASETS[name]
        qpath=checked_file(root,d['queries_path'],d['queries_sha256'],name+' queries')
        cpath=checked_file(root,d['corpus_path'],d['corpus_sha256'],name+' corpus')
        gpath=checked_file(root,d['group_map_path'],d['group_map_sha256'],name+' groups')
        queries,corpus,groups=read(qpath),read(cpath),read(gpath)
        if isinstance(groups,dict) and 'query_groups' in groups:groups=groups['query_groups']
        require(isinstance(groups,dict),'Group map must be query_id -> group_id')
        qids=[q['id'] for q in queries];cids={c['id'] for c in corpus}
        require(len(set(qids))==len(qids) and len(cids)==len(corpus),'Duplicate query/corpus ID')
        require(set(groups)==set(qids) and all(isinstance(x,str) and x for x in groups.values()),'Exact nonempty group map required')
        normalized_task='menu' if d['task_type']=='native_menu' else d['task_type']
        require(normalized_task==task,'Task projection changed: '+name)
        if not fixture:
            require(len(qids)==n and len(set(groups.values()))==ng,'Frozen population/group count changed: '+name)
            require(d.get('expected_queries',n)==n and d.get('expected_groups',ng)==ng,'Plan count mismatch')
        for q in queries:
            menu=q.get('candidate_ids') if task=='menu' else cids
            require(bool(q['positives']) and len(set(q['positives']))==len(q['positives']) and set(q['positives'])<=set(menu)<=cids,'Invalid gold/menu')
            if 'group_id' in q: require(q['group_id']==groups[q['id']],'Group map disagrees with frozen query')
            if task=='menu':
                require(len(set(menu))==len(menu)>0,'Empty or duplicated menu IDs')
                require(set(q['candidate_tie_break_keys'])==set(menu) and len(set(q['candidate_tie_break_keys'].values()))==len(menu),'Menu tie keys missing or duplicated')
        checked.append({**d,'task_type':normalized_task,'queries_path':str(qpath),'corpus_path':str(cpath),'group_map_path':str(gpath),
                        '_queries':queries,'_corpus':corpus,'_groups':groups})
    return root,plan,checked
def validate_models(root,plan,path):
    data=read(path);models=data['models'] if isinstance(data,dict) else data
    require(len(models)==20,'Exactly 20 model identities required before any evaluation')
    by={cell_key(c):c for c in plan['cells']};require({cell_key(m) for m in models}==set(by),'Missing/duplicate factorial cell')
    require(len({m['run_id'] for m in models})==20,'Duplicate model run ID')
    answer=[]
    for m in models:
        require(m['run_id']==by[cell_key(m)]['run_id'],'Model run ID disagrees with cell')
        checkpoint=resolve(root,m['checkpoint_path'])
        expected=checked_file(root,m['checkpoint_manifest_path'],m.get('checkpoint_manifest_file_sha256',m.get('checkpoint_manifest_path_sha256')),'checkpoint manifest')
        expected_data=read(expected)
        if 'files' in expected_data and isinstance(expected_data['files'],dict):expected_data=expected_data['files']
        actual=directory_manifest(checkpoint);require(actual==expected_data,'Checkpoint directory differs from its manifest: '+m['run_id'])
        ident=sha_json(actual)
        if m.get('checkpoint_manifest_sha256'):require(ident==m['checkpoint_manifest_sha256'],'Canonical checkpoint identity mismatch')
        if m.get('model_sha256'):require(sha(checkpoint/'model.safetensors')==m['model_sha256'],'Model weight hash mismatch')
        provenance=checked_file(root,m['provenance_path'],m.get('provenance_sha256',m.get('provenance_path_sha256')),'model provenance')
        answer.append({**m,'checkpoint_path':str(checkpoint),'checkpoint_manifest_path':str(expected),
                       'checkpoint_manifest_sha256':ident,'checkpoint_manifest':actual,'provenance_path':str(provenance)})
    return answer
