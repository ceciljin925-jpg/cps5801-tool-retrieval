"""Only the explicit-plus-other-positive loss and its auditable train update.

Torch is imported lazily so mask and mathematical CPU tests need no GPU packages.
All extras use already encoded positive rows; there is no detach or extra forward.
"""
import math
from mask_core import plan_microbatch


def append_extra_logits(q, d, base_logits, plan, temperature):
    import torch
    b = q.shape[0]
    if d.shape[:2] != (b, 5) or plan['microbatch_size'] != b:
        raise ValueError('Expected original B x 5 candidates and matching plan')
    if b == 1 or not any(any(a['eligible']) for a in plan['anchors']):
        return base_logits
    source = torch.tensor([a['source_rows'] for a in plan['anchors']], dtype=torch.long, device=q.device)
    allowed = torch.tensor([a['eligible'] for a in plan['anchors']], dtype=torch.bool, device=q.device)
    # Each row selects the other already-encoded positive embeddings in row order.
    extra = (q[:, None, :] * d[:, 0, :][source]).sum(-1) / temperature
    return torch.cat((base_logits, extra.masked_fill(~allowed, float('-inf'))), dim=1)


def update_with_extras(encoder, optimizer, batch, negatives, qtokens, dtokens,
                       microbatch, temperature, known, forbidden, signatures,
                       expected_plans=None):
    """Original forward order, bf16 boundary, loss weighting, clipping and AdamW."""
    import torch
    model, tok, device = encoder.model, encoder.tokenizer, encoder.device
    optimizer.zero_grad(set_to_none=True)
    weighted = 0
    for micro_index, a in enumerate(range(0, len(batch), microbatch)):
        mb = batch[a:a + microbatch]
        plan = plan_microbatch(mb, negatives, known, forbidden, signatures)
        if expected_plans is not None and plan != expected_plans[micro_index]['plan']:
            raise RuntimeError('Consumed mask differs from frozen microbatch plan')
        qs = tok.pad([qtokens[s['query_id']] for s in mb], padding=True, return_tensors='pt').to(device)
        ids = [tid for s in mb for tid in [s['positive']] + negatives[s['query_id']]]
        ds = tok.pad([dtokens[tid] for tid in ids], padding=True, return_tensors='pt').to(device)
        with torch.autocast('cuda', dtype=torch.bfloat16):
            q = encoder.pool(qs)
            d = encoder.pool(ds).view(len(mb), 5, -1)
            logits = (q[:, None, :] * d).sum(-1) / temperature
            logits = append_extra_logits(q, d, logits, plan, temperature)
            loss = torch.nn.functional.cross_entropy(logits, torch.zeros(len(mb), dtype=torch.long, device=device))
        if not torch.isfinite(loss):
            raise RuntimeError('Nonfinite loss')
        (loss * len(mb) / len(batch)).backward()
        weighted += loss.item() * len(mb) / len(batch)
    grad = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0))
    if not math.isfinite(grad):
        raise RuntimeError('Nonfinite gradient norm')
    optimizer.step()
    return weighted, grad
