"""One-machine queue for the fixed bridge. Never changes old experiment files.

inspect is CPU-only. all performs prepare -> CUDA preflight -> train -> lock all
models -> 100 evaluations -> CPU reconstruction. collect is a separate command.
"""
from __future__ import annotations
import argparse, contextlib, math, os, pathlib, shutil, subprocess, sys, time
from bridge_eval_io import read, dump, sha, sha_json, directory_manifest, require, now, validate_plan, validate_models

ROOT=pathlib.Path(__file__).resolve().parents[1]
CODE=ROOT/'code'
STATE=ROOT/'run_state'

def inspect():
    manifest=read(ROOT/'PACKAGE_MANIFEST.json')
    for rel,rec in manifest['files'].items():
        p=(ROOT/rel).resolve(strict=True)
        require(ROOT in p.parents and p.is_file(), 'Unsafe package manifest entry')
        require(p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],'Package file changed: '+rel)
    root,plan,data=validate_plan(ROOT/'bridge_plan.json')
    for rec in read(ROOT/'input_manifest.json')['copied_files']:
        p=ROOT/rec['path'];require(p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],'Frozen input mismatch: '+rec['path'])
    return {'status':'PASS_CPU_PACKAGE_IDENTITY','package_manifest_sha256':sha(ROOT/'PACKAGE_MANIFEST.json'),
            'cells':len(plan['cells']),'datasets':len(data),'evaluations':100,'gpu_preflight':'NOT_RUN_BY_INSPECT'}

def run_child(args, label):
    folder=STATE/'command_logs';folder.mkdir(parents=True,exist_ok=True)
    stamp=str(time.time_ns());log=folder/(stamp+'_'+label+'.log')
    command=[sys.executable,*[str(x) for x in args]]
    record={'started_at':now(),'command':command,'log':str(log.relative_to(ROOT))}
    with log.open('wb') as stream:
        result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,
                              env={**os.environ,'PYTHONUNBUFFERED':'1','PYTHONIOENCODING':'utf-8','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'})
    record.update(finished_at=now(),returncode=result.returncode)
    dump(log.with_suffix('.json'),record)
    require(result.returncode==0,'Step failed; preserved log: '+str(log))
    print('COMPLETED',label,flush=True)

def runtime():
    from train_bridge import load_vendor
    v,e=load_vendor();e.setup_runtime('cuda')
    return e.runtime_record()

def same_runtime(a,b):
    return {k:v for k,v in a.items() if k not in ('created_at','executable')}=={k:v for k,v in b.items() if k not in ('created_at','executable')}

def prepare(args):
    inspection=inspect();plan=read(ROOT/'bridge_plan.json')
    old=pathlib.Path(args.gpu_work_root).resolve()
    model=pathlib.Path(args.model_path).resolve() if args.model_path else old/'repro/data/raw/model'
    require(old!=ROOT and old not in ROOT.parents and ROOT not in old.parents,'New package and old work tree must not overlap')
    require(shutil.disk_usage(ROOT).free>=25*2**30,'Keep at least 25 GiB free for weights, recovery states, predictions and archive')
    import train_bridge as trainer
    current=runtime()
    static={'package_manifest_sha256':inspection['package_manifest_sha256'],'plan_sha256':sha(ROOT/'bridge_plan.json'),
            'gpu_work_root':str(old),'model_path':str(model),'reuse_mode':args.reuse,'training_code':trainer.code_identity()}
    if (STATE/'execution_lock.json').exists():
        lock=read(STATE/'execution_lock.json')
        require(all(lock[k]==v for k,v in static.items()),'Execution lock changed; preserve original package/run_state and investigate')
        require(same_runtime(lock['runtime'],current),'Runtime changed after prepare; do not mix environments')
        for name,digest in lock['configs'].items():require(sha(ROOT/name)==digest,'Frozen config changed')
        return lock
    require(not (STATE/'configs').exists(),'Partial prepare exists; inspect and preserve it before a new clean extraction')
    STATE.mkdir(parents=True,exist_ok=True);configs={}
    for cell in plan['cells']:
        conf={**plan['fixed_recipe'],**{k:cell[k] for k in ('run_id','objective','policy','seed')},
              **{k:str((ROOT/v).resolve()) for k,v in plan['training'].items()},
              'model_path':str(model),'output_root':str(STATE/'train_runs'),
              'schedule_path':str(ROOT/'inputs/training'/f"schedule_seed{cell['seed']}.json"),
              'negatives_path':str(ROOT/'inputs/training'/f"{cell['policy']}_seed{cell['seed']}.json")}
        conf['input_hashes']={conf[k]:sha(conf[k]) for k in trainer.DATA_FIELDS}
        trainer.validate_config(conf)
        path=STATE/'configs'/(cell['run_id']+'.json');dump(path,conf);configs[str(path.relative_to(ROOT)).replace('\\','/')]=sha(path)
    lock={**static,'runtime':current,'created_at':now(),'configs':configs,'scientific_cells':20,'evaluations':100}
    dump(STATE/'execution_lock.json',lock)
    return lock

def preflight(lock):
    from train_bridge import code_identity
    path=STATE/'preflight'/'preflight_report.json'
    config=STATE/'configs/BRIDGE_E5_EXPLICIT_R_ID_s42.json'
    if not path.exists():
        require(not (STATE/'preflight').exists(),'Interrupted preflight folder must be preserved; investigate before a clean extraction')
        run_child([CODE/'gpu_smoke_bridge.py','--config',config,'--output',path.parent],'gpu_preflight')
    report=read(path)
    require(report['status']=='PASS' and report['source_hashes']==code_identity(),'Current GPU/code acceptance did not pass')
    require(report['formal_config_sha256']==sha_json(read(config)),'Preflight used a different formal configuration')
    require(report['base_model_weight_sha256']==sha(pathlib.Path(lock['model_path'])/'model.safetensors'),'Preflight base weight differs')
    require(same_runtime(report['runtime'],lock['runtime']),'Preflight environment differs')
    return report

def reuse_decision(lock,smoke):
    from bridge_reuse import inspect_reuse
    p=STATE/'reuse_decision.json'
    fresh=inspect_reuse(ROOT,pathlib.Path(lock['gpu_work_root']),lock['runtime'],smoke)
    if lock['reuse_mode']=='never':fresh.update(eligible=False,reasons=fresh.get('reasons',[])+['User/session selected full fresh matrix before training'])
    chosen=fresh['controls_verified'] if fresh['eligible'] else []
    selection={(c['policy'],c['seed']):c for c in chosen}
    require(len(selection) in (0,6),'Reuse must be all six or none')
    identity={'execution_lock_sha256':sha(STATE/'execution_lock.json'),'preflight_sha256':sha(STATE/'preflight/preflight_report.json'),
              'mode':'reuse_all_six' if selection else 'fresh_all_twenty','reused_controls':chosen,
              'scientific_new_trainings':20-len(selection),'scientific_total':20,'audit':fresh}
    if p.exists():
        old=read(p)
        for k in ('execution_lock_sha256','preflight_sha256','mode','reused_controls'):
            require(old[k]==identity[k],'Frozen reuse eligibility changed: '+k)
        return old
    dump(p,identity);return identity

def completed_attempt(path,conf):
    if not (path/'status.json').exists() or read(path/'status.json').get('status')!='completed':return False
    require(read(path/'config.json')==conf,'Completed config mismatch')
    rows=[__import__('json').loads(s) for s in (path/'loss.jsonl').read_text(encoding='utf-8').splitlines()]
    require(len(rows)==625 and [r['step'] for r in rows]==list(range(1,626)),'Completed trace is not exactly 625 contiguous steps')
    require(all(math.isfinite(r['loss']) and math.isfinite(r['grad_norm']) for r in rows),'Nonfinite training trace')
    stats=read(path/'training.json');require(stats['steps']==625 and stats['exposures']==20000,'Wrong completed budget')
    ident=read(path/'identity.json')
    from train_bridge import code_identity
    require(ident['bridge']['source_hashes']==code_identity() and stats['identity_sha256']==sha_json(ident),'Training identity mismatch')
    checkpoint=path/'checkpoints/step_0625'
    require(directory_manifest(checkpoint)==read(path/'checkpoint_manifest.json')['step_0625'],'Final weight manifest mismatch')
    require(ident['bridge']['objective']==conf['objective'] and ident['bridge']['run_id']==conf['run_id'],'Objective/run identity differs')
    cp=read(checkpoint/'checkpoint_provenance.json')
    require(cp['identity_sha256']==sha_json(ident) and cp['run_id']==conf['run_id'] and cp['step']==625,'Checkpoint provenance differs')
    from verify_mask_artifacts import validate_mask_artifacts
    validate_mask_artifacts(path,conf)
    return True

def train_all(args,decision):
    plan=read(ROOT/'bridge_plan.json');reused={(c['policy'],c['seed']):c for c in decision['reused_controls']}
    registry=[]
    for cell in plan['cells']:
        name=cell['run_id'];config=STATE/'configs'/(name+'.json');conf=read(config)
        old=reused.get((cell['policy'],cell['seed'])) if cell['objective']=='explicit_1p4' else None
        if old:
            checkpoint=pathlib.Path(old['checkpoint_path']);prov={'origin':'verified_old_S0_control','cell':cell,'old':old,'reuse_decision_sha256':sha(STATE/'reuse_decision.json')}
        else:
            parent=STATE/'train_runs'/name;attempts=sorted(parent.glob('attempt_*')) if parent.exists() else []
            attempt=attempts[-1] if attempts else parent/'attempt_01'
            if not completed_attempt(attempt,conf):
                extra=[]
                if attempt.exists():
                    require(args.retry_technical and args.failure_note,'Interrupted/failed training requires --retry-technical --failure-note after diagnosis')
                    require(len(list(parent.glob('attempt_*/retry_record_*.json')))==0,'Only one recovery invocation per cell is allowed in this handoff; return partial evidence if it fails again')
                    failure=read(attempt/'status.json') if (attempt/'status.json').exists() else {}
                    require(not any(x in str(failure.get('error','')).lower() for x in ('nonfinite','non-finite','nan loss','inf loss')),'Numerical failure requires returning evidence; do not retune')
                    dump(attempt/'retry_record_01.json',{'time':now(),'note':pathlib.Path(args.failure_note).read_text(encoding='utf-8-sig'),'note_sha256':sha(args.failure_note)})
                    if (attempt/'latest_resume.pt').exists():extra=['--resume']
                    else:
                        require(len(attempts)<2,'One fresh technical retry maximum');attempt=parent/'attempt_02'
                run_child([CODE/'train_bridge.py','--config',config,'--output',attempt,*extra],name)
            require(completed_attempt(attempt,conf),'Training did not produce an auditable final checkpoint')
            checkpoint=attempt/'checkpoints/step_0625'
            prov={'origin':'new_bridge_training','cell':cell,'attempt_path':str(attempt.relative_to(ROOT)).replace('\\','/'),
                  'evidence':{f:sha(attempt/f) for f in ('config.json','identity.json','training.json','loss.jsonl','checkpoint_manifest.json','mask_summary.json','status.json')}}
        folder=STATE/'model_manifests'/name
        mf=folder/'files.json';pf=folder/'provenance.json';manifest=directory_manifest(checkpoint)
        for p,value in ((mf,manifest),(pf,prov)):
            if p.exists():require(read(p)==value,'Previously registered model changed')
            else:dump(p,value)
        registry.append({**{k:cell[k] for k in ('run_id','objective','policy','seed')},'checkpoint_path':str(checkpoint),
            'checkpoint_manifest_path':str(mf.relative_to(ROOT)).replace('\\','/'),'checkpoint_manifest_file_sha256':sha(mf),
            'checkpoint_manifest_sha256':sha_json(manifest),'model_sha256':sha(checkpoint/'model.safetensors'),
            'provenance_path':str(pf.relative_to(ROOT)).replace('\\','/'),'provenance_sha256':sha(pf)})
        dump(STATE/'training_queue_progress.json',{'updated_at':now(),'ready':len(registry),'expected':20,'ready_models':registry})
    value={'models':registry,'evidence_stage':'posthoc_followup'};path=STATE/'models_ready.json'
    if path.exists():require(read(path)==value,'Frozen model registry changed')
    else:dump(path,value)
    validate_models(ROOT,plan,path)

def all_steps(args):
    lock=prepare(args);smoke=preflight(lock);decision=reuse_decision(lock,smoke);train_all(args,decision)
    ev=STATE/'evaluation_batch01'
    extra=['--retry-incomplete'] if args.retry_technical else []
    run_child([CODE/'bridge_evaluate.py','--plan',ROOT/'bridge_plan.json','--models',STATE/'models_ready.json','--output',ev,*extra],'evaluate100')
    analysis=STATE/'analysis_batch01'
    if not (analysis/'analysis_complete.json').exists():
        require(not analysis.exists(),'Incomplete CPU analysis must be preserved; run bridge_analyze.py into a NEW analysis directory and document it')
        run_child([CODE/'bridge_analyze.py','--plan',ROOT/'bridge_plan.json','--evaluation-root',ev,'--output',analysis],'analyze100')
    require(read(analysis/'summary.json')['status']=='COMPLETE_REBUILT','Analysis incomplete')
    dump(STATE/'STUDY_COMPLETE.json',{'completed_at':now(),'scientific_cells':20,'evaluations':100,'new_trainings':decision['scientific_new_trainings'],
          'models_registry_sha256':sha(STATE/'models_ready.json'),'evaluation_complete_sha256':sha(ev/'evaluation_complete.json'),
          'analysis_complete_sha256':sha(analysis/'analysis_complete.json'),'evidence_stage':'posthoc_followup','next':'collect return ZIP; do not tune or add experiments'})

@contextlib.contextmanager
def exclusive():
    STATE.mkdir(parents=True,exist_ok=True);p=STATE/'runner_active.lock'
    fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    try:
        os.write(fd,('pid='+str(os.getpid())+'\ncreated='+now()).encode());os.close(fd);yield
    finally:p.unlink(missing_ok=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['inspect','all','status','collect'])
    p.add_argument('--gpu-work-root',required=True);p.add_argument('--model-path')
    p.add_argument('--reuse',choices=['auto','never'],default='auto');p.add_argument('--retry-technical',action='store_true');p.add_argument('--failure-note')
    p.add_argument('--output',type=pathlib.Path);p.add_argument('--partial',action='store_true')
    args=p.parse_args()
    require(not args.retry_technical or (args.failure_note and pathlib.Path(args.failure_note).is_file()),'Retry requires an existing written technical diagnosis')
    if args.command=='inspect':print(__import__('json').dumps(inspect(),indent=2));return
    if args.command=='status':
        for name in ('reuse_decision.json','training_queue_progress.json','STUDY_COMPLETE.json'):
            path=STATE/name
            if path.exists():
                value=read(path);print(name,{k:v for k,v in value.items() if k not in ('audit','ready_models','reused_controls')})
        return
    with exclusive():
        if args.command=='all':all_steps(args)
        else:
            from bridge_collect import collect
            output=args.output or ROOT.parent/('CPS5801_BRIDGE_RETURN_'+time.strftime('%Y%m%d_%H%M%S')+'.zip')
            print(collect(ROOT,output,partial=args.partial))

if __name__=='__main__':main()
