"""Check complete return evidence without GPU, neural libraries, or old absolute paths.

This verifies identity/completeness. Run bridge_analyze.py into a new directory to
independently rebuild numerical results from saved positive ranks.
"""
from __future__ import annotations
import argparse,pathlib
from bridge_eval_io import *
from bridge_analyze import resolve_attempt

REQUIRED={'predictions.json','metrics.json','config.json','status.json','environment.json','tokenization.json','embedding_mapping.json','embedding_manifest.json'}

def check(plan_path,batch,analysis,models=None):
    root,plan,data=validate_plan(plan_path);batch=resolve(root,batch);analysis=resolve(root,analysis)
    lockpath=batch/'evaluation_lock.json';lock=read(lockpath);regpath=batch/'evaluation_registry.json';reg=read(regpath)
    require(lock['plan_sha256']==sha(plan_path),'Plan differs from frozen evaluation lock')
    require(reg['lock_sha256']==sha(lockpath)==read(batch/'evaluation_lock.sha256.json')['sha256'],'Lock identity mismatch')
    expected={(d['dataset'],c['run_id']) for d in data for c in plan['cells']};jobs=reg['evaluations']
    require(len(jobs)==100 and {(j['dataset'],j['run_id']) for j in jobs}==expected,'Exactly 100 unique completed evaluations required')
    complete=read(batch/'evaluation_complete.json')
    require(complete['evaluations']==100 and complete['models']==20 and complete['registry_sha256']==sha(regpath) and complete['lock_sha256']==sha(lockpath),'Evaluation completion receipt mismatch')
    sourcefiles=read(analysis/'source_manifest.json')['files']
    def source_identity(suffix,digest):
        matches=[v for k,v in sourcefiles.items() if k.replace('\\','/').endswith('/'+suffix.replace('\\','/'))]
        require(matches==[digest],'Analysis source differs from returned evidence: '+suffix)
    source_identity('bridge_plan.json',sha(plan_path));source_identity('evaluation_registry.json',sha(regpath));source_identity('evaluation_lock.json',sha(lockpath))
    for d in data:
        for key in ('queries_path','corpus_path','group_map_path'):source_identity(str(pathlib.Path(d[key]).relative_to(root)),sha(d[key]))
    for job in jobs:
        require(job['status']=='completed','Missing/failed evaluation')
        require(1<=len(job['attempts'])<=2,'Unexpected retry count')
        out=resolve_attempt(batch,job);require(set(job['evidence_hashes'])==REQUIRED,'Missing evidence file digest')
        for name,digest in job['evidence_hashes'].items():require(sha(out/name)==digest,'Evaluation evidence hash mismatch: '+str(out/name))
        for name in ('predictions.json','metrics.json'):source_identity(str((out/name).relative_to(batch)),job['evidence_hashes'][name])
        require(read(out/'status.json')['status']=='completed','Evaluation attempt did not complete')
        manifest=read(out/'embedding_manifest.json')
        require(set(manifest)=={'corpus_embeddings.npy','query_embeddings.npy','embedding_mapping.json'},'Embedding archive incomplete')
        for name,item in manifest.items():require((out/name).stat().st_size==item['bytes'] and sha(out/name)==item['sha256'],'Embedding evidence hash mismatch: '+str(out/name))
    ac=read(analysis/'analysis_complete.json');summary=read(analysis/'summary.json')
    require(ac['evaluations']==100 and ac['all_five_seeds_retained'] and ac['summary_sha256']==sha(analysis/'summary.json') and ac['source_manifest_sha256']==sha(analysis/'source_manifest.json') and ac['output_manifest_sha256']==sha(analysis/'output_manifest.json'),'Analysis completion receipt mismatch')
    require(summary['status']=='COMPLETE_REBUILT' and summary['evaluations']==100 and summary['expected_seeds']==list(SEEDS) and summary['evidence_stage']=='posthoc_followup','Incomplete or incorrectly scoped analysis')
    manifest=read(analysis/'output_manifest.json')
    actual=directory_manifest(analysis)
    actual.pop('analysis_complete.json',None);actual.pop('output_manifest.json',None)
    require(actual==manifest,'Analysis table/figure/bootstrap files differ from output manifest')
    for filename in ('figures/01_bfcl_live_four_cells.svg','figures/02_bfcl_live_interaction.svg','figures/03_legacy_recall5.svg','results_triggered_next_steps.json','interaction_seed_conditional_intervals.csv','toolhop_exact_document_sensitivity.csv'):
        require(filename in manifest,'Required analysis output missing: '+filename)
    model_count=None
    if models is not None:model_count=len(validate_models(root,plan,resolve(root,models)))
    return {'status':'COMPLETE_EVIDENCE_IDENTITIES_VERIFIED','evaluations':100,'model_conditions':20,'returned_model_directories_verified':model_count,'analysis_files_verified':len(manifest),'embedding_files_verified':200,'torch_imported':False,'evidence_stage':'posthoc_followup','limitation':'Identity/completeness check, not a new training run or independent rescoring; rebuild numerics with bridge_analyze.py.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',required=True,type=pathlib.Path);p.add_argument('--evaluation-root',required=True);p.add_argument('--analysis-root',required=True);p.add_argument('--models');p.add_argument('--report')
    a=p.parse_args();a.plan=a.plan.resolve(strict=True);result=check(a.plan,a.evaluation_root,a.analysis_root,a.models)
    if a.report:dump(safe_output(a.plan.parent,a.report),result)
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
