"""Validate and publish manually authored AI-only case notes, never human labels."""
from __future__ import annotations
import argparse
import collections
import datetime as dt
import html
import importlib.util
import json
from pathlib import Path
import shutil

from compare_reproduction import read, sha, write, write_csv

LABELS = {"F": "clear_function_mismatch", "C": "constraint_or_context_mismatch", "A": "plausible_unlabelled_alternative", "U": "insufficient_or_conflicting_metadata", "M": "mixed_or_no_single_explanation"}


def review_timestamps(proxy):
    materialized_at = dt.datetime.now(dt.timezone.utc).isoformat()
    previous_path = proxy / "review_status.json"
    previous = read(previous_path) if previous_path.exists() else {}
    reviewed_at = materialized_at
    if str(previous.get("status", "")).startswith("AI_ONLY_REVIEW_COMPLETED") and previous.get("completion_utc"):
        reviewed_at = previous["completion_utc"]
        dt.datetime.fromisoformat(reviewed_at)  # Reject a corrupt historical timestamp.
    return reviewed_at, materialized_at


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-root", required=True, type=Path)
    args = parser.parse_args()
    root = args.analysis_root.resolve()
    proxy = root / "ai_proxy"
    plan = read(proxy / "review_plan.json")
    inputs = read(proxy / "review_inputs.json")
    path = root / "original/cases.json"
    backup = path.with_name("cases_evidence_before_ai_review.json")
    if not backup.exists():
        if sha(path) != plan["case_source_sha256"]:
            raise ValueError("Original case evidence changed after AI review plan")
        shutil.copyfile(path, backup)
    if sha(backup) != plan["case_source_sha256"]:
        raise ValueError("Immutable evidence backup hash differs")
    cases = read(backup)
    spec = importlib.util.spec_from_file_location("manual_ai_notes", proxy / "review_notes.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    notes = module.NOTES
    if set(notes) != set(range(1, 61)) or len(cases) != 60 or len(inputs) != 60:
        raise ValueError("Exactly the frozen 60 cases must receive notes")
    input_by_case = {r["case_id"]: r for r in inputs}
    candidate_rows, query_rows = [], []
    reviewed_at, materialized_at = review_timestamps(proxy)
    for case in cases:
        number = int(case["case_id"].removeprefix("CASE"))
        operation, context, constraints, rationale, candidate_notes = notes[number]
        if operation not in {"single_operation", "multiple_operations", "unclear"} or not isinstance(context, bool) or not isinstance(constraints, bool) or not rationale:
            raise ValueError("Invalid explicit query review")
        expected = {r["id"]: r for r in input_by_case[case["case_id"]]["review_candidates"]}
        if {n[0] for n in candidate_notes} != set(expected) or len(candidate_notes) != len(expected):
            raise ValueError("Candidate coverage mismatch: " + case["case_id"])
        case["query_semantic_review"] = {"status": "AI_ONLY_REVIEW_COMPLETED", "operation_structure": operation, "context_dependent": context,
                                         "explicit_constraints": constraints, "rationale": rationale, "reviewer_type": "AI-only", "reviewed_at_utc": reviewed_at,
                                         "qualitative_confidence": "moderate; documentation-only judgement, not calibrated probability"}
        candidate_reviews = []
        for tid, codes, reason, evidence in candidate_notes:
            target = expected[tid]
            evidence_source = target["text"] + "\n" + json.dumps(target["raw"], ensure_ascii=False)
            if evidence not in evidence_source:
                raise ValueError("Evidence is not an exact source substring: " + case["case_id"] + " " + tid + " " + evidence)
            labels = [LABELS[code] for code in codes.split(",")]
            row = {"candidate_id": tid, "labels": labels, "reason": reason, "evidence_text": evidence,
                   "evidence_source": "serialized text and, where needed, original raw metadata; source code fragments only read, never executed",
                   "origins": target["origins"], "reviewer_type": "AI-only", "reviewed_at_utc": reviewed_at,
                   "qualitative_confidence": "moderate; no runtime/API verification", "human_judgement": None}
            candidate_reviews.append(row)
            candidate_rows.append({"case_id": case["case_id"], "query_id": case["query_id"], "sample_group": case["sample_design"]["group"],
                                   "candidate_id": tid, "origins": "|".join(row["origins"]), "labels": "|".join(labels), "reason": reason, "evidence_text": evidence,
                                   "reference_similarity": case["reference_similarity"], "reference_similarity_stratum": case["reference_similarity_stratum"], "reviewer_type": "AI-only"})
        case["candidate_semantic_review"] = candidate_reviews
        case["query_summary_labels"] = sorted({label for row in candidate_reviews for label in row["labels"]})
        case["query_summary_rule"] = "Union of labels on the first unlabelled top5 candidate in each seed42 policy, deduplicated by tool ID; other candidates were not semantically reviewed. Multiple labels are retained without assigning a single cause."
        case["reviewer_type"] = "AI-only"
        case["review_model_identity"] = plan["model_identity"]
        case["human_review_status"] = "HUMAN_PENDING"
        case["actual_human_review_count"] = 0
        query_rows.append({"case_id": case["case_id"], "query_id": case["query_id"], "sample_group": case["sample_design"]["group"],
                           "operation_structure": operation, "context_dependent": context, "explicit_constraints": constraints, "reason": rationale,
                           "candidate_review_count": len(candidate_reviews), "query_union_labels": "|".join(case["query_summary_labels"]), "reviewer_type": "AI-only"})
    write(path, cases)
    write(proxy / "documented_reviews.json", {"status": "AI_ONLY_REVIEW_COMPLETED", "review_plan_sha256": sha(proxy / "review_plan.json"),
                                             "manual_notes_sha256": sha(proxy / "review_notes.py"), "case_evidence_sha256": sha(backup),
                                             "human_completed_count": 0, "query_reviews": query_rows, "candidate_reviews": candidate_rows})
    write_csv(proxy / "query_operation_reviews.csv", query_rows)
    write_csv(proxy / "candidate_error_reviews.csv", candidate_rows)
    summary = []
    for group in ("hard_wins", "hard_losses", "ties"):
        selected_cases = [case for case in cases if case["sample_design"]["group"] == group]
        candidates = [row for row in candidate_rows if row["sample_group"] == group]
        for label in LABELS.values():
            summary.append({"sample_group": group, "label": label, "sample_queries": len(selected_cases), "reviewed_unique_query_candidate_pairs": len(candidates),
                            "queries_with_label": sum(label in c["query_summary_labels"] for c in selected_cases),
                            "candidate_pairs_with_label": sum(label in c["labels"].split("|") for c in candidates),
                            "population_rate": "not_estimated; fixed outcome-stratified qualitative sample", "reviewer_type": "AI-only"})
    write_csv(proxy / "review_summary_by_sample_group.csv", summary)
    op_summary = []
    for group in ("hard_wins", "hard_losses", "ties"):
        rows = [r for r in query_rows if r["sample_group"] == group]
        for op in ("single_operation", "multiple_operations", "unclear"):
            op_summary.append({"sample_group": group, "operation_structure": op, "n": sum(r["operation_structure"] == op for r in rows), "sample_n": len(rows), "reviewer_type": "AI-only"})
    write_csv(proxy / "query_operation_summary.csv", op_summary)
    status = {"status": "AI_ONLY_REVIEW_COMPLETED_HUMAN_PENDING", "case_count": len(cases), "candidate_pair_count": len(candidate_rows),
              "reviewed_rank_scope": plan["candidate_sampling"], "human_completed_count": 0, "independent_human_review": False,
              "primary_labels_changed": False, "real_tools_executed": False, "review_plan_sha256": sha(proxy / "review_plan.json"),
              "review_notes_sha256": sha(proxy / "review_notes.py"), "reviewed_cases_sha256": sha(path), "completion_utc": reviewed_at,
              "materialized_at_utc": materialized_at,
              "limitations": ["AI-only, not independent human ground truth", "outcome-stratified 20/20/20 cases are not a population error-rate estimate", "only declared seed42 candidate subset reviewed; all six rankings retained", "documents do not establish execution validity or complete relevance labels", "AI reviewer had method/outcome labels; this is descriptive review, not blinded human review"]}
    write(proxy / "review_status.json", status)
    original_status = read(root / "original/status.json")
    original_status.update(semantic_review="AI_ONLY_REVIEW_COMPLETED", human_review="HUMAN_PENDING", human_completed_count=0, reviewed_case_count=60, reviewed_candidate_pair_count=len(candidate_rows))
    write(root / "original/status.json", original_status)
    parts = ["<!doctype html><html lang='zh'><meta charset='utf-8'><title>60例AI代理审阅</title><style>body{font-family:system-ui;max-width:1100px;margin:2rem auto;line-height:1.6}article{border-top:2px solid #888;margin-top:2rem}pre{white-space:pre-wrap;background:#f3f3f3;padding:1rem}small{color:#555}summary{cursor:pointer}</style><h1>60例AI代理审阅</h1><p>AI-only，真人完成0。每题仅语义审阅seed42随机/BM25前5名中的首个未标注候选（相同ID去重），完整六组排名另保留。20/20/20配额案例不能估计测试集总体错误率。标签未修改，工具未执行。</p>"]
    for case in cases:
        parts.append("<article><h2>" + html.escape(case["case_id"] + " / " + case["query_id"]) + "</h2><p>" + html.escape(case["sample_design"]["group"] + " · Jaccard stratum " + case["reference_similarity_stratum"]) + "</p><pre>" + html.escape(case["query"]) + "</pre>")
        review = case["query_semantic_review"]
        parts.append("<p><b>" + html.escape(review["operation_structure"]) + "</b>；上下文依赖=" + str(review["context_dependent"]) + "；显式约束=" + str(review["explicit_constraints"]) + "。" + html.escape(review["rationale"]) + "</p>")
        for row in case["candidate_semantic_review"]:
            parts.append("<h3>" + html.escape(row["candidate_id"]) + "</h3><p>" + html.escape(" / ".join(row["origins"])) + "</p><p><b>" + html.escape(" + ".join(row["labels"])) + "</b></p><p>" + html.escape(row["reason"]) + "</p><blockquote>" + html.escape(row["evidence_text"]) + "</blockquote>")
        parts.append("<details><summary>冻结正例及六个run完整top5证据</summary><pre>" + html.escape(json.dumps({"positives": case["positives"], "runs": case["six_run_evidence"]}, ensure_ascii=False, indent=2)) + "</pre></details></article>")
    target = root / "original/cases_readable.html"
    if not target.with_name("cases_evidence_only.html").exists():
        shutil.copyfile(target, target.with_name("cases_evidence_only.html"))
    target.write_text("\n".join(parts) + "</html>", encoding="utf-8")
    report = "60例实际AI-only文档审阅已完成，覆盖114个预先声明的query-candidate pair；真人完成0，未做API调用。\n"
    report += "审阅同时记录请求操作结构、上下文/显式约束，并连接共同的固定词面相似度分层及候选歧义标签；仅分析seed42声明子集，不能推广成六个seed都犯同一错误。\n"
    report += "例CASE048：随机seed42返回未标注calculate_square_root，文档直接覆盖81开平方；BM25首个被审候选subtract_square则是另一运算。此例显示固定ID指标可能漏记文档上适配的候选，但不是已修正的真实gold。\n"
    report += "例CASE054：两策略被审候选都是明确按Ethereum地址取余额的工具，虽非冻结正例仍有文档支持；不能把不同ID直接判为功能错误。\n"
    report += "例CASE027/040：同主题的重启、启动顺序或会议日程工具，与原请求的BCD修复/文本文件编辑不是同一操作。\n"
    report += "例CASE041–044：表格或图像上下文缺失，不能从文本记录验证任务答案；这与负例训练机制的因果解释必须分开。\n"
    report += "样本保留hard_wins/hard_losses/ties各20题；候选标签多选、U保持不确定，未将其合并成已证实语义错误率。原研究、复现与新方案确认成绩仍分别处理。\n"
    (proxy / "review_interpretation_zh.txt").write_text(report, encoding="utf-8")
    print(json.dumps(status, ensure_ascii=False))


if __name__ == "__main__":
    main()
