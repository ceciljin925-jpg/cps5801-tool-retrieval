"""Create the complete portable handoff, retaining large GPU artifacts locally."""
import argparse
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
WORK=ROOT.parent
WORKSPACE=WORK.parent
PACKAGE=WORK/'handoff/CPS5801_PUBLICATION_HANDOFF_20261112'
SOURCE=PACKAGE/'archive/CPS5801_HANDOFF_20261025/CPS5801'
REPRO=WORK/'repro'


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def large_artifact(path):
    return path.suffix.lower() in ('.safetensors','.pt','.pth','.npy','.npz','.bin','.onnx')


def artifact_role(path):
    relative=path.relative_to(WORK).as_posix()
    if '/profile/' in relative or 'fixture' in relative:
        return 'engineering_fixture_binary_not_scientific_run'
    if path.name=='range_probe.bin':return 'historical_download_probe'
    if path.name=='latest_resume.pt':return 'optimizer_rng_and_model_recovery_state'
    if path.suffix=='.safetensors' or path.name=='pytorch_model.bin':
        return 'pretrained_model_weight' if '/models/' in relative or '/data/raw/model/' in relative else 'trained_checkpoint_weight'
    if path.suffix in ('.npy','.npz'):
        return 'embedding' if 'embedding' in path.name else 'numeric_array_evidence'
    return 'other_binary_evidence'


def copy_tree(source,destination,exclusions=()):
    if not source.is_dir():raise FileNotFoundError('Required evidence directory missing: '+str(source))
    copied=[]
    for path in sorted(source.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(source)
        if any(part in ('__pycache__','.cache','.git') for part in relative.parts):continue
        if any(relative.as_posix()==x or relative.as_posix().startswith(x+'/') for x in exclusions):continue
        if large_artifact(path) or path.suffix in ('.tmp','.downloading','.part','.incomplete'):continue
        target=destination/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,target)
        copied.append(target)
    return copied


def copy_small_root_files(source,destination):
    """Preserve protocol/release metadata without recopying raw dataset shards."""
    destination.mkdir(parents=True,exist_ok=True)
    for path in sorted(source.iterdir()):
        if path.is_file() and not large_artifact(path):
            shutil.copy2(path,destination/path.name)


def manifest_identity_index(training,final,path_mappings):
    """Index registry-declared evidence paths; never infer run IDs from prefixes.

    This reads only the already-loaded registry metadata. Model initialization
    paths are deliberately not mapped to a single run because they are shared.
    """
    def normalized(value):return str(value).replace('\\','/').rstrip('/')
    mappings=sorted([(normalized(k),v) for k,v in path_mappings.items()],key=lambda x:len(x[0]),reverse=True)
    def relative(value):
        if not value:return None
        value=normalized(value)
        for source,target in mappings:
            if value.casefold()==source.casefold():return target
            if value.casefold().startswith(source.casefold()+'/'):return target+value[len(source):]
        return None
    runs={};entries=[]
    for row in [*training,*final.get('evaluations',[])]:
        run_id=row.get('run_id')
        if not isinstance(run_id,str) or not run_id:continue
        stage=row.get('stage')
        previous=runs.get(run_id)
        if previous is not None and stage is not None and previous!=stage:
            raise ValueError('Conflicting registry stage for run: '+run_id)
        runs[run_id]=stage if stage is not None else previous
    def add_path(path,run_id=None,stage=None,dataset=None,scope='run',basis='registry_path',exact=False,already_relative=False):
        target=normalized(path) if already_relative else relative(path)
        if target is None:return
        entries.append({'path':target,'exact':exact,'run_id':run_id,'stage':stage,'dataset':dataset,
                        'association_scope':scope,'association_basis':basis})
    for row in training:
        run_id=row['run_id'];stage=runs.get(run_id)
        # The queue's run directory contains config, attempts, and process logs.
        add_path('publication/runs/'+run_id,run_id,stage,basis='exact_registry_run_directory',already_relative=True)
        for field in ('output_path','checkpoint_path'):
            add_path(row.get(field),run_id,stage)
        for attempt in row.get('attempts',[]):
            add_path(attempt.get('output'),run_id,stage)
            add_path(attempt.get('config_path'),run_id,stage,exact=True)
        for evaluation in row.get('dev_evaluations',[]):
            metrics=relative(evaluation.get('metrics_path'))
            if metrics:
                split=evaluation.get('split','original_dev')
                dataset='original_development' if split in ('original_dev','original_development','dev','development') else None
                directory=metrics.rsplit('/',1)[0]
                if directory==relative(row.get('output_path')):
                    # Legacy S0 mixes training logs and dev predictions in one directory.
                    for name in (metrics.rsplit('/',1)[1],'predictions.json'):
                        add_path(directory+'/'+name,run_id,stage,dataset,basis='registry_development_file',exact=True,already_relative=True)
                else:
                    add_path(directory,run_id,stage,dataset,basis='registry_development_output',already_relative=True)
    for row in final.get('evaluations',[]):
        run_id=row['run_id'];stage=runs.get(run_id);dataset=row.get('dataset')
        add_path(row.get('output_path'),run_id,stage,dataset,basis='final_evaluation_registry_output')
        add_path(row.get('config_path'),run_id,stage,dataset,basis='final_evaluation_registry_config',exact=True)
        if dataset:
            add_path('publication/evaluations/'+dataset+'/'+run_id,run_id,stage,dataset,
                     basis='exact_final_registry_evaluation_directory',already_relative=True)
            add_path('publication/data/external/'+dataset,dataset=dataset,scope='dataset',
                     basis='exact_final_registry_dataset_directory',already_relative=True)
    for dataset_record in final.get('efficiency',[]):
        dataset=dataset_record.get('dataset');plan=relative(dataset_record.get('plan_path'))
        if plan:
            add_path(plan.rsplit('/',1)[0],dataset=dataset,scope='dataset',basis='profiling_registry_plan_directory',already_relative=True)
        for model in dataset_record.get('models',[]):
            run_id=model['run_id']
            # Profiling records may omit stage; use the same exact final run ID.
            if run_id not in runs:continue
            stage=runs[run_id]
            add_path(model.get('output_path'),run_id,stage,dataset,basis='profiling_registry_output')
            if plan:
                add_path(plan.rsplit('/',1)[0]+'/'+run_id,run_id,stage,dataset,
                         basis='exact_profiling_registry_run_directory',already_relative=True)
    return entries


def manifest_file_identity(relative,index):
    """Return explicit origin and the most specific known scientific association."""
    relative=str(relative).replace('\\','/');parts=relative.split('/');origin=parts[0]
    answer={'origin_scope':origin,'run_id':None,'stage':None,'dataset':None,
            'association_scope':'global','association_basis':'no_single_registry_run_association'}
    if origin in ('original_reference','original_environment','original_session','input_protocol','external_source_assets'):
        answer['association_basis']='historical_or_input_scope_not_new_run'
        return answer
    if origin=='publication' and len(parts)>2 and parts[1]=='locks':
        for stage in ('S2','S4'):
            if parts[2] in (stage+'_selection.json',stage+'_selection_input_registry.json'):
                answer.update(stage=stage,association_scope='stage',association_basis='exact_stage_lock_filename')
                return answer
    matches=[entry for entry in index if relative==entry['path'] or (not entry['exact'] and relative.startswith(entry['path']+'/'))]
    if matches:
        longest=max(len(entry['path']) for entry in matches)
        matches=[entry for entry in matches if len(entry['path'])==longest]
        for field in ('run_id','stage','dataset'):
            values={entry[field] for entry in matches}
            answer[field]=next(iter(values)) if len(values)==1 else None
        identities={(entry['run_id'],entry['stage'],entry['dataset']) for entry in matches}
        if len(identities)>1:
            answer.update(association_scope='shared',association_basis='multiple_exact_registry_associations')
            answer['related_run_ids']=sorted({entry['run_id'] for entry in matches if entry['run_id'] is not None})
        else:
            answer.update(association_scope=matches[0]['association_scope'],association_basis=matches[0]['association_basis'])
    elif origin=='publication' and len(parts)>1 and parts[1] in ('runs','evaluations','efficiency'):
        answer.update(association_scope='unassociated',association_basis='no_matching_registry_evidence_path')
    elif origin=='reproduction' and len(parts)>1 and parts[1] in ('results','logs'):
        answer.update(association_scope='unassociated',association_basis='reproduction_artifact_without_explicit_current_run_binding')
    return answer


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name')
    args=parser.parse_args()
    status=read(ROOT/'completion_status.json')
    if status.get('all_independent_work_completed') is not True:
        raise RuntimeError('Cannot package an unfinished plan as complete')
    training=read(ROOT/'run_registry.json')['runs']
    if any(r['status'] not in ('completed','failed','reused','not_applicable','blocked') for r in training):
        raise RuntimeError('Unaccounted-for training tasks remain')
    final=read(ROOT/'final_evaluation_registry.json')
    if any(e['status']!='completed' for e in final['evaluations']):raise RuntimeError('Final predictions incomplete')
    if any(m['status']!='completed' for dataset in final['efficiency'] for m in dataset['models']):
        raise RuntimeError('Efficiency measurements incomplete')
    date=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y%m%d_%H%M')
    bundle_name=args.name or ('CPS5801_GPU研究结果与完整交接_'+date)
    out=WORKSPACE/'outputs'
    out.mkdir(exist_ok=True)
    bundle=out/bundle_name
    if bundle.exists():raise FileExistsError('Preserve previous return attempts; choose a new name')
    bundle.mkdir()
    # Compact evidence plus every source/config/log/failure. Large originals stay on this machine.
    copy_tree(ROOT,bundle/'publication',exclusions=('return_package',))
    copy_tree(WORK/'environment',bundle/'environment')
    for folder in ('results','logs','scripts','data/main_20261025','data/audited_pilot_20261025','data/prepared','data/raw/model'):
        copy_tree(REPRO/folder,bundle/'reproduction'/folder)
    for name in ('reproduction_setup.json','requirements-training-portable.txt'):
        shutil.copy2(REPRO/name,bundle/'reproduction'/name)
    # Historical evidence is visibly separate from the new reproduction.
    for folder in ('results','logs','paper','scripts','data/main_20261025','data/audited_pilot_20261025','data/prepared','data/raw/model'):
        copy_tree(SOURCE/folder,bundle/'original_reference'/folder)
    copy_small_root_files(SOURCE,bundle/'original_reference')
    copy_small_root_files(SOURCE/'data/raw',bundle/'original_reference/data/raw')
    copy_small_root_files(REPRO/'data/raw',bundle/'reproduction/data/raw')
    for path in PACKAGE.iterdir():
        if path.is_file() and path.suffix in ('.txt','.json','.py'):
            target=bundle/'input_protocol'/path.name;target.parent.mkdir(exist_ok=True)
            shutil.copy2(path,target)
    copy_tree(PACKAGE/'legacy_course',bundle/'input_protocol/legacy_course')
    copy_tree(PACKAGE/'assets',bundle/'external_source_assets')
    copy_tree(PACKAGE/'supporting',bundle/'input_protocol/supporting')
    copy_tree(PACKAGE/'archive/CPS5801_HANDOFF_20261025/ENVIRONMENT',bundle/'original_environment')
    copy_tree(PACKAGE/'archive/CPS5801_HANDOFF_20261025/SESSION',bundle/'original_session')
    copy_tree(PACKAGE/'archive/CPS5801_HANDOFF_20261025/ORIGINAL_INPUT',bundle/'input_protocol/prior_original_input')
    copy_small_root_files(PACKAGE/'archive/CPS5801_HANDOFF_20261025',bundle/'input_protocol/archived_handoff')
    paths={str(ROOT):'publication',str(REPRO):'reproduction',str(SOURCE):'original_reference',
           str(PACKAGE/'assets'):'external_source_assets',
           str(PACKAGE/'archive/CPS5801_HANDOFF_20261025/ENVIRONMENT'):'original_environment',
           str(PACKAGE/'archive/CPS5801_HANDOFF_20261025/SESSION'):'original_session',
           str(PACKAGE/'archive/CPS5801_HANDOFF_20261025/ORIGINAL_INPUT'):'input_protocol/prior_original_input',
           str(PACKAGE/'archive/CPS5801_HANDOFF_20261025'):'input_protocol/archived_handoff',
           str(WORK/'environment'):'environment',str(PACKAGE):'input_protocol'}
    dump(bundle/'path_map.json',{'schema_version':1,'mappings':[{'source_prefix':k,'target_prefix':v} for k,v in paths.items()],
         'note':'Original absolute paths remain in immutable run records; this map relocates evidence for offline rebuild.'})
    retained=[]
    for base in (ROOT,REPRO):
        for path in sorted(base.rglob('*')):
            if path.is_file() and large_artifact(path) and '.cache' not in path.parts:
                retained.append({'absolute_gpu_path':str(path),'work_relative_path':path.relative_to(WORK).as_posix(),
                                 'bytes':path.stat().st_size,'sha256':sha(path),'included_in_main_zip':False,
                                 'kind':artifact_role(path)})
    dump(bundle/'weights/retained_gpu_artifact_manifest.json',{'files':retained,'total_bytes':sum(x['bytes'] for x in retained),
          'retention':'Kept on GPU computer; not deleted. No separate weight archive is claimed to have been delivered.',
          'main_zip_contains':'all compact predictions, positive exact ranks, code, configs, logs, statistics, audit and handoff evidence'})
    dump(bundle/'input_protocol/omitted_original_inputs.json',{
        'full_original_input_zip':read(WORK/'environment/input_zip_identity.json')['Path'],
        'input_zip_identity':read(WORK/'environment/input_zip_identity.json'),
        'scope':'Raw20w parquet release and original baseline weights are referenced by original handoff identity; no new derived evidence omitted except GPU-retained large arrays/weights.',
        'original_input_package':'CPS5801_投稿研究完整交接包_20261112.zip'})
    for name in ('README_研究结果与下一步.txt','CONTINUE_PROMPT_新电脑接手.txt','executive_summary_en.txt'):
        source=ROOT/'claims'/name
        if not source.exists():raise RuntimeError('Missing required user-facing handoff text: '+name)
        shutil.copy2(source,bundle/name)
    verification=bundle/'verification'
    verification.mkdir()
    command=[str(WORK/'analysis_venv/Scripts/python.exe'),str(bundle/'publication/extensions/rebuild_research.py'),
             '--input-root',str(bundle),'--output-dir',str(verification/'offline_rebuild')]
    with (verification/'offline_rebuild.stdout.log').open('w',encoding='utf-8') as stdout, (verification/'offline_rebuild.stderr.log').open('w',encoding='utf-8') as stderr:
        checked=subprocess.run(command,stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    dump(verification/'offline_rebuild_status.json',{'command':command,'exit_code':checked.returncode,
         'purpose':'Rebuild from actual copied portable bundle using path_map, never assume original absolute paths are available'})
    if checked.returncode:raise RuntimeError('Portable copied-bundle rebuild failed; preserve attempt and inspect verification logs')
    # Package verifier requires only Python's standard library.
    verifier='''import hashlib,json,pathlib,sys,zipfile\nr=pathlib.Path(__file__).resolve().parent\nm=json.loads((r/'return_manifest.json').read_text(encoding='utf-8'))\nerrors=[]\nfor x in m['files']:\n p=(r/x['path']).resolve()\n if r not in p.parents or not p.is_file():errors.append(x['path']+':missing');continue\n with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()\n if p.stat().st_size!=x['bytes'] or h!=x['sha256']:errors.append(x['path']+':identity')\nprint(json.dumps({'passed':not errors,'files':len(m['files']),'errors':errors},ensure_ascii=False,indent=2))\nsys.exit(bool(errors))\n'''
    (bundle/'verify_return.py').write_text(verifier,encoding='utf-8')
    identity_index=manifest_identity_index(training,final,paths)
    files=[]
    for path in sorted(bundle.rglob('*')):
        if path.is_file():
            relative=path.relative_to(bundle).as_posix()
            files.append({'path':relative,'bytes':path.stat().st_size,'sha256':sha(path),
                          'purpose':relative.split('/')[0],**manifest_file_identity(relative,identity_index)})
    dump(bundle/'return_manifest.json',{'schema_version':1,'created_at':date,'files':files,
         'file_association_rule':'Exact registry run IDs and declared evidence paths; longest path binding wins; historical/input scopes never inherit new run IDs; unknown associations are null.',
         'completed_status':status,'exclusions':'manifest itself; large GPU artifacts separately inventoried; raw original input package referenced'})
    archive=out/(bundle_name+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for path in sorted(bundle.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(bundle).as_posix())
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad:raise ValueError('ZIP CRC failure: '+bad)
        for item in files:
            data=z.read(item['path'])
            if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
                raise ValueError('ZIP member manifest mismatch: '+item['path'])
        if hashlib.sha256(z.read('return_manifest.json')).hexdigest()!=sha(bundle/'return_manifest.json'):
            raise ValueError('ZIP manifest itself differs from verified on-disk manifest')
    identity={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
              'members_verified':len(files)+1,'CRC_verified':True,'all_member_hashes_verified':True,
              'return_manifest_sha256':sha(bundle/'return_manifest.json'),
              'human_review_status':'HUMAN_PENDING','extracted_directory':str(bundle)}
    dump(out/(bundle_name+'_校验信息.json'),identity)
    print(json.dumps(identity,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
