"""Continue the already authorized single-GPU work after S0; never report a launch as completion."""
import csv
import json
import pathlib
import sys
import time
import traceback

from execute_logged import execute, dump, now

ROOT=pathlib.Path(__file__).resolve().parents[1]
EXT=ROOT/'extensions'
WORK=ROOT.parent
PYTHON=WORK/'venv/Scripts/python.exe'
CPU=WORK/'analysis_venv/Scripts/python.exe'
STATE=ROOT/'research_controller_status.json'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def state(phase,**fields):
    dump(STATE,{'updated_at':now(),'controller_pid':__import__('os').getpid(),'phase':phase,**fields})
    print('CONTROLLER',phase,fields,flush=True)


def recorded(name,command):
    status=ROOT/'logs'/f'{name}.process_status.json'
    if status.exists():
        record=read(status)
        if record['status']=='completed' and record.get('exit_code')==0:return
        raise RuntimeError('Existing incomplete attempt requires explicit recovery: '+name)
    execute(list(map(str,command)),ROOT,ROOT/'logs',name)


def review_exact_s0():
    report=read(ROOT/'comparison/reproduction_comparison.json')
    if report['summary']['status']!='PASS_COMPLETE':return False
    with (ROOT/'comparison/original_vs_reproduction.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    exact_predictions=(len(rows)==80 and all(float(r['reproduction_minus_original'])==0 and
                       float(r['top10_identical_fraction'])==1 and float(r['max_abs_same_id_score_difference'])==0 for r in rows))
    exact_training=(len(report['training'])==6 and all(all(r['field_identity'].values()) and
                    all(v['max_absolute_difference']==0 for v in r['trace'].values()) for r in report['training']))
    weights=[f for r in report['training'] for f in r['checkpoint_files'] if f['path'].endswith('model.safetensors')]
    exact_weights=len(weights)==6 and all(f['bytes_match_historical_record'] is True for f in weights)
    record={'reviewed_at':now(),'continue_publication':exact_predictions and exact_training and exact_weights,
            'review_kind':'automated_exhaustive_exact_equality_gate','no_new_numeric_tolerance':True,
            'all16_prediction_rankings_and_scores_exact':exact_predictions,
            'all6_loss_gradient_traces_and_inputs_exact':exact_training,
            'all6_checkpoint_weight_hashes_match_archived_records':exact_weights,
            'limitations':'Only this observed hardware/software execution; does not establish cross-platform bitwise reproducibility. Historical omitted weights are checked against recorded SHA256.'}
    dump(ROOT/'comparison/reproduction_exact_equality_audit.json',record)
    if record['continue_publication'] and not (ROOT/'comparison/reproduction_review.json').exists():
        dump(ROOT/'comparison/reproduction_review.json',record)
    return record['continue_publication']


def main():
    state('waiting_for_s0')
    while not (ROOT/'s0_completed.json').exists():
        status=read(ROOT/'logs/s0_pipeline.process_status.json')
        if status['status'] not in ('running','starting','completed'):
            raise RuntimeError('S0 failed/interrupted; inspect its logs before continuing')
        if status['status']=='completed':raise RuntimeError('S0 process ended without complete evidence')
        time.sleep(5)
    review_exact_s0()
    review_path=ROOT/'comparison/reproduction_review.json'
    if not review_path.exists() or read(review_path).get('continue_publication') is not True:
        state('s0_numeric_differences_require_agent_diagnosis')
        while not review_path.exists() or read(review_path).get('continue_publication') is not True:
            time.sleep(5)
    state('freezing_static_dense_negatives')
    recorded('dense_mining',[PYTHON,EXT/'prepare_policies.py','--stage','mine'])
    recorded('complete_negative_freeze',[CPU,EXT/'prepare_policies.py','--stage','negatives'])
    recorded('complete_negative_diagnostics',[CPU,EXT/'negative_diagnostics.py','--stage','complete',
                                           '--output',ROOT/'analysis/negative_complete_attempt01'])
    state('training_and_development_S1_to_S5')
    recorded('publication_training_queue',[PYTHON,EXT/'run_queue.py'])
    state('final_lock_and_batch_evaluation')
    recorded('final_locked_batch',[PYTHON,EXT/'run_final_evaluations.py','--prepare','--run','--efficiency'])
    state('final_cpu_analysis')
    recorded('rebuild_all_final',[CPU,EXT/'rebuild_all.py','--input-root',ROOT,'--output-dir',ROOT/'analysis/final_rebuild'])
    state('gpu_and_core_analysis_completed_awaiting_final_review_and_package')


if __name__=='__main__':
    try:main()
    except BaseException as error:
        state('failed_or_interrupted',error=repr(error),traceback=traceback.format_exc())
        raise
