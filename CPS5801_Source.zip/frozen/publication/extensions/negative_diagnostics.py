"""CPU audit of frozen negative IDs, encoder inputs and minimal-repair changes.

--stage validate accepts the five available policies before dense mining and
explicitly reports pending dense/similarity work. --stage complete requires all
six policies and saved pretrained-E5 mining embeddings. Neither stage resamples
or writes training negatives. BGE signatures are diagnostic, never supervision.
"""
from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import random
import re
import time
import traceback

os.environ['TOKENIZERS_PARALLELISM'] = 'false'
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
SOURCE = REPRO / 'data/main_20261025'
TRAINING = ROOT / 'data/training'
POLICIES = ['R_ID', 'B_ID', 'R_UNIQUE', 'B_UNIQUE', 'MIXED_2R2B', 'DENSE_STATIC']
SEEDS = list(range(41, 47))


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, obj):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local_rng(text):
    return random.Random(int(hashlib.sha256(text.encode()).hexdigest()[:16], 16))


def signatures(corpus, model, prefix):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    result, lengths = {}, {}
    for offset in range(0, len(corpus), 512):
        rows = corpus[offset:offset + 512]
        texts = [prefix + row['text'] for row in rows]
        truncated = tokenizer(texts, truncation=True, max_length=384)['input_ids']
        full = tokenizer(texts, truncation=False)['input_ids']
        for row, ids, original_ids in zip(rows, truncated, full, strict=True):
            result[row['id']] = hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest()
            lengths[row['id']] = {'encoded_tokens': len(ids), 'full_tokens': len(original_ids), 'characters': len(row['text'])}
    metadata = {'model_path': str(pathlib.Path(model).resolve()), 'document_prefix': prefix,
                'max_tokens_including_prefix': 384,
                'tokenizer_files': {p.name: sha(p) for p in pathlib.Path(model).iterdir()
                                    if p.is_file() and (p.name.startswith('tokenizer') or p.name in ('vocab.txt', 'special_tokens_map.json', 'config.json'))}}
    return result, lengths, metadata


def describe(values):
    values = np.asarray(values, dtype=np.float64)
    if not len(values):
        return {'n': 0, 'mean': None, 'median': None, 'p05': None, 'p95': None, 'min': None, 'max': None}
    require(np.isfinite(values).all(), 'Nonfinite diagnostic values')
    return {'n': len(values), 'mean': float(values.mean()), 'median': float(np.median(values)),
            'p05': float(np.percentile(values, 5)), 'p95': float(np.percentile(values, 95)),
            'min': float(values.min()), 'max': float(values.max())}


def audit(stage, output, bge_model):
    out = pathlib.Path(output).resolve()
    require(ROOT in out.parents, 'Diagnostics output must stay below publication work directory')
    require(not out.exists(), 'Choose a new diagnostic attempt; earlier evidence is retained')
    out.mkdir(parents=True)
    dump(out / 'status.json', {'status': 'running', 'started_at': now(), 'stage': stage})
    started = time.perf_counter()
    inputs = {}
    def load(path):
        path = pathlib.Path(path)
        inputs[str(path.resolve())] = sha(path)
        return read(path)
    try:
        train = load(SOURCE / 'train.json')
        corpus = load(SOURCE / 'corpus.json')
        train_ids = load(SOURCE / 'train_tool_ids.json')
        masks = {qid: set(ids) for qid, ids in load(SOURCE / 'forbidden_ids.json').items()}
        bpools = load(SOURCE / 'bm25_top50_eligible.json')
        frozen_sig = load(TRAINING / 'e5_input_signatures.json')
        frozen_lengths = load(TRAINING / 'e5_tool_lengths.json')
        by_query = {row['id']: row for row in train}
        by_doc = {row['id']: row for row in corpus}
        qids, allowed = set(by_query), set(train_ids)
        require(len(train) == len(qids) == 10000, 'Expected 10,000 distinct training queries')
        require(len(allowed) == len(train_ids), 'Duplicate training tool IDs')
        e5_sig, e5_lengths, e5_meta = signatures(corpus, REPRO / 'data/raw/model', 'passage: ')
        require(e5_sig == frozen_sig, 'Independent E5 token signature reconstruction disagrees with frozen signatures')
        require(e5_lengths == frozen_lengths, 'Independent E5 token lengths disagree with frozen lengths')
        bge_sig, bge_lengths, bge_meta = signatures(corpus, bge_model, '')
        dump(out / 'bge_input_signatures.json', bge_sig)
        dump(out / 'bge_tool_lengths.json', bge_lengths)
        dump(out / 'encoder_input_manifest.json', {'e5': e5_meta, 'bge': bge_meta,
             'bge_rule': 'Observe BGE collisions for the identical frozen tool IDs; never remine or repair supervision by BGE signatures'})
        available = [policy for policy in POLICIES if all((TRAINING / f'{policy}_seed{seed}.json').exists() for seed in SEEDS)]
        require(all(policy in available for policy in POLICIES[:-1]), 'Five predense policies must be present for all six seeds')
        if stage == 'complete':
            mining_manifest = load(TRAINING / 'dense_mining_manifest.json')
            require(mining_manifest['model_sha256'] == sha(REPRO / 'data/raw/model/model.safetensors'), 'Mining vectors came from a different E5 weight identity')
            require(mining_manifest['source_freeze_sha256'] == sha(SOURCE / 'freeze_manifest.json'), 'Mining source freeze differs')
            require(mining_manifest['pool_sha256'] == sha(TRAINING / 'dense_top50_eligible.json'), 'Dense pool differs from mining manifest')
            require(available == POLICIES, 'Complete diagnostics requires all six policies')
        dense = load(TRAINING / 'dense_top50_eligible.json') if 'DENSE_STATIC' in available else None
        if dense is not None:
            require(set(dense) == qids, 'Dense pool query IDs differ')
            for qid, pool in dense.items():
                require(len(pool) == len(set(pool)) == 50 and set(pool) <= allowed and not set(pool) & masks[qid],
                        f'Invalid dense pool: {qid}')
        # Complete stage consumes normalized float32 embeddings only; no model loading.
        mining = None
        if stage == 'complete':
            order_path = TRAINING / 'mining_order.json'
            order = load(order_path)
            dpath, qpath = TRAINING / 'mining_corpus_embeddings.npy', TRAINING / 'mining_query_embeddings.npy'
            inputs[str(dpath.resolve())], inputs[str(qpath.resolve())] = sha(dpath), sha(qpath)
            documents, query_vectors = np.load(dpath, mmap_mode='r'), np.load(qpath, mmap_mode='r')
            require(documents.dtype == query_vectors.dtype == np.float32, 'Mining embeddings must retain float32 precision')
            require(documents.shape == (len(order['corpus_ids']), 384), 'Unexpected E5 corpus embedding shape')
            require(query_vectors.shape == (len(order['query_ids']), 384), 'Unexpected E5 query embedding shape')
            require(set(order['corpus_ids']) == allowed and len(set(order['corpus_ids'])) == len(allowed), 'Mining corpus does not equal training-side corpus')
            require(set(order['query_ids']) == qids and len(set(order['query_ids'])) == len(qids), 'Mining query mapping differs')
            require(np.isfinite(documents).all() and np.isfinite(query_vectors).all(), 'Nonfinite mining embeddings')
            d_norm_error = float(np.max(np.abs(np.linalg.norm(documents, axis=1) - 1)))
            q_norm_error = float(np.max(np.abs(np.linalg.norm(query_vectors, axis=1) - 1)))
            require(max(d_norm_error, q_norm_error) <= 1e-4, 'Mining embeddings are not L2 normalized within stated float32 norm-check tolerance')
            mining = {'documents': documents, 'queries': query_vectors,
                      'd_index': {tid: i for i, tid in enumerate(order['corpus_ids'])},
                      'q_index': {qid: i for i, qid in enumerate(order['query_ids'])},
                      'norm_check': {'max_document_error': d_norm_error, 'max_query_error': q_norm_error,
                                     'absolute_tolerance': 1e-4, 'scope': 'norm sanity only, not cross-run score/rank equivalence'}}
        aggregates, verified_replacements = [], []
        sorted_ids = sorted(train_ids)
        with (out / 'policy_query_diagnostics.jsonl').open('w', encoding='utf-8') as query_stream:
            for seed in SEEDS:
                negatives = {policy: load(TRAINING / f'{policy}_seed{seed}.json') for policy in available}
                require(all(set(rows) == qids for rows in negatives.values()), f'Policy query sets differ, seed {seed}')
                random_stream, bm25_stream = random.Random(seed + 2000), random.Random(seed + 3000)
                for query in train:
                    qid, expected_random = query['id'], []
                    while len(expected_random) < 4:
                        tid = random_stream.choice(train_ids)
                        if tid not in masks[qid] and tid not in expected_random:
                            expected_random.append(tid)
                    require(negatives['R_ID'][qid] == expected_random, f'R_ID sequential RNG mismatch for seed {seed}, {qid}')
                    require(negatives['B_ID'][qid] == bm25_stream.sample(bpools[qid], 4), f'B_ID sequential RNG mismatch for seed {seed}, {qid}')
                old = load(SOURCE / f'negatives_seed{seed}.json') if seed in (42, 43, 44) else None
                if old is not None:
                    require(all(negatives['R_ID'][qid] == old[qid]['random'] and negatives['B_ID'][qid] == old[qid]['bm25'] for qid in qids),
                            f'Original R/B frozen negative prefix differs, seed {seed}')
                repairs = load(TRAINING / f'unique_repairs_seed{seed}.json')
                repair_map = {(r['query_id'], r['policy'], r['position']): r for r in repairs}
                require(len(repair_map) == len(repairs), f'Duplicate repair log key, seed {seed}')
                mixed_rows = load(TRAINING / f'mixed_sources_seed{seed}.json')
                mixed_map = {r['query_id']: r for r in mixed_rows}
                require(set(mixed_map) == qids and len(mixed_map) == len(mixed_rows), 'Mixed provenance query map differs')
                observed_repairs = set()
                for policy, rows in negatives.items():
                    counts = collections.Counter()
                    e5_sizes, bge_sizes, negative_tokens, negative_chars = [], [], [], []
                    for query in train:
                        qid, ids = query['id'], rows[query['id']]
                        require(len(ids) == len(set(ids)) == 4, f'Not four unique IDs: {seed}/{policy}/{qid}')
                        require(set(ids) <= allowed and not set(ids) & masks[qid], f'Tool outside training/mask: {seed}/{policy}/{qid}')
                        pos_e5 = {e5_sig[tid] for tid in query['positives']}
                        require(not set(e5_sig[tid] for tid in ids) & pos_e5, f'E5 input alias of positive used as negative: {seed}/{policy}/{qid}')
                        e5_unique, bge_unique = len({e5_sig[tid] for tid in ids}), len({bge_sig[tid] for tid in ids})
                        bge_pos_aliases = sum(bge_sig[tid] in {bge_sig[p] for p in query['positives']} for tid in ids)
                        counts['queries'] += 1
                        counts['queries_with_e5_negative_input_duplicates'] += e5_unique < 4
                        counts['queries_with_bge_negative_input_duplicates'] += bge_unique < 4
                        counts['queries_with_bge_positive_input_aliases'] += bge_pos_aliases > 0
                        counts['bge_negative_positive_alias_slots'] += bge_pos_aliases
                        e5_sizes.append(e5_unique)
                        bge_sizes.append(bge_unique)
                        negative_tokens.extend(e5_lengths[tid]['encoded_tokens'] for tid in ids)
                        negative_chars.extend(e5_lengths[tid]['characters'] for tid in ids)
                        if policy in ('B_ID', 'B_UNIQUE'):
                            require(set(ids) <= set(bpools[qid]), f'BM25 policy expanded beyond original eligible pool: {qid}')
                        if policy == 'DENSE_STATIC':
                            require(set(ids) <= set(dense[qid]), f'Dense policy outside frozen pool: {qid}')
                            require(ids == local_rng(f'publication_v1|dense_static|{seed}|{qid}').sample(dense[qid], 4), 'Dense local sampling RNG mismatch')
                        if policy == 'MIXED_2R2B':
                            provenance = mixed_map[qid]
                            require(provenance['ids'] == ids and provenance['sources'] == ['R_ID', 'R_ID', 'B_ID', 'B_ID'], 'Mixed source/order mismatch')
                            require(set(ids[2:]) <= set(bpools[qid]), 'Mixed B items outside frozen pool')
                            expected_mixed, rejected = [], {'R_ID': 0, 'B_ID': 0}
                            for origin, pool in [('R_ID', train_ids), ('B_ID', bpools[qid])]:
                                local = local_rng(f'publication_v1|mixed|{origin}|{seed}|{qid}')
                                for _ in range(2):
                                    while True:
                                        tid = local.choice(pool)
                                        if tid not in masks[qid] and tid not in expected_mixed:
                                            break
                                        rejected[origin] += 1
                                    expected_mixed.append(tid)
                            require(ids == expected_mixed and provenance['rejections'] == rejected, 'Mixed local RNG/rejection provenance mismatch')
                        changed = []
                        if policy in ('R_UNIQUE', 'B_UNIQUE'):
                            parent = negatives['R_ID' if policy == 'R_UNIQUE' else 'B_ID'][qid]
                            seen, duplicate_positions = set(), []
                            for position, tid in enumerate(parent):
                                if e5_sig[tid] in seen:
                                    duplicate_positions.append(position)
                                seen.add(e5_sig[tid])
                            changed = [i for i in range(4) if parent[i] != ids[i]]
                            require(changed == duplicate_positions, f'Unique changed an original first occurrence: {seed}/{policy}/{qid}')
                            require(e5_unique == 4, f'Unique retained repeated E5 inputs: {qid}')
                            local = local_rng(f'publication_v1|unique_repair|{policy}|{seed}|{qid}')
                            used = {e5_sig[tid] for tid in parent}
                            pool = sorted_ids if policy == 'R_UNIQUE' else sorted(bpools[qid])
                            for position in changed:
                                candidates = [tid for tid in pool if tid not in masks[qid] and e5_sig[tid] not in used]
                                require(candidates, 'No eligible repair candidate')
                                expected = local.choice(candidates)
                                require(ids[position] == expected, f'Unique deterministic repair RNG differs: {seed}/{policy}/{qid}')
                                used.add(e5_sig[expected])
                                key = (qid, policy, position)
                                require(key in repair_map, 'Missing repair provenance')
                                item = repair_map[key]
                                require(item['seed'] == seed and item['old_id'] == parent[position] and item['new_id'] == expected
                                        and item['old_signature'] == e5_sig[parent[position]] and item['new_signature'] == e5_sig[expected], 'Repair provenance differs from actual frozen IDs')
                                observed_repairs.add(key)
                                verified_replacements.append(dict(item))
                            counts['changed_queries'] += bool(changed)
                            counts['changed_slots'] += len(changed)
                        query_stream.write(json.dumps({'seed': seed, 'policy': policy, 'query_id': qid, 'e5_distinct_negative_inputs': e5_unique,
                            'bge_distinct_negative_inputs': bge_unique, 'bge_positive_alias_slots': bge_pos_aliases,
                            'changed_slots': changed}, ensure_ascii=False) + '\n')
                    aggregates.append({'seed': seed, 'policy': policy, **dict(counts),
                         'e5_duplicate_query_fraction': counts['queries_with_e5_negative_input_duplicates'] / len(train),
                         'bge_duplicate_query_fraction': counts['queries_with_bge_negative_input_duplicates'] / len(train),
                         'changed_query_fraction': counts['changed_queries'] / len(train) if policy.endswith('UNIQUE') else None,
                         'e5_distinct_input_count': describe(e5_sizes), 'bge_distinct_input_count': describe(bge_sizes),
                         'e5_negative_encoded_tokens': describe(negative_tokens), 'negative_characters': describe(negative_chars)})
                require(observed_repairs == set(repair_map), f'Repair provenance contains nonexistent changes, seed {seed}')
                print('verified frozen policies for seed', seed, 'available', len(available), flush=True)
        dump(out / 'policy_aggregates.json', aggregates)
        dump(out / 'verified_unique_repairs.json', verified_replacements)
        replacement_aggregates = []
        if stage == 'complete':
            common_path = REPRO / 'scripts/common.py'
            spec = importlib.util.spec_from_file_location('original_diagnostic_common', common_path)
            common = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(common)
            inputs[str(common_path.resolve())] = sha(common_path)
            bm25 = common.BM25([by_doc[tid]['text'] for tid in train_ids])
            bm_index = {tid: i for i, tid in enumerate(train_ids)}
            wordsets = {tid: set(re.findall(r'[a-z0-9]+', by_doc[tid]['text'].lower())) for tid in train_ids}
            by_repair_query = collections.defaultdict(list)
            for item in verified_replacements:
                by_repair_query[item['query_id']].append(item)
            measures = collections.defaultdict(lambda: collections.defaultdict(list))
            with (out / 'replacement_quality_changes.jsonl').open('w', encoding='utf-8') as stream:
                for qid in sorted(by_repair_query):
                    query = by_query[qid]
                    # Reuse original term weights, but follow the extension's
                    # frozen deterministic float32 column-summation order.
                    columns = sorted({bm25.vocab[word] for word in common.words(query['query']) if word in bm25.vocab})
                    bm_scores = np.asarray(bm25.mat[:, columns].sum(axis=1)).ravel().astype(np.float32)
                    query_words = set(re.findall(r'[a-z0-9]+', query['query'].lower()))
                    qvec = mining['queries'][mining['q_index'][qid]]
                    for item in by_repair_query[qid]:
                        record = dict(item)
                        before_after = {}
                        for side, tid in [('before', item['old_id']), ('after', item['new_id'])]:
                            union = query_words | wordsets[tid]
                            before_after[side] = {'bm25': float(bm_scores[bm_index[tid]]),
                                'fixed_e5_cosine': float(np.dot(qvec, mining['documents'][mining['d_index'][tid]])),
                                'e5_full_tokens': e5_lengths[tid]['full_tokens'], 'e5_encoded_tokens': e5_lengths[tid]['encoded_tokens'],
                                'bge_full_tokens': bge_lengths[tid]['full_tokens'], 'bge_encoded_tokens': bge_lengths[tid]['encoded_tokens'],
                                'characters': len(by_doc[tid]['text']),
                                'query_document_jaccard': len(query_words & wordsets[tid]) / len(union) if union else 0.0}
                        delta = {key: before_after['after'][key] - before_after['before'][key] for key in before_after['before']}
                        record.update(**before_after, delta=delta)
                        stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')
                        group = (item['seed'], item['policy'])
                        for key in delta:
                            for side in ('before', 'after'):
                                measures[group][side + '.' + key].append(before_after[side][key])
                            measures[group]['delta.' + key].append(delta[key])
            for (seed, policy), fields in sorted(measures.items()):
                replacement_aggregates.append({'seed': seed, 'policy': policy,
                    'slot_weighted_description': {key: describe(values) for key, values in fields.items()}})
            dump(out / 'replacement_quality_aggregates.json', replacement_aggregates)
        report = {'status': 'PASS_COMPLETE' if stage == 'complete' else 'PASS_AVAILABLE_POLICIES_DENSE_AND_SIMILARITIES_PENDING',
                  'created_at': now(), 'stage': stage, 'seeds': SEEDS, 'policies_validated': available,
                  'pending_policies': [p for p in POLICIES if p not in available], 'queries_per_policy_seed': len(train),
                  'policy_seed_cells_validated': len(available) * len(SEEDS), 'four_distinct_negative_IDs_all_passed': True,
                  'training_side_only_and_forbidden_ID_masks_all_passed': True,
                  'all_known_positive_E5_input_aliases_excluded': True, 'original_42_43_44_R_B_ID_lists_exact': True,
                  'unique_first_occurrence_and_no_change_when_original_distinct': True,
                  'unique_deterministic_minimal_repair_and_provenance_exact': True,
                  'bge_supervision_unchanged': True, 'verified_replacement_slots': len(verified_replacements),
                  'similarity_diagnostics_complete': stage == 'complete',
                  'mining_embedding_norm_check': mining['norm_check'] if mining else None,
                  'diagnostic_definitions': {'BM25': 'original common.BM25 term weights, canonical sorted vocabulary-column float32 sum as extension scoring; training-side corpus only; k1=1.5,b=.75,positive Robertson IDF',
                    'fixed_e5': 'CPU float32 dot product of saved normalized pretrained-E5 mining vectors; may differ at roundoff scale from GPU arithmetic',
                    'lexical_overlap': 'set Jaccard of lowercase regex [a-z0-9]+ query and serialized document tokens',
                    'lengths': 'E5 prefix passage: / BGE empty document prefix; full and384-token-capped token counts, plus document Unicode characters',
                    'repair_aggregation': 'slot-weighted before/after/delta distribution, separately per seed and policy; changed-query proportion separately reported'},
                  'claims_boundary': 'Input/ID facts and replacement associations only; no semantic false-negative truth or causal mechanism claim',
                  'input_sha256': inputs, 'code_sha256': sha(__file__), 'elapsed_seconds': time.perf_counter() - started}
        dump(out / 'diagnostics_report.json', report)
        dump(out / 'status.json', {'status': 'completed', 'completed_at': now(), 'scientific_scope': report['status']})
        return report
    except Exception as error:
        dump(out / 'status.json', {'status': 'failed', 'failed_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=['validate', 'complete'])
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--bge-model', type=pathlib.Path, default=ROOT / 'models/bge-small-5c38ec7c405e')
    args = parser.parse_args()
    report = audit(args.stage, args.output, args.bge_model)
    print(json.dumps({key: report[key] for key in ('status', 'policy_seed_cells_validated', 'verified_replacement_slots', 'elapsed_seconds')}, indent=2))


if __name__ == '__main__':
    main()
