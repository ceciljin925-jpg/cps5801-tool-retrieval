"""Portable CPU tables from frozen negative-policy diagnostics; no model scores.

Full policy distributions: duplicate inputs, repair rates and document lengths.
BM25/cosine/Jaccard before/after values: actual replaced slots only. These are
never relabelled as a full-policy hardness distribution or semantic truth.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

import numpy as np

from rebuild_all import Resolver, read_json, require, sha, write_csv, write_json

POLICIES = ['R_ID','B_ID','R_UNIQUE','B_UNIQUE','MIXED_2R2B','DENSE_STATIC']
SEEDS = [41,42,43,44,45,46]
MEASURES = {'bm25':'BM25 score', 'fixed_e5_cosine':'cosine similarity',
            'e5_full_tokens':'tokens including passage prefix and special tokens; untruncated',
            'e5_encoded_tokens':'tokens including passage prefix and special tokens; capped at384',
            'bge_full_tokens':'tokens including special tokens, no document prefix; untruncated',
            'bge_encoded_tokens':'tokens including special tokens, no document prefix; capped at384',
            'characters':'Unicode characters of retrieval document text',
            'query_document_jaccard':'lowercase [a-z0-9]+ set Jaccard'}
FULL_MEASURES = {'e5_distinct_input_count':'distinct encoded negative inputs per query',
                 'bge_distinct_input_count':'distinct encoded negative inputs per query',
                 'e5_negative_encoded_tokens':'E5 document tokens including prefix/specials, cap384',
                 'negative_characters':'Unicode characters per negative document'}
SUMMARY_FIELDS = ['n','mean','median','p05','p95','min','max']


def describe(values):
    values = np.asarray(values,dtype=np.float64)
    require(len(values)>0 and np.isfinite(values).all(),'Empty/nonfinite diagnostic observations')
    return {'n':len(values),'mean':float(values.mean()),'median':float(np.median(values)),
            'p05':float(np.percentile(values,5)),'p95':float(np.percentile(values,95)),
            'min':float(values.min()),'max':float(values.max())}


def same_summary(actual, saved, label):
    require(set(saved)==set(SUMMARY_FIELDS),'Unrecognized summary fields: '+label)
    for key in SUMMARY_FIELDS:
        require(math.isclose(actual[key],saved[key],rel_tol=1e-12,abs_tol=1e-10), 'Saved diagnostic summary differs: '+label+'/'+key)


class NegativeRebuilder:
    def __init__(self, root, output, diagnostics=None, figure=True):
        self.resolver = Resolver(root)
        self.pub = self.resolver.publication
        self.diag = self.resolver.resolve(diagnostics,self.pub) if diagnostics else self.pub/'analysis/negative_complete_attempt01'
        self.out = Path(output).resolve()
        require(not self.out.exists() or not any(self.out.iterdir()),'Choose a new empty output; preserve previous rebuilds')
        require(self.out != self.resolver.root and self.out not in self.resolver.root.parents,'Output cannot replace input root/ancestor')
        self.out.mkdir(parents=True,exist_ok=True)
        self.inputs, self.provenance, self.validation = {}, [], []
        self.figure = figure
        self.report = self.load(self.diag/'diagnostics_report.json')
        self.bindings = {str(self.resolver.resolve(p,must_exist=False)):value for p,value in self.report['input_sha256'].items()}

    def source(self,path):
        path = Path(path).resolve()
        if path not in self.inputs:
            value = sha(path)
            expected = getattr(self,'bindings',{}).get(str(path))
            require(expected is None or value==expected,'Frozen diagnostic input SHA mismatch: '+str(path))
            self.inputs[path] = {'path':self.resolver.display(path),'bytes':path.stat().st_size,'sha256':value}
        return self.inputs[path]

    def load(self,path):
        self.source(path)
        return read_json(path)

    def register(self,path,sources,formula,unit,scope):
        self.provenance.append({'output':path.relative_to(self.out).as_posix(),'output_sha256':sha(path),'output_bytes':path.stat().st_size,
            'inputs':[self.source(p) for p in sorted(set(sources))],
            'script':{'name':Path(__file__).name,'sha256':sha(__file__)},
            'formula':formula,'unit':unit,'scope':scope,'seeds':SEEDS,
            'missing_handling':'Unavailable full-policy hardness remains explicitly unavailable; no extrapolation from repair slots',
            'quantiles':'numpy linear interpolation,5th/50th/95th sample percentiles; not confidence intervals'})

    def table(self,name,rows,sources,formula,unit,scope):
        path=self.out/name
        write_csv(path,rows)
        self.register(path,sources,formula,unit,scope)

    def verify_policy_rows(self):
        path = self.diag/'policy_query_diagnostics.jsonl'
        self.source(path)
        cells = {(seed,policy):{'query_ids':set(),'e5':[],'bge':[],'alias_slots':0,'alias_queries':0,'changed_queries':0,'changed_slots':0}
                 for seed in SEEDS for policy in POLICIES}
        repair_keys = set()
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                row=json.loads(line); key=(row['seed'],row['policy'])
                require(key in cells,'Unexpected policy/seed in query diagnostics')
                cell=cells[key]; qid=row['query_id']
                require(qid not in cell['query_ids'],'Duplicate query in policy/seed cell')
                cell['query_ids'].add(qid)
                for encoder in ['e5','bge']:
                    value=row[encoder+'_distinct_negative_inputs']
                    require(isinstance(value,int) and 1<=value<=4,'Invalid distinct-input count')
                    cell[encoder].append(value)
                aliases=row['bge_positive_alias_slots']
                require(isinstance(aliases,int) and 0<=aliases<=4,'Invalid positive alias count')
                cell['alias_slots']+=aliases;cell['alias_queries']+=aliases>0
                changed=row['changed_slots']
                require(len(changed)==len(set(changed)) and all(i in [0,1,2,3] for i in changed),'Invalid changed slot indices')
                require(not changed or row['policy'] in ['R_UNIQUE','B_UNIQUE'],'Changes attributed to nonrepair policy')
                cell['changed_queries']+=bool(changed);cell['changed_slots']+=len(changed)
                repair_keys.update((row['seed'],row['policy'],qid,i) for i in changed)
        require(all(len(c['query_ids'])==10000 for c in cells.values()),'Each cell must contain10000 unique queries')
        reference=cells[(41,'R_ID')]['query_ids']
        require(all(c['query_ids']==reference for c in cells.values()),'Policy query frames differ')
        return cells,repair_keys

    def policies(self):
        aggregate_path=self.diag/'policy_aggregates.json'
        saved=self.load(aggregate_path)
        require(len(saved)==36 and len({(r['seed'],r['policy']) for r in saved})==36,'Expected36 policy/seed summaries')
        cells,repair_keys=self.verify_policy_rows()
        lengths_path=self.pub/'data/training/e5_tool_lengths.json'
        lengths=self.load(lengths_path)
        rates,distributions=[],[]
        sources=[aggregate_path,self.diag/'policy_query_diagnostics.jsonl',lengths_path]
        for row in sorted(saved,key=lambda r:(POLICIES.index(r['policy']),r['seed'])):
            key=(row['seed'],row['policy']);cell=cells[key];n=len(cell['query_ids']);slots=4*n
            require(row['queries']==n,'Wrong full-policy query denominator')
            counts={'queries_with_e5_negative_input_duplicates':sum(v<4 for v in cell['e5']),
                    'queries_with_bge_negative_input_duplicates':sum(v<4 for v in cell['bge']),
                    'queries_with_bge_positive_input_aliases':cell['alias_queries'],'bge_negative_positive_alias_slots':cell['alias_slots']}
            for field,value in counts.items():require(row[field]==value,'Aggregate/query count mismatch: '+field)
            repair=row['policy'] in ['R_UNIQUE','B_UNIQUE']
            if repair:
                require(row['changed_queries']==cell['changed_queries'] and row['changed_slots']==cell['changed_slots'],'Repair count mismatch')
                require(math.isclose(row['changed_query_fraction'],cell['changed_queries']/n,abs_tol=1e-12),'Repair fraction mismatch')
            for encoder in ['e5','bge']:
                require(math.isclose(row[encoder+'_duplicate_query_fraction'],counts['queries_with_'+encoder+'_negative_input_duplicates']/n,abs_tol=1e-12),'Duplicate fraction mismatch')
                same_summary(describe(cell[encoder]),row[encoder+'_distinct_input_count'],str(key)+'/'+encoder)
            policy_path=self.pub/f'data/training/{row["policy"]}_seed{row["seed"]}.json'
            negatives=self.load(policy_path);sources.append(policy_path)
            require(set(negatives)==cell['query_ids'],'Negative query frame differs from diagnostics')
            require(all(len(ids)==len(set(ids))==4 for ids in negatives.values()),'Not four distinct negative IDs')
            flat_ids=[tid for ids in negatives.values() for tid in ids]
            for metric,field in [('e5_negative_encoded_tokens','encoded_tokens'),('negative_characters','characters')]:
                same_summary(describe([lengths[tid][field] for tid in flat_ids]),row[metric],str(key)+'/'+metric)
            rates.append({'seed':row['seed'],'policy':row['policy'],'scope':'all frozen realized negatives, every training query once',
                'query_denominator':n,'negative_slots_per_query':4,'slot_denominator':slots,
                'e5_duplicate_query_count':counts['queries_with_e5_negative_input_duplicates'],
                'e5_duplicate_query_fraction':row['e5_duplicate_query_fraction'],
                'bge_duplicate_query_count':counts['queries_with_bge_negative_input_duplicates'],
                'bge_duplicate_query_fraction':row['bge_duplicate_query_fraction'],
                'bge_positive_alias_query_count':cell['alias_queries'],'bge_positive_alias_query_fraction':cell['alias_queries']/n,
                'bge_positive_alias_slot_count':cell['alias_slots'],'bge_positive_alias_slot_fraction':cell['alias_slots']/slots,
                'repair_applicable':repair,'changed_query_count':cell['changed_queries'] if repair else None,
                'changed_query_fraction':cell['changed_queries']/n if repair else None,
                'changed_slot_count':cell['changed_slots'] if repair else None,
                'changed_slot_fraction':cell['changed_slots']/slots if repair else None,
                'repair_parent_policy':row['policy'].replace('_UNIQUE','_ID') if repair else None,
                'full_policy_BM25_cosine_Jaccard_distribution':'not measured by these diagnostics'})
            for metric,unit in FULL_MEASURES.items():
                distributions.append({'seed':row['seed'],'policy':row['policy'],'scope':'all training queries once' if 'distinct' in metric else 'all frozen negative slots once',
                    'metric':metric,'unit':unit,**row[metric]})
        self.table('policy_input_rates.csv',rates,sources,'Counts/fractions over10000 unique query rows or40000 negative slots; repair only for UNIQUE policies','fractions[0,1], counts','full realized policy')
        self.table('policy_full_distributions.csv',distributions,sources,'Exact descriptive summary of saved query diagnostics; length summaries independently checked against all frozen negative IDs/token metadata','per-row explicit units','full realized policy; no BM25/cosine/Jaccard distribution')
        self.validation.append({'check':'full_policy_counts_and_length_distributions','cells':36,'query_rows':360000,'negative_slots':1440000,'passed':True})
        return rates,repair_keys

    def repairs(self,expected_keys):
        raw_path=self.diag/'replacement_quality_changes.jsonl'
        raw=self.load(raw_path)
        original=self.load(self.diag/'verified_unique_repairs.json')
        saved=self.load(self.diag/'replacement_quality_aggregates.json')
        key=lambda r:(r['seed'],r['policy'],r['query_id'],r['position'])
        require(len(raw)==len(original)==self.report['verified_replacement_slots']==4830,'Repair slot count differs from complete report')
        require(len({key(r) for r in raw})==len(raw) and {key(r) for r in raw}==expected_keys,'Raw repair/query diagnostics differ')
        records={key(r):r for r in original}
        series=defaultdict(list);observations=[]
        for row in sorted(raw,key=key):
            require(all(row[k]==v for k,v in records[key(row)].items()),'Original repair metadata mismatch')
            result={k:row[k] for k in ['seed','policy','query_id','position','old_id','new_id']}
            for side in ['before','after','delta']:require(set(row[side])==set(MEASURES),'Unexpected repair diagnostic fields')
            for metric in MEASURES:
                require(math.isclose(row['after'][metric]-row['before'][metric],row['delta'][metric],rel_tol=1e-12,abs_tol=1e-12),'Unpaired before/after delta')
                for side in ['before','after','delta']:
                    value=row[side][metric];require(math.isfinite(value),'Nonfinite repair value')
                    series[(row['seed'],row['policy'],side,metric)].append(value)
                    result[side+'_'+metric]=value
            observations.append(result)
        summaries=[];seen=set()
        for row in saved:
            require(set(row['slot_weighted_description'])=={s+'.'+m for s in ['before','after','delta'] for m in MEASURES},'Missing repair metric/side')
            for name,summary in row['slot_weighted_description'].items():
                side,metric=name.split('.',1);key_=(row['seed'],row['policy'],side,metric)
                require(key_ not in seen,'Duplicate repair summary');seen.add(key_)
                actual=describe(series[key_]);same_summary(actual,summary,str(key_))
                qids={r['query_id'] for r in raw if (r['seed'],r['policy'])==(row['seed'],row['policy'])}
                summaries.append({'seed':row['seed'],'policy':row['policy'],'scope':'actually replaced negative slots only',
                    'side':side,'metric':metric,'unit':MEASURES[metric],
                    'affected_query_count':len(qids),'all_training_query_count':10000,'all_negative_slot_count':40000,
                    'fraction_of_all_negative_slots':actual['n']/40000,**actual})
        require(seen==set(series),'Saved repair summaries omit observations')
        sources=[raw_path,self.diag/'verified_unique_repairs.json',self.diag/'replacement_quality_aggregates.json',self.diag/'policy_query_diagnostics.jsonl']
        self.table('replacement_slot_distributions.csv',summaries,sources,'Before/after and per-slot paired difference distributions, recomputed from actual replacement records; percentiles are not confidence intervals','per-row explicit units','replaced slots only, not all policy negatives or unique query-tool pairs')
        self.table('replacement_slot_observations.csv',observations,sources,'One row per actual seed/policy/query/slot replacement; delta=after-before','raw numeric diagnostics','replaced slots only; repeated queries/pairs across seeds remain separate')
        self.validation.append({'check':'raw_repair_metadata_deltas_and_summary_statistics','replacement_slots':len(raw),'summary_rows':len(summaries),'passed':True})
        return summaries

    def explanations(self,rates,repairs):
        summary=[]
        for policy in POLICIES:
            rows=[r for r in rates if r['policy']==policy]
            summary.append({'policy':policy,'seeds':'41,42,43,44,45,46','number_of_fixed_sampling_seeds':6,
                'minimum_duplicate_query_count':min(r['e5_duplicate_query_count'] for r in rows),
                'maximum_duplicate_query_count':max(r['e5_duplicate_query_count'] for r in rows),
                'minimum_duplicate_query_percent':100*min(r['e5_duplicate_query_fraction'] for r in rows),
                'maximum_duplicate_query_percent':100*max(r['e5_duplicate_query_fraction'] for r in rows),
                'observed_E5_and_BGE_counts_equal':all(r['e5_duplicate_query_count']==r['bge_duplicate_query_count'] for r in rows),
                'range_interpretation':'range across six frozen negative-sampling seeds; not confidence interval or training-effect uncertainty'})
        self.table('policy_descriptive_seed_ranges.csv',summary,[self.out/'policy_input_rates.csv'],'Min/max across all six fixed negative-sampling seeds; never a statistical confidence interval','count and percent of10000 queries','full policy input duplication only')
        r42=next(r for r in rates if r['seed']==42 and r['policy']=='R_UNIQUE')
        b42=next(r for r in rates if r['seed']==42 and r['policy']=='B_UNIQUE')
        bchanges={r['metric']:r for r in repairs if r['seed']==42 and r['policy']=='B_UNIQUE' and r['side']=='delta'}
        zh='本表只描述冻结负例的采样与编码输入事实，没有读取训练效果、开发成绩或外部确认成绩。\n'
        zh+='每个策略与采样种子有10000个训练query，每个query有4个不同工具ID，合计40000个负例槽。不同ID仍可能编码成相同输入；重复率的分子是4个负例中存在相同编码输入的query数，分母是10000，不是工具ID重复率。\n'
        for row in summary:
            zh+=f"{row['policy']}：E5重复query数为{row['minimum_duplicate_query_count']}–{row['maximum_duplicate_query_count']}，即{row['minimum_duplicate_query_percent']:.4g}%–{row['maximum_duplicate_query_percent']:.4g}%；这里的范围来自采样seed41–46，不是置信区间。\n"
        zh+='本次全部36个策略×seed格中，E5与BGE的重复query计数相同；这只描述相同工具ID在这两个冻结输入处理规则下的观测，不能推广到任意tokenizer或编码器。Unique修复按E5输入签名定义，BGE仅接受相同监督ID并作事后输入诊断。\n'
        zh+=f"以预先指定seed42为例，R_UNIQUE改变{r42['changed_query_count']}个query、{r42['changed_slot_count']}个槽（query率{r42['changed_query_fraction']:.4%}，槽率{r42['changed_slot_fraction']:.4%}）；B_UNIQUE改变{b42['changed_query_count']}个query、{b42['changed_slot_count']}个槽（query率{b42['changed_query_fraction']:.4%}，槽率{b42['changed_slot_fraction']:.4%}）。query率与槽率不可互换。\n"
        zh+='policy_full_distributions.csv覆盖各完整策略的全部query或全部负例槽。replacement_slot_distributions.csv则只覆盖实际被替换的槽；BM25、固定未微调E5余弦、Jaccard及其长度变化都属于这个选择后的子集，未计算整个策略的难度分布，也不能将子集均值当完整策略均值。\n'
        zh+=f"seed42的B_UNIQUE实际替换槽，平均逐槽变化为BM25 {bchanges['bm25']['mean']:+.6g}、固定E5余弦 {bchanges['fixed_e5_cosine']['mean']:+.6g}、E5编码长度 {bchanges['e5_encoded_tokens']['mean']:+.6g} token、Jaccard {bchanges['query_document_jaccard']['mean']:+.6g}。这是替换前后对应槽的描述，不是模型性能变化，也不是全部负例的难度变化。\n"
        zh+='所有分位数是实际记录的描述性分位数，不是统计置信区间；同一query、工具或pair可在槽/seed之间重复，不假设这些行彼此独立。token计数含编码器特殊token及实际prefix，区分不截断与384上限；它不同于效率图中的raw JSON无特殊token、无截断文档token口径。\n'
        zh+='输入去重同时可能改变难度、长度、多样性等因素。这些记录不能证明语义假负例已减少、机制已识别或检索效果提高；独立人审仍为HUMAN_PENDING。不会用R_UNIQUE极少的实际修复补抽其他层或追挑更明显案例。\n'
        en='These tables describe frozen negative sampling and encoder inputs only. No training, development or external confirmation scores are read.\n'
        en+='Each policy/seed cell contains10,000 training queries and four distinct tool IDs per query, hence40,000 negative slots. Input duplication is the fraction of queries with fewer than four distinct encoded negative inputs, not duplicate tool IDs.\n'
        en+='The policy tables describe all realized negatives. BM25, fixed pretrained-E5 cosine, Jaccard and paired before/after changes describe only the actually replaced slots. Their conditional distributions are not full-policy hardness distributions. No such full-policy hardness estimate is imputed.\n'
        en+=f"For prespecified sampling seed42, R_UNIQUE changes{r42['changed_query_count']} queries/{r42['changed_slot_count']} slots; B_UNIQUE changes{b42['changed_query_count']} queries/{b42['changed_slot_count']} slots. Query and slot denominators are10,000 and40,000 respectively.\n"
        en+='The observed E5/BGE duplicate-query counts agree across these36 cells; this is limited to the frozen IDs and input rules. E5 signatures determine repair; BGE receives the same IDs without separate repair.\n'
        en+='Percentiles and ranges across six sampling seeds are descriptive, not confidence intervals. Repeated query/tool/pair occurrences are retained; slots or seeds are not asserted independent. Lengths include special tokens and actual encoder prefixes, with full and384-token-capped versions; these differ from raw-JSON, no-special-token, untruncated document budgets used in efficiency plots.\n'
        en+='Repair may alter hardness, length and diversity jointly. These observations neither identify a semantic false-negative mechanism nor establish retrieval improvement. Independent human validation remains HUMAN_PENDING. Sparse Random repair strata are not topped up.\n'
        for name,text in [('解释_采样与输入事实.txt',zh),('interpretation_sampling_and_inputs_en.txt',en)]:
            path=self.out/name;path.write_text(text,encoding='utf-8')
            self.register(path,[self.out/'policy_input_rates.csv',self.out/'replacement_slot_distributions.csv'],'Bounded factual narrative of diagnostic tables','descriptive facts','no trained-model performance or human semantic claims')
        definitions={'policy_input_rates.csv':{'unit':'one policy/seed; every training query once','duplicate_query_fraction':'query count with <4 distinct encoded negative inputs /10000',
            'changed_query_fraction':'query count with>=1 replaced slot /10000, UNIQUE only','changed_slot_fraction':'actual changed slots /40000, UNIQUE only','blank_repair_fields':'not applicable for non-UNIQUE policies, not measured zero effect'},
            'policy_full_distributions.csv':{'unit':'query for distinct-input count; negative slot for document length','measures':FULL_MEASURES,'no_full_policy_hardness':'BM25/E5-cosine/Jaccard unavailable for full policies'},
            'replacement_slot_distributions.csv':{'unit':'actually replaced slot within seed/policy','before':'removed tool at that slot','after':'replacement tool at same slot','delta':'paired after-before; median(delta) need not equal median(after)-median(before)','measures':MEASURES,'n':'changed-slot count, not unique query or unique pair count'},
            'replacement_slot_observations.csv':{'position':'zero-based original negative slot0..3','rows':'retained per seed; no cross-seed pair deduplication'},
            'all_summaries':{'mean':'equal weight per declared observation unit','quantiles':'numpy linear percentile interpolation','uncertainty':'no inferential confidence intervals or p-values','seed_scope':'negative sampling seeds41..46, not fitted model performance'}}
        path=self.out/'field_definitions.json';write_json(path,definitions)
        self.register(path,[self.diag/'diagnostics_report.json',self.diag/'encoder_input_manifest.json'],'Column units, denominators and missingness rules','metadata','all diagnostic tables')

    def plot(self,rates):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(1,2,figsize=(10.8,4.3),gridspec_kw={'width_ratios':[1.65,1]},layout='constrained')
        colors=plt.get_cmap('viridis')(np.linspace(.12,.88,6))
        for j,seed in enumerate(SEEDS):
            for i,policy in enumerate(POLICIES):
                row=next(r for r in rates if (r['seed'],r['policy'])==(seed,policy))
                axes[0].scatter(100*row['e5_duplicate_query_fraction'],i+(j-2.5)*.055,s=27,color=colors[j],label=str(seed) if i==0 else None,zorder=3)
            for i,policy in enumerate(['R_UNIQUE','B_UNIQUE']):
                row=next(r for r in rates if (r['seed'],r['policy'])==(seed,policy))
                axes[1].scatter(100*row['changed_slot_fraction'],i+(j-2.5)*.055,s=27,color=colors[j],zorder=3)
        axes[0].set_yticks(range(6),POLICIES);axes[0].invert_yaxis();axes[0].set_xlim(-.15,9.3)
        axes[0].set_title('Queries with duplicated E5 negative inputs')
        axes[0].set_xlabel('Percent of 10,000 training queries')
        axes[1].set_yticks([0,1],['R_UNIQUE','B_UNIQUE']);axes[1].invert_yaxis();axes[1].set_ylim(1.6,-.6);axes[1].set_xlim(-.05,2.3)
        axes[1].set_title('Actual replacement slots')
        axes[1].set_xlabel('Percent of 40,000 negative slots')
        for ax in axes:
            ax.grid(axis='x',alpha=.2);ax.spines[['top','right']].set_visible(False)
        axes[0].legend(title='Sampling seed',ncol=3,loc='center right',fontsize=7,title_fontsize=8)
        r_values=[100*r['e5_duplicate_query_fraction'] for r in rates if r['policy']=='R_ID']
        axes[0].text(.2,.37,f'{min(r_values):.2f}–{max(r_values):.2f}%',fontsize=8,color='#444444')
        r_slots=[100*r['changed_slot_fraction'] for r in rates if r['policy']=='R_UNIQUE']
        axes[1].text(.1,-.27,f'{min(r_slots):.4g}–{max(r_slots):.4g}%',fontsize=8,color='#444444')
        fig.suptitle('Frozen negative-input diagnostics: six sampling seeds, no training outcomes',fontsize=12)
        for extension in ['png','pdf']:
            path=self.out/('negative_input_rates.'+extension)
            fig.savefig(path,dpi=180)
            self.register(path,[self.out/'policy_input_rates.csv'],'Dots show observed sampling-seed rates; no error bars or inference','percent, different explicit denominators per panel','full policy duplication and actual repair-slot rates')
        plt.close(fig)

    def run(self):
        require(self.report['status']=='PASS_COMPLETE' and self.report['policy_seed_cells_validated']==36 and self.report['seeds']==SEEDS and self.report['policies_validated']==POLICIES,'Complete frozen diagnostic report required')
        require(self.report['similarity_diagnostics_complete'] and not self.report['pending_policies'],'Pending diagnostics cannot be labelled complete')
        require(self.load(self.diag/'status.json')['status']=='completed','Diagnostic attempt incomplete')
        self.load(self.diag/'encoder_input_manifest.json')
        rates,keys=self.policies();repairs=self.repairs(keys);self.explanations(rates,repairs)
        if self.figure:self.plot(rates)
        status={'status':'PASS_COMPLETE_NEGATIVE_INPUT_TABLES','created_at_utc':datetime.now(timezone.utc).isoformat(),
                'policy_seed_cells':36,'full_policy_query_rows':360000,'full_policy_negative_slots':1440000,
                'replacement_slots':4830,'validation':self.validation,'new_training_or_final_scores_read':False,
                'models_loaded':False,'GPU_used':False,'human_status':'HUMAN_PENDING',
                'full_policy_hardness_distribution':'not measured; no extrapolation from replacement subset',
                'script_sha256':sha(__file__)}
        write_json(self.out/'table_provenance.json',{'schema_version':1,'tables_and_artifacts':self.provenance,
            'all_input_files':list(self.inputs.values()),'input_root':str(self.resolver.root),
            'diagnostic_producer_code_sha256':self.report['code_sha256'],
            'upstream_large_vectors':'Not loaded by this table rebuilder; original diagnostic source hashes retained in diagnostics_report.json; large files may be GPU-retained only'})
        write_json(self.out/'status.json',status)
        return status


def self_test():
    values=[1,2,7,10]
    expected={'n':4,'mean':5.0,'median':4.5,'p05':1.15,'p95':9.55,'min':1.0,'max':10.0}
    same_summary(describe(values),expected,'fixture')
    try:same_summary(describe(values),{**expected,'mean':6},'tampered')
    except ValueError:pass
    else:raise AssertionError('Tampered saved aggregate accepted')
    before=np.array([0,100,101]);after=np.array([50,51,102])
    require(np.median(after-before)!=np.median(after)-np.median(before),'Fixture must distinguish paired-delta median')
    return {'passed':True,'checks':['linear descriptive quantiles','aggregate mismatch rejection','paired-delta vs difference-of-medians distinction'],'no_real_scores':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root',type=Path);parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--diagnostics',type=Path);parser.add_argument('--no-figure',action='store_true')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:print(json.dumps(self_test()));return 0
    if args.input_root is None or args.output_dir is None:parser.error('--input-root and --output-dir required')
    output=NegativeRebuilder(args.input_root,args.output_dir,args.diagnostics,not args.no_figure)
    try:report=output.run()
    except BaseException as error:
        write_json(output.out/'status.json',{'status':'FAILED_VERIFICATION','error':repr(error),'no_training_or_final_scores_read':True})
        raise
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0


if __name__=='__main__':
    sys.exit(main())
