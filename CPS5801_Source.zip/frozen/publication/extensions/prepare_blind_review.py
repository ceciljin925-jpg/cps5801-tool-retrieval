"""Prepare blank, genuinely blinded human-review materials; never label items.

Commands: original (50 archived audit pairs), freeze-new-plan (four strata,
at most 80 draws), new (realized seed42 Unique repair pairs), validate.
All source files remain read-only. Only blind_review.csv/.html and
reviewer_instructions.txt should be sent to reviewers. Hidden keys and sampling
manifests disclose strata/original decisions and must remain with the organizer.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import html
import io
import json
import math
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT.parent / "handoff" / "CPS5801_PUBLICATION_HANDOFF_20261112"
SOURCE = PACKAGE / "archive" / "CPS5801_HANDOFF_20261025" / "CPS5801"
LABELS = {"N": "文档明确支持候选不能满足所需功能，是可辩护的负例。",
          "V": "文档支持候选可替代所请求的某个组件，不要求独自完成多组件请求。",
          "C": "文档支持候选是遗漏但共同必需的组件，与可替代工具不同。",
          "U": "元数据缺失、冲突或约束不明确，不能可靠判断。"}
BLIND_FIELDS = ["blind_id", "query", "candidate_tool_json", "known_positive_context_json",
                "label", "reason", "evidence_text", "reviewer_role", "reviewed_at", "ai_assistance_used"]


def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, obj, *, replace=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    require(replace or not path.exists(), f"Refusing to overwrite {path}")
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def derived_seed(text):
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:16], 16)


def source_record(path, root):
    return {"path": str(Path(path).relative_to(root)).replace("\\", "/"), "bytes": Path(path).stat().st_size, "sha256": sha(path)}


def instructions():
    return ("独立文档相关性审核说明\n\n请只查看本说明、blind_review.csv 与 blind_review.html；完成初始独立判断前不要查看 hidden_key.json 或 sample_manifest.json。\n"
            "本审核只依据文档，不调用真实 API。已标注正例是理解请求的参考，不是绝对正确答案。共同主题或提供商不足以判 V；不同 ID 不足以判 N。\n\n" +
            "\n".join(f"{label}：{description}" for label, description in LABELS.items()) +
            "\n\n每项填写一个标签及一至两句理由，可短引支撑文本；证据不足可选 U。请记录愿意披露的身份/角色、日期、实际完成范围及是否使用 AI 协助；未完成项留空。\n"
            "请在 CSV 中填写并另存原始答复；HTML 是阅读视图，页面输入不会自动保存。不要修改盲审 ID。完成前不要与组织者讨论原判断。\n"
            "本文件中的所有新标签、理由均为空白；这不表示已完成审核。原有记录曾由 AI 提出意见、学生批量确认，新审核必须如实声明其独立程度。\n")


def render_blind(items):
    parts = ["<!doctype html><html lang='zh-CN'><meta charset='utf-8'><title>独立文档相关性审核</title>",
             "<style>body{max-width:1100px;margin:40px auto;padding:0 24px;font:16px/1.6 Arial,sans-serif;color:#17212b}article{border:1px solid #ccd3db;padding:24px;margin:28px 0;border-radius:8px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f6f8;padding:15px;font:14px/1.5 Consolas,monospace}h1,h2,h3{line-height:1.3}textarea{display:block;width:95%;min-height:70px}label{display:block;margin-top:12px}.note{color:#526170}details{margin:15px 0}</style>",
             "<h1>独立文档相关性审核</h1><p>请逐项阅读请求、候选工具文档和已标注正例参考。仅依据文档；不执行工具。请在 CSV 填写并另存原始答复，以下输入栏不会自动保存。</p>",
             "<ul>" + "".join(f"<li><strong>{label}</strong>：{html.escape(text)}</li>" for label, text in LABELS.items()) + "</ul>",
             "<p class='note'>已标注正例仅作参考，不代表绝对正确。证据不足请选择 U。完成独立初始判断前，请勿查看隐藏映射或抽样清单。</p>"]
    for item in items:
        parts.extend([f"<article><h2>{html.escape(item['blind_id'])}</h2><h3>用户请求</h3><pre>{html.escape(item['query'])}</pre>",
                      f"<h3>候选工具文档</h3><pre>{html.escape(json.dumps(item['tool'], ensure_ascii=False, indent=2))}</pre>",
                      f"<details><summary>已标注正例文档（仅作参考）</summary><pre>{html.escape(json.dumps(item['known_positives'], ensure_ascii=False, indent=2))}</pre></details>",
                      "<label>标签 <select><option value=''></option><option>N</option><option>V</option><option>C</option><option>U</option></select></label>",
                      "<label>理由（1–2句）<textarea></textarea></label><label>支持文档短句（可选）<textarea></textarea></label></article>"])
    parts.append("</html>")
    return "\n".join(parts)


def write_blind(directory, items, key, manifest, *, replace_pending=False):
    directory.mkdir(parents=True, exist_ok=True)
    require(len(items) == len({item["blind_id"] for item in items}) == len(key), "Duplicate blind IDs")
    csv_path = directory / "blind_review.csv"
    require(not csv_path.exists(), "Refusing to overwrite existing blank or completed review form")
    with csv_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=BLIND_FIELDS)
        writer.writeheader()
        for item in items:
            row = {name: "" for name in BLIND_FIELDS}
            row.update(blind_id=item["blind_id"], query=item["query"],
                       candidate_tool_json=json.dumps(item["tool"], ensure_ascii=False),
                       known_positive_context_json=json.dumps(item["known_positives"], ensure_ascii=False))
            writer.writerow(row)
    (directory / "blind_review.html").write_text(render_blind(items), encoding="utf-8")
    (directory / "reviewer_instructions.txt").write_text(instructions(), encoding="utf-8")
    write_json(directory / "hidden_key.json", {"do_not_share_before_review": True, "items": key})
    # Manifest is written before the caller's content is semantically reviewed;
    # all contents derive mechanically from the frozen ID sample.
    if not (directory / "sample_manifest.json").exists():
        write_json(directory / "sample_manifest.json", manifest)
    write_json(directory / "status.json", {"status": "HUMAN_PENDING", "prepared_count": len(items),
                "completed_count": 0, "prepared_at": now(), "human_labels_present": False,
                "blocking_claims": ["independent_human_agreement", "human_verified_semantic_false_negative_rate", "human_supported_semantic_mechanism"],
                "not_blocking": ["training", "fixed_label_evaluation", "statistics", "complete_return_package"],
                "files_for_reviewer": ["reviewer_instructions.txt", "blind_review.csv", "blind_review.html"],
                "organizer_only": ["hidden_key.json", "sample_manifest.json", "sample_plan.json"]}, replace=replace_pending)
    for name in ["received", "adjudication"]:
        (directory / name).mkdir(exist_ok=True)
    return validate(directory)


def positive_context(query_id, train_map, corpus_map):
    require(query_id in train_map, f"Missing query positive context {query_id}")
    positive_ids = train_map[query_id]["positives"]
    require(positive_ids, f"No known positives for {query_id}")
    require(all(tool_id in corpus_map for tool_id in positive_ids), f"Missing positive tool metadata {query_id}")
    return [corpus_map[tool_id]["raw"] for tool_id in positive_ids]


def prepare_original(source, out):
    directory = out / "original_50_pair_review"
    if (directory / "blind_review.csv").exists():
        return validate(directory)
    paths = {
        "pilot": {"blind": source / "data/prepared/human_audit_blind.json", "key": source / "data/prepared/human_audit_key.json",
                  "confirmed": source / "results/human_audit_20261025/confirmed_review.json", "train": source / "data/prepared/train.json", "corpus": source / "data/prepared/corpus.json"},
        "expanded": {"blind": source / "data/main_20261025/audit_blind.json", "key": source / "data/main_20261025/audit_key.json",
                     "confirmed": source / "results/main_human_audit_20261025/confirmed_review.json", "train": source / "data/main_20261025/train_base.json", "corpus": source / "data/main_20261025/corpus.json"}}
    loaded, sources = {}, []
    for round_name, files in paths.items():
        objects = {name: read(path) for name, path in files.items()}
        loaded[round_name] = {"blind": {row["pair_id"]: row for row in objects["blind"]},
                              "key": {row["pair_id"]: row for row in objects["key"]},
                              "confirmed": {row["pair_id"]: row for row in objects["confirmed"]["items"]},
                              "train": {row["id"]: row for row in objects["train"]},
                              "corpus": {row["id"]: row for row in objects["corpus"]}}
        require(len(loaded[round_name]["key"]) == len(objects["key"]) == 200, "Audit round must have 200 unique pairs")
        require(set(loaded[round_name]["blind"]) == set(loaded[round_name]["key"]) == set(loaded[round_name]["confirmed"]), "Archived audit joins do not cover same pairs")
        sources.extend(source_record(path, source) for path in files.values())
    quotas = [("pilot", "random", 13), ("pilot", "bm25", 12), ("expanded", "random", 12), ("expanded", "bm25", 13)]
    rng, selections, strata = random.Random(20261112), [], []
    for round_name, policy, count in quotas:
        frame = sorted(pair_id for pair_id, row in loaded[round_name]["key"].items() if row["pools"] == [policy])
        require(len(frame) >= count, f"Insufficient archived stratum {round_name}/{policy}")
        selected = rng.sample(frame, count)
        selections.extend((round_name, policy, pair_id, count / len(frame)) for pair_id in selected)
        strata.append({"round": round_name, "policy": policy, "population_size": len(frame), "sample_size": count,
                       "inclusion_probability": count / len(frame), "sorted_frame_pair_ids": frame, "selected_pair_ids": selected})
    random.Random(derived_seed("publication_v1|original_review_blind_order|20261112")).shuffle(selections)
    manifest = {"schema_version": "1.0.0", "prepared_at": now(), "sample_seed": 20261112,
                "sample_algorithm": "Python random.Random single stream; fixed stratum order; pair-ID-sorted SRSWOR",
                "stratum_order": [f"{r}/{p}" for r, p, _ in quotas], "strata": strata, "sources": sources,
                "code_sha256": sha(__file__), "sampling_frame": "Archived AI-proposed, student-batch-confirmed 400 audit pairs; not all training candidates",
                "blind_order_seed_recipe": "SHA256(publication_v1|original_review_blind_order|20261112) first16hex",
                "score_based_selection": False, "reviewer_labels": "blank", "combined_rate": "No unweighted pooled prevalence claim across four different frames"}
    directory.mkdir(parents=True, exist_ok=True)
    write_json(directory / "sample_manifest.json", manifest)
    items, key = [], []
    for index, (round_name, policy, pair_id, probability) in enumerate(selections, 1):
        current = loaded[round_name]
        payload, original = current["blind"][pair_id], current["confirmed"][pair_id]
        mapping = current["key"][pair_id]
        positives = payload.get("known_positives") or original.get("known_positive_context")
        if not positives:
            positives = positive_context(mapping["query_id"], current["train"], current["corpus"])
        blind_id = f"H{index:04d}"
        items.append({"blind_id": blind_id, "query": payload["query"], "tool": payload["tool"], "known_positives": positives})
        key.append({"blind_id": blind_id, "round": round_name, "policy": policy, "original_pair_id": pair_id,
                    "query_id": mapping["query_id"], "tool_id": mapping["tool_id"], "inclusion_probability": probability,
                    "original_suggestion": original.get("suggestion"), "original_human_review": original.get("human_review"),
                    "original_label_source": "AI proposal followed by student batch confirmation; not independent dual-human labeling"})
    return write_blind(directory, items, key, manifest)


def freeze_new_plan(out):
    directory = out / "new_mechanism_review"
    path = directory / "sample_plan.json"
    if path.exists():
        return {"status": "existing_plan_preserved", "path": str(path), "sha256": sha(path)}
    plan = {"schema_version": "1.0.0", "frozen_at": now(), "before_new_confirmation_scores": True,
            "frame": "Unique (query_id, tool_id) pairs actually replaced or introduced by seed42 Unique repairs",
            "training_seed": 42, "sampling_seed": 2026111204,
            "strata": [{"policy": policy, "side": side, "quota": 20} for policy in ["B_UNIQUE", "R_UNIQUE"] for side in ["before", "after"]],
            "maximum_draws_before_cross_stratum_dedup": 80,
            "within_stratum_unit": "unique query-tool pair; duplicate replacement occurrences are collapsed",
            "sorting": "query_id then tool_id, ascending strings", "sampling": "simple random sample without replacement in each stratum",
            "rng": "independent Python random.Random per stratum, seed=int(SHA256('publication_v1|new_mechanism_review|2026111204|POLICY|SIDE')[:16],16)",
            "short_stratum": "take all; report actual size; never top up from another stratum",
            "cross_stratum_duplicates": "one blind ID per query-tool pair; retain all population memberships and actual sampled-stratum memberships",
            "probability": "within-stratum n_h/N_h; union probability 1-product(1-n_h/N_h) across every stratum containing the pair, using independent draws",
            "estimands": ["per-stratum document-level N/V/C/U distributions using that stratum's sampled membership", "optional union-frame Horvitz-Thompson label totals divided by known union population size; no naive pooled sample rate"],
            "uncertainty": "requires actual responses and declared finite-population/stratified/query-cluster design; no fabricated intervals while pending",
            "blind_shuffle": "independent SHA256(publication_v1|new_review_blind_order|2026111204) first16hex",
            "source_repairs": "data/training/unique_repairs_seed42.json (hash fixed when realized, before sampling)",
            "score_access": "No development, confirmation, similarity or original-human label used to choose these pairs",
            "reviewer_labels": "leave all labels and reasons blank", "status": "HUMAN_PENDING", "code_sha256": sha(__file__)}
    write_json(path, plan)
    write_json(directory / "status.json", {"status": "HUMAN_PENDING", "frame_status": "awaiting_realized_unique_repairs",
                "prepared_count": 0, "completed_count": 0, "human_labels_present": False,
                "blocking_claims": ["new_semantic_mechanism_human_validation"], "plan_sha256": sha(path)})
    return {"status": "plan_frozen", "path": str(path), "sha256": sha(path)}


def prepare_new(source, out, repairs_path):
    directory = out / "new_mechanism_review"
    plan_path = directory / "sample_plan.json"
    require(plan_path.exists(), "Freeze new sample plan before reading realized repair frame")
    if (directory / "blind_review.csv").exists():
        return validate(directory)
    plan = read(plan_path)
    require(plan["sampling_seed"] == 2026111204 and plan["training_seed"] == 42, "New audit sampling plan drift")
    repairs = read(repairs_path)
    require(isinstance(repairs, list), "Unique repair artifact must be a list")
    frames = {(policy, side): set() for policy in ["B_UNIQUE", "R_UNIQUE"] for side in ["before", "after"]}
    occurrence_counts = {}
    for row in repairs:
        require(row["seed"] == 42 and row["policy"] in ["B_UNIQUE", "R_UNIQUE"], "Unexpected repair seed/policy")
        require(row["old_id"] != row["new_id"], "Repair does not change tool ID")
        for side, field in [("before", "old_id"), ("after", "new_id")]:
            stratum, pair = (row["policy"], side), (row["query_id"], row[field])
            frames[stratum].add(pair)
            occurrence_counts[(stratum, pair)] = occurrence_counts.get((stratum, pair), 0) + 1
    selections, strata = {}, []
    for (policy, side), frame_set in frames.items():
        frame = sorted(frame_set)
        count = min(20, len(frame))
        seed = derived_seed(f"publication_v1|new_mechanism_review|2026111204|{policy}|{side}")
        picked = random.Random(seed).sample(frame, count)
        selections[(policy, side)] = set(picked)
        strata.append({"policy": policy, "side": side, "population_size": len(frame), "sample_size": count,
                       "requested_quota": 20, "shortfall": 20 - count, "inclusion_probability": count / len(frame) if frame else None,
                       "rng_seed": seed, "frame_pairs": [list(pair) for pair in frame], "sampled_pairs": [list(pair) for pair in picked]})
    union_frame = set().union(*frames.values())
    selected_pairs = sorted(set().union(*selections.values()))
    random.Random(derived_seed("publication_v1|new_review_blind_order|2026111204")).shuffle(selected_pairs)
    train_path, corpus_path = source / "data/main_20261025/train.json", source / "data/main_20261025/corpus.json"
    manifest = {"schema_version": "1.0.0", "prepared_at": now(), "plan_sha256": sha(plan_path), "code_sha256": sha(__file__),
                "repairs_source": {"path": str(repairs_path.resolve()), "bytes": repairs_path.stat().st_size, "sha256": sha(repairs_path)},
                "metadata_sources": [source_record(path, source) for path in [train_path, corpus_path]],
                "strata": strata, "union_frame_size": len(union_frame), "total_stratum_draws": sum(len(s) for s in selections.values()),
                "unique_blind_items": len(selected_pairs), "score_based_selection": False,
                "no_replacement_across_short_strata": True, "actual_semantic_labels": "HUMAN_PENDING"}
    write_json(directory / "sample_manifest.json", manifest)
    train_map = {row["id"]: row for row in read(train_path)}
    corpus_map = {row["id"]: row for row in read(corpus_path)}
    items, keys = [], []
    for index, pair in enumerate(selected_pairs, 1):
        qid, tool_id = pair
        require(qid in train_map and tool_id in corpus_map, "Missing repair query/tool metadata")
        memberships, sampled_memberships, not_included_probability = [], [], 1.
        for stratum, frame in frames.items():
            if pair not in frame:
                continue
            probability = min(20, len(frame)) / len(frame)
            membership = {"policy": stratum[0], "side": stratum[1], "population_size": len(frame),
                          "sample_size": min(20, len(frame)), "inclusion_probability": probability,
                          "repair_occurrences": occurrence_counts[(stratum, pair)], "sampled_in_this_stratum": pair in selections[stratum]}
            memberships.append(membership)
            if pair in selections[stratum]:
                sampled_memberships.append(list(stratum))
            not_included_probability *= 1 - probability
        blind_id = f"H{index:04d}"
        items.append({"blind_id": blind_id, "query": train_map[qid]["query"], "tool": corpus_map[tool_id]["raw"],
                      "known_positives": positive_context(qid, train_map, corpus_map)})
        keys.append({"blind_id": blind_id, "query_id": qid, "tool_id": tool_id,
                     "population_memberships": memberships, "sampled_memberships": sampled_memberships,
                     "union_inclusion_probability": 1 - not_included_probability,
                     "original_or_ai_label": None, "semantic_truth_status": "not_human_reviewed"})
    return write_blind(directory, items, keys, manifest, replace_pending=True)


def validate(directory):
    with (directory / "blind_review.csv").open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == BLIND_FIELDS, "Blind CSV fields changed")
        rows = list(reader)
    key = read(directory / "hidden_key.json")["items"]
    require(len(rows) == len(key) == len({row["blind_id"] for row in rows}), "Blind row/key count mismatch")
    require({row["blind_id"] for row in rows} == {row["blind_id"] for row in key}, "Blind key IDs mismatch")
    for row in rows:
        require(all(row[field] == "" for field in BLIND_FIELDS[4:]), "Prepared form unexpectedly contains a reviewer response")
        require(bool(row["query"]) and bool(json.loads(row["candidate_tool_json"])), "Missing blind document")
        require(isinstance(json.loads(row["known_positive_context_json"]), list), "Invalid positive reference")
    page = (directory / "blind_review.html").read_text(encoding="utf-8")
    for token in ["original_pair_id", "initial_suggestion", "original_suggestion", "human_review", "R_UNIQUE", "B_UNIQUE", "candidate_improver"]:
        require(token not in page, f"Blind page leaks organizer field {token}")
    status = read(directory / "status.json")
    require(status["completed_count"] == 0 and status["prepared_count"] == len(rows), "Pending human status mismatch")
    report = {"passed": True, "prepared_count": len(rows), "completed_count": 0, "status": "HUMAN_PENDING",
              "csv_sha256": sha(directory / "blind_review.csv"), "html_sha256": sha(directory / "blind_review.html"),
              "manifest_sha256": sha(directory / "sample_manifest.json"), "blind_fields": BLIND_FIELDS}
    validation_path = directory / "validation.json"
    if validation_path.exists():
        require(read(validation_path) == report, "Previously validated blind materials changed")
    else:
        write_json(validation_path, report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["original", "freeze-new-plan", "new", "validate"])
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=ROOT / "human_review")
    parser.add_argument("--repairs", type=Path, default=ROOT / "data/training/unique_repairs_seed42.json")
    args = parser.parse_args()
    if args.command == "original":
        result = prepare_original(args.source, args.output)
    elif args.command == "freeze-new-plan":
        result = freeze_new_plan(args.output)
    elif args.command == "new":
        result = prepare_new(args.source, args.output, args.repairs)
    else:
        result = validate(args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError) as exc:
        print(f"BLIND_REVIEW_REJECTED: {exc}", file=sys.stderr)
        raise SystemExit(2)
