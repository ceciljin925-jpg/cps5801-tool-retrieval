"""CPU-only cross-stage repeatability audit; never changes scientific run counts.

After S3: --output NEW_ANALYSIS_DIRECTORY
Comparator fixture only: --fixture-only --output NEW_ANALYSIS_DIRECTORY
No torch, transformers, GPU, evaluation scores or training mutation is used.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
import math
import os
import pathlib
import traceback

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
DATA = REPRO / 'data/main_20261025'
SOURCE_PINS = {
    ROOT / 'extensions/encoders.py': '2930b9fabf3fc91819d4a26a8980e5eeb5b926b90113fff40d3acc1b4cead6fe',
    ROOT / 'extensions/train_configurable.py': '52ea15d219848fc8a0df3b3ab3accb675286a5d37ed4d8b79ec5f64569b4ff77',
    REPRO / 'scripts/main_training_engine.py': '311ec9dc7f33f9eae1c7bcfa4c65333b3f494d113ca2c5a9d7bc0497c4aa0e3f',
    REPRO / 'scripts/experiment.py': '494ddda899e9257a1af3aaccab3afe00721cdfd676079166201c8274e3fcfc7b',
}
# Existing accepted ledgers, pinned before this new S3 comparison is observed.
ANCHOR_PINS = {
    ROOT / 'analysis/s1_stage_review_actual_attempt02/table_provenance.json': 'aaeb295857ab6d4d83d711df2189660fded9c30a643551d12718c2fd3e6f3988',
    ROOT / 'analysis/s1_stage_review_actual_attempt02/review_report.json': '5bd15e49233c0a9bb8128e785e8e3e2a6f9ff86a3123d2e79b2a2758d27ea707',
    ROOT / 'analysis/s2_stage_interpretation_actual/captured_evidence/S2_review_report.json': '2eb56f5e4c1da4dc9e1408a3d3de976f7fada52ff9db7fd7d3d65f1ef3f2c31e',
    ROOT / 'comparison/reproduction_review.json': 'c74b38fecf0df96a9fc9776b145219d55fc391019dc6829961189a4894cb15a2',
}
FIXED = {'optimizer': 'AdamW', 'betas': [.9, .999], 'eps': 1e-8, 'weight_decay': .01,
         'clip_grad_norm': 1.0, 'effective_batch': 32, 'negative_per_query': 4,
         'precision': 'bfloat16_autocast', 'query_tokens': 128, 'tool_tokens': 384,
         'schedule': 'constant_lr_no_warmup', 'midtraining_evaluation': 'separate_process_only'}
LEGACY_RECIPE = {'effective_batch': 32, 'microbatch': 8, 'accumulation': 4, 'temperature': .05,
                 'lr': 2e-5, 'weight_decay': .01, 'lr_schedule': 'constant; no warmup',
                 'clip_grad_norm': 1.0, 'precision': 'bfloat16 mixed training; float32 eval',
                 'in_batch_negatives': False, 'negative_per_query': 4, 'query_max_tokens': 128, 'tool_max_tokens': 384}


def stamp():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat()


def sha(path):
    with pathlib.Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def canon(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def json_sha(value):
    return hashlib.sha256(canon(value).encode()).hexdigest()


def dump(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def differences(left, right, prefix=''):
    """Explicit leaf differences, including missing keys; never ignores fields."""
    if isinstance(left, dict) and isinstance(right, dict):
        rows = []
        for key in sorted(left.keys() | right.keys()):
            field = prefix + '.' + key if prefix else key
            if key not in left or key not in right:
                rows.append({'field': field, 'left_present': key in left, 'right_present': key in right,
                             'left': left.get(key), 'right': right.get(key)})
            else:
                rows.extend(differences(left[key], right[key], field))
        return rows
    return [] if left == right else [{'field': prefix, 'left': left, 'right': right}]


def trace_comparison(left, right, steps=625):
    faults, mismatches, rows = [], [], []
    if len(left) < steps or len(right) < steps:
        return {'exact': False, 'structural_faults': ['trace shorter than comparison prefix'],
                'mismatches': [], 'left_length': len(left), 'right_length': len(right)}, rows
    for index, (a, b) in enumerate(zip(left[:steps], right[:steps], strict=True), 1):
        if a.get('step') != index or b.get('step') != index:
            faults.append({'step': index, 'kind': 'noncontiguous_step'})
        record = {'step': index}
        for field in ('epoch', 'loss', 'grad_norm'):
            av, bv = a.get(field), b.get(field)
            valid = all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in (av, bv))
            if not valid:
                faults.append({'step': index, 'field': field, 'kind': 'nonfinite_or_invalid'})
            equal = valid and av == bv
            saved_a = av if isinstance(av, (int, float)) and math.isfinite(av) else repr(av)
            saved_b = bv if isinstance(bv, (int, float)) and math.isfinite(bv) else repr(bv)
            record.update({field + '_left': saved_a, field + '_right': saved_b, field + '_exact': equal})
            if not equal:
                mismatches.append({'step': index, 'field': field, 'left': saved_a, 'right': saved_b})
        rows.append(record)
    return {'exact': not faults and not mismatches, 'compared_updates': steps,
            'left_length': len(left), 'right_length': len(right), 'structural_faults': faults,
            'mismatch_count': len(mismatches), 'first_mismatches': mismatches[:20],
            'maximum_absolute_loss_difference': max(abs(a['loss'] - b['loss']) for a, b in zip(left[:steps], right[:steps])) if not faults else None,
            'maximum_absolute_gradient_norm_difference': max(abs(a['grad_norm'] - b['grad_norm']) for a, b in zip(left[:steps], right[:steps])) if not faults else None}, rows


def verdict(ready, preconditions, exact):
    if not ready:
        return 'NOT_READY'
    if not all(row['satisfied'] for row in preconditions):
        return 'NOT_COMPARABLE'
    return 'PASS_EXACT_OBSERVED' if exact else 'FAIL_NONEXACT_WITH_MATCHING_PRECONDITIONS'


class Evidence:
    def __init__(self):
        self.files, self.json_cache, self.text_cache = {}, {}, {}

    def bind(self, path):
        path = pathlib.Path(path).resolve(strict=True)
        key = str(path)
        if key not in self.files:
            self.files[key] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        return self.files[key]

    def read(self, path):
        key = str(pathlib.Path(path).resolve())
        if key not in self.json_cache:
            self.bind(path)
            self.json_cache[key] = json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))
        return self.json_cache[key]

    def lines(self, path):
        self.bind(path)
        return [json.loads(line) for line in pathlib.Path(path).read_text(encoding='utf-8').splitlines() if line.strip()]

    def manifest(self, directory):
        directory = pathlib.Path(directory).resolve(strict=True)
        return {path.relative_to(directory).as_posix(): self.bind(path) for path in sorted(directory.rglob('*'))
                if path.is_file() and '__pycache__' not in path.parts and not path.name.endswith('.tmp')}


def condition(rows, name, left, right, explanation=None):
    diff = differences(left, right)
    row = {'name': name, 'satisfied': not diff, 'differences': diff}
    if explanation:
        row['explanation'] = explanation
    rows.append(row)
    return not diff


def project_negatives(data, policy):
    return {qid: value[policy] if isinstance(value, dict) else value for qid, value in data.items()}


def exposure_rows(schedule, negatives, train, corpus, count=20000):
    queries = {row['id']: row['query'] for row in train}
    documents = {row['id']: row['text'] for row in corpus}
    qhash = {qid: hashlib.sha256(('query: ' + text).encode()).hexdigest() for qid, text in queries.items()}
    dhash = {tid: hashlib.sha256(('passage: ' + text).encode()).hexdigest() for tid, text in documents.items()}
    output = []
    for offset, row in enumerate(schedule[:count]):
        qid, positive = row['query_id'], row['positive']
        ids = [positive] + negatives[qid]
        output.append({'exposure': offset + 1, 'query_id': qid, 'epoch': row['epoch'], 'ordered_positive_then_negative_ids': ids,
                       'prefixed_query_text_sha256': qhash[qid], 'ordered_prefixed_document_text_sha256': [dhash[tid] for tid in ids]})
    return output


def extension_record(row, ev, conditions, tag, expected_seed, expected_policy, expected_stage, expected_steps):
    folder = pathlib.Path(row['output_path'])
    config, identity = ev.read(folder / 'config.json'), ev.read(folder / 'identity.json')
    stats, status = ev.read(folder / 'training.json'), ev.read(folder / 'status.json')
    condition(conditions, tag + '.run_id_binding', config.get('run_id'), row['run_id'])
    condition(conditions, tag + '.registry_config_binding', config, row.get('config'))
    condition(conditions, tag + '.statistics_run_identity',
              {key: stats.get(key) for key in ('run_id', 'family', 'policy', 'seed')},
              {key: config.get(key) for key in ('run_id', 'family', 'policy', 'seed')})
    condition(conditions, tag + '.registry_run_identity',
              {key: row.get(key) for key in ('family', 'policy', 'seed')},
              {key: config.get(key) for key in ('family', 'policy', 'seed')})
    condition(conditions, tag + '.registry_actual_steps', row.get('actual_steps'), stats.get('steps'))
    condition(conditions, tag + '.completed', {'registry': row['status'], 'attempt': status['status']},
              {'registry': 'completed', 'attempt': 'completed'})
    expected = {'family': 'e5', 'seed': expected_seed, 'policy': expected_policy, 'stage': expected_stage,
                'steps': expected_steps, 'lr': 2e-5, 'temperature': .05, 'microbatch': 8, 'accumulation': 4,
                'checkpoint_steps': [expected_steps], 'resume_every': 100}
    condition(conditions, tag + '.requested_recipe', {key: config.get(key) for key in expected}, expected)
    for key in ('family', 'seed', 'steps', 'lr', 'temperature', 'microbatch', 'accumulation'):
        condition(conditions, tag + '.identity_matches_config.' + key, identity.get(key), config.get(key))
    condition(conditions, tag + '.fixed_recipe', identity.get('fixed_config'), FIXED)
    condition(conditions, tag + '.model_assets_still_match', ev.manifest(config['model_path']), identity['model_files'])
    condition(conditions, tag + '.model_source_is_original_pretrained', str(pathlib.Path(config['model_path']).resolve()),
              str((REPRO / 'data/raw/model').resolve()))
    for key, recorded in identity['input_files'].items():
        condition(conditions, tag + '.actual_input.' + key, ev.bind(config[key])['sha256'], recorded)
    for name, recorded in identity['code'].items():
        condition(conditions, tag + '.actual_source.' + name, ev.bind(ROOT / 'extensions' / name)['sha256'], recorded)
    schedule = ev.read(config['schedule_path'])[:config['steps'] * 32]
    negatives = project_negatives(ev.read(config['negatives_path']), config['policy'])
    condition(conditions, tag + '.actual_schedule_identity', json_sha(schedule), identity['actual_schedule_prefix_sha256'])
    condition(conditions, tag + '.actual_negative_identity', json_sha(negatives), identity['actual_negatives_sha256'])
    condition(conditions, tag + '.training_identity_binding', stats['identity_sha256'], json_sha(identity))
    condition(conditions, tag + '.completed_exposures', {'steps': stats['steps'], 'exposures': stats['exposures']},
              {'steps': expected_steps, 'exposures': expected_steps * 32})
    trace = ev.lines(folder / 'loss.jsonl')
    condition(conditions, tag + '.full_trace_length', len(trace), expected_steps)
    # Wrapper evidence establishes a fresh authorized train invocation, not cache reuse.
    process = ev.read(folder.parent / 'train_attempt_01.process_status.json')
    command = process.get('command', [])
    condition(conditions, tag + '.process_completed', [process.get('status'), process.get('exit_code')], ['completed', 0])
    fresh = bool(command and '--resume' not in command and any(pathlib.Path(arg).name == 'train_configurable.py' for arg in command))
    condition(conditions, tag + '.fresh_nonresume_invocation', fresh, True)
    condition(conditions, tag + '.single_fresh_attempt', len(row.get('attempts', [])), 1)
    attempts = row.get('attempts', [])
    if len(attempts) == 1:
        condition(conditions, tag + '.attempt_output_binding', str(pathlib.Path(attempts[0]['output']).resolve()), str(folder.resolve()))
    condition(conditions, tag + '.no_recovery_tail', (folder / 'interrupted_tails').exists(), False)
    outer_config = pathlib.Path(command[command.index('--config') + 1])
    condition(conditions, tag + '.outer_and_actual_config', ev.read(outer_config), config)
    condition(conditions, tag + '.actual_output_binding', str(pathlib.Path(command[command.index('--output') + 1]).resolve()), str(folder.resolve()))
    condition(conditions, tag + '.initial_environment_capture_matches_identity',
              {key: value for key, value in ev.read(folder / 'environment.json').items() if key not in ('created_at', 'executable')}, identity['runtime'])
    checkpoint = folder / 'checkpoints' / f'step_{expected_steps:04d}'
    provenance = ev.read(checkpoint / 'checkpoint_provenance.json')
    condition(conditions, tag + '.checkpoint_provenance_binding',
              {key: provenance.get(key) for key in ('run_id', 'step', 'exposures', 'identity_sha256')},
              {'run_id': config['run_id'], 'step': expected_steps, 'exposures': expected_steps * 32, 'identity_sha256': json_sha(identity)})
    weight = checkpoint / 'model.safetensors'
    condition(conditions, tag + '.registry_final_checkpoint_path', str(pathlib.Path(row['checkpoint_path']).resolve()), str(checkpoint.resolve()))
    condition(conditions, tag + '.checkpoint_file_manifest_binding', ev.bind(weight),
              ev.read(folder / 'checkpoint_manifest.json')[f'step_{expected_steps:04d}']['model.safetensors'])
    dev_bindings = [entry for entry in row.get('dev_evaluations', []) if entry['steps'] == expected_steps]
    condition(conditions, tag + '.final_checkpoint_registry_binding_count', len(dev_bindings), 1)
    if len(dev_bindings) == 1:
        condition(conditions, tag + '.final_checkpoint_registry_weight_hash', ev.bind(weight)['sha256'], dev_bindings[0]['checkpoint_sha256'])
        condition(conditions, tag + '.final_checkpoint_registry_path', str(checkpoint.resolve()), str(pathlib.Path(dev_bindings[0]['checkpoint_path']).resolve()))
    return {'folder': folder, 'config': config, 'identity': identity, 'stats': stats, 'process': process,
            'schedule': schedule, 'negatives': negatives, 'trace': trace, 'weight': weight,
            'train': ev.read(config['train_path']), 'corpus': ev.read(config['corpus_path'])}


def run_audit(output):
    ev = Evidence()
    registry = ev.read(ROOT / 'run_registry.json')
    lock = ev.read(ROOT / 'locks/S2_selection.json')
    global_conditions = []
    for path, expected in SOURCE_PINS.items():
        condition(global_conditions, 'reviewed_source.' + path.name, ev.bind(path)['sha256'], expected)
    for path, expected in ANCHOR_PINS.items():
        condition(global_conditions, 'accepted_ledger.' + path.relative_to(ROOT).as_posix(), ev.bind(path)['sha256'], expected)
    s0_review = ev.read(ROOT / 'comparison/reproduction_review.json')
    s0_comparison_path = ROOT / 'comparison/reproduction_comparison.json'
    s0_binding = [entry for entry in s0_review['evidence'] if pathlib.Path(entry['path']).resolve() == s0_comparison_path.resolve()]
    condition(global_conditions, 'S0.accepted_comparison_binding_unique', len(s0_binding), 1)
    if len(s0_binding) == 1:
        condition(global_conditions, 'S0.accepted_comparison_hash', ev.bind(s0_comparison_path)['sha256'], s0_binding[0]['sha256'])
    # Only the accepted report's input-file ledger is used, not retrieval scores.
    s0_ledger = ev.read(s0_comparison_path)['input_files']
    s1_provenance = ev.read(ROOT / 'analysis/s1_stage_review_actual_attempt02/table_provenance.json')
    s1_ledger = {str((ROOT / item['path']).resolve()): item for item in s1_provenance['all_input_files']}
    condition(global_conditions, 'S1.prior_review_passed', ev.read(ROOT / 'analysis/s1_stage_review_actual_attempt02/review_report.json')['status'],
              'PASS_S1_FIXED_RECIPE_DEVELOPMENT_REVIEW')
    s2_review = ev.read(ROOT / 'analysis/s2_stage_interpretation_actual/captured_evidence/S2_review_report.json')
    condition(global_conditions, 'S2.prior_review_passed', s2_review['status'], 'PASS_INDEPENDENT_SELECTION_REVIEW')
    condition(global_conditions, 'S2.accepted_lock_hash', ev.bind(ROOT / 'locks/S2_selection.json')['sha256'], s2_review['locked_selection_sha256'])
    fixture = ev.read(ROOT / 'analysis/engine_fixture_attempt01/gpu_fixture_report.json')
    fixture_identity = ev.read(ROOT / 'analysis/engine_fixture_attempt01/new_engine/identity.json')
    condition(global_conditions, 'existing_three_update_engine_fixture_passed', fixture.get('passed'), True)
    condition(global_conditions, 'existing_fixture_resume_exact', fixture.get('resume_exact'), True)
    condition(global_conditions, 'existing_fixture_original_source_binding', fixture.get('original_engine_sha256'), SOURCE_PINS[REPRO / 'scripts/main_training_engine.py'])
    condition(global_conditions, 'lock.selected_extension', lock['selected_extension']['policy'], 'B_UNIQUE')
    for policy, steps in [('R_ID', 1250), ('B_ID', 1250), ('B_UNIQUE', 625)]:
        item = lock['selection'][policy]
        condition(global_conditions, 'lock.recipe.' + policy, {key: item[key] for key in ('lr', 'temperature', 'steps')},
                  {'lr': 2e-5, 'temperature': .05, 'steps': steps})
    s3_rows = [r for r in registry['runs'] if r['stage'] == 'S3']
    def resolved_policy(row):
        policy = row.get('config', {}).get('policy') or row['policy']
        return lock['selected_extension']['policy'] if policy == 'SELECTED_EXTENSION' else policy
    expected_slots = sorted((policy, seed) for policy in ('R_ID', 'B_ID', 'B_UNIQUE') for seed in (42, 43, 44, 45, 46))
    actual_slots = sorted((resolved_policy(row), row['seed']) for row in s3_rows)
    condition(global_conditions, 'S3.exact_fifteen_policy_seed_slots', actual_slots, expected_slots)
    condition(global_conditions, 'S3.unique_run_ID_count', len({row['run_id'] for row in s3_rows}), 15)
    stage_ready = len(s3_rows) == 15 and all(row['status'] == 'completed' for row in s3_rows)
    results = []
    for seed in (42, 43, 44):
        for policy in ('R_ID', 'B_ID', 'B_UNIQUE'):
            comparison_id = f'S3_{policy}_seed{seed}_vs_' + ('S1_full625' if policy == 'B_UNIQUE' else 'S0_prefix625')
            checks = json.loads(json.dumps(global_conditions))
            report = {'comparison_id': comparison_id, 'seed': seed, 'policy': policy, 'comparison_updates': 625,
                      'comparison_exposures': 20000, 'preconditions': checks, 'not_new_scientific_replication': True}
            results.append(report)
            targets = [row for row in s3_rows if row['seed'] == seed and resolved_policy(row) == policy]
            if not stage_ready:
                report.update(status='NOT_READY', reason='All15 S3 runs must complete before any actual comparison; no active-run metadata is audited')
                continue
            try:
                if len(targets) != 1:
                    raise ValueError('Expected exactly one matching S3 policy/seed slot')
                steps = 625 if policy == 'B_UNIQUE' else 1250
                new = extension_record(targets[0], ev, checks, 'S3', seed, policy, 'S3', steps)
                condition(checks, 'S3.runtime_matches_existing_engine_fixture', new['identity']['runtime'], fixture_identity['runtime'])
                condition(checks, 'S3.code_matches_existing_engine_fixture', new['identity']['code'], fixture_identity['code'])
                condition(checks, 'S3.initial_assets_match_existing_engine_fixture', new['identity']['model_files'], fixture_identity['model_files'])
                if policy == 'B_UNIQUE':
                    priors = [row for row in registry['runs'] if row['stage'] == 'S1' and row['seed'] == seed and row['policy'] == policy]
                    if len(priors) != 1:
                        raise ValueError('Expected exactly one prior S1 run')
                    old = extension_record(priors[0], ev, checks, 'S1', seed, policy, 'S1', 625)
                    for relative in ('config.json', 'identity.json', 'training.json', 'loss.jsonl', 'status.json', 'checkpoint_manifest.json',
                                     'checkpoints/step_0625/model.safetensors', 'checkpoints/step_0625/checkpoint_provenance.json'):
                        prior_path = old['folder'] / relative
                        recorded = s1_ledger.get(str(prior_path.resolve()))
                        condition(checks, 'S1.accepted_ledger.' + relative, ev.bind(prior_path),
                                  {key: recorded[key] for key in ('sha256', 'bytes')} if recorded else None)
                    condition(checks, 'complete_scientific_identity', old['identity'], new['identity'])
                    report['all_configuration_differences'] = differences(old['config'], new['config'])
                    report['permitted_configuration_differences'] = ['run_id', 'stage']
                    substantive = {key: value for key, value in old['config'].items() if key not in ('run_id', 'stage')}
                    condition(checks, 'all_other_configuration_fields', substantive,
                              {key: value for key, value in new['config'].items() if key not in ('run_id', 'stage')})
                else:
                    legacy_policy = 'random' if policy == 'R_ID' else 'bm25'
                    legacy_run = f'M{3 + 2 * (seed - 42) + (legacy_policy == "bm25"):02}_{legacy_policy}_seed{seed}'
                    folder = REPRO / 'results/main_20261025' / legacy_run
                    stats = ev.read(folder / 'training.json')
                    for filename in ('training.json', 'loss.jsonl'):
                        prior_path = folder / filename
                        key = 'reproduction:' + prior_path.relative_to(REPRO).as_posix()
                        condition(checks, 'S0.accepted_ledger.' + filename, ev.bind(prior_path), s0_ledger.get(key))
                    prior_config = ev.read(folder / 'config.json')
                    master_config = ev.read(REPRO / 'results/main_20261025/config.json')
                    condition(checks, 'S0.legacy_recipe', {key: master_config.get(key) for key in LEGACY_RECIPE}, LEGACY_RECIPE)
                    condition(checks, 'S0.seed_policy_steps', {key: stats.get(key) for key in ('seed', 'policy', 'steps')},
                              {'seed': seed, 'policy': legacy_policy, 'steps': 625})
                    for key, filename in [('schedule_sha256', f'shared_schedule_seed{seed}.json'),
                                          ('negative_manifest_sha256', f'negatives_seed{seed}.json'), ('snapshot_manifest_sha256', 'freeze_manifest.json')]:
                        condition(checks, 'S0.actual_input.' + key, ev.bind(DATA / filename)['sha256'], stats[key])
                        condition(checks, 'S0.config_stats.' + key, prior_config[key], stats[key])
                    condition(checks, 'S0.main_engine_binding', stats['experiment_code_sha256'], SOURCE_PINS[REPRO / 'scripts/main_training_engine.py'])
                    condition(checks, 'S0.encoder_binding', stats['evaluation_code_sha256'], SOURCE_PINS[REPRO / 'scripts/experiment.py'])
                    freeze = ev.read(DATA / 'freeze_manifest.json')
                    for key in ('train_path', 'corpus_path', 'forbidden_path', 'train_tool_ids_path'):
                        relative = pathlib.Path(new['config'][key]).relative_to(REPRO).as_posix()
                        condition(checks, 'S0_S3.frozen_input.' + key, ev.bind(new['config'][key])['sha256'], freeze['files'][relative])
                    old = {'folder': folder, 'config': prior_config, 'stats': stats,
                           'schedule': ev.read(DATA / f'shared_schedule_seed{seed}.json'),
                           'negatives': project_negatives(ev.read(DATA / f'negatives_seed{seed}.json'), legacy_policy),
                           'trace': ev.lines(folder / 'loss.jsonl'), 'train': ev.read(DATA / 'train.json'), 'corpus': ev.read(DATA / 'corpus.json')}
                    condition(checks, 'S0.complete_trace_length', len(old['trace']), 625)
                    capture = ev.read(ROOT.parent / 'environment/environment.json')
                    runtime = new['identity']['runtime']
                    actual_environment = {'python': capture['python'], 'platform': capture['platform'], 'cuda': capture['cuda_runtime'], 'gpu': capture['gpu'],
                                          **{key: capture['versions'][key] for key in ('torch', 'transformers', 'tokenizers', 'numpy', 'safetensors')}}
                    condition(checks, 'S0.actual_captured_environment', actual_environment, {key: runtime[key] for key in actual_environment})
                    process = ev.read(ROOT / 'logs/s0_pipeline.process_status.json')
                    condition(checks, 'S0.actual_pipeline_completed', [process.get('status'), process.get('exit_code')], ['completed', 0])
                    condition(checks, 'S0.same_actual_python_executable', str(pathlib.Path(process['command'][0]).resolve()),
                              str(pathlib.Path(new['process']['command'][0]).resolve()))
                    events = ev.lines(REPRO / 'logs/main_events.jsonl')
                    relevant = [event for event in events if event.get('run') == legacy_run]
                    condition(checks, 'S0.fresh_training_started_once', sum(event['event'] == 'training_started' for event in relevant), 1)
                    condition(checks, 'S0.fresh_training_completed_once', sum(event['event'] == 'training_completed' for event in relevant), 1)
                    condition(checks, 'S0.no_checkpoint_reuse', sum(event['event'] == 'reuse_completed_checkpoint' for event in relevant), 0)
                    report['runtime_evidence_limit'] = {'legacy_inherited_config_python': master_config.get('python'),
                        'actual_captured_python_used_for_check': capture['python'],
                        'note': 'S0 inherited config retains an older Python build string. Actual environment capture and same venv launch are used; no per-run full S0 runtime identity exists.'}
                    report['intentional_engine_differences'] = [
                        'S3 runs1250 updates; only first625 are compared to the625-update S0.',
                        'S3 full schedule hash covers40000 exposures; the shared20000-exposure prefix is recomputed below.',
                        'S3 pretokenizes extra documents for later epochs; deterministic per-text caches do not change the compared ordered batches.',
                        'Original tokenizer is constructed before per-run seeding; extension tokenizer is loaded after seeding. Frozen tokenization uses no random sampling; existing3-update fixture supports the implementation comparison but is not a625-step result.',
                        'S3 saves recovery state every100 updates under full RNG/mode preservation; S0 has no midtraining recovery writes.',
                        'S3 R/B retains onlystep1250 weights: step625 model/optimizer state is unavailable and is NOT inferred from scalar logs.']
                condition(checks, 'actual_schedule_prefix', old['schedule'][:20000], new['schedule'][:20000])
                condition(checks, 'all_ordered_negative_lists', old['negatives'], new['negatives'])
                condition(checks, 'actual_query_records', old['train'], new['train'])
                condition(checks, 'actual_corpus_records', old['corpus'], new['corpus'])
                exposures_old = exposure_rows(old['schedule'], old['negatives'], old['train'], old['corpus'])
                exposures_new = exposure_rows(new['schedule'], new['negatives'], new['train'], new['corpus'])
                condition(checks, 'actual_ordered_exposure_count', [len(exposures_old), len(exposures_new)], [20000, 20000])
                condition(checks, 'ordered_actual_exposure_identity', json_sha(exposures_old), json_sha(exposures_new))
                # Structural trace faults are invalid evidence, not a numeric
                # training mismatch under otherwise matching prerequisites.
                structural_trace, _ = trace_comparison(old['trace'], new['trace'])
                condition(checks, 'valid_contiguous_finite_comparison_traces', structural_trace['structural_faults'], [])
                for tag, record in (('left', old), ('right', new)):
                    expected_epochs = [record['schedule'][offset * 32]['epoch'] + 1 for offset in range(625)]
                    condition(checks, tag + '.trace_epochs_match_actual_batches',
                              [item.get('epoch') for item in record['trace'][:625]], expected_epochs)
                old_used = set(row['positive'] for row in old['schedule']) | {tid for ids in old['negatives'].values() for tid in ids}
                new_used = set(row['positive'] for row in new['schedule']) | {tid for ids in new['negatives'].values() for tid in ids}
                report['input_exposures'] = {'left_prefix_sha256': json_sha(exposures_old), 'right_prefix_sha256': json_sha(exposures_new),
                    'actual_prefix_schedule_sha256': {'left': json_sha(old['schedule'][:20000]), 'right': json_sha(new['schedule'][:20000])},
                    'all_ordered_negative_lists_sha256': {'left': json_sha(old['negatives']), 'right': json_sha(new['negatives'])},
                    'full_pre_tokenization_document_counts': {'left': len(old_used), 'right': len(new_used)},
                    'full_token_cache_equality_required': policy == 'B_UNIQUE',
                    'scope': 'Ordered sample IDs and prefixed input text hashes reconstructed from bound actual files and frozen loader code; original token tensors were not separately saved.'}
                if not all(check['satisfied'] for check in checks):
                    report.update(status='NOT_COMPARABLE', reason='Preconditions differ or lack binding; no exact-result verdict is imposed',
                                  unsatisfied_preconditions=[check['name'] for check in checks if not check['satisfied']])
                    continue
                trace, trace_rows = trace_comparison(old['trace'], new['trace'])
                for index, row in enumerate(trace_rows):
                    left_batch, right_batch = exposures_old[index*32:(index+1)*32], exposures_new[index*32:(index+1)*32]
                    row.update(left_exposure_sha256=json_sha(left_batch), right_exposure_sha256=json_sha(right_batch),
                               exposures_exact=left_batch == right_batch)
                path = output / (comparison_id + '_per_update.csv')
                with path.open('w', encoding='utf-8', newline='') as stream:
                    writer = csv.DictWriter(stream, fieldnames=list(trace_rows[0]));writer.writeheader();writer.writerows(trace_rows)
                report['trace'] = trace
                report['per_update_evidence'] = {'path': path.name, 'sha256': sha(path)}
                weight_exact = True
                if policy == 'B_UNIQUE':
                    # Only the weights are compared across runs. Their provenance and timestamps must differ.
                    report['final_weights'] = {'left': ev.bind(old['weight']), 'right': ev.bind(new['weight']),
                                               'same_file_object': os.path.samefile(old['weight'], new['weight'])}
                    weight_exact = ev.bind(old['weight']) == ev.bind(new['weight'])
                    report['final_weights']['sha256_and_bytes_exact'] = weight_exact
                    if report['final_weights']['same_file_object']:
                        checks.append({'name': 'fresh_independent_weight_file_object', 'satisfied': False,
                                       'differences': [{'reason': 'Both paths refer to the same file object; fresh output evidence needs review'}]})
                else:
                    report['final_weights'] = {'compared': False, 'reason': 'No retained S3step625 checkpoint; S3final1250 is not the matching budget.'}
                report['status'] = verdict(True, checks, trace['exact'] and weight_exact and all(row['exposures_exact'] for row in trace_rows))
                report['unsatisfied_preconditions'] = [check['name'] for check in checks if not check['satisfied']]
            except Exception as error:
                report.update(status='NOT_COMPARABLE', reason='Missing, invalid or unbound prerequisite evidence', error=repr(error), traceback=traceback.format_exc())
    # Compare only immutable consumed run evidence; registry itself may advance to S4 while this CPU audit runs.
    registry_key = str((ROOT / 'run_registry.json').resolve())
    changed = [path for path, record in ev.files.items() if path != registry_key and sha(path) != record['sha256']]
    if changed:
        for row in results:
            row['verdict_before_concurrent_mutation_check'] = row['status']
            row['status'] = 'NOT_COMPARABLE'
            row['reason'] = 'An immutable consumed input changed during audit; observed comparison is not accepted'
    counts = collections.Counter(row['status'] for row in results)
    status = ('FAIL_OBSERVED_NONEXACT' if counts['FAIL_NONEXACT_WITH_MATCHING_PRECONDITIONS'] else
              'INCOMPARABLE_EVIDENCE_REQUIRES_REVIEW' if counts['NOT_COMPARABLE'] or changed or not all(c['satisfied'] for c in global_conditions) else
              'PENDING_S3_COMPLETION' if counts['NOT_READY'] or not stage_ready else 'PASS_ALL9_COMPARISONS_EXACT')
    report = {'created_at': stamp(), 'status': status, 'audit_code_sha256': sha(__file__),
              's3_all15_registry_completed_at_snapshot': stage_ready, 'comparison_counts': dict(counts),
              'global_preconditions': global_conditions,
              'comparisons': results, 'source_semantic_contract_sha256': json_sha({str(k): v for k, v in SOURCE_PINS.items()}),
              'existing_fixture_scope': fixture['scope'], 'immutable_inputs_changed_during_audit': changed, 'input_files': ev.files,
              'limits': ['Engineering repeated-configuration/prefix validation only; these nine comparisons add zero independent scientific samples and do not alter84jobs or final evaluations.',
                         'The52 final run conditions need not represent52 distinct weight sets. If S3B_UNIQUE seeds42–44 exactly match S1, those three conditions share corresponding weights; all260final evaluations and80efficiency jobs still run as predeclared, without deduplication or cancellation.',
                         'Exact losses and global gradient norms are scalar observations; unavailable full historical gradient, parameter and optimizer tensors are not inferred.',
                         'Cross-engine preconditions rely on frozen source review, matching actual inputs, same captured environment/venv and preexisting short engineering fixture; S0 has no per-run full runtime identity.',
                         'No deterministic-algorithms enforcement or cross-hardware/driver universal bitwise guarantee is asserted.',
                         'No final or external evaluation score was read. No approval, queue, model, optimizer or training evidence was modified.']}
    dump(output / 's3_cross_stage_repeatability.json', report)
    return report


def fixture():
    import copy
    trace = [{'step': i, 'epoch': 1 + (i > 1), 'loss': .2, 'grad_norm': .4, 'elapsed_seconds': i} for i in (1, 2)]
    changed = copy.deepcopy(trace);changed[1]['elapsed_seconds'] = 999
    assert trace_comparison(trace, changed, 2)[0]['exact']
    changed[1]['grad_norm'] += 1e-12
    assert not trace_comparison(trace, changed, 2)[0]['exact']
    changed[1]['grad_norm'] = float('nan')
    invalid = trace_comparison(trace, changed, 2)[0]
    assert not invalid['exact']
    json.dumps(invalid, allow_nan=False)
    assert verdict(True, [{'satisfied': False}], False) == 'NOT_COMPARABLE'
    assert verdict(True, [{'satisfied': True}], False) == 'FAIL_NONEXACT_WITH_MATCHING_PRECONDITIONS'
    assert verdict(False, [], True) == 'NOT_READY'
    assert differences({'x': 1}, {'x': 2}) == [{'field': 'x', 'left': 1, 'right': 2}]
    schedule = [{'query_id': 'q', 'positive': 'p', 'epoch': 0}]
    train = [{'id': 'q', 'query': 'synthetic query'}]
    corpus = [{'id': key, 'text': key} for key in ('p', 'a', 'b', 'c', 'd')]
    left = exposure_rows(schedule, {'q': ['a', 'b', 'c', 'd']}, train, corpus, 1)
    right = exposure_rows(schedule, {'q': ['b', 'a', 'c', 'd']}, train, corpus, 1)
    assert json_sha(left) != json_sha(right)
    return {'passed': True, 'scope': 'CPU comparator only: tiny gradient mismatch, time exclusion, missing-precondition classification, ordered input exposures; no actual training claim'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--fixture-only', action='store_true')
    args = parser.parse_args()
    output = args.output.resolve()
    if ROOT / 'analysis' not in output.parents or output.exists():
        raise ValueError('Choose a NEW directory under publication/analysis')
    output.mkdir(parents=True)
    if args.fixture_only:
        result = fixture();result['audit_code_sha256'] = sha(__file__)
        dump(output / 'fixture_report.json', result);print(json.dumps(result));return 0
    try:
        result = run_audit(output)
    except BaseException as error:
        dump(output / 'audit_failure.json', {'created_at': stamp(), 'status': 'AUDIT_EXECUTION_FAILED',
                                            'error': repr(error), 'traceback': traceback.format_exc(),
                                            'comparison_verdict_granted': False})
        raise
    print(json.dumps({'status': result['status'], 'comparison_counts': result['comparison_counts'], 'output': str(output)}, indent=2))
    return {'PASS_ALL9_COMPARISONS_EXACT': 0, 'FAIL_OBSERVED_NONEXACT': 2,
            'INCOMPARABLE_EVIDENCE_REQUIRES_REVIEW': 3, 'PENDING_S3_COMPLETION': 4}[result['status']]


if __name__ == '__main__':
    raise SystemExit(main())
