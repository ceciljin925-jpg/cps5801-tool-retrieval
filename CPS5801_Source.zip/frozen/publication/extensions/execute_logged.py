"""Run a command with durable command, stdout, stderr and process-status records."""
import argparse
import ctypes
import datetime
import json
import pathlib
import subprocess
import sys
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parents[1]


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def dump(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


def execute(command, cwd, output, name):
    if not name or pathlib.Path(name).name != name or '/' in name or '\\' in name:
        raise ValueError('Command record name must be one safe filename component')
    output = pathlib.Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    status_path = output / f'{name}.process_status.json'
    if status_path.exists():
        raise FileExistsError(f'Preserve attempts; choose unused command name: {status_path}')
    record = {'name':name, 'command':list(map(str,command)), 'cwd':str(pathlib.Path(cwd).resolve()),
              'started_at':now(), 'stdout':str(output/f'{name}.stdout.log'),
              'stderr':str(output/f'{name}.stderr.log'), 'status':'starting'}
    started=time.perf_counter()
    process, code = None, None
    awake_requested = False
    # Write starting evidence before Popen, so launch failures have a record.
    dump(status_path,record)
    try:
        # Keep this authorized job awake without changing power-plan settings.
        if sys.platform=='win32':
            awake_requested = True
            record['awake_request_succeeded'] = bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
        with open(record['stdout'],'w',encoding='utf-8') as stdout, open(record['stderr'],'w',encoding='utf-8') as stderr:
            process = subprocess.Popen(command, cwd=cwd, stdout=stdout, stderr=stderr,
                                       creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            record.update(pid=process.pid,status='running')
            dump(status_path,record)
            print(json.dumps(record,ensure_ascii=False),flush=True)
            code = process.wait()
        record.update(exit_code=code, child_may_still_be_running=False,
                      status='completed' if code==0 else 'failed')
    except BaseException as error:
        observed_code = process.poll() if process is not None else None
        interrupted = isinstance(error, (KeyboardInterrupt, SystemExit))
        record.update(status='monitor_interrupted' if interrupted else ('launch_failed' if process is None else 'monitor_failed'),
                      error=repr(error), traceback=traceback.format_exc(), exit_code=observed_code,
                      child_may_still_be_running=process is not None and observed_code is None,
                      recovery_note='Inspect retained PID and actual artifacts before retry. A monitor exception does not prove the child stopped; no child was terminated by this wrapper.')
        raise
    finally:
        if awake_requested:
            try:
                record['awake_release_succeeded'] = bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000000))
            except Exception as release_error:
                record['awake_release_error'] = repr(release_error)
        record.update(ended_at=now(),seconds=time.perf_counter()-started)
        dump(status_path,record)
        provenance = ROOT/'provenance'
        provenance.mkdir(parents=True,exist_ok=True)
        with (provenance/'commands.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(record,ensure_ascii=False)+'\n')
        print(json.dumps(record,ensure_ascii=False),flush=True)
    if code:
        raise subprocess.CalledProcessError(code,command)
    return record


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cwd',type=pathlib.Path,required=True)
    p.add_argument('--output',type=pathlib.Path,required=True)
    p.add_argument('--name',required=True)
    p.add_argument('command',nargs=argparse.REMAINDER)
    a=p.parse_args()
    command=a.command[1:] if a.command and a.command[0]=='--' else a.command
    if not command:p.error('Command is required after --')
    execute(command,a.cwd,a.output,a.name)
