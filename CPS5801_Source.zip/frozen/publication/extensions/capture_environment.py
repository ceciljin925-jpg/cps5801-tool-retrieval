"""Record the actual isolated execution environment, not copied legacy metadata."""
import datetime
import hashlib
import importlib.metadata
import json
import pathlib
import platform
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT.parent / 'environment'


def main():
    import torch
    OUT.mkdir(exist_ok=True)
    versions = {name: importlib.metadata.version(name) for name in
                ['torch', 'transformers', 'tokenizers', 'numpy', 'scipy', 'safetensors', 'huggingface_hub', 'pyarrow']}
    gpu = subprocess.run(['nvidia-smi', '-q'], capture_output=True, text=True, check=True).stdout
    (OUT / 'nvidia-smi.txt').write_text(gpu, encoding='utf-8')
    for filename, args in [('pip_freeze.txt', ['freeze']), ('pip_check.txt', ['check'])]:
        result = subprocess.run([sys.executable, '-m', 'pip', *args], capture_output=True, text=True)
        (OUT / filename).write_text(result.stdout + result.stderr, encoding='utf-8')
        if result.returncode:
            raise RuntimeError(filename + ': ' + result.stdout + result.stderr)
    facts = {'recorded_at': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
             'sys_executable': sys.executable, 'python': sys.version, 'platform': platform.platform(),
             'machine': platform.machine(), 'processor': platform.processor(),
             'versions': versions, 'cuda_runtime': torch.version.cuda,
             'cuda_available': torch.cuda.is_available(), 'bf16_supported': torch.cuda.is_bf16_supported(),
             'gpu': torch.cuda.get_device_name(0), 'gpu_memory_bytes': torch.cuda.get_device_properties(0).total_memory,
             'disk_free_bytes': shutil.disk_usage(ROOT).free,
             'pip_check_passed': True,
             'reference_versions': 'Python3.12.14, torch2.7.1+cu128, transformers4.57.1, tokenizers0.22.2, numpy2.2.6, scipy1.16.3'}
    assert facts['cuda_available'] and facts['bf16_supported']
    assert versions['torch'] == '2.7.1+cu128'
    (OUT / 'environment.json').write_text(json.dumps(facts, indent=2), encoding='utf-8')
    print(json.dumps(facts, indent=2))


if __name__ == '__main__':
    main()
