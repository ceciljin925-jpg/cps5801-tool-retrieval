"""Independent artifact verification, with no retrieval/model scoring."""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publication", required=True, type=Path)
    args = parser.parse_args()
    root = args.publication.resolve()
    manifest_path = root / "data/external/final_dataset_manifest.json"
    manifest = load(manifest_path)
    lock = load(root / "locks/external_lock.json")
    assert lock["final_dataset_manifest_sha256"] == digest(manifest_path)
    assert lock["source_code_sha256"] == digest(root / "extensions/external_prepare.py")
    assert lock["external_eval_specs_sha256"] == digest(root / "locks/external_eval_specs.json")
    assert lock["audit_plan_sha256"] == digest(root / "locks/external_audit_plan.json")
    seen_paths = set()
    for item in manifest["files"]:
        path = root / item["path"]
        assert path.resolve().is_relative_to(root)
        assert item["path"] not in seen_paths
        seen_paths.add(item["path"])
        assert path.stat().st_size == item["bytes"], item["path"]
        assert digest(path) == item["sha256"], item["path"]
    exclusions = [json.loads(s) for s in (root / "data/external/audit/exclusion_log.jsonl").read_text(encoding="utf-8").splitlines()]
    excluded_ids = {r["id"] for r in exclusions}
    group_rows = [json.loads(s) for s in (root / "data/external/audit/family_group_membership.jsonl").read_text(encoding="utf-8").splitlines()]
    group_by_id = {r["id"]: r for r in group_rows}
    results = {}
    for dataset, counts in manifest["datasets"].items():
        queries = load(root / "data/external" / dataset / "queries.json")
        corpus = load(root / "data/external" / dataset / "corpus.json")
        assert len({r["id"] for r in queries}) == len(queries) == counts["included_queries"]
        assert len({r["id"] for r in corpus}) == len(corpus) == counts["corpus_instances"]
        docs = {r["id"]: r for r in corpus}
        for doc in corpus:
            text_data = json.loads(doc["text"])
            assert set(text_data) == {"name", "description", "parameters"}
            assert doc["text"] == canon(text_data)
            assert hashlib.sha256(doc["text"].encode()).hexdigest() == doc["document_sha256"]
        for query in queries:
            assert query["id"] not in excluded_ids
            assert query["query"].strip()
            assert query["positives"] and len(query["positives"]) == len(set(query["positives"]))
            assert set(query["positives"]) <= set(docs)
            assert group_by_id[query["id"]]["group_id"] == query["group_id"]
            assert group_by_id[query["id"]]["included"] is True
            if dataset.startswith("bfcl_"):
                assert query["query"] == "\n".join(m["role"] + ": " + m["content"] for m in query["messages"])
                ids = query["candidate_ids"]
                assert len(ids) == len(set(ids)) and set(query["positives"]) < set(ids)
                assert set(ids) <= set(docs)
                assert set(query["candidate_tie_break_keys"]) == set(ids)
                for tid in ids:
                    assert tid.startswith("bfcl:" + query["id"] + ":")
                    expected = hashlib.sha256(("publication_v1|tie|" + query["id"] + "|" + docs[tid]["name"]).encode()).hexdigest()
                    assert query["candidate_tie_break_keys"][tid] == expected
                if dataset != "bfcl_parallel_multiple":
                    assert len(query["positives"]) == 1
            else:
                assert "candidate_ids" not in query
                assert set(query["positives"]) <= set(query["equivalent_positives"])
                assert all(t.startswith("toolhop:" + str(query["source_id"]) + ":") for t in query["positives"])
                true_fingerprints = {docs[t]["document_sha256"] for t in query["positives"]}
                expected_equivalent = {tid for tid, doc in docs.items() if doc["document_sha256"] in true_fingerprints}
                assert expected_equivalent == set(query["equivalent_positives"])
        group_counts = collections.Counter(r["group_id"] for r in queries)
        assert len(group_counts) == counts["uncertainty_groups"]
        assert len(queries) + sum(r["dataset"] == dataset for r in exclusions) == counts["raw_queries"]
        results[dataset] = {"queries": len(queries), "corpus_instances": len(corpus), "groups": len(group_counts), "unique_exact_documents": len({d["document_sha256"] for d in corpus})}
    assert results["toolhop"]["corpus_instances"] == 3912
    assert results["toolhop"]["unique_exact_documents"] == 3909
    report = {"status": "PASS", "verification_script_sha256": digest(Path(__file__)), "verified_frozen_files": len(seen_paths),
              "datasets": results, "model_scores_computed": False, "checks": ["all_frozen_hashes_and_sizes", "path_containment", "unique_ids", "complete_context_serialization", "no_gold_or_answer_in_document_payload_fields", "native_menu_and_gold_integrity", "tie_hash_formula", "exclusion_denominators", "group_mapping", "ToolHop_exact_document_classes"]}
    (root / "locks/external_verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(canon(report))


if __name__ == "__main__":
    main()
