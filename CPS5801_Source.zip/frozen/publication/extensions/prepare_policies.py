"""Freeze publication schedules and negative policies without consulting dev/final scores."""
import argparse
import collections
import hashlib
import json
import os
import pathlib
import random
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / 'repro' / 'data' / 'main_20261025'
MODEL = ROOT.parent / 'repro' / 'data' / 'raw' / 'model'
DATA = ROOT / 'data' / 'training'


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with pathlib.Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def dump(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, indent=2).encode('utf-8')
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError('Refuse to overwrite a different frozen artifact: ' + str(path))
    else:
        path.write_bytes(raw)


def rng(text):
    return random.Random(int(hashlib.sha256(text.encode('utf-8')).hexdigest()[:16], 16))


def shared_schedules():
    train = read(SOURCE / 'train.json')
    records = {}
    for seed in range(41, 47):
        order_rng, pos_rng = random.Random(seed), random.Random(seed + 1000)
        schedule = []
        for epoch in range(4):
            order = list(range(len(train)))
            order_rng.shuffle(order)
            schedule.extend({'epoch': epoch, 'query_id': train[i]['id'],
                             'positive': pos_rng.choice(train[i]['positives'])} for i in order)
        if seed in (42, 43, 44):
            assert schedule[:20000] == read(SOURCE / f'shared_schedule_seed{seed}.json')
        path = DATA / f'schedule_seed{seed}.json'
        dump(path, schedule)
        records[str(seed)] = {'path': str(path), 'sha256': sha(path), 'rows': len(schedule),
                              'legacy_prefix_equal': seed in (42, 43, 44)}
    dump(DATA / 'schedule_manifest.json', {
        'algorithm': 'freeze_main_study.py independent Random(seed) shuffle and Random(seed+1000) positive selection, four sequential epochs',
        'continuation': 'RNG streams continue after epoch2 without reseeding; batches concatenate across epoch boundaries',
        'source_freeze': sha(SOURCE / 'freeze_manifest.json'), 'schedules': records})


def signatures():
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
    corpus = read(SOURCE / 'corpus.json')
    result, lengths = {}, {}
    for i in range(0, len(corpus), 512):
        batch = corpus[i:i+512]
        tokens = tok(['passage: ' + d['text'] for d in batch], truncation=True, max_length=384)
        full = tok(['passage: ' + d['text'] for d in batch], truncation=False)
        for row, ids, fullids in zip(batch, tokens['input_ids'], full['input_ids']):
            result[row['id']] = hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest()
            lengths[row['id']] = {'encoded_tokens': len(ids), 'full_tokens': len(fullids), 'characters': len(row['text'])}
    dump(DATA / 'e5_input_signatures.json', result)
    dump(DATA / 'e5_tool_lengths.json', lengths)
    return result


def prepare_negatives():
    sig = read(DATA / 'e5_input_signatures.json')
    train, train_ids = read(SOURCE / 'train.json'), read(SOURCE / 'train_tool_ids.json')
    masks, bpools = read(SOURCE / 'forbidden_ids.json'), read(SOURCE / 'bm25_top50_eligible.json')
    dense_path = DATA / 'dense_top50_eligible.json'
    dense = read(dense_path) if dense_path.exists() else None
    sorted_ids = sorted(train_ids)
    ids_set = set(train_ids)
    aliases = collections.defaultdict(set)
    for tool in train_ids:
        aliases[sig[tool]].add(tool)
    masks = {q: set(v) for q, v in masks.items()}
    for g in train:
        for positive in g['positives']:
            assert positive in masks[g['id']]
            additional = aliases[sig[positive]] - masks[g['id']]
            if additional:
                raise RuntimeError(f'Actual-token aliases absent from frozen masks: {g["id"]}: {additional}')
        assert len({sig[t] for t in bpools[g['id']]}) >= 4
    report = {'seeds': {}, 'dense_available': dense is not None,
              'minimal_repair_rule': 'Reserve every original first-occurrence signature, replace only duplicate positions, candidates sorted by tool ID and selected uniformly after rejecting used signatures',
              'source_freeze_sha256': sha(SOURCE / 'freeze_manifest.json')}
    for seed in range(41, 47):
        rr, br = random.Random(seed + 2000), random.Random(seed + 3000)
        originals = {}
        for g in train:
            q, neg = g['id'], []
            while len(neg) < 4:
                t = rr.choice(train_ids)
                if t not in masks[q] and t not in neg:
                    neg.append(t)
            originals[q] = {'random': neg, 'bm25': br.sample(bpools[q], 4)}
        if seed in (42, 43, 44):
            assert originals == read(SOURCE / f'negatives_seed{seed}.json')
        rows, repairs, mixed_details = {}, [], []
        counts = collections.Counter()
        for g in train:
            q = g['id']
            row = {'R_ID': originals[q]['random'], 'B_ID': originals[q]['bm25']}
            for policy, parent in [('R_UNIQUE', 'R_ID'), ('B_UNIQUE', 'B_ID')]:
                original = row[parent]
                used = {sig[t] for t in original}
                seen, fixed = set(), list(original)
                local = rng(f'publication_v1|unique_repair|{policy}|{seed}|{q}')
                pool = sorted_ids if parent == 'R_ID' else sorted(bpools[q])
                changed = False
                for index, old in enumerate(original):
                    if sig[old] not in seen:
                        seen.add(sig[old])
                        continue
                    eligible = [t for t in pool if t not in masks[q] and sig[t] not in used]
                    if not eligible:
                        raise RuntimeError(f'No distinct input replacement: {q} {policy}')
                    new = local.choice(eligible)
                    fixed[index] = new
                    used.add(sig[new])
                    repairs.append({'seed': seed, 'policy': policy, 'query_id': q, 'position': index,
                                    'old_id': old, 'new_id': new, 'old_signature': sig[old],
                                    'new_signature': sig[new], 'reason': 'duplicate_negative_encoded_input'})
                    changed = True
                row[policy] = fixed
                counts[policy + '_changed_queries'] += changed
                assert len({sig[t] for t in fixed}) == 4
                if len({sig[t] for t in original}) == 4:
                    assert fixed == original
            mixed, sources, rejections = [], [], {'R_ID': 0, 'B_ID': 0}
            for source, pool in [('R_ID', train_ids), ('B_ID', bpools[q])]:
                local = rng(f'publication_v1|mixed|{source}|{seed}|{q}')
                for _ in range(2):
                    while True:
                        t = local.choice(pool)
                        if t not in masks[q] and t not in mixed:
                            break
                        rejections[source] += 1
                    mixed.append(t)
                    sources.append(source)
            row['MIXED_2R2B'] = mixed
            mixed_details.append({'query_id': q, 'ids': mixed, 'sources': sources, 'rejections': rejections,
                                  'unique_inputs': len({sig[t] for t in mixed})})
            if dense is not None:
                row['DENSE_STATIC'] = rng(f'publication_v1|dense_static|{seed}|{q}').sample(dense[q], 4)
            for policy, values in row.items():
                assert len(values) == len(set(values)) == 4
                assert set(values) <= ids_set and not (set(values) & masks[q])
                counts[policy + '_queries_with_duplicate_inputs'] += len({sig[t] for t in values}) < 4
            rows[q] = row
        # Policy files are separate so a later dense pool cannot overwrite the earlier freeze.
        for policy in next(iter(rows.values())):
            dump(DATA / f'{policy}_seed{seed}.json', {q: row[policy] for q, row in rows.items()})
        dump(DATA / f'unique_repairs_seed{seed}.json', repairs)
        dump(DATA / f'mixed_sources_seed{seed}.json', mixed_details)
        report['seeds'][str(seed)] = dict(counts)
    dump(DATA / ('negative_manifest_complete.json' if dense else 'negative_manifest_pre_dense.json'), report)
    print(json.dumps(report, indent=2), flush=True)


def mine_dense():
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    import numpy as np
    import torch
    from encoders import Encoder
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    train = read(SOURCE / 'train.json')
    ids = sorted(read(SOURCE / 'train_tool_ids.json'))
    byid = {x['id']: x for x in read(SOURCE / 'corpus.json')}
    masks = {q: set(v) for q, v in read(SOURCE / 'forbidden_ids.json').items()}
    # The Encoder API is checked before this stage executes.
    encoder = Encoder('e5', str(MODEL))
    started = time.perf_counter()
    docs = encoder.encode([byid[t]['text'] for t in ids], kind='document', batch_size=32)
    queries = encoder.encode([g['query'] for g in train], kind='query', batch_size=32)
    if isinstance(docs, torch.Tensor):
        docs = docs.detach().cpu().numpy()
    if isinstance(queries, torch.Tensor):
        queries = queries.detach().cpu().numpy()
    docs = np.asarray(docs, dtype=np.float32)
    queries = np.asarray(queries, dtype=np.float32)
    np.save(DATA / 'mining_corpus_embeddings.npy', docs)
    np.save(DATA / 'mining_query_embeddings.npy', queries)
    dump(DATA / 'mining_order.json', {'corpus_ids': ids, 'query_ids': [g['id'] for g in train]})
    d = torch.from_numpy(docs).cuda()
    pools, pool_scores = {}, {}
    for start in range(0, len(train), 128):
        scores = (torch.from_numpy(queries[start:start+128]).cuda() @ d.T).cpu().numpy()
        for g, s in zip(train[start:start+128], scores):
            order = np.argsort(-s, kind='stable')
            chosen = [int(i) for i in order if ids[i] not in masks[g['id']]][:50]
            assert len(chosen) == 50
            pools[g['id']] = [ids[i] for i in chosen]
            pool_scores[g['id']] = [float(s[i]) for i in chosen]
    dump(DATA / 'dense_top50_eligible.json', pools)
    dump(DATA / 'dense_top50_scores.json', pool_scores)
    dump(DATA / 'dense_mining_manifest.json', {
        'model': str(MODEL), 'model_sha256': sha(MODEL / 'model.safetensors'),
        'source_freeze_sha256': sha(SOURCE / 'freeze_manifest.json'),
        'queries': len(train), 'training_tools': len(ids), 'pool_size': 50,
        'rule': 'exact float32 dot product, stable sorted-ID ties; rank all then shared mask then top50',
        'seconds': time.perf_counter()-started, 'peak_allocated_GiB': torch.cuda.max_memory_allocated()/2**30,
        'pool_sha256': sha(DATA / 'dense_top50_eligible.json')})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=['schedules', 'signatures', 'negatives', 'mine'])
    args = parser.parse_args()
    DATA.mkdir(parents=True, exist_ok=True)
    {'schedules': shared_schedules, 'signatures': signatures, 'negatives': prepare_negatives,
     'mine': mine_dense}[args.stage]()
