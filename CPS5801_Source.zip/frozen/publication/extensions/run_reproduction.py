"""Execute the unchanged S0 pipeline in the clean isolated reproduction tree."""
import json
import hashlib
import pathlib
import sys

from execute_logged import execute, now, dump

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent/'repro'
R = REPRO/'results/main_20261025'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    registry = read(ROOT/'run_registry.json')
    if any(r['status'] != 'pending' for r in registry['runs'] if r['stage']=='S0'):
        raise RuntimeError('S0 already attempted; inspect existing results before explicit technical recovery')
    for name in ('main_representation_stats','validate_main_snapshot','check_encoder_collisions'):
        execute([sys.executable, f'scripts/{name}.py'], REPRO, REPRO/'logs', name)
    for row in registry['runs']:
        if row['stage']=='S0':
            row.update(status='running',started_at=now(),attempts=[{'attempt_id':'attempt_01','engine':'unchanged_original','root':str(REPRO)}])
    dump(ROOT/'run_registry.json',registry)
    execute([sys.executable,'scripts/run_logged.py','scripts/main_training_engine.py'], REPRO, REPRO/'logs','s0_training')
    for row in registry['runs']:
        if row['stage']!='S0':continue
        seed=row['seed']; policy='random' if row['policy']=='R_ID' else 'bm25'
        legacy=f'M{3+2*(seed-42)+(policy=="bm25"):02}_{policy}_seed{seed}'
        out=R/legacy
        training=read(out/'training.json')
        losses=(out/'loss.jsonl').read_text().splitlines()
        assert training['steps']==len(losses)==625
        assert (out/'checkpoint/model.safetensors').is_file()
        assert len(read(out/'predictions.json'))==1000
        row.update(status='completed',completed_at=now(),legacy_run_id=legacy,output_path=str(out),
                   checkpoint_path=str(out/'checkpoint'),actual_steps=625,
                   checkpoint_sha256=hashlib.sha256((out/'checkpoint/model.safetensors').read_bytes()).hexdigest(),
                   config={'stage':'S0','family':'e5','policy':row['policy'],'seed':seed,'lr':2e-5,'temperature':.05,'steps':625},
                   dev_evaluations=[{'steps':625,'metrics_path':str(out/'metrics.json')}])
    dump(ROOT/'run_registry.json',registry)
    execute([sys.executable,'scripts/evaluate_main_test.py'], REPRO, REPRO/'logs','s0_legacy_test')
    execute([sys.executable,'scripts/analyze_main_study.py'], REPRO, REPRO/'logs','s0_analysis')
    package=ROOT.parent/'handoff/CPS5801_PUBLICATION_HANDOFF_20261112'
    execute([sys.executable,str(ROOT/'extensions/compare_reproduction.py'),
             '--original-root',str(package/'archive/CPS5801_HANDOFF_20261025/CPS5801'),
             '--reproduction-root',str(REPRO),'--package-root',str(package),
             '--output-dir',str(ROOT/'comparison')],ROOT,REPRO/'logs','s0_comparison')
    dump(ROOT/'s0_completed.json',{'completed_at':now(),'trained_runs':6,'dev_evaluations':8,'legacy_evaluations':8,
                                'external_final_scored':False,'source_results_reused':False})


if __name__=='__main__':
    main()
