"""Require independent development-selection evidence before opening final scores."""
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def require(condition, message):
    if not condition:
        raise RuntimeError('Independent selection review gate: ' + message)


def verify_selection_reviews(root):
    root = Path(root).resolve()
    bindings = {}
    for stage, cells in [('S2', 72), ('S4', 36)]:
        folder = root / 'analysis/selection_stage_reviews' / (stage + '_attempt01') / 'review'
        report_path = folder / 'review_report.json'
        status_path = folder / 'status.json'
        lock_path = root / 'locks' / (stage + '_selection.json')
        report, state, lock = read(report_path), read(status_path), read(lock_path)
        require(report['status'] == state['status'] == 'PASS_INDEPENDENT_SELECTION_REVIEW', stage + ' review is not PASS')
        require(report['stage'] == state['stage'] == lock['stage'] == stage, stage + ' identity differs')
        require(report['all_locked_choices_match'] is True, stage + ' choices mismatch')
        require(report['valid_grid_slots'] == cells and report['explicit_numerical_failed_slots'] == 0
                and report['invalid_or_missing_slots'] == 0, stage + ' grid has unreviewed failed/missing cells')
        lock_sha = sha(lock_path)
        require(report['locked_selection_sha256'] == lock_sha, stage + ' selection lock changed')
        source = lock['input_registry']
        snapshot = Path(source['immutable_snapshot_path']).resolve(strict=True)
        require(snapshot == (root / 'locks' / (stage + '_selection_input_registry.json')).resolve(), stage + ' unexpected snapshot location')
        snapshot_sha = sha(snapshot)
        require(source['same_bytes_used_for_selection_and_snapshot'] is True
                and source['sha256'] == source['immutable_snapshot_sha256'] == snapshot_sha,
                stage + ' consumed registry snapshot changed')
        require(report['selector_immutable_registry_snapshot_verified'] is True
                and report['selector_immutable_snapshot_sha256'] == snapshot_sha, stage + ' snapshot not independently verified')
        require(report['script_sha256'] == sha(root / 'extensions/review_selection_stage.py'), stage + ' reviewer code changed')
        if stage == 'S4':
            require(report['upstream_S2_review_sha256'] == bindings['S2']['report_sha256']
                    and report['upstream_S2_lock_sha256'] == bindings['S2']['selection_lock_sha256'],
                    'S4 does not bind the reviewed S2 choice')
        bindings[stage] = {'report_path': str(report_path), 'report_sha256': sha(report_path),
                           'status_path': str(status_path), 'status_sha256': sha(status_path),
                           'selection_lock_sha256': lock_sha, 'input_registry_snapshot_sha256': snapshot_sha,
                           'reviewer_code_sha256': report['script_sha256'], 'valid_grid_slots': cells}
    return bindings
