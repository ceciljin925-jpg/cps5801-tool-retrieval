"""CPU check: paired training must agree before the first policy intervention.

This engineering audit does not select methods or inspect final test results.
"""
import argparse
import hashlib
import json
import pathlib

from execute_logged import dump, now

ROOT = pathlib.Path(__file__).resolve().parents[1]


def read(path):
    text = path.read_text(encoding='utf-8-sig')
    return [json.loads(line) for line in text.splitlines()] if path.suffix == '.jsonl' else json.loads(text)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Preserve earlier audit snapshots')
    records, pending = [], []
    for seed in (42, 43, 44):
        for policy, original_policy, offset in [('R_UNIQUE', 'random', 0), ('B_UNIQUE', 'bm25', 1)]:
            run_id = f'S1_e5_{policy}_s{seed}_lr2e-5_t0.05'
            directory = ROOT / 'runs' / run_id / 'attempt_01'
            if not (directory / 'training.json').exists():
                pending.append(run_id)
                continue
            original_id = f'M{3 + 2*(seed-42) + offset:02}_{original_policy}_seed{seed}'
            original_loss = ROOT.parent / 'repro/results/main_20261025' / original_id / 'loss.jsonl'
            training = ROOT / 'data/training'
            base_path = training / f'{policy[0]}_ID_seed{seed}.json'
            unique_path = training / f'{policy}_seed{seed}.json'
            schedule_path = training / f'schedule_seed{seed}.json'
            baseline, unique, schedule = map(read, (base_path, unique_path, schedule_path))
            changed = sorted(qid for qid in baseline if baseline[qid] != unique[qid])
            changed_set = set(changed)
            first = next((index for index, row in enumerate(schedule[:20000]) if row['query_id'] in changed_set), None)
            first_step = first // 32 + 1 if first is not None else 626
            old, new = read(original_loss), read(directory / 'loss.jsonl')
            assert len(old) == len(new) == 625
            differences = [a['step'] for a, b in zip(old, new, strict=True)
                           if any(a[key] != b[key] for key in ('step', 'loss', 'grad_norm'))]
            passed = all(step >= first_step for step in differences)
            inputs = [original_loss, directory / 'loss.jsonl', base_path, unique_path, schedule_path]
            records.append({'run_id': run_id, 'original_run': original_id, 'changed_queries': changed,
                'first_changed_exposure_zero_based': first, 'first_affected_update_one_based': first_step,
                'unchanged_prefix_update_count': first_step - 1,
                'first_observed_loss_or_gradient_difference': differences[0] if differences else None,
                'unchanged_prefix_exact': passed,
                'sources': [{'path': str(path), 'sha256': sha(path)} for path in inputs]})
    result = {'created_at': now(), 'status': 'PASS_AVAILABLE_PREFIXES' if all(row['unchanged_prefix_exact'] for row in records) else 'FAILED',
              'records': records, 'pending': pending, 'code_sha256': sha(pathlib.Path(__file__)),
              'scope': 'Same seed/config, original and unique policies. Only pre-intervention loss/gradient equality is required. Zero-length prefixes provide no additional test. Does not establish a semantic mechanism.'}
    dump(args.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result['status'] == 'FAILED':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
