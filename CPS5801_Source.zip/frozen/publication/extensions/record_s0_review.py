"""Record the root agent's reviewed S0 decision against exact observed evidence.

This is deliberately specific to this execution. It is not a general numeric
tolerance, an automatic future-error exemption, or independent human review.
"""
import csv
import hashlib
import json
import pathlib

from execute_logged import dump, now

ROOT = pathlib.Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    target = ROOT / 'comparison/reproduction_review.json'
    if target.exists():
        raise FileExistsError('Preserve prior scientific review')
    audit_path = ROOT / 'analysis/auto_review_s0_attempt01/auto_review_s0_candidate.json'
    comparison_path = ROOT / 'comparison/reproduction_comparison.json'
    test_path = ROOT / 'analysis/bm25_test_numerics_attempt01/bm25_numerical_diagnosis.json'
    audit, comparison, test = map(read, (audit_path, comparison_path, test_path))
    assert not audit['failures'] and all(audit['strict_checks'].values())
    assert comparison['summary']['status'] == 'PASS_COMPLETE'
    assert audit['known_bm25_development_diagnosis']['all_bound_evidence_matches']
    assert all(audit['extension_bm25_fix_checks'].values())
    with (ROOT / 'comparison/original_vs_reproduction.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 80 and all(float(row['reproduction_minus_original']) == 0 for row in rows)
    dev = next(row for row in audit['bm25'] if row['split'] == 'development')
    legacy = next(row for row in audit['bm25'] if row['split'] == 'official_test')
    assert dev['rank_changed_query_ids'] == ['train_195756']
    assert not legacy['rank_changed_query_ids'] and not test['saved_top10_changed_queries']
    assert legacy['query_count'] == test['queries'] == 7961
    assert legacy['score_changed_query_count'] == test['saved_same_ID_score_changed_query_count'] == 7231
    assert legacy['maximum_same_ID_score_difference'] == test['saved_maximum_same_ID_score_difference']
    assert all(value == 0 for value in test['saved_aggregate_metric_differences'].values())
    assert test['saved_metrics_exactly_recomputed'] is True
    for key in ('delta_from_original_saved', 'delta_from_reproduction_saved'):
        assert all(value == 0 for value in test['canonical_column_order_legacy_test'][key].values())
    for record in test['source_files_unchanged_and_identical'].values():
        path = pathlib.Path(record['path'])
        assert path.stat().st_size == record['bytes'] and sha(path) == record['sha256']
    assert sha(ROOT / 'extensions/investigate_bm25_test.py') == test['diagnostic_code_sha256']
    assert not (ROOT / 'EXTERNAL_FINAL_OPENED.json').exists()
    assert not (ROOT / 'external_access_log.jsonl').exists()
    evidence = [audit_path, comparison_path, test_path,
                ROOT / 'analysis/bm25_numerics_attempt01/bm25_numerical_diagnosis.json',
                ROOT / 'provenance/bm25_numerical_fix.json', ROOT / 'comparison/original_vs_reproduction.csv']
    record = {
        'reviewed_at': now(), 'continue_publication': True,
        'review_kind': 'root_AI_agent_scientific_review_after_strict_independent_code_audit',
        'independent_human_review': False,
        'strict_checks': audit['strict_checks'], 'all80_reported_metric_deltas_exactly_zero': True,
        'original_outputs_substituted_for_new': False,
        'bm25_development': {'queries': 1000, 'ranking_changed_queries': ['train_195756'],
            'score_changed_queries': 955, 'maximum_same_ID_score_difference': dev['maximum_same_ID_score_difference'],
            'cause_evidence': 'Controlled query-term accumulation permutations reproduce both saved rankings. Float64 term totals tie; float32 sum order separates the tie. All five aggregate metrics agree exactly.'},
        'bm25_legacy_test': {'queries': 7961, 'ranking_changed_queries': [], 'score_changed_queries': 7231,
            'maximum_same_ID_score_difference': legacy['maximum_same_ID_score_difference'],
            'assessment': 'All rankings and five independently recomputed metrics agree exactly. Residual score-byte differences are consistent with the demonstrated set-order float32 sensitivity; historical hash salt and every historical score byte have not been reconstructed.'},
        'decision': 'S0 reproduces all reported retrieval metrics, all neural rankings/scores, all six training traces and checkpoint weight files. The isolated BM25 floating-point ordering issue is documented and does not alter this reproduction conclusion. Proceed with the predeclared extension matrix.',
        'technical_amendment': 'S0 original code and saved outputs remain unchanged. Extension BM25 uses the already-recorded canonical term-column order, fixed and CPU-tested before new extension/final results.',
        'cross_execution_numeric_tolerance': None,
        'no_blanket_future_difference_exemption': True,
        'limitations': ['Not a claim that all S0 score bytes are identical.',
                       'No guarantee of bitwise reproducibility on different hardware/software.',
                       'No new external final model score has been opened.',
                       'No human semantic review or execution-success claim.'],
        'evidence': [{'path': str(path), 'sha256': sha(path)} for path in evidence],
        'review_record_code_sha256': sha(pathlib.Path(__file__))
    }
    dump(target, record)
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
