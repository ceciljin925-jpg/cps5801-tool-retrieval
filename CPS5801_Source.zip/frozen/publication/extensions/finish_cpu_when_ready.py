"""Local CPU postprocessing queue; no model/API calls and no completion claim.

The user returns for scientific review, figure inspection and the final ZIP.
"""
import json
import pathlib
import time
import traceback

from execute_logged import execute, dump, now

ROOT = pathlib.Path(__file__).resolve().parents[1]
WORK = ROOT.parent
EXT = ROOT / 'extensions'
CPU = WORK / 'analysis_venv/Scripts/python.exe'
SOURCE = WORK / 'handoff/CPS5801_PUBLICATION_HANDOFF_20261112/archive/CPS5801_HANDOFF_20261025/CPS5801'
REPRO = WORK / 'repro'
STATE = ROOT / 'finish_cpu_status.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def state(phase, **fields):
    dump(STATE, {'phase': phase, 'updated_at': now(), **fields})
    print(phase, fields, flush=True)


def run(name, arguments):
    status = ROOT / 'logs' / (name + '.process_status.json')
    if status.exists():
        saved = read(status)
        if saved['status'] == 'completed' and saved.get('exit_code') == 0:
            return
        raise RuntimeError('Existing incomplete CPU attempt needs explicit recovery: ' + name)
    execute([str(CPU), *map(str, arguments)], ROOT, ROOT / 'logs', name)


def check_controller():
    controller = read(ROOT / 'research_controller_status.json')
    if controller['phase'] == 'failed_or_interrupted':
        raise RuntimeError('Research controller stopped; preserve evidence and inspect its failure status')
    process = read(ROOT / 'logs/research_controller.process_status.json')
    if process['status'] not in ('starting', 'running', 'completed'):
        raise RuntimeError('Research process failed/interrupted; inspect retained PID before recovery')
    return controller


def main():
    state('waiting_for_s0')
    while not (ROOT / 's0_completed.json').exists():
        check_controller()
        time.sleep(30)
    state('rebuilding_reproduction_errors_and_legacy_tables')
    run('legacy_errors_with_reproduction', [EXT / 'analyze_errors.py', '--original-root', SOURCE,
        '--reproduction-root', REPRO, '--output-dir', ROOT / 'analysis/legacy_errors'])
    run('restore_documented_ai_only_review', [EXT / 'complete_legacy_ai_review.py',
        '--analysis-root', ROOT / 'analysis/legacy_errors'])
    run('legacy_all_original_and_reproduction', [EXT / 'rebuild_legacy_tables.py', '--input-root', ROOT,
        '--include-reproduction', '--output-dir', ROOT / 'tables/legacy_original_and_reproduction_attempt01'])
    state('waiting_for_all_gpu_and_core_analysis')
    while check_controller()['phase'] != 'gpu_and_core_analysis_completed_awaiting_final_review_and_package':
        time.sleep(30)
    state('rebuilding_complete_efficiency_evidence')
    run('efficiency_analysis_all_final', [EXT / 'analyze_efficiency.py', '--input-root', ROOT,
        '--output-dir', ROOT / 'analysis/final_efficiency'])
    status = read(ROOT / 'analysis/final_efficiency/status.json')
    if status.get('completed_accuracy_evaluations') != 260 or status.get('completed_profiles') != 80 or status.get('pending') or status.get('failures'):
        raise RuntimeError('Complete efficiency evidence has not passed verification')
    state('ready_for_agent_scientific_review_and_final_packaging',
          remaining=['review real effects and limitations', 'inspect generated figures',
                     'write claim ledger and Chinese handoff', 'run completion checks',
                     'rebuild copied portable bundle and verify final ZIP'],
          all_independent_work_completed=False, human_review='HUMAN_PENDING')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        state('failed_or_interrupted', error=repr(error), traceback=traceback.format_exc())
        raise
