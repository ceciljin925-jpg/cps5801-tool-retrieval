"""Durable single-GPU publication queue. Training and dev only, never final scores."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys
import traceback

from execute_logged import execute, now, dump

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXT = ROOT/'extensions'
DATA = ROOT.parent/'repro/data/main_20261025'
REGISTRY = ROOT/'run_registry.json'


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def validated_completed(row):
    out=pathlib.Path(row['output_path'])
    stats=read(out/'training.json')
    assert stats['steps']==row['actual_steps']
    assert len((out/'loss.jsonl').read_text().splitlines())==row['actual_steps']
    assert read(out/'status.json')['status']=='completed'
    for ev in row['dev_evaluations']:
        report=read(ev['metrics_path'])
        assert report['n']==1000
        assert pathlib.Path(ev['checkpoint_path'],'model.safetensors').is_file()


def model_path(family):
    if family=='e5':return ROOT.parent/'repro/data/raw/model'
    report=read(ROOT/'models/verified_models.json')
    return pathlib.Path(next(m['local_dir'] for m in report['models'] if m['repo_id']=='BAAI/bge-small-en-v1.5'))


def config_for(row):
    frozen=read(DATA/'freeze_manifest.json')
    for relative,expected in frozen['files'].items():
        path=(ROOT.parent/'repro'/relative).resolve(strict=True)
        if sha(path)!=expected:raise RuntimeError('Frozen original input changed: '+relative)
    stage=row['stage']
    policy=row['policy']
    if policy=='SELECTED_EXTENSION':
        policy=read(ROOT/'locks/S2_selection.json')['selected_extension']['policy']
    if stage in ('S3','S5'):
        lock=read(ROOT/'locks'/('S2_selection.json' if stage=='S3' else 'S4_selection.json'))
        chosen=lock['selection'][policy]
        lr,temperature,steps=chosen['lr'],chosen['temperature'],chosen['steps']
        milestones=[steps]
    else:
        lr,temperature,steps=row['learning_rate'],row['temperature'],row['optimizer_updates']
        milestones=row['development_checkpoint_updates']
    config={'run_id':row['run_id'],'stage':stage,'family':row['family'],'policy':policy,'seed':row['seed'],
            'model_path':str(model_path(row['family'])),'train_path':str(DATA/'train.json'),
            'corpus_path':str(DATA/'corpus.json'),
            'schedule_path':str(ROOT/'data/training'/f'schedule_seed{row["seed"]}.json'),
            'negatives_path':str(ROOT/'data/training'/f'{policy}_seed{row["seed"]}.json'),
            'train_tool_ids_path':str(DATA/'train_tool_ids.json'),'forbidden_path':str(DATA/'forbidden_ids.json'),
            'lr':lr,'temperature':temperature,'steps':steps,'checkpoint_steps':milestones,
            'microbatch':8,'accumulation':4,'resume_every':100,
            'input_hashes':{str(ROOT.parent/'repro'/relative):expected for relative,expected in frozen['files'].items()}}
    return config


def _run_one(registry,row):
    if row['status']=='completed':
        validated_completed(row)
        return
    if row['status']=='failed' and row.get('failure_kind')=='numerical':return
    if row['status']!='pending':
        raise RuntimeError('Inspect interrupted/failed attempt before explicit recovery: '+row['run_id'])
    config=config_for(row)
    directory=ROOT/'runs'/row['run_id']
    directory.mkdir(parents=True,exist_ok=True)
    attempt=directory/'attempt_01'
    config_path=directory/'config_attempt_01.json'
    if config_path.exists() or attempt.exists():raise RuntimeError('Unexpected existing attempt: '+str(directory))
    dump(config_path,config)
    row.update(status='running',started_at=now(),planned_policy=row['policy'],policy=config['policy'],
               config=config,lr=config['lr'],temperature=config['temperature'],optimizer_updates=config['steps'],
               output_path=str(attempt),active_phase='training',
               active_command_status_path=str(directory/'train_attempt_01.process_status.json'),
               attempts=[{'attempt_id':'attempt_01','config_path':str(config_path),'output':str(attempt)}])
    dump(REGISTRY,registry)
    numeric=False
    try:
        execute([sys.executable,str(EXT/'train_configurable.py'),'--config',str(config_path),'--output',str(attempt)],
                ROOT,directory,'train_attempt_01')
    except subprocess.CalledProcessError:
        state=read(attempt/'status.json') if (attempt/'status.json').exists() else {}
        error=state.get('error','Process failed; inspect stdout/stderr')
        numeric='Nonfinite loss' in error or 'Nonfinite gradient' in error
        row.update(status='failed',failure_reason=error,failure_kind='numerical' if numeric else 'technical',failed_at=now())
        dump(REGISTRY,registry)
        if not numeric:raise
    if not numeric:
        row['active_phase']='training_validation'
        stats=read(attempt/'training.json')
        assert stats['steps']==config['steps']
        assert stats['exposures']==config['steps']*32
        assert len((attempt/'loss.jsonl').read_text().splitlines())==config['steps']
        row['actual_steps']=stats['steps']
        row['training_completed']=True
    else:
        row['actual_steps']=len((attempt/'loss.jsonl').read_text().splitlines())
    row['dev_evaluations']=[]
    for step in config['checkpoint_steps']:
        checkpoint=attempt/'checkpoints'/f'step_{step:04d}'
        if numeric and not (checkpoint/'checkpoint_provenance.json').exists():continue
        evconfig={'run_id':row['run_id'],'family':row['family'],'model_path':str(checkpoint),
                  'queries_path':str(DATA/'dev.json'),'corpus_path':str(DATA/'corpus.json'),
                  'task_type':'pooled','batch_size':64,'query_block_size':32,'save_embeddings':False,
                  'latency_count':0,'latency_warmups':0,'split':'original_development'}
        evpath=directory/f'dev_step{step:04d}_config.json'
        evout=attempt/f'dev_step_{step:04d}'
        dump(evpath,evconfig)
        row.update(active_phase='development_evaluation',active_checkpoint_step=step,
                   active_command_status_path=str(directory/f'dev_step{step:04d}_attempt01.process_status.json'))
        dump(REGISTRY,registry)
        execute([sys.executable,str(EXT/'evaluate_retrieval.py'),'--config',str(evpath),'--output',str(evout)],
                ROOT,directory,f'dev_step{step:04d}_attempt01')
        assert read(evout/'metrics.json')['n']==1000
        assert len(read(evout/'predictions.json'))==1000
        row['dev_evaluations'].append({'steps':step,'metrics_path':str(evout/'metrics.json'),
                                       'checkpoint_path':str(checkpoint),'checkpoint_sha256':sha(checkpoint/'model.safetensors'),
                                       'metrics_sha256':sha(evout/'metrics.json'),'predictions_sha256':sha(evout/'predictions.json'),
                                       'split':'original_dev'})
        dump(REGISTRY,registry)
    if not numeric:
        row.update(status='completed',completed_at=now(),checkpoint_path=str(attempt/'checkpoints'/f'step_{config["steps"]:04d}'))
    row['active_phase']='terminal'
    dump(REGISTRY,registry)
    print('JOB_COMPLETED' if not numeric else 'NUMERICAL_FAILURE_EARLIER_CHECKPOINTS_RETAINED',row['run_id'],flush=True)


def run_one(registry,row):
    try:
        return _run_one(registry,row)
    except BaseException as error:
        # Preserve known training failure and successful earlier evaluations when
        # initialization, validation, dev inference, or the monitor fails.
        previous = {key: row[key] for key in ('failure_reason','failure_kind','failed_at') if key in row}
        if previous:
            row.setdefault('failure_history',[]).append(previous)
        phase='completed_evidence_validation' if row.get('status')=='completed' else row.get('active_phase','initialization')
        row.update(status='interrupted' if isinstance(error,(KeyboardInterrupt,SystemExit)) else 'failed',
                   failure_reason=repr(error),failure_kind='technical',failure_phase=phase,
                   failed_at=now(),failure_traceback=traceback.format_exc())
        command_path=row.get('active_command_status_path')
        if command_path and pathlib.Path(command_path).exists():
            state=read(command_path)
            row['last_command_status']=state
            if state.get('child_may_still_be_running'):
                row['recovery_warning']='Child may still run; inspect PID before launching another GPU job.'
        dump(REGISTRY,registry)
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stages',nargs='+',default=['S1','S2','S3','S4','S5'],choices=['S1','S2','S3','S4','S5'])
    args=parser.parse_args()
    # New-engine equivalence is an actual evidence gate, not a ready flag.
    fixture=read(ROOT/'analysis/engine_fixture_attempt01/gpu_fixture_report.json')
    if fixture.get('passed') is not True:raise RuntimeError('GPU engine fixtures have not passed')
    if not (ROOT/'s0_completed.json').exists():raise RuntimeError('Complete S0 and inspect comparison first')
    comparison=read(ROOT/'comparison/reproduction_comparison.json')
    if comparison['summary']['status']!='PASS_COMPLETE':raise RuntimeError('S0 saved-prediction comparison did not pass')
    review=read(ROOT/'comparison/reproduction_review.json')
    if review.get('continue_publication') is not True:raise RuntimeError('Review S0 numerical differences before extension comparisons')
    if not (ROOT/'data/training/negative_manifest_complete.json').exists():raise RuntimeError('Negative policies not frozen')
    registry=read(REGISTRY)
    for stage in args.stages:
        print('STAGE_STARTED',stage,now(),flush=True)
        for row in registry['runs']:
            if row['stage']==stage:run_one(registry,row)
        if stage in ('S2','S4'):
            if not (ROOT/'locks/final_dataset_manifest.json').exists():
                raise RuntimeError('External data must be frozen before scientific model selection')
            lock=ROOT/'locks'/f'{stage}_selection.json'
            if not lock.exists():
                command=[sys.executable,str(EXT/'select_on_dev.py'),'--registry',str(REGISTRY),'--stage',stage,'--output',str(lock)]
                if stage=='S4':command+=['--s2-lock',str(ROOT/'locks/S2_selection.json')]
                execute(command,ROOT,ROOT/'logs',f'{stage}_selection')
        print('STAGE_COMPLETED',stage,now(),flush=True)
    dump(ROOT/'training_queue_completed.json',{'completed_at':now(),'stages':args.stages,
                                            'status_counts':{s:sum(r['status']==s for r in registry['runs']) for s in ('completed','failed','pending')}})


if __name__=='__main__':
    try:main()
    except BaseException as error:
        dump(ROOT/'queue_last_error.json',{'at':now(),'error':repr(error),'traceback':traceback.format_exc()})
        raise
