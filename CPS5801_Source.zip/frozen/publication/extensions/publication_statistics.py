"""Paired, query-weighted bootstrap statistics for CPS5801 publication_v1.

JSON input schema:
{
 "evidence_stage":"confirmation", "expected_seeds":[42,43,44,45,46],
 "expected_query_ids":["q1","q2"], "query_groups":{"q1":"g1","q2":"g2"},
 "metrics":["mrr"],
 "contrasts":[{"contrast_id":"e5_selected_minus_random",
                "coefficients":{"e5_selected":1,"e5_R_ID":-1}}],
 "records":[{"method":"e5_selected","seed":42,"query_id":"q1",
             "metrics":{"mrr":0.5}}, ...],
 "bootstrap":{"replicates":5000,"query_seed":2026111201,
              "cluster_seed":2026111202,"engine":"numpy","batch_size":128}
}

Each method/seed/query/metric must be present exactly once. A long row with
metric/value is also supported. Scores must have been independently recomputed
from rankings and frozen labels upstream. No final scores are read by self-test.
Use evidence_stage=fixed_mechanism and seeds42,43,44 for factorial contrasts:
{"B_UNIQUE":1,"B_ID":-1,"R_UNIQUE":-1,"R_ID":1}.

Bootstrap engine is explicit and recorded. numpy uses PCG64; stdlib uses
random.Random MT19937. Never silently switch engines after freezing the plan.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def numeric(value, label):
    require(not isinstance(value, bool), f"{label} is boolean")
    result = float(value)
    require(math.isfinite(result), f"Non-finite {label}")
    return result


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def percentile_linear(values, probability):
    require(len(values) > 0 and 0 <= probability <= 1, "Invalid quantile input")
    values = sorted(values)
    position = (len(values) - 1) * probability
    low, high = math.floor(position), math.ceil(position)
    weight = position - low
    return values[low] * (1 - weight) + values[high] * weight


def paired_difference(records, query_ids, seeds, coefficients, metric):
    """Return per-seed query contrasts and their querywise seed mean."""
    per_seed = {}
    for seed in seeds:
        per_seed[seed] = [math.fsum(coef * records[(method, seed, qid)][metric]
                                  for method, coef in coefficients.items()) for qid in query_ids]
    means = [math.fsum(per_seed[seed][i] for seed in seeds) / len(seeds) for i in range(len(query_ids))]
    return per_seed, means


def bootstrap(values, group_ids=None, *, replicates=5000, seed=2026111201,
              engine="stdlib", batch_size=128, confidence_level=.95):
    """Uniformly resample units, carrying every row of each sampled cluster.

    For clusters, the replicate estimate is sum(row contrasts)/number of rows,
    not an unweighted mean of group means. Repeated groups repeat all their rows.
    Return all replicate denominators and estimates for direct auditing.
    """
    require(len(values) > 0, "Empty bootstrap observations")
    require(isinstance(replicates, int) and replicates > 0, "Positive integer replicate count required")
    require(isinstance(batch_size, int) and batch_size > 0, "Positive batch size required")
    require(0 < confidence_level < 1, "Confidence level outside (0,1)")
    require(engine in ["stdlib", "numpy"], "Bootstrap engine must be explicitly stdlib or numpy")
    values = [numeric(value, "bootstrap value") for value in values]
    if group_ids is None:
        sums, counts = values, [1] * len(values)
        grouped = False
    else:
        require(len(group_ids) == len(values), "Group alignment mismatch")
        buckets = {}
        for group, value in zip(group_ids, values):
            buckets.setdefault(str(group), []).append(value)
        sums = [math.fsum(bucket) for bucket in buckets.values()]
        counts = [len(bucket) for bucket in buckets.values()]
        grouped = True
    n_units = len(sums)
    estimates, sample_sizes, unique_unit_counts = [], [], []
    if engine == "numpy":
        try:
            import numpy as np
        except ImportError as exc:
            raise ValueError("Frozen engine numpy unavailable; install numpy or explicitly revise plan before results") from exc
        rng = np.random.Generator(np.random.PCG64(seed))
        unit_sums, unit_counts = np.asarray(sums, dtype=np.float64), np.asarray(counts, dtype=np.int64)
        for start in range(0, replicates, batch_size):
            size = min(batch_size, replicates - start)
            indices = rng.integers(0, n_units, size=(size, n_units), dtype=np.int64)
            denominators = unit_counts[indices].sum(axis=1, dtype=np.int64)
            numerators = unit_sums[indices].sum(axis=1, dtype=np.float64)
            estimates.extend((numerators / denominators).tolist())
            sample_sizes.extend(denominators.tolist())
            sorted_indices = np.sort(indices, axis=1)
            unique_unit_counts.extend((1 + np.count_nonzero(sorted_indices[:, 1:] != sorted_indices[:, :-1], axis=1)).tolist())
        engine_version = {"numpy": np.__version__, "bit_generator": "PCG64"}
    else:
        rng = random.Random(seed)
        for _ in range(replicates):
            indices = [rng.randrange(n_units) for _ in range(n_units)]
            denominator = sum(counts[i] for i in indices)
            estimates.append(math.fsum(sums[i] for i in indices) / denominator)
            sample_sizes.append(denominator)
            unique_unit_counts.append(len(set(indices)))
        engine_version = {"python": sys.version.split()[0], "bit_generator": "random.Random MT19937"}
    alpha = (1 - confidence_level) / 2
    interval = [percentile_linear(estimates, alpha), percentile_linear(estimates, 1 - alpha)]
    warnings = []
    if n_units == 1:
        warnings.append("Only one independent resampling unit; no inferential confidence interval is reported.")
    elif n_units < 10:
        warnings.append("Fewer than 10 resampling units; bootstrap uncertainty is fragile and must be interpreted descriptively.")
    if grouped and max(counts) / len(values) > .2:
        warnings.append("Largest cluster exceeds 20% of observations; dependence and size imbalance limit inference.")
    return {
        "unit": "query_group" if grouped else "query", "estimator": "query_weighted_mean",
        "n_rows": len(values), "n_units": n_units, "unit_sizes": counts if grouped else None,
        "replicates": replicates, "seed": seed, "engine": engine, "engine_version": engine_version,
        "batch_size": batch_size, "confidence_level": confidence_level,
        "quantile_method": "sorted_linear_interpolation_at_(n-1)*p",
        "percentile_interval": interval if n_units > 1 else None,
        "degenerate_resampling_range": interval if n_units == 1 else None,
        "interval_status": "unavailable_single_unit" if n_units == 1 else ("fragile_few_units" if n_units < 10 else "conditional_interval"),
        "sampled_unit_draws_per_replicate": n_units,
        "replicate_estimates": estimates, "replicate_n_rows": sample_sizes,
        "replicate_unique_units": unique_unit_counts, "warnings": warnings,
        "conditioning": "These fitted models, fixed labels, and this evaluation distribution; excludes full training/model-selection/label/data-selection uncertainty.",
    }


def normalize_input(data):
    require(isinstance(data, dict), "Statistics input must be an object")
    stage = data.get("evidence_stage")
    require(stage in ["confirmation", "fixed_mechanism", "original", "exploratory"], "Explicit evidence_stage required")
    seeds = data.get("expected_seeds")
    require(isinstance(seeds, list) and seeds and all(isinstance(s, int) and not isinstance(s, bool) for s in seeds), "Explicit integer expected_seeds required")
    require(len(set(seeds)) == len(seeds), "Duplicate expected seed")
    if stage == "confirmation":
        require(seeds == [42, 43, 44, 45, 46], "Confirmation must contain all five frozen seeds in order")
    if stage in ["fixed_mechanism", "original"]:
        require(seeds == [42, 43, 44], "Fixed/original comparison requires the three frozen seeds")
    query_ids = data.get("expected_query_ids")
    require(isinstance(query_ids, list) and query_ids and all(isinstance(q, str) and q for q in query_ids), "Explicit nonempty string expected_query_ids required")
    require(len(set(query_ids)) == len(query_ids), "Duplicate expected query ID")
    metrics = data.get("metrics")
    require(isinstance(metrics, list) and metrics and len(set(metrics)) == len(metrics) and all(isinstance(m, str) and m for m in metrics), "Explicit unique metric names required")
    group_map = data.get("query_groups")
    require(isinstance(group_map, dict), "Explicit query_groups required; use one group per query only when justified before results")
    require(set(group_map) == set(query_ids), "Group map must cover exactly expected query IDs")
    require(all(isinstance(value, str) and value for value in group_map.values()), "Groups must have nonempty string IDs")
    contrasts = data.get("contrasts")
    require(isinstance(contrasts, list) and contrasts, "At least one contrast required")
    methods, contrast_ids = set(), set()
    for contrast in contrasts:
        require(isinstance(contrast, dict), "Invalid contrast")
        contrast_id = contrast.get("contrast_id")
        require(isinstance(contrast_id, str) and contrast_id and contrast_id not in contrast_ids, "Unique contrast_id required")
        contrast_ids.add(contrast_id)
        coefficients = contrast.get("coefficients")
        require(isinstance(coefficients, dict) and len(coefficients) >= 2, "Contrast must have >=2 method coefficients")
        coefficients = {method: numeric(coef, "coefficient") for method, coef in coefficients.items()}
        require(all(isinstance(method, str) and method and coef != 0 for method, coef in coefficients.items()), "Invalid method/coefficient")
        require(abs(math.fsum(coefficients.values())) <= 1e-12, "Contrast coefficients must sum to zero")
        contrast["coefficients"] = coefficients
        methods.update(coefficients)
    raw_records = data.get("records")
    require(isinstance(raw_records, list), "records must be a list")
    table = defaultdict(dict)
    query_set, seed_set, metric_set = set(query_ids), set(seeds), set(metrics)
    for row in raw_records:
        require(isinstance(row, dict), "Invalid score record")
        method, seed, qid = row.get("method"), row.get("seed"), row.get("query_id")
        require(method in methods and seed in seed_set and qid in query_set, f"Unexpected method/seed/query: {(method, seed, qid)}")
        require(isinstance(seed, int) and not isinstance(seed, bool), "Record seed must be an integer")
        values = row.get("metrics", {row.get("metric"): row.get("value")})
        require(isinstance(values, dict) and values, "Missing per-query metrics")
        require(set(values).issubset(metric_set), "Unexpected metric in record")
        key = (method, seed, qid)
        for metric, value in values.items():
            require(metric not in table[key], f"Duplicate aligned score {key}/{metric}")
            score = numeric(value, f"score {key}/{metric}")
            require(0 <= score <= 1, f"Retrieval score must be in [0,1]: {key}/{metric}")
            table[key][metric] = score
    missing = []
    for method in sorted(methods):
        for seed in seeds:
            for qid in query_ids:
                key = (method, seed, qid)
                if key not in table or set(table[key]) != metric_set:
                    missing.append(key)
    require(not missing, f"Incomplete paired input: {len(missing)} method/seed/query rows missing metrics; examples {missing[:5]}")
    return table, query_ids, seeds, metrics, group_map, contrasts


def analyze(data):
    records, query_ids, seeds, metrics, group_map, contrasts = normalize_input(data)
    config = {"replicates": 5000, "query_seed": 2026111201, "cluster_seed": 2026111202,
              "engine": "stdlib", "batch_size": 128, "confidence_level": .95, **data.get("bootstrap", {})}
    require(config["replicates"] == 5000 or data.get("fixture_only") is True, "Scientific runs require 5000 bootstrap repetitions")
    group_ids = [group_map[qid] for qid in query_ids]
    results = []
    for contrast in contrasts:
        for metric in metrics:
            per_seed, differences = paired_difference(records, query_ids, seeds, contrast["coefficients"], metric)
            seed_effects = [math.fsum(per_seed[seed]) / len(query_ids) for seed in seeds]
            common = {"replicates": config["replicates"], "engine": config["engine"],
                      "batch_size": config["batch_size"], "confidence_level": config["confidence_level"]}
            query_bs = bootstrap(differences, seed=config["query_seed"], **common)
            cluster_bs = bootstrap(differences, group_ids, seed=config["cluster_seed"], **common)
            results.append({
                "contrast_id": contrast["contrast_id"], "coefficients": contrast["coefficients"], "metric": metric,
                "n_queries": len(query_ids), "n_groups": len(set(group_ids)), "seeds": seeds,
                "per_seed_effects": [{"seed": seed, "effect": value} for seed, value in zip(seeds, seed_effects)],
                "mean_paired_effect": math.fsum(seed_effects) / len(seed_effects),
                "sample_sd_across_seed_effects": statistics.stdev(seed_effects) if len(seed_effects) > 1 else None,
                "positive_seed_count": sum(value > 0 for value in seed_effects),
                "negative_seed_count": sum(value < 0 for value in seed_effects),
                "zero_seed_count": sum(value == 0 for value in seed_effects),
                "per_query_seed_mean_effect": dict(zip(query_ids, differences)),
                "paired_query_bootstrap": query_bs, "paired_query_weighted_cluster_bootstrap": cluster_bs,
                "primary_uncertainty": "paired_query_weighted_cluster_bootstrap",
                "query_bootstrap_role": "sensitivity only when queries share dependence groups",
                "interval_multiplicity": "pointwise; not simultaneous familywise 95% coverage",
                "p_value": None, "p_value_policy": "No hypothesis test implemented or inferred from intervals.",
            })
    methods = sorted({method for contrast in contrasts for method in contrast["coefficients"]})
    method_summary = []
    for method in methods:
        for metric in metrics:
            values = [math.fsum(records[(method, seed, qid)][metric] for qid in query_ids) / len(query_ids) for seed in seeds]
            method_summary.append({"method": method, "metric": metric,
                                   "per_seed": [{"seed": seed, "value": value} for seed, value in zip(seeds, values)],
                                   "mean": math.fsum(values) / len(values),
                                   "sample_sd": statistics.stdev(values) if len(values) > 1 else None})
    return {"schema_version": "1.0.0", "evidence_stage": data["evidence_stage"], "status": "computed",
            "dataset": data.get("dataset"), "n_queries": len(query_ids), "n_groups": len(set(group_ids)),
            "expected_seeds": seeds, "bootstrap_configuration": config, "method_summary": method_summary,
            "contrasts": results, "alignment": {"passed": True, "query_weighting": "macro_equal_query", "missing_rows": 0},
            "assumptions": ["Group construction was frozen before results; it remains a dependence proxy.",
                            "Bootstrap intervals condition on fitted seeds and fixed labels; seed SD is reported separately.",
                            "No seed-by-query independence assumption and no independent arm resampling.",
                            "A narrow conditional interval does not establish broad training or external validity."]}


def self_test():
    # Unequal group sizes distinguish query-weighted from group-equal estimates.
    values, groups = [0., 1., 1., 1.], ["small", "large", "large", "large"]
    bs = bootstrap(values, groups, replicates=100, seed=7)
    require(set(bs["replicate_n_rows"]) == {2, 4, 6}, "Cluster rows were not carried together")
    require(set(bs["replicate_estimates"]) == {0., .75, 1.}, "Cluster bootstrap is not query weighted")
    require(bs == bootstrap(values, groups, replicates=100, seed=7), "Bootstrap not deterministic")
    single = bootstrap([.2, .4], ["g", "g"], replicates=10)
    require(single["percentile_interval"] is None and single["interval_status"] == "unavailable_single_unit", "Single cluster falsely supports inference")
    seeds, qids = [42, 43, 44], ["q1", "q2"]
    method_values = {"B_UNIQUE": [.8, .6], "B_ID": [.4, .2], "R_UNIQUE": [.7, .5], "R_ID": [.6, .4]}
    data = {"evidence_stage": "fixed_mechanism", "expected_seeds": seeds, "expected_query_ids": qids,
            "query_groups": {"q1": "g1", "q2": "g2"}, "metrics": ["recall@5", "mrr@10"],
            "contrasts": [{"contrast_id": "interaction", "coefficients": {"B_UNIQUE": 1, "B_ID": -1, "R_UNIQUE": -1, "R_ID": 1}}],
            "records": [{"method": method, "seed": seed, "query_id": qid, "metrics": {"recall@5": values[i], "mrr@10": values[i] / 2}}
                        for method, values in method_values.items() for seed in seeds for i, qid in enumerate(qids)],
            "fixture_only": True, "bootstrap": {"replicates": 20}}
    result = analyze(data)
    require(abs(result["contrasts"][0]["mean_paired_effect"] - .3) < 1e-12, "Factorial contrast incorrect")
    require(abs(result["contrasts"][1]["mean_paired_effect"] - .15) < 1e-12, "Multiple metrics not handled")
    for mode in ["missing", "duplicate", "nan", "missing_group", "missing_seed"]:
        bad = json.loads(json.dumps(data))
        if mode == "missing":
            bad["records"].pop()
        elif mode == "duplicate":
            bad["records"].append(bad["records"][0])
        elif mode == "nan":
            bad["records"][0]["metrics"]["mrr@10"] = float("nan")
        elif mode == "missing_group":
            bad["query_groups"].pop("q1")
        else:
            bad["evidence_stage"] = "confirmation"
        try:
            analyze(bad)
            raise AssertionError(f"Invalid {mode} accepted")
        except ValueError:
            pass
    np_check = "not_installed"
    try:
        import numpy  # noqa: F401
        np_bs = bootstrap(values=[0., 1., 1., 1.], group_ids=groups, replicates=100, seed=7, engine="numpy", batch_size=7)
        require(set(np_bs["replicate_estimates"]) == {0., .75, 1.}, "Numpy query weighting incorrect")
        np_other = bootstrap(values=[0., 1., 1., 1.], group_ids=groups, replicates=100, seed=7, engine="numpy", batch_size=31)
        require(np_bs["replicate_estimates"] == np_other["replicate_estimates"] and np_bs["replicate_n_rows"] == np_other["replicate_n_rows"], "Numpy batch size changed draw stream")
        np_check = "passed_weighting_and_batch_invariance"
    except ImportError:
        pass
    return {"passed": True, "numpy_check": np_check,
            "checks": ["unequal_cluster_query_weighting", "deterministic", "single_cluster", "factorial_interaction", "multiple_metrics", "missing", "duplicate", "nonfinite", "missing_group", "five_seed_gate"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2))
        return
    require(args.input is not None and args.output is not None, "--input and --output required")
    data = json.loads(args.input.read_text(encoding="utf-8-sig"))
    result = analyze(data)
    result["input_file"] = {"path": str(args.input.resolve()), "sha256": sha256(args.input)}
    result["code_sha256"] = sha256(__file__)
    result["created_at_utc"] = datetime.now(timezone.utc).isoformat()
    require(not args.output.exists(), f"Refusing to overwrite statistics output {args.output}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": "computed", "contrasts": len(result["contrasts"]), "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError) as exc:
        print(f"STATISTICS_REJECTED: {exc}", file=sys.stderr)
        raise SystemExit(2)
