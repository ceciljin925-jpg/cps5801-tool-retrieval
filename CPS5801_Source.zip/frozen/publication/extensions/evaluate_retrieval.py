"""Float32 exact pooled/native-menu retrieval with independently recoverable ranks.

Config required: run_id,family(e5/bge/qwen_reference/bm25),queries_path,corpus_path;
neural families also model_path. Optional task_type=pooled/menu,batch_size=32,
query_block_size=32,save_embeddings=True,latency_count=1000,latency_warmups=5.
External evaluations require a matching, hashed final-lock evaluation entry.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import pathlib
import re
import time
import traceback

from encoders import (Encoder, directory_manifest, dump, ensure_output, now, preserve_rng_and_mode,
                      read, runtime_record, setup_runtime, sha_file, sha_json, sync, np, torch)


def row_metrics(ranks, candidate_count):
    if not ranks or len(set(ranks)) != len(ranks) or any(r < 1 or r > candidate_count for r in ranks):
        raise ValueError('Invalid positive ranks')
    ranks = sorted(ranks)
    n = len(ranks)
    metrics = {}
    for k in (1, 3, 5, 10, 20, 50):
        found = sum(r <= k for r in ranks)
        metrics[f'recall@{k}'] = found / n
        metrics[f'coverage@{k}'] = found / n
        metrics[f'hit@{k}'] = float(found > 0)
        metrics[f'complete@{k}'] = float(found == n)
    metrics['mrr@10'] = 1 / ranks[0] if ranks[0] <= 10 else 0.0
    metrics['mrr'] = 1 / ranks[0]
    metrics['average_precision'] = sum(i / rank for i, rank in enumerate(ranks, 1)) / n
    metrics['mean_positive_rank'] = float(np.mean(ranks))
    return metrics


def stable_full_sort(scores, tie_order=None):
    scores = np.asarray(scores, dtype=np.float32)
    if scores.ndim != 1 or not np.isfinite(scores).all():
        raise ValueError('Expected finite 1D float32 scores')
    if tie_order is None:
        tie_order = np.arange(len(scores), dtype=np.int64)
    return tie_order[np.argsort(-scores[tie_order], kind='stable')]


def rank_scores(scores, corpus_ids, positives, candidate_ids=None, tie_break_keys=None, top_k=50, id_to_index=None):
    """Order by descending float32 score, then frozen explicit tie key or ID."""
    scores = np.asarray(scores, dtype=np.float32)
    if scores.shape != (len(corpus_ids),) or not np.isfinite(scores).all():
        raise ValueError('Wrong score shape or nonfinite score')
    mapping = id_to_index if id_to_index is not None else {tid: i for i, tid in enumerate(corpus_ids)}
    candidate_ids = corpus_ids if candidate_ids is None else candidate_ids
    if not candidate_ids or len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError('Empty/duplicate candidate IDs')
    if not set(positives) <= set(candidate_ids) or not positives or len(positives) != len(set(positives)):
        raise ValueError('Missing, duplicate, or out-of-menu positives')
    if not set(candidate_ids) <= mapping.keys():
        raise ValueError('Missing candidate mapping')
    indices = np.array([mapping[tid] for tid in candidate_ids], dtype=np.int64)
    if tie_break_keys is None:
        keys = list(candidate_ids)
    else:
        if set(candidate_ids) != set(tie_break_keys):
            raise ValueError('Tie-break map must cover exactly candidate menu')
        keys = [tie_break_keys[tid] for tid in candidate_ids]
        if len(set(keys)) != len(keys):
            raise ValueError('Tie keys collide')
    tie_order = np.argsort(np.asarray(keys), kind='stable')
    order = stable_full_sort(scores[indices], tie_order)
    ranked_indices = indices[order]
    ranked = [corpus_ids[i] for i in ranked_indices]
    positions = {tid: i + 1 for i, tid in enumerate(ranked)}
    positives_out = [{'id': tid, 'rank': positions[tid], 'score': float(scores[mapping[tid]])} for tid in positives]
    return {'top50': ranked[:top_k], 'scores': scores[ranked_indices[:top_k]].tolist(),
            'positive_ranks': positives_out, 'candidate_count': len(candidate_ids),
            **row_metrics([x['rank'] for x in positives_out], len(candidate_ids))}


def prepare_rank_context(corpus_ids, candidate_ids=None, tie_break_keys=None, id_to_index=None):
    """Prepare immutable ID/tie maps once; no scores or labels are inspected."""
    mapping = id_to_index if id_to_index is not None else {tid: i for i, tid in enumerate(corpus_ids)}
    if len(mapping) != len(corpus_ids):
        raise ValueError('Duplicate corpus IDs')
    candidate_ids = list(corpus_ids if candidate_ids is None else candidate_ids)
    if not candidate_ids or len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError('Empty/duplicate candidate menu')
    if not set(candidate_ids) <= mapping.keys():
        raise ValueError('Unmapped candidate ID')
    if tie_break_keys is None:
        keys = candidate_ids
    else:
        if set(tie_break_keys) != set(candidate_ids):
            raise ValueError('Tie keys must cover exact candidate menu')
        keys = [tie_break_keys[tid] for tid in candidate_ids]
        if len(set(keys)) != len(keys):
            raise ValueError('Duplicate tie key')
    return {'corpus_size': len(corpus_ids), 'candidate_ids': candidate_ids,
            'indices': np.asarray([mapping[tid] for tid in candidate_ids], dtype=np.int64),
            'local_index': {tid: i for i, tid in enumerate(candidate_ids)},
            'tie_order': np.argsort(np.asarray(keys), kind='stable')}


def rank_with_context(scores, positives, context, top_k=50, return_order=False):
    """One float32 full sort; inverse integer ranks avoid per-query ID dictionaries."""
    scores = np.asarray(scores, dtype=np.float32)
    if scores.shape != (context['corpus_size'],) or not np.isfinite(scores).all():
        raise ValueError('Wrong score shape or nonfinite score')
    if not positives or len(positives) != len(set(positives)) or not set(positives) <= context['local_index'].keys():
        raise ValueError('Empty, duplicate, or out-of-menu positives')
    local_scores = scores[context['indices']]
    ordered = stable_full_sort(local_scores, context['tie_order'])
    inverse_ranks = np.empty(len(ordered), dtype=np.int64)
    inverse_ranks[ordered] = np.arange(1, len(ordered) + 1, dtype=np.int64)
    top_order = ordered[:top_k]
    positive_rows = [{'id': tid, 'rank': int(inverse_ranks[context['local_index'][tid]]),
                      'score': float(local_scores[context['local_index'][tid]])} for tid in positives]
    result = {'top50': [context['candidate_ids'][i] for i in top_order], 'scores': local_scores[top_order].tolist(),
              'positive_ranks': positive_rows, 'candidate_count': len(ordered),
              **row_metrics([row['rank'] for row in positive_rows], len(ordered))}
    return (result, context['indices'][ordered]) if return_order else result


class BM25:
    """Original positive Robertson IDF, k1=1.5,b=.75, float32 sparse matrix."""
    def __init__(self, texts, k1=1.5, b=0.75):
        from scipy.sparse import csc_matrix
        self.vocab = {}
        rows, cols, values, lengths = [], [], [], []
        for i, text in enumerate(texts):
            counts = collections.Counter(re.findall(r'[a-z0-9]+', text.lower()))
            lengths.append(sum(counts.values()))
            for word, count in counts.items():
                j = self.vocab.setdefault(word, len(self.vocab))
                rows.append(i)
                cols.append(j)
                values.append(count)
        mat = csc_matrix((np.array(values, dtype=np.float32), (rows, cols)), shape=(len(texts), len(self.vocab)))
        df = np.diff(mat.indptr)
        idf = np.log1p((len(texts) - df + 0.5) / (df + 0.5))
        lengths = np.asarray(lengths)
        average = lengths.mean()
        if average == 0:
            raise ValueError('Empty BM25 vocabulary')
        for j in range(mat.shape[1]):
            a, z = mat.indptr[j:j + 2]
            tf = mat.data[a:z]
            dl = lengths[mat.indices[a:z]]
            mat.data[a:z] = idf[j] * tf * (k1 + 1) / (tf + k1 * (1 - b + b * dl / average))
        self.mat = mat

    def query_columns(self, query):
        # Canonical summation order removes process-hash-salt variation while
        # preserving the authorized float32 weights, IDF and scoring formula.
        return sorted({self.vocab[word] for word in re.findall(r'[a-z0-9]+', query.lower()) if word in self.vocab})

    def scores_from_columns(self, columns):
        return np.asarray(self.mat[:, columns].sum(axis=1)).ravel().astype(np.float32)

    def scores(self, query):
        return self.scores_from_columns(self.query_columns(query))


def validate_data(queries, corpus, task_type, allowed_empty_query_ids=()):
    if not queries or not corpus:
        raise ValueError('Queries and corpus must be nonempty')
    qids, cids = [q['id'] for q in queries], [d['id'] for d in corpus]
    if len(set(qids)) != len(qids) or len(set(cids)) != len(cids):
        raise ValueError('Duplicate query or corpus IDs')
    for doc in corpus:
        if not isinstance(doc['text'], str) or not doc['text'].strip():
            raise ValueError('Empty/nonstring document text')
    empty_ids = {query['id'] for query in queries if isinstance(query['query'], str) and not query['query'].strip()}
    if empty_ids != set(allowed_empty_query_ids):
        raise ValueError(f'Actual empty query IDs differ from explicitly frozen allow-list: {sorted(empty_ids)}')
    for query in queries:
        if not isinstance(query['query'], str):
            raise ValueError('Nonstring query text')
        if not query['positives'] or len(query['positives']) != len(set(query['positives'])):
            raise ValueError('Empty/duplicate positives')
        candidates = query['candidate_ids'] if task_type == 'menu' else cids
        if not set(query['positives']) <= set(candidates) or not set(candidates) <= set(cids):
            raise ValueError('Candidate/positive mapping conflict')
        if task_type == 'menu' and 'candidate_tie_break_keys' not in query:
            raise ValueError('Native-menu evaluation requires frozen tie-break keys')
    return qids, cids


def final_access_gate(config, output, model_manifest):
    if not config.get('external_final'):
        return
    lock_path = pathlib.Path(config['final_lock_path']).resolve(strict=True)
    lock = read(lock_path)
    matches = [x for x in lock['evaluations'] if x['evaluation_id'] == config['evaluation_id']]
    if len(matches) != 1:
        raise ValueError('Evaluation ID missing/duplicated in final lock')
    expected = {'run_id': config['run_id'], 'checkpoint_manifest_sha256': sha_json(model_manifest),
                'queries_sha256': sha_file(config['queries_path']), 'corpus_sha256': sha_file(config['corpus_path'])}
    for key, value in expected.items():
        if matches[0].get(key) != value:
            raise ValueError(f'Final lock mismatch: {key}')
    log_path = ensure_output(config['access_log_path'])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    record = {'time': now(), 'event': 'external_final_opened', 'evaluation_id': config['evaluation_id'],
              'lock_sha256': sha_file(lock_path), 'attempt_output': str(output), **expected}
    with log_path.open('a', encoding='utf-8') as stream:
        stream.write(__import__('json').dumps(record) + '\n')
        stream.flush()
    marker = log_path.parent / 'EXTERNAL_FINAL_OPENED.json'
    if not marker.exists():
        dump(marker, record)


def evaluate(config, output):
    for key in ('run_id', 'family', 'queries_path', 'corpus_path'):
        if key not in config:
            raise ValueError(f'Missing config field {key}')
    task_type = config.get('task_type', 'pooled')
    if task_type not in ('pooled', 'menu'):
        raise ValueError('task_type must be pooled or menu')
    out = ensure_output(output)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Evaluation attempt already exists; preserve it and use a new attempt')
    corpus, queries = read(config['corpus_path']), read(config['queries_path'])
    query_ids, corpus_ids = validate_data(queries, corpus, task_type, config.get('allowed_empty_query_ids', []))
    model_manifest = directory_manifest(config['model_path']) if config['family'] != 'bm25' else {'family': 'bm25', 'code_sha256': sha_file(__file__)}
    final_access_gate(config, out, model_manifest)
    out.mkdir(parents=True, exist_ok=True)
    dump(out / 'config.json', config)
    dump(out / 'status.json', {'status': 'running', 'started_at': now()})
    device = config.get('device', 'cuda')
    setup_runtime(device)
    dump(out / 'environment.json', runtime_record())
    started = time.perf_counter()
    index_seconds, query_seconds, search_seconds = 0.0, 0.0, 0.0
    encoder, doc_gpu, query_emb, bm25, menu_bm25 = None, None, None, None, {}
    try:
        if config['family'] == 'bm25':
            index_started = time.perf_counter()
            if task_type == 'pooled':
                bm25 = BM25([d['text'] for d in corpus])
            else:
                # Native menus get native-menu IDF, never an artificial global corpus.
                docs = {d['id']: d['text'] for d in corpus}
                for query in queries:
                    menu_bm25[query['id']] = BM25([docs[tid] for tid in query['candidate_ids']])
            index_seconds = time.perf_counter() - index_started
        else:
            if device.startswith('cuda'):
                torch.cuda.reset_peak_memory_stats()
            encoder = Encoder(config['family'], config['model_path'], device)
            doc_emb, doc_stats = encoder.encode([d['text'] for d in corpus], 'document', config.get('batch_size', 32), True)
            query_emb, query_stats = encoder.encode([q['query'] for q in queries], 'query', config.get('batch_size', 32), True)
            index_seconds, query_seconds = doc_stats['encoding_seconds'], query_stats['encoding_seconds']
            dump(out / 'tokenization.json', {'document': doc_stats, 'query': query_stats})
            mappings = {'corpus_ids': corpus_ids, 'query_ids': query_ids,
                        'query_text_sha256': [hashlib.sha256(q['query'].encode()).hexdigest() for q in queries],
                        'corpus_text_sha256': [hashlib.sha256(d['text'].encode()).hexdigest() for d in corpus],
                        'model_manifest_sha256': sha_json(model_manifest), 'queries_file_sha256': sha_file(config['queries_path']),
                        'corpus_file_sha256': sha_file(config['corpus_path']), 'dtype': 'float32', 'normalized': True}
            dump(out / 'embedding_mapping.json', mappings)
            if config.get('save_embeddings', True):
                np.save(out / 'corpus_embeddings.npy', doc_emb, allow_pickle=False)
                np.save(out / 'query_embeddings.npy', query_emb, allow_pickle=False)
                dump(out / 'embedding_manifest.json', {name: {'bytes': (out / name).stat().st_size, 'sha256': sha_file(out / name)}
                                                       for name in ('corpus_embeddings.npy', 'query_embeddings.npy', 'embedding_mapping.json')})
            doc_gpu = torch.from_numpy(doc_emb).to(device)
        rows = []
        mapping = {tid: i for i, tid in enumerate(corpus_ids)}
        equivalence_keys = {doc['id']: doc.get('document_equivalence_key', hashlib.sha256(doc['text'].encode()).hexdigest()) for doc in corpus}
        if task_type == 'pooled':
            pooled_context = prepare_rank_context(corpus_ids, id_to_index=mapping)
            menu_contexts = None
        else:
            pooled_context = None
            menu_contexts = {q['id']: prepare_rank_context(corpus_ids, q['candidate_ids'], q['candidate_tie_break_keys'], mapping) for q in queries}
        block_size = config.get('query_block_size', 32)
        if not isinstance(block_size, int) or block_size < 1:
            raise ValueError('query_block_size must be positive')
        search_started = time.perf_counter()
        with torch.inference_mode():
            for offset in range(0, len(queries), block_size):
                if encoder:
                    score_block = (torch.from_numpy(query_emb[offset:offset + block_size]).to(device) @ doc_gpu.T).cpu().numpy()
                else:
                    score_block = []
                    for query in queries[offset:offset + block_size]:
                        if task_type == 'menu':
                            scores = np.zeros(len(corpus_ids), dtype=np.float32)
                            scores[[mapping[tid] for tid in query['candidate_ids']]] = menu_bm25[query['id']].scores(query['query'])
                        else:
                            scores = bm25.scores(query['query'])
                        score_block.append(scores)
                for local, query in enumerate(queries[offset:offset + block_size]):
                    candidates = query.get('candidate_ids') if task_type == 'menu' else None
                    context = menu_contexts[query['id']] if task_type == 'menu' else pooled_context
                    ranked, full_order = rank_with_context(score_block[local], query['positives'], context,
                                                          len(candidates) if task_type == 'menu' else 50, return_order=True)
                    row = {'id': query['id'], 'positives': query['positives'], 'query_text_sha256': hashlib.sha256(query['query'].encode()).hexdigest(), **ranked}
                    for key in ('group_id', 'track', 'role', 'source_id', 'task_id'):
                        if key in query:
                            row[key] = query[key]
                    if task_type == 'menu':
                        row['ranking'] = row['top50']
                    if config.get('document_equivalence_sensitivity') or 'equivalent_positives' in query:
                        if task_type != 'pooled':
                            raise ValueError('Document-equivalence stress sensitivity is defined for pooled evaluation')
                        seen, collapsed = set(), []
                        for index in full_order:
                            key = equivalence_keys[corpus_ids[index]]
                            if key not in seen:
                                seen.add(key)
                                collapsed.append(key)
                        gold_classes = {equivalence_keys[tid] for tid in query['positives']}
                        class_rank = {key: rank for rank, key in enumerate(collapsed, 1)}
                        sensitive_ranks = [class_rank[key] for key in sorted(gold_classes)]
                        row['equivalence_sensitivity'] = {
                            'definition': 'collapse ranked IDs by exact canonical document key, keeping first occurrence; gold denominator is unique gold document classes',
                            'gold_document_classes': sorted(gold_classes), 'positive_class_ranks': sensitive_ranks,
                            'candidate_document_classes': len(collapsed), **row_metrics(sensitive_ranks, len(collapsed))}
                    rows.append(row)
                if offset and offset % (block_size * 25) == 0:
                    print('scored', offset, '/', len(queries), flush=True)
        sync(device)
        search_seconds = time.perf_counter() - search_started
        dump(out / 'predictions.json', rows)
        metrics = {key: float(np.mean([row[key] for row in rows])) for key in row_metrics([1], 1)}
        latency_ids = config.get('latency_query_ids')
        if latency_ids is None:
            selected = sorted(queries, key=lambda q: hashlib.sha256(('publication_v1|latency|' + q['id']).encode()).hexdigest())
            selected = selected[:min(config.get('latency_count', 1000), len(selected))]
        else:
            qm = {q['id']: q for q in queries}
            selected = [qm[qid] for qid in latency_ids]
        latencies = []
        warmups = config.get('latency_warmups', 5)
        if selected:
            with preserve_rng_and_mode(encoder.model if encoder else None):
                if encoder:
                    encoder.model.eval()
                with torch.inference_mode():
                    for iteration in range(len(selected) + warmups):
                        query = selected[iteration % len(selected)]
                        sync(device)
                        tick = time.perf_counter()
                        if encoder:
                            ts = encoder.tokenizer(encoder.format(query['query'], 'query'), truncation=True, max_length=128, return_tensors='pt').to(device)
                            q = encoder.pool(ts)
                            if task_type == 'menu':
                                candidates_gpu = doc_gpu[[mapping[tid] for tid in query['candidate_ids']]]
                                torch.topk(q @ candidates_gpu.T, min(50, len(query['candidate_ids'])))
                            else:
                                torch.topk(q @ doc_gpu.T, min(50, len(corpus_ids)))
                        else:
                            scores = menu_bm25[query['id']].scores(query['query']) if task_type == 'menu' else bm25.scores(query['query'])
                            np.argsort(-scores, kind='stable')[:50]
                        sync(device)
                        elapsed_ms = (time.perf_counter() - tick) * 1000
                        if iteration >= warmups:
                            latencies.append({'id': query['id'], 'ms': elapsed_ms})
        dump(out / 'latency_ms.json', latencies)
        report = {'run_id': config['run_id'], 'family': config['family'], 'task_type': task_type, 'n': len(rows),
                  'candidate_tools': len(corpus), 'metrics': metrics, 'index_seconds': index_seconds,
                  'query_encoding_seconds': query_seconds, 'search_and_ranking_seconds': search_seconds,
                  'total_evaluation_seconds': time.perf_counter() - started,
                  'peak_eval_allocated_GiB': torch.cuda.max_memory_allocated() / 2**30 if device.startswith('cuda') else 0,
                  'latency_ms_median': float(np.median([r['ms'] for r in latencies])) if latencies else None,
                  'latency_ms_p95': float(np.percentile([r['ms'] for r in latencies], 95)) if latencies else None,
                  'latency_boundary': 'batch1 tokenize+encode+exact-score+top50; BM25 tokenize+score+stable-sort; native-menu candidates only',
                  'latency_warmups': warmups, 'latency_count': len(latencies),
                  'tie_break': 'frozen per-menu SHA256 keys' if task_type == 'menu' else 'corpus ID ascending',
                  'input_hashes': {'queries': sha_file(config['queries_path']), 'corpus': sha_file(config['corpus_path'])},
                  'model_manifest_sha256': sha_json(model_manifest), 'evaluation_code_sha256': sha_file(__file__), 'finished_at': now()}
        if all('equivalence_sensitivity' in row for row in rows):
            report['equivalence_sensitivity_metrics'] = {key: float(np.mean([row['equivalence_sensitivity'][key] for row in rows])) for key in row_metrics([1], 1)}
        dump(out / 'metrics.json', report)
        dump(out / 'status.json', {'status': 'completed', 'completed_at': now(), 'query_count': len(rows)})
        return report
    except Exception as error:
        dump(out / 'status.json', {'status': 'failed', 'failed_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=pathlib.Path)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    args = parser.parse_args()
    evaluate(read(args.config), args.output)


if __name__ == '__main__':
    main()
