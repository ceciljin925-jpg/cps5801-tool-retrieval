"""Deterministic development selection for CPS5801 publication_v1.

Input: a list of runs, or {"runs": list-or-dict}. Each run has run_id,
stage/family/policy/seed/lr/temperature in the row or a nested config (which may
also be a JSON path), status, and dev_evaluations=[{steps,metrics}] where metrics
contains recall@5 and mrr@10. metrics_path is accepted instead of metrics.
One checkpoint per row is also accepted, with steps and dev_metrics/metrics.
Paths are resolved against the registry directory. Failed trajectories must
have an explicit failure_reason/error/reason; their unsaved grid cells remain
failed and cannot win. Pending or silently missing cells prevent selection.
Multiple authoritative attempts for the same cell are rejected, never ranked.

Only original development scores are accepted. This program does not load test
predictions. S4 requires the immutable S2 selection file to bind the extension.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from functools import cmp_to_key
import hashlib
import json
import math
from pathlib import Path
import sys

POLICIES = ["R_ID", "B_ID", "R_UNIQUE", "B_UNIQUE", "MIXED_2R2B", "DENSE_STATIC"]
EXTENSION_ORDER = ["B_UNIQUE", "MIXED_2R2B", "DENSE_STATIC", "R_UNIQUE"]
LRS = [1e-5, 2e-5]
TEMPERATURES = [0.01, 0.05]
STEPS = [312, 625, 1250]
TIE_TOLERANCE = 1e-12


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def resolve_json(value, base, sources):
    if isinstance(value, (str, Path)):
        path = Path(value)
        path = path if path.is_absolute() else base / path
        path = path.resolve()
        sources[str(path)] = sha256(path)
        return read_json(path)
    return value


def number(value, label):
    require(not isinstance(value, bool), f"{label}: boolean is not a number")
    result = float(value)
    require(math.isfinite(result), f"{label}: non-finite value")
    return result


def metric_pair(value):
    require(isinstance(value, dict), "metrics must be an object")
    if "metrics" in value and "recall@5" not in value:
        value = value["metrics"]
    result = {}
    for name in ["recall@5", "mrr@10"]:
        require(name in value, f"Missing selection metric {name}")
        result[name] = number(value[name], name)
        require(0 <= result[name] <= 1, f"{name} must use [0,1] units, not percent")
    return result


def compare_metric(a, b, name):
    delta = a["metrics"][name] - b["metrics"][name]
    return 0 if abs(delta) <= TIE_TOLERANCE else (-1 if delta > 0 else 1)


def compare_configs(a, b):
    for name in ["recall@5", "mrr@10"]:
        result = compare_metric(a, b, name)
        if result:
            return result
    ka = (a["steps"], a["lr"], 0 if a["temperature"] == 0.05 else 1)
    kb = (b["steps"], b["lr"], 0 if b["temperature"] == 0.05 else 1)
    return (ka > kb) - (ka < kb)


def compare_policies(a, b):
    # Between policies, an R@5 tie goes directly to the frozen policy order.
    # MRR and configuration-cost tie breaks select a configuration WITHIN a
    # policy; they do not create a second policy-selection opportunity.
    result = compare_metric(a, b, "recall@5")
    if result:
        return result
    ka, kb = EXTENSION_ORDER.index(a["policy"]), EXTENSION_ORDER.index(b["policy"])
    return (ka > kb) - (ka < kb)


def get_runs(registry):
    runs = registry.get("runs", registry) if isinstance(registry, dict) else registry
    require(isinstance(runs, (list, dict)), "registry must contain a list or map of runs")
    if isinstance(runs, dict):
        result = []
        for run_id, value in runs.items():
            require(isinstance(value, dict), f"Invalid run {run_id}")
            result.append({"run_id": run_id, **value})
        return result
    return runs


def select(registry, stage, base=Path("."), s2_lock=None):
    require(stage in ["S2", "S4"], "Only S2 and S4 are selection stages")
    sources = {}
    if stage == "S4":
        require(isinstance(s2_lock, dict), "S4 requires S2 lock")
        require(s2_lock.get("stage") == "S2" and s2_lock.get("status") == "selected", "Invalid S2 lock")
        extension = s2_lock["selected_extension"]["policy"]
        require(extension in EXTENSION_ORDER, "Invalid S2 extension")
        policies = ["R_ID", "B_ID", extension]
    else:
        policies = POLICIES
    family = "e5" if stage == "S2" else "bge"
    cells, observed_trajectories = {}, set()
    for row in get_runs(registry):
        require(isinstance(row, dict), "Each run must be an object")
        config = resolve_json(row.get("config", row.get("config_path", {})), base, sources)
        require(isinstance(config, dict), "Run config must be an object")
        merged = {**config, **row}
        if merged.get("stage") != stage:
            continue
        require(merged.get("family") == family, "Unexpected family in selection stage")
        policy = merged.get("policy")
        if policy == "SELECTED_EXTENSION" and stage == "S4":
            policy = extension
        require(policy in policies, f"Unexpected policy {policy} in {stage}")
        require(merged.get("seed") == 41, "Screening must use seed 41 only")
        for forbidden_field in ["split", "evaluation_split", "selection_split"]:
            if forbidden_field in merged:
                require(merged[forbidden_field] in ["dev", "development", "original_dev"], "Selection input is not original development")
        lr = number(merged.get("lr", merged.get("learning_rate")), "lr")
        temperature = number(merged.get("temperature"), "temperature")
        require(lr in LRS and temperature in TEMPERATURES, "Configuration outside frozen grid")
        run_id = str(merged.get("run_id", ""))
        require(bool(run_id), "Missing run_id")
        require(merged.get("status") in ["completed", "failed", "reused"],
                f"Run {run_id} is not terminal; cannot lock a pending/running trajectory")
        trajectory = (policy, lr, temperature)
        observed_trajectories.add(trajectory)
        evaluations = merged.get("dev_evaluations", merged.get("development_evaluations"))
        if evaluations is None:
            evaluations = [{"steps": merged.get("steps", merged.get("optimizer_updates")),
                            "metrics": merged.get("dev_metrics", merged.get("metrics")),
                            "metrics_path": merged.get("dev_metrics_path", merged.get("metrics_path"))}]
        require(isinstance(evaluations, list), "dev_evaluations must be a list")
        present_steps = set()
        for evaluation in evaluations:
            require(isinstance(evaluation, dict), "Invalid checkpoint evaluation")
            raw_metrics = evaluation.get("metrics", evaluation.get("dev_metrics"))
            if raw_metrics is None:
                raw_metrics = evaluation.get("metrics_path")
            if raw_metrics is None:
                continue
            for name in ["split", "evaluation_split"]:
                if name in evaluation:
                    require(evaluation[name] in ["dev", "development", "original_dev"], "Non-development score in checkpoint")
            raw_steps = evaluation.get("steps", evaluation.get("step", evaluation.get("updates")))
            require(isinstance(raw_steps, int) and not isinstance(raw_steps, bool), "Checkpoint steps must be an integer")
            require(raw_steps in STEPS, f"Unexpected checkpoint {raw_steps}")
            metrics = metric_pair(resolve_json(raw_metrics, base, sources))
            key = (*trajectory, raw_steps)
            require(key not in cells, f"Duplicate authoritative checkpoint {key}; resolve attempts before selection")
            cells[key] = {"run_id": run_id, "stage": stage, "family": family,
                          "policy": policy, "seed": 41, "lr": lr, "temperature": temperature,
                          "steps": raw_steps, "metrics": metrics, "status": "valid",
                          "checkpoint_path": evaluation.get("checkpoint_path"),
                          "checkpoint_sha256": evaluation.get("checkpoint_sha256"),
                          "metrics_source": str(raw_metrics) if isinstance(raw_metrics, (str, Path)) else "inline"}
            present_steps.add(raw_steps)
        if merged.get("status") == "failed":
            reason = merged.get("failure_reason", merged.get("error", merged.get("reason")))
            require(bool(reason), f"Failed run {run_id} requires a reason")
            for steps in STEPS:
                if steps in present_steps:
                    continue
                key = (*trajectory, steps)
                require(key not in cells, f"Failed duplicate trajectory {key}")
                cells[key] = {"run_id": run_id, "stage": stage, "family": family,
                              "policy": policy, "seed": 41, "lr": lr, "temperature": temperature,
                              "steps": steps, "metrics": None, "status": "failed", "reason": str(reason)}
    expected = [(policy, lr, temperature, step) for policy in policies for lr in LRS for temperature in TEMPERATURES for step in STEPS]
    missing = [key for key in expected if key not in cells]
    require(not missing, f"Cannot lock incomplete grid: {len(missing)} missing cells: {missing[:8]}")
    selection, unavailable = {}, []
    for policy in policies:
        valid = [cells[key] for key in expected if key[0] == policy and cells[key]["status"] == "valid"]
        if not valid:
            unavailable.append(policy)
        else:
            selection[policy] = sorted(valid, key=cmp_to_key(compare_configs))[0]
    require(not unavailable, f"Policies with no valid grid cells cannot be confirmed: {unavailable}")
    result = {
        "schema_version": "1.0.0", "stage": stage, "status": "selected", "family": family,
        "selection_seed": 41, "selection_split": "original_development_only",
        "selection": selection, "grid": [cells[key] for key in expected],
        "grid_cell_count": len(expected),
        "valid_grid_cell_count": sum(cell["status"] == "valid" for cell in cells.values()),
        "failed_grid_cell_count": sum(cell["status"] == "failed" for cell in cells.values()),
        "rules": {"absolute_tie_tolerance": TIE_TOLERANCE,
                  "config_order": ["recall@5_desc", "mrr@10_desc", "steps_asc", "lr_asc", "temperature_0.05_first"],
                  "extension_order": ["recall@5_desc", "fixed_policy_order"],
                  "fixed_policy_order": EXTENSION_ORDER,
                  "candidate_signal_absolute_recall5": 0.01,
                  "no_candidate_policy": "B_UNIQUE",
                  "not_statistical_significance": True},
        "referenced_input_sha256": sources,
    }
    if stage == "S2":
        ranked = sorted([selection[p] for p in EXTENSION_ORDER], key=cmp_to_key(compare_policies))
        best = ranked[0]
        baseline_best = max(selection[p]["metrics"]["recall@5"] for p in ["R_ID", "B_ID"])
        margin = best["metrics"]["recall@5"] - baseline_best
        # Inclusive >= at the threshold, using the plan's numerical-tie
        # tolerance to avoid .41-.40 being represented below .01 in binary.
        signal = margin >= 0.01 or abs(margin - 0.01) <= TIE_TOLERANCE
        chosen = best["policy"] if signal else "B_UNIQUE"
        result["selected_extension"] = {"policy": chosen,
            "branch": "candidate_improver" if signal else "mechanism_followup_no_development_improver",
            "best_extension_policy": best["policy"], "best_extension_margin": margin,
            "baseline_best_recall@5": baseline_best, "candidate_signal_met": signal,
            "locked_config": selection[chosen], "ranked_extension_policies": [r["policy"] for r in ranked]}
    else:
        result["selected_extension"] = {"policy": extension, "branch": s2_lock["selected_extension"]["branch"],
                                        "identity_binding": "S2.selected_extension.policy", "locked_config": selection[extension]}
    return result


def self_test():
    def fixture(stage="S2", extension="B_UNIQUE"):
        rows = []
        policies = POLICIES if stage == "S2" else ["R_ID", "B_ID", extension]
        for policy in policies:
            for lr in LRS:
                for temperature in TEMPERATURES:
                    rows.append({"run_id": f"{stage}_{policy}_{lr}_{temperature}", "stage": stage,
                                 "family": "e5" if stage == "S2" else "bge", "policy": policy,
                                 "seed": 41, "lr": lr, "temperature": temperature, "status": "completed",
                                 "dev_evaluations": [{"steps": step, "metrics": {"recall@5": .4, "mrr@10": .3}} for step in STEPS]})
        return rows
    rows = fixture()
    out = select(rows, "S2")
    require(out["grid_cell_count"] == 72, "fixture grid count")
    require(all(c["steps"] == 312 and c["lr"] == 1e-5 and c["temperature"] == .05 for c in out["selection"].values()), "configuration tie order")
    require(out["selected_extension"]["policy"] == "B_UNIQUE" and not out["selected_extension"]["candidate_signal_met"], "no improvement fallback")
    tie_rows = fixture()
    for row in tie_rows:
        if row["policy"] == "DENSE_STATIC":
            for evaluation in row["dev_evaluations"]:
                evaluation["metrics"]["mrr@10"] = .9
    require(select(tie_rows, "S2")["selected_extension"]["best_extension_policy"] == "B_UNIQUE", "Policy tie must ignore MRR")
    boundary_rows = fixture()
    for row in boundary_rows:
        if row["policy"] == "R_UNIQUE":
            for evaluation in row["dev_evaluations"]:
                evaluation["metrics"]["recall@5"] = .41
    require(select(boundary_rows, "S2")["selected_extension"]["policy"] == "R_UNIQUE", "Inclusive 0.01 threshold")
    for row in rows:
        if row["policy"] == "DENSE_STATIC":
            for evaluation in row["dev_evaluations"]:
                evaluation["metrics"]["recall@5"] = .42
    improved = select(rows, "S2")
    require(improved["selected_extension"]["policy"] == "DENSE_STATIC", "candidate threshold selection")
    bge = select(fixture("S4", "DENSE_STATIC"), "S4", s2_lock=improved)
    require(bge["grid_cell_count"] == 36 and bge["selected_extension"]["policy"] == "DENSE_STATIC", "BGE identity binding")
    bad = fixture()
    bad.pop()
    try:
        select(bad, "S2")
        raise AssertionError("Missing cells accepted")
    except ValueError:
        pass
    failed = fixture()
    failed[0].update(status="failed", failure_reason="nonfinite loss", dev_evaluations=[])
    require(select(failed, "S2")["failed_grid_cell_count"] == 3, "failed cells not retained")
    duplicate = fixture()
    duplicate.append(duplicate[0])
    try:
        select(duplicate, "S2")
        raise AssertionError("Duplicate attempt accepted")
    except ValueError:
        pass
    leaked = fixture()
    leaked[0]["dev_evaluations"][0]["split"] = "external_final"
    try:
        select(leaked, "S2")
        raise AssertionError("Final split accepted")
    except ValueError:
        pass
    nan = fixture()
    nan[0]["dev_evaluations"][0]["metrics"]["recall@5"] = float("nan")
    try:
        select(nan, "S2")
        raise AssertionError("NaN accepted")
    except ValueError:
        pass
    return {"passed": True, "checks": ["72/36_grid", "configuration_ties", "policy_tie_ignores_MRR", "inclusive_0.01_threshold", "fallback", "candidate", "S4_binding", "missing_grid", "failed_cells", "duplicate_attempt", "split_gate", "nonfinite_metric"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--stage", choices=["S2", "S4"])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--s2-lock", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2))
        return
    require(args.registry is not None and args.stage is not None and args.output is not None, "--registry, --stage and --output required")
    registry = args.registry.resolve()
    require(not args.output.exists(), f"Refusing to overwrite selection lock {args.output}")
    registry_bytes = registry.read_bytes()
    registry_digest = hashlib.sha256(registry_bytes).hexdigest()
    result = select(json.loads(registry_bytes.decode('utf-8-sig')), args.stage, registry.parent, read_json(args.s2_lock) if args.s2_lock else None)
    snapshot = args.output.with_name(args.output.stem + '_input_registry.json').resolve()
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    with snapshot.open('xb') as stream:
        stream.write(registry_bytes)
    result["input_registry"] = {"path": str(registry), "sha256": registry_digest,
        "immutable_snapshot_path": str(snapshot), "immutable_snapshot_sha256": registry_digest,
        "same_bytes_used_for_selection_and_snapshot": True}
    result["code_sha256"] = sha256(__file__)
    result["created_at_utc"] = datetime.now(timezone.utc).isoformat()
    if args.s2_lock:
        result["s2_lock"] = {"path": str(args.s2_lock.resolve()), "sha256": sha256(args.s2_lock)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    require(not args.output.exists(), f"Refusing to overwrite selection lock {args.output}")
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "stage": args.stage, "selected_extension": result["selected_extension"], "output": str(args.output)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError) as exc:
        print(f"SELECTION_REJECTED: {exc}", file=sys.stderr)
        raise SystemExit(2)
