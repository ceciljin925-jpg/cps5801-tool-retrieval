"""Read-only CPU completion audit; no model execution or result selection.

Final: --input-root PUB_OR_BUNDLE --rebuild-dir COMPLETE_REBUILD --output NEW.json
Snapshot: --input-root PUB_OR_BUNDLE --snapshot --output NEW.json
Snapshot reads registry/human metadata only, never final score/prediction contents.
Final checks require the already completed rebuild_research.py output and claims.
Large retained binaries are hashed only with --verify-large-files; portable
bundles otherwise require their explicit retained-GPU manifest. No file is edited.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import tempfile

from rebuild_all import Resolver, read_json, require, sha

STAGES = {'S0': 6, 'S1': 12, 'S2': 24, 'S3': 15, 'S4': 12, 'S5': 15}
DATASETS = {'legacy_observed_test', 'bfcl_live_multiple', 'bfcl_multiple', 'bfcl_parallel_multiple', 'toolhop'}
LARGE = {'.safetensors', '.pt', '.pth', '.npy', '.npz', '.bin', '.onnx'}
CLAIM_FIELDS = {'claim_id', 'statement_en', 'explanation_zh', 'stage', 'evidence_type', 'comparison', 'dataset', 'metric',
                'effect_estimate', 'uncertainty', 'per_seed_effects', 'practical_threshold', 'evidence_paths',
                'counterevidence', 'limitations', 'human_dependency', 'status'}
NEGATIVE_TABLE_ARTIFACTS = {
    'policy_input_rates.csv', 'policy_full_distributions.csv', 'replacement_slot_distributions.csv',
    'replacement_slot_observations.csv', 'policy_descriptive_seed_ranges.csv',
    'negative_input_rates.png', 'negative_input_rates.pdf', 'field_definitions.json',
    'interpretation_sampling_and_inputs_en.txt', '解释_采样与输入事实.txt',
}


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def inventory(runs, final=None, lock=None):
    require(len(runs) == 84 and len({r['run_id'] for r in runs}) == 84, 'Exactly84 unique scientific training IDs required')
    require(dict(Counter(r['stage'] for r in runs)) == STAGES, 'Stage allocation differs from6/12/24/15/12/15')
    for row in runs:
        stage = row['stage']
        require(row['family'] == ('bge' if stage in ('S4', 'S5') else 'e5'), 'Unexpected family: ' + row['run_id'])
        require(row['seed'] in ([41] if stage in ('S2', 'S4') else [42,43,44] if stage in ('S0','S1') else [42,43,44,45,46]), 'Unexpected seed')
    report = {'training_total': len(runs), 'training_statuses': dict(Counter(r['status'] for r in runs)),
              'by_stage': {s: dict(Counter(r['status'] for r in runs if r['stage'] == s)) for s in STAGES}}
    if final is None:
        report.update(final_registry_present=False, expected_retrieval=260, expected_profiles=80, expected_lock_entries=340)
        return report
    entries = final['evaluations']
    profiles = [(group['dataset'], row) for group in final['efficiency'] for row in group['models']]
    require(len(entries) == 260 and len({r['evaluation_id'] for r in entries}) == 260, 'Exactly260 unique retrieval entries required')
    require(len(profiles) == 80 and len({(d,r['run_id']) for d,r in profiles}) == 80, 'Exactly80 unique profile entries required')
    require(Counter(e['dataset'] for e in entries) == Counter({d:52 for d in DATASETS}), 'Each dataset requires52 retrievals')
    require(Counter(d for d,r in profiles) == Counter({d:16 for d in DATASETS}), 'Each dataset requires16 profiles')
    require(lock is not None and len(lock['evaluations']) == 340, 'Final lock requires340 entries')
    locked = lock['evaluations']
    require(len({r['evaluation_id'] for r in locked}) == 340, 'Duplicate lock entry')
    require({r['evaluation_id'] for r in locked if r['purpose']=='final_retrieval'} == {r['evaluation_id'] for r in entries}, 'Locked retrieval IDs differ')
    require({(r['dataset'],r['run_id']) for r in locked if r['purpose'].startswith('predeclared_efficiency')} == {(d,r['run_id']) for d,r in profiles}, 'Locked profiling IDs differ')
    models = lock['models']
    require(len(models) == 52 and len({m['run_id'] for m in models}) == 52, 'Final model inventory differs')
    wanted = {r['run_id'] for r in runs if r['stage'] in ('S0','S1','S3','S5')}
    wanted |= {'baseline_'+x for x in ['bm25','e5','bge','qwen_reference']}
    require({m['run_id'] for m in models} == wanted, 'Missing/extra final model')
    timing = {m['run_id'] for m in models if m['stage']=='BASELINE' or m['seed']==42}
    require(len(timing)==16, 'Incorrect seed42/baseline profiling membership')
    for dataset in DATASETS:
        require({e['run_id'] for e in entries if e['dataset']==dataset} == wanted, 'Retrieval model set changed by dataset')
        require({r['run_id'] for d,r in profiles if d==dataset} == timing, 'Profiling model set changed by dataset')
    report.update(final_registry_present=True, retrieval_total=260, profiling_total=80, final_lock_total=340,
                  retrieval_statuses=dict(Counter(e['status'] for e in entries)), profiling_statuses=dict(Counter(r['status'] for d,r in profiles)))
    return report


def pending_human(directory, expected):
    status = read_json(directory/'status.json')
    with (directory/'blind_review.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    require(len(rows)==expected and len({r['blind_id'] for r in rows})==expected, 'Blind item count/uniqueness mismatch')
    require(status['prepared_count']==expected, 'Prepared human count mismatch')
    if status['completed_count']==0:
        require(status['status']=='HUMAN_PENDING', 'Zero labels must remain HUMAN_PENDING')
        require(all(not r.get('label','').strip() and not r.get('reason','').strip() for r in rows), 'Pending human forms contain filled labels/reasons')
    else:
        raise ValueError('Real human replies require separate validated receipt/agreement/design analysis; this pre-reply checker cannot certify them')
    for name in ['blind_review.html','hidden_key.json','sample_manifest.json','reviewer_instructions.txt']:
        require((directory/name).is_file(), 'Missing blind-review artifact: '+name)
    return {'status':status['status'], 'prepared':expected, 'completed':0}


class CompletionChecker:
    def __init__(self, root, rebuild=None, large=False, snapshot=False):
        self.resolver = Resolver(root)
        self.pub = self.resolver.publication
        self.bundle = self.resolver.mapping_path.parent if self.resolver.mapping_path else self.pub.parent
        self.rebuild = Path(rebuild).resolve() if rebuild else None
        self.large, self.snapshot = large, snapshot
        self.checks, self.errors, self.evidence, self.retained, self.failure_records = [], [], {}, [], []

    def check(self, name, operation):
        try:
            result = operation()
            self.checks.append({'check':name,'status':'PASS','detail':result})
        except (ValueError, KeyError, TypeError, OSError, AssertionError, StopIteration) as exc:
            self.errors.append({'check':name,'error':str(exc)})
            self.checks.append({'check':name,'status':'FAIL','error':str(exc)})

    def file(self, path, expected=None, size=None):
        path = Path(path).resolve()
        require(path.is_file(), 'Missing required file: '+str(path))
        if path not in self.evidence:
            self.evidence[path] = {'path':self.resolver.display(path),'bytes':path.stat().st_size,'sha256':sha(path)}
        row = self.evidence[path]
        require(expected is None or row['sha256']==expected, 'SHA mismatch: '+str(path))
        require(size is None or row['bytes']==size, 'Size mismatch: '+str(path))
        return row

    def load(self, path):
        self.file(path)
        return read_json(path)

    def resolve(self, path):
        return self.resolver.resolve(path, self.pub)

    def directory_manifest(self, directory, manifest):
        directory = Path(directory)
        require(isinstance(manifest,dict) and bool(manifest), 'Empty binary/evidence manifest')
        for relative, item in manifest.items():
            path = (directory/relative).resolve()
            require(directory.resolve() in path.parents, 'Manifest path escapes directory')
            if path.suffix.lower() in LARGE and not self.large:
                self.retained.append({'path':str(path),'bytes':item['bytes'],'sha256':item['sha256'], 'verified_now':False})
            else:
                self.file(path,item['sha256'],item['bytes'])

    def training(self, runs):
        decisions = self.load(self.pub/'locks/execution_decisions.json')
        package = self.resolve(decisions['source'])
        matrix_path = package/'experiment_matrix.json'
        matrix = self.load(matrix_path)
        registry = self.load(self.pub/'run_registry.json')
        self.file(matrix_path,registry['matrix_sha256'])
        planned = {r['run_id']:r for r in matrix['planned_training_jobs']}
        require(set(planned)=={r['run_id'] for r in runs}, 'Registry differs from immutable84-job matrix')
        selections = {s:self.load(self.pub/f'locks/{s}_selection.json') for s in ['S2','S4']}
        budget, failed_grid, pairing = [], [], []
        for row in runs:
            label = row['run_id']; original = planned[label]; stage = row['stage']
            for field in ['stage','family','seed']:
                require(row[field]==original[field], 'Planned identity changed: '+label+'/'+field)
            require(row.get('attempts'), 'No attempt/reuse evidence: '+label)
            require(row['status'] in ['completed','failed','reused'], 'Unfinished training: '+label)
            if row['status']=='reused':
                raise ValueError('Exact reuse needs explicit full scientific-key equality review: '+label)
            config = row.get('config')
            if isinstance(config,str): config = self.load(self.resolve(config))
            require(isinstance(config,dict), 'Missing executed config: '+label)
            require(all(config[key]==row[key] for key in ['stage','family','seed']),'Executed stage/family/seed differs: '+label)
            chosen_policy = selections['S2']['selected_extension']['policy'] if original['policy']=='SELECTED_EXTENSION' else original['policy']
            require(config['policy']==chosen_policy, 'Selected extension/policy differs from frozen decision: '+label)
            if stage in ['S3','S5']:
                chosen = selections['S2' if stage=='S3' else 'S4']['selection'][chosen_policy]
                expected = (chosen['lr'],chosen['temperature'],chosen['steps'])
            else:
                expected = (original['learning_rate'],original['temperature'],original['optimizer_updates'])
            require((config['lr'],config['temperature'],config['steps'])==expected, 'Training budget/config changed: '+label)
            out = self.resolve(row['output_path'])
            losses = self.load(out/'loss.jsonl')
            require([r['step'] for r in losses]==list(range(1,len(losses)+1)), 'Noncontiguous optimizer trace: '+label)
            require(all(math.isfinite(r['loss']) and math.isfinite(r['grad_norm']) for r in losses), 'Nonfinite saved loss/gradient: '+label)
            if row['status']=='failed':
                require(stage in ['S2','S4'] and row.get('failure_kind')=='numerical' and row.get('failure_reason'), 'Unresolved technical/final-model failure: '+label)
                require(len(losses)<=config['steps'], 'Failed run exceeded planned budget')
                require(self.load(out/'status.json')['status']=='failed','Failure evidence missing')
                failed_grid.append(label)
            else:
                train = self.load(out/'training.json')
                require(train['steps']==row['actual_steps']==config['steps']==len(losses), 'Actual optimizer budget differs: '+label)
                if stage!='S0':
                    require(train['exposures']==config['steps']*32 and self.load(out/'status.json')['status']=='completed', 'Exposure/completion mismatch: '+label)
                    require(self.load(out/'config.json')==config,'Executed/registry config mismatch')
                    identity = self.load(out/'identity.json')
                    require(train['identity_sha256']==canonical_sha(identity),'Training identity digest differs')
                    require((config['microbatch'],config['accumulation'])==(8,4),'Frozen effective-batch implementation changed')
                    for key, expected_hash in identity['input_files'].items():self.file(self.resolve(config[key]),expected_hash)
                    schedule = self.load(self.resolve(config['schedule_path']))[:config['steps']*32]
                    require(len(schedule)==config['steps']*32 and canonical_sha(schedule)==identity['actual_schedule_prefix_sha256'],'Actual exposure prefix differs')
                    require(canonical_sha(self.load(self.resolve(config['negatives_path'])))==identity['actual_negatives_sha256'],'Actual negative IDs differ')
                    pairing.append({'family':row['family'],'seed':row['seed'],'initial_model':canonical_sha(identity['model_files']),
                                    'schedule':identity['input_files']['schedule_path']})
                    for path, expected_hash in config.get('input_hashes',{}).items():self.file(self.resolve(path),expected_hash)
                    checkpoints = self.load(out/'checkpoint_manifest.json')
                    for name, manifest in checkpoints.items():self.directory_manifest(out/'checkpoints'/name,manifest)
                else:
                    cp = self.resolver.resolve(row['checkpoint_path'],must_exist=False)
                    self.directory_manifest(cp,{'model.safetensors':{'bytes':(cp/'model.safetensors').stat().st_size if (cp/'model.safetensors').exists() else 0,'sha256':row['checkpoint_sha256']}})
            milestones = [312,625,1250] if stage in ['S2','S4'] else [config['steps']]
            actual_steps = [e['steps'] for e in row['dev_evaluations']]
            require(len(actual_steps)==len(set(actual_steps)) and set(actual_steps)<=set(milestones),'Duplicate/unplanned dev checkpoints')
            if row['status']=='completed':require(sorted(actual_steps)==milestones,'Completed trajectory missing dev checkpoint')
            for ev in row['dev_evaluations']:
                metrics = self.resolve(ev['metrics_path'])
                self.file(metrics,ev.get('metrics_sha256'))
                self.file(metrics.with_name('predictions.json'),ev.get('predictions_sha256'))
                require(self.load(metrics)['n']==1000,'Development query count differs')
            budget.append({'run_id':label,'stage':stage,'status':row['status'],'actual_updates':len(losses),
                           'planned_updates':config['steps'],'query_exposures':len(losses)*32,'attempts':len(row['attempts'])})
        for family,seed in {(r['family'],r['seed']) for r in pairing}:
            group = [r for r in pairing if (r['family'],r['seed'])==(family,seed)]
            require(len({r['initial_model'] for r in group})==len({r['schedule'] for r in group})==1,'Within-family initial weights/exposure schedule are not paired')
        comparison = self.load(self.pub/'comparison/reproduction_comparison.json')
        require(comparison['summary']['status']=='PASS_COMPLETE','Original/new reproduction verification incomplete')
        require(self.load(self.pub/'comparison/reproduction_review.json')['continue_publication'] is True,'S0 differences lack recorded acceptance')
        return {'scientific_jobs':84,'completed_or_accounted':len(budget),'documented_numerical_grid_failures':failed_grid,
                'optimizer_updates':sum(r['actual_updates'] for r in budget),'runs':budget}

    def final(self, registry, lock):
        self.file(self.pub/'locks/final_lock.json',registry['lock_sha256'])
        require(lock['no_prior_external_final_scores'] is True,'No-prior-score lock declaration absent')
        require(lock['five_confirmatory_seeds']==[42,43,44,45,46],'Confirmation seeds changed')
        require(lock['confirmatory_comparisons']==['e5:selected-R_ID','e5:selected-B_ID','bge:selected-R_ID','bge:selected-B_ID'],'Primary family changed')
        for key,name in [('analysis_plan_sha256','analysis_plan.json'),('external_eval_specs_sha256','external_eval_specs.json'),('external_dataset_manifest_sha256','final_dataset_manifest.json')]:
            self.file(self.pub/'locks'/name,lock[key])
        for name,value in lock['selection_hashes'].items():self.file(self.pub/'locks'/name,value)
        for name,value in lock['code_sha256'].items():self.file(self.pub/'extensions'/name,value)
        for item in self.load(self.pub/'locks/final_dataset_manifest.json')['files']:
            self.file(self.pub/item['path'],item['sha256'],item['bytes'])
        locked = {r['evaluation_id']:r for r in lock['evaluations']}
        for row in registry['evaluations']:
            require(row['status']=='completed','Unfinished retrieval: '+row['evaluation_id'])
            bound = locked[row['evaluation_id']]
            for key in ['queries','corpus']:
                self.file(self.resolve(row[key+'_path']),bound[key+'_sha256'])
            self.file(self.resolve(row['config_path']),bound['config_sha256'])
            out = self.resolve(row['output_path'])
            require(self.load(out/'status.json')['status']=='completed','Raw retrieval status incomplete')
            self.file(out/'predictions.json',row['predictions_sha256'])
            self.file(out/'metrics.json',row['metrics_sha256'])
            require(self.load(out/'config.json')==self.load(self.resolve(row['config_path'])),'Executed final config differs')
            if row['family']!='bm25':
                self.directory_manifest(out,self.load(out/'embedding_manifest.json'))
        for group in registry['efficiency']:
            plan_path = self.resolve(group['plan_path'])
            self.file(plan_path,group['plan_sha256'])
            plan = self.load(plan_path)
            require((plan['sampling_seed'],plan['warmups'],plan['rounds'],plan['batch_size'],plan['concurrency'])==(2026111203,50,5,1,1),'Profiling protocol changed')
            for row in group['models']:
                require(row['status']=='completed','Unfinished profiling: '+row['run_id'])
                bound = next(r for r in lock['evaluations'] if r['dataset']==group['dataset'] and r['run_id']==row['run_id'] and r['purpose'].startswith('predeclared_efficiency'))
                require(bound['profiling_plan_sha256']==group['plan_sha256'],'Profiling plan differs from lock')
                self.directory_manifest(self.resolve(row['output_path']),row['evidence_manifest'])
        for model in lock['models']:
            if model['family']=='bm25':continue
            require(canonical_sha(model['checkpoint_manifest'])==model['checkpoint_manifest_sha256'],'Model manifest digest differs')
            self.directory_manifest(self.resolver.resolve(model['model_path'],must_exist=False),model['checkpoint_manifest'])
        marker = self.load(self.pub/'final_evaluations_completed.json')
        require(marker['evaluations']==260 and marker['efficiency_included'] is True,'Final batch marker incomplete')
        require(marker['lock_sha256']==registry['lock_sha256'],'Completion marker points to different final lock')
        accesses = self.load(self.pub/'external_access_log.jsonl')
        expected_external = {r['evaluation_id'] for r in lock['evaluations'] if r['dataset']!='legacy_observed_test'}
        require({r['evaluation_id'] for r in accesses}==expected_external and len(expected_external)==272,'External access record coverage differs')
        for access in accesses:
            require(access['lock_sha256']==registry['lock_sha256'],'Access used different final lock')
            require(datetime.fromisoformat(access['time'])>=datetime.fromisoformat(lock['lock_timestamp']),'Recorded final score access preceded lock')
        require(self.load(self.pub/'EXTERNAL_FINAL_OPENED.json')==accesses[0],'First exposure marker differs from append-only access record')
        return {'retrieval':260,'profiles':80,'lock_entries':340,'score_values_not_used_for_acceptance':True}

    def human(self):
        result = {name:pending_human(self.pub/'human_review'/name,n) for name,n in [('original_50_pair_review',50),('new_mechanism_review',48)]}
        rates = self.load(self.pub/'human_review/agreement_and_rates.json')
        require(rates['completed_count']==0 and rates['total_prepared_count']==98,'Human total mismatch')
        require(all(rates[key] is None for key in ['agreement','cohen_kappa','semantic_rates']),'Human pending fabricated statistics')
        return {'groups':result,'status':'HUMAN_PENDING','prepared':98,'completed':0,'does_not_block_independent_experiments':True}

    def diagnostics(self):
        negative = self.load(self.pub/'analysis/negative_complete_attempt01/diagnostics_report.json')
        require(negative['status']=='PASS_COMPLETE' and negative['policy_seed_cells_validated']==36 and negative['similarity_diagnostics_complete'],'Full negative/confound diagnostics missing')
        for path,value in negative['input_sha256'].items():
            p = self.resolver.resolve(path,must_exist=False)
            if p.suffix in LARGE and not self.large:continue
            self.file(p,value)
        errors = self.load(self.pub/'analysis/legacy_errors/status.json')
        require(all(errors.get(side)=='NUMERICAL_DESCRIPTIVE_ANALYSIS_COMPLETE' for side in ['original','reproduction']),'Both original/reproduction error analyses required')
        review = self.load(self.pub/'analysis/legacy_errors/ai_proxy/review_status.json')
        require(review['case_count']==60 and review['human_completed_count']==0 and review['independent_human_review'] is False,'AI60 case provenance conflated with human review')
        require(review['primary_labels_changed'] is False and review['real_tools_executed'] is False,'Qualitative reviews changed scope')
        for name in ['query_strata.csv','text_similarity.csv','sample_manifest.json']:
            self.file(self.pub/'analysis/legacy_errors'/name)
        self.file(self.pub/'analysis/reference_document_tokens/manifest.json')
        return {'negative_cells':36,'old_cases_AI_only':60,'new_human_labels':0,'original_and_reproduction_error_analysis':'complete'}

    def provenance(self, directory, path, kind):
        data = self.load(path)
        if kind=='legacy':
            for source in data['all_input_files']:
                self.file(self.resolver.resolve(source['path'],self.resolver.root),source['sha256'],source['bytes'])
            records = data['tables_and_figures']
        else:records = data['tables_and_artifacts' if kind in ('research','negative_tables') else 'artifacts']
        if kind=='negative_tables':
            for source in data['all_input_files']:
                self.file(self.resolver.resolve(source['path'],self.resolver.root),source['sha256'],source['bytes'])
        require(bool(records),'Empty table provenance')
        for record in records:
            outputs = record['outputs'] if kind=='legacy' else [{'path':record['output'],'sha256':record.get('output_sha256',record.get('sha256')),'bytes':record.get('output_bytes',record.get('bytes'))}]
            for item in outputs:self.file(directory/item['path'],item['sha256'],item['bytes'])
            for item in record.get('inputs',[]):
                self.file(self.resolver.resolve(item['path'],self.resolver.root),item['sha256'],item['bytes'])
        return len(records)

    def negative_tables(self, directory):
        directory = Path(directory)
        status = self.load(directory/'status.json')
        require(status.get('status')=='PASS_COMPLETE_NEGATIVE_INPUT_TABLES','Negative input table rebuild did not pass')
        require(status.get('policy_seed_cells')==36 and status.get('replacement_slots')==4830,
                'Negative input table coverage differs from36 policy/seed cells and4830 actual replacement slots')
        manifest = directory/'table_provenance.json'
        data = self.load(manifest)
        records = data['tables_and_artifacts']
        names = [record['output'] for record in records]
        require(len(names)==len(set(names)) and NEGATIVE_TABLE_ARTIFACTS <= set(names),
                'Negative input table provenance omits or duplicates required artifacts')
        bindings = data['all_input_files'] + [item for record in records for item in record['inputs']]
        bindings += [{'sha256':record.get('output_sha256'),'bytes':record.get('output_bytes')} for record in records]
        require(bool(data['all_input_files']) and all(isinstance(item.get('sha256'),str) and len(item['sha256'])==64
                and type(item.get('bytes')) is int and item['bytes']>0 for item in bindings),
                'Negative input table provenance requires explicit SHA256 and byte counts for every input/output')
        source = self.pub/'extensions/rebuild_negative_tables.py'
        require(self.file(source)['sha256']==status.get('script_sha256'),'Negative table status producer SHA mismatch')
        require(self.file(self.pub/'extensions/negative_diagnostics.py')['sha256']==data.get('diagnostic_producer_code_sha256'),
                'Negative diagnostic producer SHA mismatch')
        for record in records:
            require(record['script']['name']==source.name,'Unexpected negative table producer')
            require(self.file(source)['sha256']==record['script'].get('sha256'),'Negative table artifact producer SHA mismatch')
        count = self.provenance(directory,manifest,'negative_tables')
        for name in NEGATIVE_TABLE_ARTIFACTS:
            require(self.file(directory/name)['bytes']>0,'Empty required negative input artifact: '+name)
        return {'status':status['status'],'policy_seed_cells':36,'replacement_slots':4830,
                'provenance_records':count,'required_artifacts':len(NEGATIVE_TABLE_ARTIFACTS)}

    def rebuilt(self):
        require(self.rebuild is not None,'--rebuild-dir must point to completed rebuild_research output')
        master = self.load(self.rebuild/'rebuild_status.json')
        require(master['status']=='PASS_COMPLETE_PORTABLE_REBUILD','Full single-entry rebuild did not pass')
        research = self.load(self.rebuild/'research/rebuild_status.json')
        require(research['pending_evaluations']==research['verification_failures']==0,'Research rebuild incomplete/invalid')
        legacy = self.load(self.rebuild/'legacy_tables/rebuild_status.json')
        require(legacy['original_main_prediction_files']==legacy['reproduction_prediction_files']==16 and legacy['historical_pilot_prediction_files']==8,'Old/new/pilot table evidence incomplete')
        efficiency = self.load(self.rebuild/'efficiency/status.json')
        require(efficiency['completed_accuracy_evaluations']==260 and efficiency['completed_profiles']==80 and efficiency['pending']==efficiency['failures']==0,'Efficiency outputs incomplete')
        counts = {}
        for name,manifest in [('research','table_provenance.json'),('legacy_tables','table_evidence_map.json'),('efficiency','table_provenance.json')]:
            counts[name] = self.provenance(self.rebuild/name,self.rebuild/name/manifest,'legacy' if name=='legacy_tables' else name)
        counts['negative_tables'] = self.negative_tables(self.rebuild/'negative_tables')
        for name in ['comparison/locked_confirmation_effects.csv','comparison/paired_effects_all_seeds.csv','comparison/fixed_mechanism_effects.csv','tables/development_grid.csv','figures/main_effects.png','figures/confirmation_seed_effects.png','figures/e5_development_grid.png']:
            self.file(self.rebuild/'research'/name)
        for name in ['all_seed_k_curves.csv','recall_or_mrr_latency_pareto.csv','recall_document_tokens_pareto.csv','latency_all_five_rounds.csv','measurement_boundaries.txt']:
            self.file(self.rebuild/'efficiency'/name)
        primary = []
        for dataset in DATASETS:
            for family in ['e5','bge']:
                stats = self.load(self.rebuild/'research/statistics'/f'{dataset}_{family}_paired_bootstrap.json')
                require(stats['expected_seeds']==[42,43,44,45,46] and stats['alignment']['missing_rows']==0,'Incomplete five-seed paired statistics')
                settings = stats['bootstrap_configuration']
                require((settings['replicates'],settings['query_seed'],settings['cluster_seed'])==(5000,2026111201,2026111202),'Bootstrap contract changed')
                for contrast in stats['contrasts']:
                    require([e['seed'] for e in contrast['per_seed_effects']]==[42,43,44,45,46],'Omitted paired seed')
                    require(contrast['p_value'] is None,'Unplanned p-value introduced')
                    for field in ['paired_query_bootstrap','paired_query_weighted_cluster_bootstrap']:
                        sample = contrast[field]
                        require(len(sample['replicate_estimates'])==len(sample['replicate_n_rows'])==5000,'Missing bootstrap draws/denominators')
                    if dataset=='bfcl_live_multiple' and contrast['metric']=='mrr':primary.append(contrast['contrast_id'])
            mechanism = self.load(self.rebuild/'research/statistics'/f'{dataset}_fixed_mechanism.json')
            require(mechanism['expected_seeds']==[42,43,44],'Three-seed mechanism scope changed')
            require({c['contrast_id'] for c in mechanism['contrasts']}=={'delta_B','delta_R','interaction_delta_B_minus_delta_R'},'Missing paired mechanism contrast')
        require(set(primary)=={f'{f}:selected_minus_{p}' for f in ['e5','bge'] for p in ['R_ID','B_ID']} and len(primary)==4,'Not exactly four predeclared main effects')
        counts['four_primary_contrasts_verified']=len(primary)
        return counts

    def processes(self):
        roots = [self.pub/'logs',self.pub/'runs',self.pub/'evaluations',self.pub/'efficiency']
        repro = next((p for p in [self.bundle/'reproduction',self.pub.parent/'repro'] if p.is_dir()),None)
        if repro:roots.append(repro/'logs')
        count = 0
        for root in roots:
            for path in sorted(root.rglob('*.process_status.json')) if root.exists() else []:
                row = self.load(path); count += 1
                require(all(key in row for key in ['command','cwd','started_at','ended_at','status','exit_code','stdout','stderr']),'Incomplete process record: '+str(path))
                require(row['status'] not in ['running','starting'] and not row.get('child_may_still_be_running',False),'Unsettled process: '+str(path))
                for key in ['stdout','stderr']:self.file(self.resolve(row[key]))
                if row['status']!='completed' or row['exit_code']!=0:
                    self.failure_records.append({'path':self.resolver.display(path),'status':row['status'],'exit_code':row['exit_code'],
                                                 'retained':True,'requires_disclosure':True})
        require(count>0,'No command/process evidence')
        return {'process_records':count,'failed_attempts_retained':self.failure_records,
                'limit':'Existence proves preservation of recorded attempts; cannot prove absence of deleted/unrecorded attempts'}

    def claims(self):
        claims = self.pub/'claims'
        for name in ['README_研究结果与下一步.txt','CONTINUE_PROMPT_新电脑接手.txt','executive_summary_en.txt',
                     'supported_conclusions_en.txt','limitations_and_missing_evidence.txt','ai_and_human_contributions.json']:
            item = self.file(claims/name); require(item['bytes']>0,'Empty claims/handoff file')
        path = next((claims/name for name in ['claim_ledger.json','claim_ledger.csv'] if (claims/name).is_file()),None)
        require(path is not None,'Missing claim ledger')
        self.file(path)
        if path.suffix=='.json':
            data = self.load(path); rows = data.get('claims',data) if isinstance(data,dict) else data
        else:
            with path.open(encoding='utf-8-sig',newline='') as stream:rows = list(csv.DictReader(stream))
        require(rows and len({r['claim_id'] for r in rows})==len(rows),'Empty/duplicate claim ledger')
        for row in rows:
            require(CLAIM_FIELDS<=row.keys(),'Missing claim ledger fields: '+str(sorted(CLAIM_FIELDS-row.keys())))
            require(row['limitations'] and row['evidence_paths'],'Claim lacks evidence or limits')
            if row['evidence_type']=='independent_human_document_judgment':require(row['status']=='HUMAN_PENDING','No actual human labels support a ready human claim')
            paths = row['evidence_paths']
            if isinstance(paths,str):
                try:paths = json.loads(paths)
                except json.JSONDecodeError:paths = [p.strip() for p in paths.split(';') if p.strip()]
            require(isinstance(paths,list) and paths,'Claim evidence_paths must be a list or semicolon-separated paths')
            for path in paths:
                p = self.resolver.resolve(path,self.pub,must_exist=False)
                if not p.exists() and self.rebuild is not None:p = self.rebuild/path
                require(p.exists(),'Claim references unavailable evidence: '+str(path))
        return {'claims':len(rows),'structure_only':True,'scientific_wording_requires_final_review':True,
                'failed_attempt_disclosure_required':bool(self.failure_records)}

    def retained_manifest(self):
        if self.large:return {'mode':'local actual large file hashes verified','files':sum(Path(p).suffix in LARGE for p in self.evidence)}
        path = self.bundle/'weights/retained_gpu_artifact_manifest.json'
        require(path.is_file(),'Without --verify-large-files, require portable weights/retained_gpu_artifact_manifest.json')
        data = self.load(path)
        items = data['files']; require(items,'Empty retained GPU inventory')
        by_hash = {(r['sha256'],r['bytes']) for r in items}
        for r in self.retained:
            # S0 compact registry carries only SHA; a portable checkpoint can be absent.
            require((r['sha256'],r['bytes']) in by_hash or (r['bytes']==0 and any(x[0]==r['sha256'] for x in by_hash)), 'Omitted weight/vector lacks retained inventory: '+r['path'])
        require(all(r.get('included_in_main_zip') is False and r.get('absolute_gpu_path') for r in items),'Retained artifact wrongly described as delivered')
        return {'files':len(items),'binding_verified':True,'local_availability_not_verified_on_other_machine':True}

    def run(self):
        runs = self.load(self.pub/'run_registry.json')['runs']
        registry_path = self.pub/'final_evaluation_registry.json'
        registry = self.load(registry_path) if registry_path.exists() else None
        lock_path = self.pub/'locks/final_lock.json'
        lock = self.load(lock_path) if lock_path.exists() else None
        self.check('inventory',lambda:inventory(runs,registry,lock))
        self.check('human_pending',self.human)
        if not self.snapshot:
            self.check('training_budget_and_evidence',lambda:self.training(runs))
            self.check('locked_final_outputs',lambda:self.final(registry,lock))
            self.check('negative_and_error_analyses',self.diagnostics)
            self.check('full_offline_rebuild',self.rebuilt)
            self.check('commands_and_failure_preservation',self.processes)
            self.check('claims_and_handoff',self.claims)
            self.check('large_evidence_retention',self.retained_manifest)
        return {'schema_version':1,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
                'status':'SNAPSHOT_NOT_FINAL_ACCEPTANCE' if self.snapshot else 'FAIL_COMPLETION_ACCEPTANCE' if self.errors else 'PASS_INDEPENDENT_WORK_WITH_HUMAN_PENDING',
                'passed':not self.snapshot and not self.errors,'snapshot':self.snapshot,'errors':self.errors,'checks':self.checks,
                'script_sha256':sha(__file__),'input_root':str(self.resolver.root),'rebuild_dir':str(self.rebuild) if self.rebuild else None,
                'input_evidence':list(self.evidence.values()),'human_status':'HUMAN_PENDING;0 of98 independent items received',
                'limits':['Engineering acceptance does not validate semantic truth or causal mechanism',
                          'Claim wording and figure readability need final review', 'ZIP CRC/member hashes require package_return verification',
                          'No guarantee against unrecorded score access or source/pretraining overlap']}


def self_test():
    # Strict omission/duplicate failures and fake-human/tamper gates without real results.
    with tempfile.TemporaryDirectory(prefix='completion_fixture_') as temporary:
        root = Path(temporary); directory = root/'human'; directory.mkdir()
        (directory/'status.json').write_text(json.dumps({'prepared_count':2,'completed_count':0,'status':'HUMAN_PENDING'}))
        for name in ['blind_review.html','hidden_key.json','sample_manifest.json','reviewer_instructions.txt']:(directory/name).write_text('{}')
        blind = directory/'blind_review.csv'; blind.write_text('blind_id,label,reason\nX1,,\nX2,,\n')
        require(pending_human(directory,2)['completed']==0,'Valid blank human fixture rejected')
        blind.write_text('blind_id,label,reason\nX1,V,AI filled\nX2,,\n')
        try:pending_human(directory,2)
        except ValueError:pass
        else:raise AssertionError('Invented pending human label accepted')
        checker = CompletionChecker(root)
        file = root/'bound.txt'; file.write_text('first'); binding = sha(file)
        checker.file(file,binding)
        file.write_text('tamper')
        try:CompletionChecker(root).file(file,binding)
        except ValueError:pass
        else:raise AssertionError('Tampered evidence accepted')
        runs=[]
        for stage,count in STAGES.items():
            for i in range(count):runs.append({'run_id':f'{stage}_{i}','stage':stage,'family':'bge' if stage in ['S4','S5'] else 'e5',
                'seed':41 if stage in ['S2','S4'] else [42,43,44][i%3] if stage in ['S0','S1'] else [42,43,44,45,46][i%5], 'status':'pending'})
        require(inventory(runs)['training_total']==84,'Valid84 fixture rejected')
        for bad in [runs[:-1],runs[:-1]+[runs[0]]]:
            try:inventory(bad)
            except ValueError:pass
            else:raise AssertionError('Missing/duplicate training identity accepted')
        try:inventory(runs,{'evaluations':[],'efficiency':[]},{'evaluations':[]})
        except ValueError:pass
        else:raise AssertionError('Missing340 final entries accepted')
    return {'passed':True,'checks':['84 scientific identities','missing/duplicate training rejection','missing340 final rejection','blank human accepted','AI-filled human rejected','SHA tamper rejected'],
            'real_final_scores_read':False,'GPU_used':False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root',type=Path);parser.add_argument('--rebuild-dir',type=Path)
    parser.add_argument('--output',type=Path);parser.add_argument('--snapshot',action='store_true')
    parser.add_argument('--verify-large-files',action='store_true');parser.add_argument('--self-test',action='store_true')
    args = parser.parse_args()
    if args.self_test:print(json.dumps(self_test(),indent=2));return 0
    if args.input_root is None or args.output is None:parser.error('--input-root and --output required')
    require(not args.output.exists(),'Choose a new report; preserve previous audit attempts')
    report = CompletionChecker(args.input_root,args.rebuild_dir,args.verify_large_files,args.snapshot).run()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({key:report[key] for key in ['status','passed','snapshot','errors']},ensure_ascii=False,indent=2))
    return 0 if args.snapshot or report['passed'] else 2


if __name__=='__main__':
    raise SystemExit(main())
