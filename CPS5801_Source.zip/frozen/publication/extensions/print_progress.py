"""Compact read-only local progress, without reading development/final scores."""
import collections
import json
import pathlib

from execute_logged import now

ROOT = pathlib.Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    registry = read(ROOT / 'run_registry.json')
    result = {'time': now(), 'phase': read(ROOT / 'research_controller_status.json')['phase'],
              'training': dict(collections.Counter(row['status'] for row in registry['runs']))}
    for row in registry['runs']:
        if row['status'] == 'running':
            active = {'run': row['run_id'], 'phase': row.get('active_phase')}
            loss_path = pathlib.Path(row['output_path']) / 'loss.jsonl'
            if loss_path.exists():
                for line in reversed(loss_path.read_text(encoding='utf-8').splitlines()[-2:]):
                    try:
                        last = json.loads(line)
                        active.update(step=last['step'], train_elapsed_s=round(last['elapsed_seconds'], 1))
                        break
                    except json.JSONDecodeError:
                        pass
            result['active'] = active
    failures = [row['run_id'] for row in registry['runs'] if row['status'] in ('failed', 'interrupted')]
    if failures:
        result['failed_training'] = failures
    final_path = ROOT / 'final_evaluation_registry.json'
    if final_path.exists():
        final = read(final_path)
        result['final_retrieval'] = dict(collections.Counter(row['status'] for row in final['evaluations']))
        result['final_efficiency'] = dict(collections.Counter(row['status'] for dataset in final['efficiency'] for row in dataset['models']))
    print(json.dumps(result, ensure_ascii=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
