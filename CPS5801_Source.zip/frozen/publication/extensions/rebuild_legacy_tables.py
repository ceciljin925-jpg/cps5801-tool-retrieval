"""CPU-only reconstruction of legacy Tables1-9/A1/B1 and Figures1-2.

Reads archived ORIGINAL evidence; optionally reads all16 actual reproduction
predictions. Historical pilot/audits are never represented as fresh runs.
Published summaries/rendered tables are checked AFTER independent computation.
No model loading, GPU, external-final predictions, or archive writes.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys
import unicodedata
import numpy as np
from scipy.stats import hypergeom
from tokenizers import Tokenizer
from compare_reproduction import RUNS, GROUPS, METRICS, validate_predictions, write_csv
from rebuild_all import Resolver

PILOT_RUNS = [r.replace("M", "A", 1) for r in RUNS]
LABELS = {"N": "defensible negative", "V": "valid alternative", "C": "omitted jointly-required component", "U": "unresolved"}

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")

def norm(text):
    return " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", text).casefold()))

def mean(values):
    return float(np.mean(values))

def finite_interval(population, sample, observed):
    """Invert inclusive equal-tailed hypergeometric tails; SRS without replacement."""
    require(0 <= observed <= sample <= population, "Invalid finite-population interval inputs")
    low, high = observed, population - sample + observed
    lo, hi = low, high
    while lo < hi:
        mid = (lo + hi) // 2
        if hypergeom.sf(observed - 1, population, mid, sample) >= .025: hi = mid
        else: lo = mid + 1
    lower = lo
    lo, hi = low, high
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if hypergeom.cdf(observed, population, mid, sample) >= .025: lo = mid
        else: hi = mid - 1
    return {"count_bounds": [lower, lo], "rate_bounds": [lower / population, lo / population]}

class LegacyRebuilder:
    def __init__(self, input_root, original, reproduction, output):
        self.resolver = Resolver(input_root)
        self.original, self.reproduction = original.resolve(), reproduction.resolve() if reproduction else None
        self.out = output.resolve()
        require(not self.out.exists() or not any(self.out.iterdir()), "Use a new empty output directory; preserve earlier attempts")
        require(not self.out.is_relative_to(self.original), "Archive is read-only")
        if self.reproduction: require(not self.out.is_relative_to(self.reproduction), "Reproduction inputs are read-only")
        self.out.mkdir(parents=True, exist_ok=True)
        self.sources, self.evidence, self.discrepancies, self.verifications = {}, [], [], []
        self.paper_rows, self.scored = {}, {}

    def register_extra(self, path, inputs, formula, units, fields):
        path=Path(path)
        self.evidence.append({'table_id':path.relative_to(self.out).as_posix(),'outputs':[{'path':path.relative_to(self.out).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}],
                              'fields':{name:{'input_files':[self.source(p,selector) for p in inputs],'formula':formula,'unit':units.get(name,'identifier')} for name,selector in fields.items()},
                              'formula':formula,'script':{'path':Path(__file__).name,'sha256':sha(__file__)},'missing_handling':'No silently omitted rows'})

    def source(self, path, fields="entire file"):
        path = Path(path).resolve()
        if path not in self.sources:
            self.sources[path] = {"path": self.resolver.display(path), "bytes": path.stat().st_size, "sha256": sha(path)}
        return {**self.sources[path], "fields": fields}

    def table(self, side, name, rows, inputs, formula, units=None, selectors=None, notes=None):
        rows = list(rows); columns = list(dict.fromkeys(k for row in rows for k in row))
        target = self.out / side / (name + ".csv")
        write_csv(target, rows, columns)
        write(target.with_suffix(".json"), rows)
        sources = [self.source(p) for p in sorted(set(map(Path, inputs)))]
        units, selectors = units or {}, selectors or {}
        fields = {key: {"input_files": [{**s, "fields": selectors.get(key, "See formula and row identifiers; all listed evidence is read directly")} for s in sources],
                        "formula": formula, "unit": units.get(key, "label or identifier"), "filter": side + "; " + str(notes or "all recorded rows")}
                  for key in columns}
        self.evidence.append({"table_id": side + "/" + name, "outputs": [{"path": p.relative_to(self.out).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)} for p in (target, target.with_suffix(".json"))],
                              "fields": fields, "formula": formula, "notes": notes, "missing_handling": "Absent fields remain null and are named; absent mandatory evidence fails rebuild",
                              "script": {"path": Path(__file__).name, "sha256": sha(__file__)},
                              "dependencies": [{"path": "compare_reproduction.py", "sha256": sha(Path(__file__).with_name("compare_reproduction.py"))}]})
        return rows

    def compare(self, location, actual, stored, source, tolerance=1e-10, fatal=False):
        same = abs(actual - stored) <= tolerance if isinstance(actual, (int, float)) and isinstance(stored, (int, float)) else actual == stored
        if not same:
            self.discrepancies.append({"location": location, "computed": actual, "stored": stored, "source": self.source(source), "status": "NUMERIC_OR_IDENTITY_MISMATCH", "tolerance": tolerance})
        if fatal: require(same, "Evidence mismatch: " + location)
        return same

    def verify_freeze(self):
        checks = []
        for relative in ["data/main_20261025/freeze_manifest.json", "data/audited_pilot_20261025/freeze_manifest.json"]:
            manifest = self.original / relative
            self.source(manifest)
            for name, expected in read(manifest)["files"].items():
                path = self.original / name
                require(path.is_file(), "Frozen source missing: " + name)
                actual = self.source(path)["sha256"]
                require(actual == expected, "Frozen source hash changed: " + name)
                checks.append({"manifest": relative, "path": name, "sha256": actual, "passed": True})
        write(self.out / "freeze_verification.json", checks)
        self.verifications.append({"check": "original_main_and_pilot_frozen_inputs", "files": len(checks), "passed": True})

    def data_table(self):
        rows, inputs = [], []
        specs = [("historical_audited_pilot", "data/audited_pilot_20261025/train.json", "data/prepared/dev.json", "data/prepared/corpus.json"),
                 ("expanded_development", "data/main_20261025/train.json", "data/main_20261025/dev.json", "data/main_20261025/corpus.json"),
                 ("official_pooled_test", "data/main_20261025/train.json", "data/main_20261025/test.json", "data/main_20261025/test_corpus.json")]
        for name, train, queries, corpus in specs:
            paths = [self.original / p for p in (train, queries, corpus)]; inputs += paths
            tr, qr, cr = map(read, paths)
            for label, data in [("train", tr), ("query", qr), ("corpus", cr)]: require(len({r['id'] for r in data}) == len(data), name + " duplicate " + label)
            rows.append({"snapshot": name, "train_queries": len(tr), "eval_queries": len(qr), "candidate_tools": len(cr),
                         "unique_normalized_queries": len({norm(q['query']) for q in qr}), "single_positive_queries": sum(len(q['positives']) == 1 for q in qr),
                         "multi_positive_queries": sum(len(q['positives']) > 1 for q in qr), "empty_query_records": sum(not q['query'] for q in qr),
                         "evidence_type": "HISTORICAL_PILOT" if "pilot" in name else "ORIGINAL", "query_source": self.resolver.display(paths[1]), "corpus_source": self.resolver.display(paths[2])})
        self.table("original", "table1_data", rows, inputs, "Count rows and distinct IDs from frozen JSON arrays; normalized query = NFKC casefold Unicode-word whitespace join; no score filtering",
                   {k: "records" for k in rows[0] if k.endswith("queries") or k.endswith("tools") or k.endswith("records")})
        self.paper_rows["Table 1"] = [["Audited pilot development", f"{rows[0]['train_queries']:,}", f"{rows[0]['eval_queries']:,}", f"{rows[0]['candidate_tools']:,}"],
                                      ["Expanded development", f"{rows[1]['train_queries']:,}", f"{rows[1]['eval_queries']:,}", f"{rows[1]['candidate_tools']:,}"],
                                      ["Official pooled test", "Same fitted models", f"{rows[2]['eval_queries']:,}", f"{rows[2]['candidate_tools']:,}"]]

    def audit_table(self):
        rows, details, inputs = [], [], []
        for phase, audit_dir, data_dir, final_dir, key_name, before_name, pool_name, train_name in [
            ("Pilot", "results/human_audit_20261025", "data/prepared", "data/audited_pilot_20261025", "human_audit_key.json", "input_identical_exclusion_ids.json", "bm25_top50_eligible.json", "train.json"),
            ("Expanded", "results/main_human_audit_20261025", "data/main_20261025", "data/main_20261025", "audit_key.json", "forbidden_preaudit.json", "hard_pool_preaudit.json", "train_preaudit.json")]:
            paths = {"review": self.original/audit_dir/"confirmed_review.json", "stored": self.original/audit_dir/"pool_statistics.json",
                     "key": self.original/data_dir/key_name, "before": self.original/data_dir/before_name, "pools": self.original/data_dir/pool_name,
                     "train": self.original/data_dir/train_name, "ids": self.original/data_dir/"train_tool_ids.json",
                     "after": self.original/final_dir/"forbidden_ids.json", "after_pools": self.original/final_dir/"bm25_top50_eligible.json", "kept": self.original/final_dir/"train.json"}
            inputs += list(paths.values()); obj = {k: read(p) for k, p in paths.items()}
            key = {r['pair_id']: r for r in obj['key']}; require(len(key) == len(obj['key']), "Duplicate audit keys")
            review = obj['review']; require({r['pair_id'] for r in review['items']} == set(key), "Audit key/review mismatch")
            require(all(r.get('human_review', {}).get('status') == 'confirmed' for r in review['items']), "Unconfirmed historical audit record")
            attestation = review.get('human_attestation', {})
            require(attestation.get('independent_double_annotation') is False, "Unexpected historical review provenance")
            label_by_pair = {r['pair_id']: r['human_review']['label'] for r in review['items']}
            require(set(label_by_pair.values()) <= set(LABELS.values()), "Unknown review label")
            ids = set(obj['ids']); before = {q: set(v) for q, v in obj['before'].items()}; after = {q: set(v) for q, v in obj['after'].items()}
            direct = {(k['query_id'], k['tool_id']) for pair, k in key.items() if label_by_pair[pair] != LABELS['N']}
            for policy in ("random", "bm25"):
                selected = [pair for pair, k in key.items() if policy in k['pools']]
                counts = Counter(label_by_pair[pair] for pair in selected); n = len(selected)
                if policy == "random":
                    population = sum(len(ids) - len(ids & before[g['id']]) for g in obj['train'])
                    remaining = sum(len(ids) - len(ids & after[g['id']]) for g in obj['kept'])
                    removed = sum(t in ids and t not in before[q] for q, t in direct)
                else:
                    population = sum(len(obj['pools'][g['id']]) for g in obj['train'])
                    remaining = sum(len(obj['after_pools'][g['id']]) for g in obj['kept'])
                    removed = sum(t in obj['pools'][q] for q, t in direct)
                ambiguous = n - counts[LABELS['N']]; interval = finite_interval(population, n, ambiguous)
                residual = min(1., max(0., (interval['count_bounds'][1] - removed) / remaining)) if remaining else None
                row = {"phase": phase, "policy": policy, "population_before": population, "sample_n": n,
                       **{code: counts[label] for code, label in LABELS.items()}, "combined_ambiguity_rate": ambiguous / n,
                       "interval_low": interval['rate_bounds'][0], "interval_high": interval['rate_bounds'][1],
                       "remaining_population": remaining, "direct_ambiguity_removals": removed, "residual_ambiguity_upper": residual,
                       "provenance": "historical student batch attestation adopting AI suggestions", "independent_double_annotation": False,
                       "new_human_completed": 0, "current_independent_human_status": "HUMAN_PENDING"}
                rows.append(row)
                stored = obj['stored'][policy]
                checks = {'population': (population, stored.get('original_population', stored.get('population_before_fresh_review'))), 'sample': (n, stored.get('sampled', stored.get('sample'))),
                          'remaining': (remaining, stored['remaining_population']), 'label_counts': (dict(counts), stored.get('label_counts', stored.get('counts'))),
                          'interval': (interval, stored['rates']['combined_ambiguity'] if phase == 'Pilot' else stored['interval'])}
                checks['interval'] = (interval, {k: checks['interval'][1][k] for k in ('count_bounds','rate_bounds')})
                for name, (computed, saved) in checks.items(): self.compare(f"Table2/{phase}/{policy}/{name}", computed, saved, paths['stored'], fatal=True)
                for code, label in LABELS.items():
                    separate = finite_interval(population, n, counts[label])
                    details.append({'phase': phase, 'policy': policy, 'code': code, 'n': n, 'count': counts[label], 'rate': counts[label]/n,
                                    'interval_low': separate['rate_bounds'][0], 'interval_high': separate['rate_bounds'][1], 'population': population})
        formula = 'Join confirmed_review.items human_review.label with original audit_key.pools; count each separate SRSWOR frame; recompute frame size from train_tool_ids and pre-review exclusions/pools; exact equal-tailed95% hypergeometric-tail inversion; residual=(upper population count-direct observed removals)/remaining population'
        self.table('original', 'table2_historical_audit', rows, inputs, formula,
                   {k: ('fraction [0,1]' if 'rate' in k or 'interval' in k or 'upper' in k else 'pairs') for k in rows[0] if k not in ('phase','policy','provenance','current_independent_human_status')},
                   notes='Historical AI-assisted student confirmation; no independent double annotation; frames are not pooled; intervals exclude annotation error, are pointwise, and concern candidate pairs rather than realized training exposures')
        self.table('original','table2_separate_label_intervals',details,inputs,formula,{k:'fraction [0,1]' for k in ('rate','interval_low','interval_high')})
        self.paper_rows['Table 2'] = [[r['phase']+' / '+('Random' if r['policy']=='random' else 'BM25'),str(r['N']),str(r['V']),str(r['U']),f"{100*r['combined_ambiguity_rate']:.0f}%",f"[{100*r['interval_low']:.1f}, {100*r['interval_high']:.1f}]"] for r in rows]

    def summarize(self, root, side, split, pilot=False):
        data = root / ('data/prepared' if pilot else 'data/main_20261025')
        query_path, corpus_path = data/('test.json' if split=='official_test' else 'dev.json'), data/('test_corpus.json' if split=='official_test' else 'corpus.json')
        queries, corpus = read(query_path), read(corpus_path)
        folder = root / ('results/audited_pilot_20261025' if pilot else 'results/main_20261025')
        if split == 'official_test': folder /= 'official_test'
        runs = PILOT_RUNS if pilot else RUNS
        inputs, results, calculations, predictions, raw_metrics = [query_path,corpus_path], {}, {}, {}, {}
        per_query = []
        for run in runs:
            prediction_path, metrics_path = folder/run/'predictions.json', folder/run/'metrics.json'
            require(prediction_path.is_file() and metrics_path.is_file(), side+'/'+split+'/'+run+' missing actual output')
            checked = validate_predictions(prediction_path, queries, corpus, metrics_path)
            require(checked['passed'], side+'/'+split+'/'+run+': '+str(checked['faults'][:3]))
            results[run], calculations[run], predictions[run], raw_metrics[run] = checked['means'], checked['calculated'], checked['predictions'], read(metrics_path)
            require(raw_metrics[run]['n']==len(queries), 'Saved metric n mismatch')
            require(raw_metrics[run]['candidate_tools']==len(corpus), 'Saved candidate count mismatch')
            inputs += [prediction_path, metrics_path]
            per_query += [{'run_id':run, 'id':row['id'], 'track':q.get('track','development'), 'category':q.get('category','unknown'), 'n_positives':len(q['positives']), **{m:row[m] for m in METRICS}} for row,q in zip(checked['calculated'],queries)]
        evidence_side = 'historical_pilot' if pilot else side
        perquery_path=self.out/evidence_side/(split+'_per_query_metrics.csv.gz')
        write_csv(perquery_path,per_query)
        self.register_extra(perquery_path,inputs,'Per-query independent top10 set intersection and first-positive reciprocal rank',{m:'fraction [0,1]' for m in METRICS},
                            {'run_id':'run directory and metrics.run_id','id':'predictions[*].id joined frozen queries[*].id','track':'queries[*].track','category':'queries[*].category','n_positives':'len(queries[*].positives)',**{m:'predictions[*].top10; frozen queries[*].positives' for m in METRICS}})
        groups = {name:[r.replace('M','A',1) for r in rs] if pilot else rs for name,rs in GROUPS.items()}
        summary_rows=[]
        for name, members in groups.items():
            for metric in METRICS:
                values=[results[r][metric] for r in members]
                summary_rows.append({'method':name,'metric':metric,'n':len(queries),'seeds_n':len(members) if len(members)>1 else 0,'mean':mean(values),'sample_sd':float(np.std(values,ddof=1)) if len(values)>1 else None,'runs':';'.join(members),'evidence_type':'HISTORICAL_PILOT' if pilot else side.upper()})
        name = ('table4_test' if split=='official_test' else 'table6_development') if not pilot else 'pilot_development_results'
        self.table(evidence_side,name,summary_rows,inputs,'Each query Recall@k=|set(top[:k]) intersect original positives|/|positives|, MRR@10=1/first positive rank or0; query-macro mean perrun; method mean and sampleSD(ddof1) across actual3 seeds; baselines counted once',{'mean':'fraction [0,1]','sample_sd':'fraction [0,1]','n':'queries','seeds_n':'training seeds'})
        differences=np.array([[b['recall@5']-a['recall@5'] for a,b in zip(calculations[rr],calculations[hr])] for rr,hr in zip(groups['Random'],groups['Hard'])]); delta=differences.mean(axis=0)
        rng=np.random.default_rng(50042); boot=[float(delta[rng.integers(0,len(delta),len(delta))].mean()) for _ in range(5000)]
        clusters={}
        for i,q in enumerate(queries): clusters.setdefault(norm(q['query']),[]).append(i)
        cluster_ci=None
        if len(clusters)<len(queries):
            sums=np.array([delta[ix].sum() for ix in clusters.values()]); sizes=np.array([len(ix) for ix in clusters.values()]); rng=np.random.default_rng(50043); cb=[]
            for _ in range(5000):
                ix=rng.integers(0,len(sizes),len(sizes)); cb.append(float(sums[ix].sum()/sizes[ix].sum()))
            cluster_ci=np.quantile(cb,[.025,.975]).tolist()
        uncertainty={'split':split,'n':len(queries),'normalized_query_groups':len(clusters),'seed_pair_n':3,'mean_delta_recall5':float(delta.mean()),'seed_delta_sample_sd':float(np.std(differences.mean(axis=1),ddof=1)),
                     'query_bootstrap_95':np.quantile(boot,[.025,.975]).tolist(),'cluster_bootstrap_95':cluster_ci,'replicates':5000,'query_seed':50042,'cluster_seed':50043,
                     'cluster_estimator':'query-weighted resampling of all normalized text groups, preserving first-appearance group order','scope':'Conditional on three fitted seed pairs and fixed labels; not all training/annotation/selection uncertainty','cluster_missing_reason':'No repeated normalized-query groups; original code did not report clusterCI' if cluster_ci is None else None}
        self.table(evidence_side,split+'_paired_uncertainty',[uncertainty],inputs,'Same frozen bootstrap algorithms and seeds as archived analyze_main_study/analyze_audited; independently computed per-query differences; percentile quantile linear',{'mean_delta_recall5':'fraction difference','seed_delta_sample_sd':'fraction difference'})
        paired=[{'seed':s,'random':results[rr]['recall@5'],'hard':results[hr]['recall@5'],'delta':float(differences[i].mean()),'wins':int((differences[i]>0).sum()),'ties':int((differences[i]==0).sum()),'losses':int((differences[i]<0).sum())} for i,(s,rr,hr) in enumerate(zip([42,43,44],groups['Random'],groups['Hard']))]
        strata=[]
        for label, indices in [('one positive',[i for i,q in enumerate(queries) if len(q['positives'])==1]),('multiple positives',[i for i,q in enumerate(queries) if len(q['positives'])>1])]:
            row={'split':split,'positive_count_stratum':label,'n':len(indices)}
            for group in ('Random','Hard'): row[group]=mean([[calculations[r][i]['recall@5'] for i in indices] for r in groups[group]])
            row['delta']=row['Hard']-row['Random']; strata.append(row)
        self.table(evidence_side,split+'_positive_count_strata',strata,inputs,'Mean per-query independent Recall@5 across all3 seeds; strata use original label count, not number of jointly required calls',{'Random':'fraction','Hard':'fraction','delta':'fraction difference','n':'queries'})
        if side=='original':
            summary_path=folder/'summary.json'
            if summary_path.exists():
                saved=read(summary_path)
                for attr in ('query_bootstrap_95','mean_paired_delta_recall5','sample_sd_paired_delta_recall5'):
                    actual={'query_bootstrap_95':uncertainty['query_bootstrap_95'],'mean_paired_delta_recall5':uncertainty['mean_delta_recall5'],'sample_sd_paired_delta_recall5':uncertainty['seed_delta_sample_sd']}[attr]
                    if attr in saved: self.compare(evidence_side+'/'+split+'/'+attr,actual,saved[attr],summary_path)
                if not pilot: self.compare(evidence_side+'/'+split+'/clusterCI',cluster_ci,saved.get('normalized_query_cluster_bootstrap_95'),summary_path)
        item={'queries':queries,'corpus':corpus,'results':results,'calculated':calculations,'predictions':predictions,'raw_metrics':raw_metrics,'groups':groups,'inputs':inputs,'folder':folder,'paired':paired,'strata':strata,'uncertainty':uncertainty}
        self.scored[(evidence_side,split)]=item
        if side=='original' and not pilot:
            self.paper_rows['Table 4' if split=='official_test' else 'Table 6']=[[name]+[f"{100*mean([results[r][m] for r in members]):.2f}"+(f" ({100*float(np.std([results[r][m] for r in members],ddof=1)):.2f})" if len(members)>1 else '') for m in METRICS] for name,members in groups.items()]
        self.verifications.append({'check':'independent_saved_ranking_metrics','side':evidence_side,'split':split,'prediction_files':len(runs),'query_rows':len(queries)*len(runs),'passed':True})
        return item

    def paired_and_tracks(self, side, dev, test):
        rows=[{'seed':a['seed'],'development_random':a['random'],'development_hard':a['hard'],'development_delta':a['delta'],'test_random':b['random'],'test_hard':b['hard'],'test_delta':b['delta'],'test_query_wins':b['wins'],'test_query_ties':b['ties'],'test_query_losses':b['losses']} for a,b in zip(dev['paired'],test['paired'])]
        self.table(side,'table5_paired_seeds',rows,dev['inputs']+test['inputs'],'All three prescribed paired seeds; hard-minus-random mean per-query Recall@5 difference; no favorable-seed selection',{k:'fraction difference' if 'delta' in k else 'fraction [0,1]' for k in rows[0] if k.startswith(('development','test')) and 'query' not in k})
        tracks=[]
        for track in sorted({q.get('track','development') for q in test['queries']}):
            indices=[i for i,q in enumerate(test['queries']) if q.get('track','development')==track]
            row={'track':track,'n':len(indices)}
            for name,members in test['groups'].items(): row[name]=mean([[test['calculated'][r][i]['recall@5'] for i in indices] for r in members])
            row['Hard_minus_Random']=row['Hard']-row['Random']; tracks.append(row)
        require(sum(r['n'] for r in tracks)==len(test['queries']),'Track coverage missing')
        self.table(side,'tableA1_all_tracks',tracks,test['inputs'],'All released tracks; Recall@5 independently recomputed with common pooled catalogue; descriptive subgroup means, no multiplicity-adjusted inference',{k:'fraction [0,1]' for k in GROUPS}|{'Hard_minus_Random':'fraction difference','n':'queries'})
        if side=='original':
            self.paper_rows['Table 5']=[[str(r['seed']),f"{100*r['development_random']:.2f}",f"{100*r['development_hard']:.2f}",f"{100*r['test_random']:.2f}",f"{100*r['test_hard']:.2f}",f"{100*r['test_delta']:+.2f}"] for r in rows]
            self.paper_rows['Table A1']=[[r['track'],str(r['n'])]+[f"{100*r[k]:.2f}" for k in GROUPS]+[f"{100*r['Hard_minus_Random']:+.2f}"] for r in tracks]

    def token_lengths(self):
        root=self.original; corpus_path=root/'data/main_20261025/test_corpus.json'; tokenizer_path=root/'data/raw/model/tokenizer.json'
        docs=read(corpus_path); tokenizer=Tokenizer.from_file(str(tokenizer_path)); tokenizer.no_truncation();tokenizer.no_padding()
        lengths={}
        for start in range(0,len(docs),128):
            batch=docs[start:start+128]; enc=tokenizer.encode_batch([json.dumps(d['raw'],ensure_ascii=False,sort_keys=True) for d in batch],add_special_tokens=True)
            lengths.update({d['id']:len(e.ids) for d,e in zip(batch,enc)})
        recorded=root/'results/main_20261025/test_tools_full_raw_token_lengths.json'; saved=read(recorded)
        require(set(saved)==set(lengths),'Raw token length ID coverage mismatch')
        differences=[{'id':k,'computed':v,'stored':saved[k]} for k,v in lengths.items() if saved[k]!=v]
        require(not differences,'Reference tokenizer count differs from recorded raw JSON token lengths: '+str(differences[:3]))
        target=self.out/'common/recomputed_test_raw_tool_token_lengths.json';write(target,lengths)
        self.register_extra(target,[corpus_path,tokenizer_path],'Each full raw JSON sorted-key serialization encoded by frozen fast E5 tokenizer, specials included, no prefix/truncation',{'tool_token_length':'E5 tokens'},
                            {'tool_id':'corpus[*].id','tool_token_length':'corpus[*].raw; tokenizer.json entire vocabulary and postprocessor'})
        self.verifications.append({'check':'all_full_raw_tool_token_lengths_independently_tokenized','n':len(lengths),'differences':len(differences),'passed':True,'tokenizer_sha256':sha(tokenizer_path),'rule':'json.dumps(raw, ensure_ascii=False, sort_keys=True), no prefix/truncation, special tokens included'})
        return lengths,[corpus_path,tokenizer_path,recorded]

    def candidate_budget(self,root,side,dev,test,lengths,token_inputs):
        selection_path=root/'results/main_20261025/official_test/development_selection.json'; selection=read(selection_path)
        require(set(selection['groups'])==set(GROUPS),'Unknown candidate budget methods')
        target=dev['results']['M02_pretrained']['recall@10'];self.compare(side+'/selection_target',target,selection['target'],selection_path,fatal=True)
        rows, perquery=[] ,[]
        for name,members in GROUPS.items():
            fixed=selection['groups'][name]; require(fixed['runs']==members,'Frozen candidate-budget run identity mismatch')
            computed_k=next((k for k in [1,3,5,10] if mean([dev['results'][r][f'recall@{k}'] for r in members])>=target),None)
            self.compare(side+'/development_selected_k/'+name,computed_k,fixed['selected_k'],selection_path,fatal=True)
            k=fixed['selected_k']
            recalls=[];tokens=[]
            if k:
                for run in members:
                    for row,calc in zip(test['predictions'][run],test['calculated'][run]):
                        total=sum(lengths[t] for t in row['top10'][:k]); recalls.append(calc[f'recall@{k}']);tokens.append(total)
                        perquery.append({'method':name,'run_id':run,'id':row['id'],'frozen_k':k,'recall_at_k':calc[f'recall@{k}'],'raw_tool_token_sum':total})
            rows.append({'method':name,'selected_k':k,'target_development_recall10':target,'test_recall_at_k':mean(recalls) if recalls else None,'mean_test_raw_tool_tokens':mean(tokens) if tokens else None,
                         'selection_source':self.resolver.display(selection_path),'proxy':'Full raw tool JSON token volume; excludes prompt/query/fees/agent execution','selection_timestamp':selection['frozen_at']})
        selected_at=datetime.fromisoformat(selection['frozen_at'])
        require(all(datetime.fromisoformat(m['finished_at'])<=selected_at for m in dev['raw_metrics'].values()),'Development selection precedes a dev evaluation completion')
        for run,m in test['raw_metrics'].items():
            require(selected_at<=datetime.fromisoformat(m['finished_at']),'Test completed before budget selection')
            require(m['selection_sha256']==sha(selection_path),'Test uses different frozen selection')
        perquery_path=self.out/side/'table7_per_query_token_sources.csv.gz';write_csv(perquery_path,perquery)
        self.register_extra(perquery_path,dev['inputs']+test['inputs']+token_inputs+[selection_path],'Sum full raw document token lengths over fixed pre-test selected topk; independently scored query Recall@k',
                            {'recall_at_k':'fraction','raw_tool_token_sum':'E5 tokens','frozen_k':'tools'},
                            {'method':'selection.groups','run_id':'selection.groups[*].runs','id':'predictions[*].id','frozen_k':'selection.groups[*].selected_k','recall_at_k':'predictions[*].top10; frozen positives','raw_tool_token_sum':'top10[:k] IDs joined independently tokenized corpus.raw'})
        self.table(side,'table7_frozen_budget_and_tokens',rows,dev['inputs']+test['inputs']+token_inputs+[selection_path],'Use saved pre-test selection; independently verify smallest k∈{1,3,5,10} reaching pretrained dev Recall@10; re-score original test labels at fixed k; sum independently tokenized complete raw tool JSON lengths for each returned ID, then mean over queries/runs',{'selected_k':'tools','target_development_recall10':'fraction','test_recall_at_k':'fraction','mean_test_raw_tool_tokens':'reference E5 tokens'})
        if side=='original':self.paper_rows['Table 7']=[[r['method'],str(r['selected_k']) if r['selected_k'] else 'Not reached',f"{100*r['test_recall_at_k']:.2f}" if r['selected_k'] else '-',f"{r['mean_test_raw_tool_tokens']:,.0f}" if r['selected_k'] else '-'] for r in rows]

    def settings_resources_latency(self,root,side,dev,test):
        folder=root/'results/main_20261025'; inputs=[]; rows=[]; resource=[]
        for name in ['config.json','config_clarified.json']:
            path=folder/name
            if not path.exists():continue
            inputs.append(path)
            for field,value in read(path).items(): rows.append({'scope':name,'field':field,'value':value,'status':'recorded_metadata_not_reexecution_measurement','source':self.resolver.display(path)})
        env_path=root/'logs/environment.json' if side=='original' else self.resolver.resolve('environment/environment.json',must_exist=False)
        if side!='original' and not env_path.exists(): env_path=self.resolver.publication.parent/'environment/environment.json'
        require(env_path.is_file(),'Actual '+side+' environment capture missing')
        inputs.append(env_path)
        for field,value in read(env_path).items(): rows.append({'scope':'actual_environment','field':field,'value':value,'status':'historical_original_machine' if side=='original' else 'current_reproduction_machine','source':self.resolver.display(env_path)})
        runtime=read(env_path);startup=read(folder/'config.json')
        for field in ['python','torch','gpu','cuda_runtime']:
            actual=runtime.get(field,runtime.get('versions',{}).get(field))
            if field in startup and actual is not None and actual!=startup[field]:
                self.discrepancies.append({'location':side+'/startup_config_vs_actual_environment/'+field,'status':'INHERITED_METADATA_DIFFERENCE','recorded_config':startup[field],'actual_environment':actual,
                                           'sources':[self.source(folder/'config.json'),self.source(env_path)],'impact':'Use actual machine capture for runtime; unchanged legacy engine inherits some startup metadata'})
        code_path=root/'scripts/main_training_engine.py'; code=code_path.read_text(encoding='utf-8');tree=ast.parse(code)
        inputs.append(code_path)
        adam=[node for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='AdamW']
        require(len(adam)==1,'AdamW source declaration ambiguous')
        for kw in adam[0].keywords:
            rows.append({'scope':'frozen_training_code','field':'AdamW.'+kw.arg,'value':ast.literal_eval(kw.value),'status':'literal_execution_code','source':self.resolver.display(code_path)+':'+str(adam[0].lineno)})
        # Extract execution literals rather than trusting the manuscript/config text.
        executed={}
        for node in ast.walk(tree):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='range' and len(node.args)==3 and isinstance(node.args[1],ast.Call):
                length=node.args[1]
                if isinstance(length.func,ast.Name) and length.func.id=='len' and len(length.args)==1 and isinstance(length.args[0],ast.Name):
                    name=length.args[0].id
                    if name in ('schedule','batch'):executed['effective_batch' if name=='schedule' else 'microbatch']=ast.literal_eval(node.args[2])
            if isinstance(node,ast.DictComp) and isinstance(node.value,ast.Call):
                if any(k.arg=='max_length' for k in node.value.keywords):
                    prefix=node.value.args[0].left.value
                    maximum=next(ast.literal_eval(k.value) for k in node.value.keywords if k.arg=='max_length')
                    executed['query_max_tokens' if prefix=='query: ' else 'tool_max_tokens']=maximum
                    executed['query_prefix' if prefix=='query: ' else 'tool_prefix']=prefix
            if isinstance(node,ast.Assign):
                if any(isinstance(t,ast.Name) and t.id=='logits' for t in node.targets):
                    require(isinstance(node.value,ast.BinOp) and isinstance(node.value.op,ast.Div),'Temperature expression changed')
                    executed['temperature']=ast.literal_eval(node.value.right)
                for target in node.targets:
                    if isinstance(target,ast.Attribute) and target.attr=='allow_tf32':executed[ast.unparse(target)]=ast.literal_eval(node.value)
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='clip_grad_norm_':executed['clip_grad_norm']=ast.literal_eval(node.args[1])
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='autocast':executed['autocast_dtype']=next(ast.unparse(k.value) for k in node.keywords if k.arg=='dtype')
        require(executed.get('effective_batch')==32 and executed.get('microbatch')==8,'Legacy batch code changed')
        executed['accumulation']=executed['effective_batch']//executed['microbatch']
        for field,value in executed.items():
            rows.append({'scope':'frozen_training_code','field':field,'value':value,'status':'actual_execution_literal_from_AST','source':self.resolver.display(code_path)})
            if field in startup:self.compare(side+'/execution_code_vs_startup/'+field,value,startup[field],folder/'config.json',fatal=True)
        base_code_path=root/'scripts/experiment.py';inputs.append(base_code_path)
        base_code=base_code_path.read_text(encoding='utf-8');base_tree=ast.parse(base_code)
        for function in [node for node in ast.walk(base_tree) if isinstance(node,ast.FunctionDef) and node.name in ('pooling','load_model')]:
            rows.append({'scope':'frozen_encoder_code','field':function.name,'value':ast.get_source_segment(base_code,function),'status':'literal_execution_source_no_model_loaded','source':self.resolver.display(base_code_path)+':'+str(function.lineno)})
        for i,run in enumerate(RUNS[2:]):
            training_path,config_path,loss_path=folder/run/'training.json',folder/run/'config.json',folder/run/'loss.jsonl'
            training,config=read(training_path),read(config_path); losses=[json.loads(line) for line in loss_path.read_text().splitlines() if line.strip()]
            inputs += [training_path,config_path,loss_path]
            require(len(losses)==training['steps']==625 and [r['step'] for r in losses]==list(range(1,626)),'Training update trace invalid: '+run)
            require(all(math.isfinite(r['loss']) and math.isfinite(r['grad_norm']) for r in losses),'Nonfinite loss/grad norm')
            schedule_path=root/f"data/main_20261025/shared_schedule_seed{training['seed']}.json";schedule=read(schedule_path);inputs.append(schedule_path)
            require(sha(schedule_path)==training['schedule_sha256'],'Schedule binding differs')
            require(len(schedule)==training['queries']*training['epochs'],'Query exposure count differs')
            negatives_path=root/f"data/main_20261025/negatives_seed{training['seed']}.json";negative_rows=read(negatives_path);inputs.append(negatives_path)
            require(sha(negatives_path)==training['negative_manifest_sha256'],'Negative list binding differs')
            negative_counts=sorted({len(ns[training['policy']]) for ns in negative_rows.values()})
            require(negative_counts==[startup['negative_per_query']],'Actual negative count differs from startup')
            rows.append({'scope':run,'field':'negative_count_per_query','value':negative_counts,'status':'actual_frozen_negative_lists','source':self.resolver.display(negatives_path)})
            self.compare(side+'/'+run+'/loss_mean',mean([r['loss'] for r in losses]),training['mean_loss'],training_path,fatal=True)
            self.compare(side+'/'+run+'/loss_first',losses[0]['loss'],training['first_loss'],training_path,fatal=True)
            self.compare(side+'/'+run+'/loss_last',losses[-1]['loss'],training['last_loss'],training_path,fatal=True)
            require(training['embedding_weight_change_l2']>0,'No parameter change recorded')
            for field,value in {**config,**training,'actual_loss_records':len(losses),'query_exposures':len(schedule)}.items():rows.append({'scope':run,'field':field,'value':value,'status':'actual_run_record','source':self.resolver.display(training_path)})
            m=test['raw_metrics'][run]
            resource.append({'run_id':run,'seed':training['seed'],'policy':training['policy'],'train_seconds':training['train_seconds'],'peak_allocated_GiB':training['peak_allocated_GiB'],'mean_loss':mean([r['loss'] for r in losses]),
                             'first_loss':losses[0]['loss'],'last_loss':losses[-1]['loss'],'steps':len(losses),'query_exposures':len(schedule),'test_index_seconds':m.get('index_seconds'),
                             'test_query_encoding_seconds':m.get('query_encoding_seconds'),'test_search_seconds':m.get('search_seconds'),'test_total_evaluation_seconds':m.get('total_evaluation_seconds'),'test_peak_allocated_GiB':m.get('peak_eval_allocated_GiB'),
                             'evidence_type':side.upper(),'training_boundary':'Tokenization precedes measured training; corpus embedding/evaluation excluded; read frozen source code','loss_comparability':'Different negative sets; loss is not a common retrieval-quality metric'})
        self.table(side,'table3_settings_and_actual_environment',rows,inputs,'Read all planned/clarified metadata separately; actual run budgets from training+loss+schedule, actual environment from that machine capture, optimizer literal kwargs from AST of frozen source; never overwrite stale flags',notes='Source config inherited pilot=true, seed42-only RNG metadata and pre-test flags can be stale; actual records and clarification remain separate')
        self.table(side,'table8_training_and_test_resources',resource,inputs+test['inputs'],'Measured times and peak allocated memory from original raw run records; mean/first/last loss independently computed from all625 finite perstep rows; no original/new hardware mixing',{'train_seconds':'seconds','peak_allocated_GiB':'GiB allocated','mean_loss':'cross entropy','first_loss':'cross entropy','last_loss':'cross entropy','steps':'updates','query_exposures':'examples','test_index_seconds':'seconds','test_query_encoding_seconds':'seconds','test_search_seconds':'seconds','test_total_evaluation_seconds':'seconds','test_peak_allocated_GiB':'GiB allocated'})
        prep=root/'data/main_20261025/preparation.json'
        prep_record=read(prep)
        prep_rows=[{'phase':name,'seconds':prep_record.get(name),'evidence_type':'HISTORICAL_FROZEN_PREPARATION_REUSED' if side=='reproduction' else 'ORIGINAL_MEASUREMENT','new_reexecution':False if side=='reproduction' else None,'scope':'Frozen data preparation record; not a timing of this reproduction run'} for name in ('bm25_index_seconds','mining_seconds','preparation_seconds')]
        self.table(side,'table8_frozen_preparation_costs',prep_rows,[prep],'Read phase timers from frozen preparation.json; explicitly historical/reused on reproduction side; never substitute new-machine timing',{'seconds':'seconds'})
        latencies=[];lat_inputs=[];raw=[]
        reference_ids=None
        for run in RUNS:
            path=test['folder']/run/'latency_ms.json'; values=read(path);m=test['raw_metrics'][run];ids=m.get('latency_query_ids')
            require(isinstance(values,list) and values and all(isinstance(v,(int,float)) and math.isfinite(v) and v>=0 for v in values),'Invalid raw latency')
            require(ids is not None and len(values)==len(ids)==128 and len(set(ids))==len(ids),'Official timing requires128 unique recorded query IDs')
            if reference_ids is None:reference_ids=ids
            require(ids==reference_ids,'Timing methods did not use same query sequence')
            median,p95=float(np.median(values)),float(np.percentile(values,95))
            self.compare(side+'/'+run+'/latency_median',median,m['latency_ms_median'],test['folder']/run/'metrics.json',fatal=True)
            self.compare(side+'/'+run+'/latency_p95',p95,m['latency_ms_p95'],test['folder']/run/'metrics.json',fatal=True)
            latencies.append({'run_id':run,'n':len(values),'median_ms':median,'p95_ms':p95,'mean_ms':mean(values),'boundary':m.get('latency_boundary'),'warmups':5,'batches':1,'query_ids_sha256':hashlib.sha256(json.dumps(ids,ensure_ascii=False).encode()).hexdigest()})
            raw += [{'run_id':run,'query_id':qid,'order':i,'latency_ms':v} for i,(qid,v) in enumerate(zip(ids,values))];lat_inputs += [path,test['folder']/run/'metrics.json']
        raw_path=self.out/side/'table9_raw_latency_queries.csv.gz';write_csv(raw_path,raw)
        self.register_extra(raw_path,lat_inputs,'Raw measured timing vector aligned by index to saved latency_query_ids; no estimates or averaging',{'latency_ms':'milliseconds','order':'zero-based position'},
                            {'run_id':'metrics.run_id','query_id':'metrics.latency_query_ids[*]','order':'latency vector index','latency_ms':'latency_ms.json[*]'})
        self.table(side,'table9_latency_per_run',latencies,lat_inputs,'Median and linear95th percentile recomputed from each raw128-item latency vector, then methods share identical ID order;5 warmups documented in frozen source; dense timing uses exact scores+topk while saved rankings use stable full sort',{'median_ms':'milliseconds','p95_ms':'milliseconds','mean_ms':'milliseconds','n':'queries','warmups':'queries'})
        group_rows=[]
        for name,members in GROUPS.items():
            selected=[r for r in latencies if r['run_id'] in members]
            group_rows.append({'method':name,'runs':';'.join(members),'n_runs':len(members),'mean_of_run_medians_ms':mean([r['median_ms'] for r in selected]),'mean_of_run_p95_ms':mean([r['p95_ms'] for r in selected]),'aggregation':'Mean of perrun quantiles, not quantile of pooled measurements'})
        self.table(side,'table9_method_latency',group_rows,lat_inputs,'Original Table9 aggregation: arithmetic mean of independently recomputed perrun median/p95, using baseline once and all3 trained seeds',{'mean_of_run_medians_ms':'milliseconds','mean_of_run_p95_ms':'milliseconds','n_runs':'runs'})
        if side=='original':
            self.paper_rows['Table 8']=[[r['run_id'],f"{r['train_seconds']:.1f}",f"{r['peak_allocated_GiB']:.2f}",f"{r['mean_loss']:.4f}",f"{r['test_index_seconds']:.1f}"] for r in resource]
            self.paper_rows['Table 9']=[[r['method'],f"{r['mean_of_run_medians_ms']:.2f}",f"{r['mean_of_run_p95_ms']:.2f}"] for r in group_rows]

    def artifact_map(self,root,side):
        rows=[]
        specs={'frozen_main_data':'data/main_20261025','main_dev_outputs':'results/main_20261025','official_test':'results/main_20261025/official_test','run_log':'results/main_20261025/experiment_log.csv','source_code':'scripts','actual_process_logs':'logs'}
        if side=='original': specs.update(historical_pilot_data='data/audited_pilot_20261025',historical_pilot_results='results/audited_pilot_20261025',historical_pilot_audit='results/human_audit_20261025',historical_expanded_audit='results/main_human_audit_20261025',paper_prose='paper/manuscript_sections.json',paper_rendered_tables='paper/rendered_blocks.json')
        for artifact,rel in specs.items():
            path=root/rel; files=[path] if path.is_file() else [p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts] if path.is_dir() else []
            rows.append({'artifact':artifact,'relative_path':self.resolver.display(path),'exists':path.exists(),'files':len(files),'bytes':sum(p.stat().st_size for p in files),'evidence_type':side.upper(),'missing_reason':None if path.exists() else 'Not included/generated in this source snapshot; no fictitious original-machine path used'})
        self.table(side,'tableB1_actual_artifact_locations',rows,[p for p in self.sources if p.is_relative_to(root)],'Inventory actual source paths visible to this invocation; portable relative locations, counts and bytes; existence does not imply large omitted checkpoints were delivered',{'files':'files','bytes':'bytes'})

    def figures(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.lines import Line2D
        for side in ['original']+(['reproduction'] if self.reproduction else []):
            pilot=self.scored[('historical_pilot','development')];dev=self.scored[(side,'development')];test=self.scored[(side,'official_test')]
            fig,axes=plt.subplots(1,3,figsize=(10,3.3),layout='constrained')
            for ax,label,item in zip(axes,['Historical pilot (not rerun)',side+' development',side+' observed test'],[pilot,dev,test]):
                for row,marker in zip(item['paired'],['o','s','^']):
                    ax.plot([0,1],[100*row['random'],100*row['hard']],color='#777777',alpha=.6);ax.scatter([0,1],[100*row['random'],100*row['hard']],c=['#23618f','#bc6324'],marker=marker,s=28)
                ax.set_xticks([0,1],['Random','BM25 negative']);ax.set_title(label,fontsize=9);ax.set_ylabel('Recall@5 (%)');ax.grid(axis='y',alpha=.2)
            fig.legend(handles=[Line2D([],[],color='#666666',marker=marker,linestyle='None',markersize=5,label=f'Seed {seed}') for seed,marker in zip([42,43,44],['o','s','^'])],
                       loc='outside upper center',ncol=3,frameon=False,fontsize=8)
            self.save_figure(fig,side,'figure1_paired_recall',pilot['inputs']+dev['inputs']+test['inputs'],'All three fixed seed pairs; pilot shown as historical even in reproduction panel; axes may have different scales')
            fig,axes=plt.subplots(1,2,figsize=(9,3.25),layout='constrained')
            fig.suptitle('Mean Recall@5 across seeds 42–44',fontsize=11)
            for ax,label,item in zip(axes,['Development','Observed test'],[dev,test]):
                x=np.arange(2); ax.bar(x-.18,[100*r['Random'] for r in item['strata']],.36,label='Random',color='#23618f');ax.bar(x+.18,[100*r['Hard'] for r in item['strata']],.36,label='BM25 negatives',color='#bc6324')
                ax.set_xticks(x,[f"{r['positive_count_stratum']}\n(n={r['n']:,})" for r in item['strata']]);ax.set_ylim(0,100);ax.set_ylabel('Recall@5 (%)');ax.set_title(label);ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2)
            self.save_figure(fig,side,'figure2_positive_count_strata',dev['inputs']+test['inputs'],'Mean across seeds42–44, all queries; original label-count strata are not required-call counts')

    def save_figure(self,fig,side,name,inputs,formula):
        import matplotlib.pyplot as plt
        outputs=[]
        for suffix in ['png','pdf']:
            path=self.out/side/'figures'/(name+'.'+suffix);path.parent.mkdir(parents=True,exist_ok=True);fig.savefig(path,dpi=220);outputs.append({'path':path.relative_to(self.out).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
        plt.close(fig)
        self.evidence.append({'table_id':side+'/'+name,'outputs':outputs,'fields':{'x_y':{'input_files':[self.source(p,'top10 + frozen positives + seed/run IDs') for p in inputs],'formula':formula,'unit':'Recall@5 percent'}},'formula':formula,'script':{'path':Path(__file__).name,'sha256':sha(__file__)}})

    def published_checks(self):
        path=self.original/'paper/rendered_blocks.json'
        if path.exists():
            checks=[]
            for block in read(path):
                if block.get('kind')!='table':continue
                name=block['caption'].split('.')[0]
                if name not in self.paper_rows: continue
                actual=self.paper_rows[name];stored=block['rows'];same=actual==stored
                checks.append({'table':name,'same_displayed_rows':same,'computed_rows':actual,'published_rows':stored,'source':self.source(path)})
                if not same:self.discrepancies.append({'location':'published/'+name,'status':'PUBLISHED_DISPLAY_DIFFERS','source':self.source(path),'details_in':'published_table_checks.json'})
            write(self.out/'published_table_checks.json',checks)
        # Explicit contradictions are retained rather than silently rewriting source metadata.
        config_path=self.original/'results/main_20261025/config.json';config=read(config_path)
        clarified_path=self.original/'results/main_20261025/config_clarified.json';clarified=read(clarified_path)
        for key in ['pilot','official_test_evaluation','additional_negative_mask']:
            if config.get(key)!=clarified.get(key):self.discrepancies.append({'location':'original_config/'+key,'status':'PRESERVED_HISTORICAL_METADATA_CLARIFICATION','recorded_startup':config.get(key),'clarified_companion':clarified.get(key),'sources':[self.source(config_path),self.source(clarified_path)],'impact':'Metadata interpretation only; independent predictions and frozen inputs remain unchanged'})
        prep=self.original/'data/main_20261025/preparation.json'
        if read(prep).get('fresh_human_review_status')=='pending':self.discrepancies.append({'location':'preparation/fresh_human_review_status','status':'HISTORICAL_PRE_REVIEW_STATUS_RETAINED','source':self.source(prep),'impact':'Later archived student batch attestation exists; this historical pending flag does not mean current independent human review completed'})

    def interpretations(self):
        notes={
            'table1':('The pilot, expanded development and pooled test are distinct frozen snapshots; pilot evidence remains historical.','数据规模由冻结数组实际计数；pilot采用旧dev/corpus，不能把三个阶段当相同协议扩样。'),
            'table2':('The two review rounds retain separate sampling frames and exact finite-population intervals; historical student batch attestations followed AI suggestions.','两轮候选池分别计数与求区间，不合并为总体假负例率；当前独立人审仍为0。'),
            'table3':('Execution literals, per-run traces and actual machine capture qualify inherited startup metadata.','训练源码AST、真实轨迹与环境采样分别列出；保留启动配置中的旧pilot/阶段标记，不静默修正原件。'),
            'table4':('Pooled-test performance is independently recomputed from saved top10 IDs and frozen labels; seed SD is not a query confidence interval.','正式旧测试按7961条原始记录重新计分；三种子标准差与条件查询区间分开。'),
            'table5':('Every prescribed seed pair is retained; hard-minus-random differences are descriptive effects within the fixed protocol.','保留42、43、44全部配对结果；复现同数据不能算新的独立外部验证。'),
            'table6':('Development results use the same independent scoring formulas and all three fitted seeds.','开发集完整保留1000条记录，不能用测试结果重新挑种子或候选预算。'),
            'table7':('The pre-test development-selected k is verified and preserved; full raw-document tokens are context-volume proxies only.','候选k来自先于测试冻结的选择文件；完整raw JSON token全量重算，不代表API费用或agent任务成功。'),
            'table8':('Measured training, preparation/mining, indexing and evaluation costs remain separate; different negative-set losses are not a common quality metric.','原机器和新机器资源分目录；复现使用的冻结准备耗时明确标旧测量，不能冒充此机重跑。'),
            'table9':('Latency quantiles are reconstructed from raw matched-query timings; the historical dense timing path uses topk while predictions use stable full sorting.','按相同128查询的raw latency重算每run中位数与p95，再按旧表对run取均值；计时路径边界明确披露。'),
            'tableA1':('All released tracks are retained as descriptive subgroups under the same pooled catalogue.','保留全部35个track；小track不稳定，子组差异不是经过多重检验的确认性发现。'),
            'tableB1':('The artifact map lists paths actually present under this input root; it does not claim omitted weights were delivered.','只列此次可访问的相对路径、真实数量/字节；旧权重缺失及GPU保留与跨机已交付需另外区分。')}
        rows=[]
        for item in self.evidence:
            name=item['table_id'].split('/')[-1]
            for prefix,(english,chinese) in notes.items():
                if name.startswith(prefix+'_'):
                    rows.append({'table_id':item['table_id'],'english_interpretation':english,'中文事实与边界':chinese,'status':'recomputed_from_saved_raw_evidence'});break
        write_csv(self.out/'table_interpretations.csv',rows);write(self.out/'table_interpretations.json',rows)

    def run(self):
        self.verify_freeze();self.data_table();self.audit_table()
        pilot=self.summarize(self.original,'original','development',pilot=True)
        lengths,token_inputs=self.token_lengths()
        for side,root in [('original',self.original)]+([('reproduction',self.reproduction)] if self.reproduction else []):
            dev=self.summarize(root,side,'development');test=self.summarize(root,side,'official_test')
            self.paired_and_tracks(side,dev,test);self.candidate_budget(root,side,dev,test,lengths,token_inputs)
            self.settings_resources_latency(root,side,dev,test);self.artifact_map(root,side)
        self.figures();self.published_checks();self.interpretations()
        write(self.out/'source_discrepancies.json',self.discrepancies)
        write(self.out/'table_evidence_map.json',{'schema_version':1,'input_root':str(self.resolver.root),'tables_and_figures':self.evidence,'all_input_files':[self.sources[p] for p in sorted(self.sources)],
                                               'original_never_modified':True,'historical_pilot_only':True,'new_human_completed':0,'external_final_scores_accessed':False,'no_models_loaded':True})
        status={'status':'PASS_COMPLETE_AVAILABLE_LEGACY_TABLES','original_main_prediction_files':16,'historical_pilot_prediction_files':8,'reproduction_prediction_files':16 if self.reproduction else 0,
                'reproduction_status':'COMPLETE_ACTUAL_OUTPUTS_REBUILT' if self.reproduction else 'NOT_REQUESTED_OR_PENDING; no historical outputs substituted',
                'tables_and_figures':len(self.evidence),'discrepancies':len(self.discrepancies),'verifications':self.verifications,'human_review':'HUMAN_PENDING; new independent completed0; historical attestations preserved',
                'created_at':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(__file__),'output_dir':str(self.out)}
        write(self.out/'rebuild_status.json',status)
        (self.out/'说明_解释与限制.txt').write_text('原表1–9、附录A/B和图1–2从逐题排名、冻结标签、审核条目/抽样池、实际配置/训练轨迹、raw latency及完整raw文档token独立重建。\n历史pilot只标historical，没有重训或混入新复现。两轮历史审核是AI建议后学生批量确认，当前独立人审仍0/HUMAN_PENDING。\n新复现只有明确传入且16份真实输出全部存在才读取，绝不用旧结果补齐。各表原/新分目录。\nsource_discrepancies保存旧配置/论文与实算之间差异；published_table_checks是计算完成后与旧显示值对照，不是计算输入。\n逐字段input SHA、公式、单位、筛选和输出SHA在table_evidence_map。计时基于原记录；历史密集latency是topk路径，排名另用stable full sort。Token仅上下文体量代理。\n本文中的“独立重建”指独立指标计算，不代表独立数据集、独立人工语义验证、全库向量重新编码或原权重逐bit复现。\n',encoding='utf-8')
        return status

def self_test():
    for n in [4,8,12]:
        for sample in range(1,min(n,5)+1):
            for x in range(sample+1):
                accepted=[k for k in range(n+1) if hypergeom.sf(x-1,n,k,sample)>=.025 and hypergeom.cdf(x,n,k,sample)>=.025]
                require(finite_interval(n,sample,x)['count_bounds']==[min(accepted),max(accepted)],'Finite population inversion fixture')
    require(norm(' A  b! ')==norm('a b'),'Historical query normalization')
    return {'passed':True,'checks':['brute-force small finite-population inclusive tail inversion','frozen normalized query formula']}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input-root',type=Path);ap.add_argument('--original-root',type=Path);ap.add_argument('--reproduction-root',type=Path);ap.add_argument('--include-reproduction',action='store_true');ap.add_argument('--output-dir',type=Path);ap.add_argument('--self-test',action='store_true')
    args=ap.parse_args()
    if args.self_test:print(json.dumps(self_test()));return 0
    require(args.output_dir is not None,'--output-dir required')
    input_root=(args.input_root or Path(__file__).resolve().parents[1]).resolve();resolver=Resolver(input_root)
    bundle=resolver.mapping_path.parent if resolver.mapping_path else (resolver.root if resolver.publication!=resolver.root else resolver.publication.parent)
    original=args.original_root
    if original is None:
        if (bundle/'original_reference').is_dir():original=bundle/'original_reference'
        else:
            decisions=read(resolver.publication/'locks/execution_decisions.json');original=resolver.resolve(str(Path(decisions['source'])/'archive/CPS5801_HANDOFF_20261025/CPS5801'))
    else: original=resolver.resolve(original)
    reproduction=args.reproduction_root
    if args.include_reproduction and reproduction is None: reproduction=bundle/('reproduction' if (bundle/'reproduction').is_dir() else 'repro')
    if reproduction is not None:
        reproduction=resolver.resolve(reproduction)
        missing=[str(reproduction/'results/main_20261025'/suffix/run/'predictions.json') for suffix in ('','official_test') for run in RUNS if not (reproduction/'results/main_20261025'/suffix/run/'predictions.json').is_file()]
        require(not missing,'Actual reproduction not complete; never substitute historical outputs: '+str(missing))
        for name in ('train.json','dev.json','test.json','corpus.json','test_corpus.json'):
            require(sha(original/'data/main_20261025'/name)==sha(reproduction/'data/main_20261025'/name),'Reproduction data identity mismatch: '+name)
    print(json.dumps(LegacyRebuilder(input_root,original,reproduction,args.output_dir).run(),ensure_ascii=False,indent=2));return 0

if __name__=='__main__':
    raise SystemExit(main())
