"""Freeze collision-screened external inputs. CPU only; never scores models.

The complete prefix-filter join uses exact character-set Jaccard >= 9/10.
Missing source provenance remains unknown; family signatures are only proxies.
No official ToolHop functions or evaluators are executed.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
import shutil
import sys
import time
import unicodedata


def canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(canon(row) + "\n")


def lines(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8").splitlines() if s.strip()]


def norm(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Query must be a non-empty string")
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def variants(text, messages=None):
    """Preserve full context, remove fixed wrappers, and compare user-only text."""
    result = {"full_context": norm(text)}
    wrapperless = re.sub(r"(?im)^\s*(?:user|system)\s*:\s*", "", text)
    result["without_role_wrappers"] = norm(wrapperless)
    if messages:
        user = "\n".join(m["content"] for m in messages if m["role"] == "user")
        if user.strip():
            result["user_only"] = norm(user)
    else:
        # Segment only explicit line-start user/system wrappers. Ordinary prose
        # containing the words is unaffected.
        matches = list(re.finditer(r"(?im)^\s*(user|system)\s*:\s*", text))
        if matches:
            user_parts = []
            for i, match in enumerate(matches):
                if match.group(1).casefold() == "user":
                    user_parts.append(text[match.end():matches[i + 1].start() if i + 1 < len(matches) else len(text)])
            if "\n".join(user_parts).strip():
                result["user_only"] = norm("\n".join(user_parts))
    return result


def grams(text):
    # Short strings receive their full normalized text as one nonempty token.
    return frozenset(text[i:i + 5] for i in range(max(1, len(text) - 4)))


class PrefixJoin:
    """Exact complete set-similarity join with a fixed global token order.

    At Jaccard >= .9, intersection >= ceil(.9*max(|A|,|B|)).
    Therefore prefixes |S|-ceil(.9*|S|)+1 under the same total order intersect.
    Tokens absent from the indexed collection sort first (frequency zero).
    This is an exact candidate filter, not MinHash/LSH.
    """
    def __init__(self, texts):
        self.sets = [grams(t) for t in texts]
        self.frequency = collections.Counter(g for s in self.sets for g in s)
        self.index = collections.defaultdict(list)
        for i, s in enumerate(self.sets):
            for gram in self.prefix(s):
                self.index[gram].append(i)
        self.candidates_verified = 0

    def prefix(self, values):
        length = len(values) - (9 * len(values) + 9) // 10 + 1
        return sorted(values, key=lambda g: (self.frequency.get(g, 0), g))[:length]

    def find(self, text):
        s = grams(text)
        candidates = set(itertools.chain.from_iterable(self.index.get(g, ()) for g in self.prefix(s)))
        found = []
        for i in candidates:
            other = self.sets[i]
            if 10 * min(len(s), len(other)) < 9 * max(len(s), len(other)):
                continue
            self.candidates_verified += 1
            common = len(s & other)
            union = len(s) + len(other) - common
            if 10 * common >= 9 * union:
                found.append((i, common, union))
        return found


class DSU:
    def __init__(self, ids):
        self.parent = {i: i for i in ids}

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        self.parent[max(a, b)] = min(a, b)


def without_descriptions(value):
    if isinstance(value, dict):
        return {k: without_descriptions(v) for k, v in value.items() if k != "description"}
    if isinstance(value, list):
        return [without_descriptions(v) for v in value]
    return value


def tool_signatures(tool):
    if not isinstance(tool, dict):
        raise ValueError("Tool is not an object")
    tool = tool.get("function", tool)
    name = tool.get("name", tool.get("api_name"))
    description = tool.get("description", tool.get("api_description"))
    valid_name = isinstance(name, str) and bool(name.strip())
    # Explicit source-schema adapters mirror documented name aliases, while
    # retaining parameter representation. No absent parameter field is silently
    # replaced by an empty schema. Different schemas cannot become exact hits.
    payload = {"name": name}
    if "description" in tool or "api_description" in tool:
        payload["description"] = description
    for key in ("parameters", "required_parameters", "optional_parameters", "additional_required_arguments", "optional_arguments", "doc_arguments", "api_arguments"):
        if key in tool:
            payload[key] = tool[key]
    schema = without_descriptions(payload)
    params = tool.get("parameters")
    required = params.get("required") if isinstance(params, dict) else None
    if required is None and isinstance(tool.get("required"), list):
        required = tool["required"]
    props = params.get("properties", params) if isinstance(params, dict) else None
    if valid_name and isinstance(required, list) and isinstance(props, dict):
        if any(name not in props or not isinstance(props[name], dict) or "type" not in props[name] for name in required):
            required_signature = None
            status = "unknown_missing_required_parameter_type"
        else:
            required_signature = sha(canon([norm(name), sorted((param, canon(props[param]["type"])) for param in required)]))
            status = "explicit_required_schema"
    elif valid_name and isinstance(tool.get("required_parameters"), list) and all(isinstance(p, dict) and "name" in p and "type" in p for p in tool["required_parameters"]):
        required_signature = sha(canon([norm(name), sorted((p["name"], canon(p["type"])) for p in tool["required_parameters"])]))
        status = "explicit_required_parameters_list"
    else:
        required_signature = None
        status = "unknown_no_explicit_required_metadata"
    return {"document": sha(canon(payload)), "schema_without_descriptions": sha(canon(schema)),
            "name_required_types": required_signature, "name_only": sha(norm(name)) if valid_name else None,
            "required_signature_status": status,
            "name_status": "present_nonempty_string" if valid_name else "missing_or_empty_preserved_no_name_inferred",
            "description_status": "present_string" if isinstance(description, str) else "missing_or_nonstring_preserved_without_imputation"}


def validate_fixture():
    rng = random.Random(20261112)
    texts = ["".join(rng.choice("abcdefghijklmnop ") for _ in range(rng.randrange(1, 200))) for _ in range(100)]
    texts += [t[:-1] + "z" for t in texts if len(t) > 50]
    texts += ["a", "ab", "abc", "abcd", "abcde", "same repeated phrase " * 8]
    join = PrefixJoin(texts)
    for text in texts:
        s = grams(text)
        reference = {i for i, other in enumerate(join.sets) if 10 * len(s & other) >= 9 * len(s | other)}
        assert {i for i, _, _ in join.find(text)} == reference
    assert norm(" ＨｅＬＬＯ \n WORLD ") == "hello world"
    assert variants("user:Hello\nsystem:rules")["user_only"] == "hello"
    assert tool_signatures({"name": "f", "description": "x", "parameters": {}})["name_required_types"] is None
    assert tool_signatures({"name": "f", "description": "x", "parameters": {"properties": {}, "required": []}})["name_required_types"] is not None
    assert tool_signatures({"api_name": "f", "api_description": "x", "required_parameters": []})["name_required_types"] is not None
    assert tool_signatures({"name": "", "description": "source metadata only"})["name_only"] is None
    return {"status": "passed", "prefix_join_compared_to_brute_force": len(texts), "threshold": "9/10 exact integer comparison"}


def prepare_bfcl(package):
    root = package / "assets/bfcl"
    records, excluded = [], []
    raw_counts = {}
    for category in ("live_multiple", "multiple", "parallel_multiple"):
        data_dir = root / "berkeley-function-call-leaderboard/bfcl_eval/data"
        source = lines(data_dir / f"BFCL_v4_{category}.json")
        answers_list = lines(data_dir / "possible_answer" / f"BFCL_v4_{category}.json")
        answers = {r["id"]: r for r in answers_list}
        if len(answers) != len(answers_list) or len({r["id"] for r in source}) != len(source) or set(answers) != {r["id"] for r in source}:
            raise ValueError("BFCL original/gold ID conflict")
        raw_counts[category] = len(source)
        for row in source:
            rid = row["id"]
            if len(row["question"]) != 1:
                raise ValueError("Unsupported BFCL context")
            messages = row["question"][0]
            if any(set(m) != {"role", "content"} or not isinstance(m["content"], str) or m["role"] not in {"user", "system"} for m in messages):
                raise ValueError("Unsupported BFCL message")
            query = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
            tools = row["function"]
            names = [t["name"] for t in tools]
            calls = answers[rid]["ground_truth"]
            if not isinstance(calls, list) or any(not isinstance(c, dict) or len(c) != 1 for c in calls):
                raise ValueError("Unsupported BFCL gold structure")
            gold_names = sorted({name for call in calls for name in call})
            if len(names) != len(set(names)) or not gold_names or not set(gold_names) <= set(names):
                raise ValueError("Ambiguous BFCL gold mapping")
            if len(names) < 2 or not set(names).difference(gold_names):
                excluded.append({"id": rid, "dataset": "bfcl_" + category, "reason": "no_nonrelevant_native_candidate", "phase": "structural"})
                continue
            candidates = []
            for ordinal, tool in enumerate(tools):
                payload = {k: tool[k] for k in ("name", "description", "parameters")}
                candidates.append({"id": f"bfcl:{rid}:{ordinal}", "name": tool["name"], "text": canon(payload),
                                   "document_sha256": sha(canon(payload)), "raw": payload,
                                   "tie_break_key": sha("publication_v1|tie|" + rid + "|" + tool["name"])})
            records.append({"id": rid, "source_id": rid, "dataset": "bfcl_" + category, "category": category,
                            "query": query, "messages": messages, "query_sha256": sha(query),
                            "normalized_query_sha256": sha(norm(query)),
                            "user_only_query_sha256": sha(norm("\n".join(m["content"] for m in messages if m["role"] == "user"))),
                            "family_signature_proxy": sha(canon(sorted(norm(n) for n in names))),
                            "source_id_prefix_proxy": rid.split("-", 1)[0] if category == "live_multiple" else rid,
                            "contains_cjk_script": bool(re.search(r"[\u3400-\u9fff]", query)),
                            "contains_non_ascii": any(ord(c) > 127 for c in query),
                            "candidates": candidates, "candidate_ids": [c["id"] for c in candidates],
                            "candidate_tie_break_keys": {c["id"]: c["tie_break_key"] for c in candidates},
                            "positives": [c["id"] for c in candidates if c["name"] in gold_names],
                            "gold_function_names": gold_names,
                            "label_scope": "official_function_name_projection_not_arguments_or_execution"})
    # Verify reconstructed inputs against the handoff pre-overlap views, without
    # trusting their grouping or final-inclusion status.
    by_id = {r["id"]: r for r in records}
    for path in sorted((root / "derived_pre_overlap").glob("*.jsonl")):
        for archived in lines(path):
            actual = by_id[archived["id"]]
            for key in ("query", "positives", "gold_function_names", "family_signature_proxy"):
                if actual[key] != archived[key]:
                    raise ValueError("BFCL rebuilt input differs: " + actual["id"] + " " + key)
            for a, b in zip(actual["candidates"], archived["candidates"], strict=True):
                if any(a[key] != b[key] for key in ("id", "text", "document_sha256", "tie_break_key")):
                    raise ValueError("BFCL rebuilt candidate differs")
    return records, excluded, raw_counts


def prepare_toolhop(package):
    raw = read(package / "assets/toolhop/data/ToolHop.json")
    records, corpus = [], []
    if len({r["id"] for r in raw}) != len(raw):
        raise ValueError("ToolHop duplicate source ID")
    doc_ids = collections.defaultdict(list)
    for row in raw:
        candidates = []
        for ordinal, tool in enumerate(row["tools"].values()):
            # Outer dictionary keys, sub_task, answer, and functions are NEVER
            # passed to model-facing outputs or executed.
            if set(tool) != {"name", "description", "parameters"}:
                raise ValueError("ToolHop unexpected tool fields")
            payload = {key: tool[key] for key in ("name", "description", "parameters")}
            item = {"id": f"toolhop:{row['id']}:{ordinal}", "name": tool["name"], "text": canon(payload),
                    "raw": payload, "document_sha256": sha(canon(payload)), "source_id": row["id"], "ordinal": ordinal}
            candidates.append(item)
            corpus.append(item)
            doc_ids[item["document_sha256"]].append(item["id"])
        rid = f"toolhop_query:{row['id']}"
        records.append({"id": rid, "source_id": row["id"], "dataset": "toolhop", "query": row["question"],
                        "query_sha256": sha(row["question"]), "normalized_query_sha256": sha(norm(row["question"])),
                        "contains_cjk_script": bool(re.search(r"[\u3400-\u9fff]", row["question"])),
                        "contains_non_ascii": any(ord(c) > 127 for c in row["question"]),
                        "positives": [c["id"] for c in candidates], "candidates": candidates,
                        "family_signature_proxy": sha(canon(sorted(norm(c["name"]) for c in candidates))),
                        "label_scope": "reference_tool_ids_not_exhaustive_relevance"})
    by_id = {c["id"]: c for c in corpus}
    for row in records:
        row["equivalent_positives"] = sorted({tid for pos in row["positives"] for tid in doc_ids[by_id[pos]["document_sha256"]]})
    return records, corpus


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--package", required=True, type=Path)
    ap.add_argument("--publication", required=True, type=Path)
    ap.add_argument("--extra-python-path", type=Path)
    ap.add_argument("--fixture-only", action="store_true")
    args = ap.parse_args()
    if args.extra_python_path:
        sys.path.insert(0, str(args.extra_python_path.resolve()))
    fixture = validate_fixture()
    if args.fixture_only:
        print(canon(fixture))
        return
    import pyarrow.parquet as pq
    started = time.time()
    package, publication = args.package.resolve(), args.publication.resolve()
    source = package / "archive/CPS5801_HANDOFF_20261025/CPS5801"
    out = publication / "data/external"
    audit = out / "audit"
    locks = publication / "locks"
    if (out / "final_dataset_manifest.json").exists():
        raise FileExistsError("Frozen external manifest already exists; preserve it and use a new publication root for a new attempt")
    audit.mkdir(parents=True, exist_ok=True)
    write(audit / "fixture_results.json", fixture)
    plan = {"schema": "publication_external_audit_v1", "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "source_code_sha256": file_sha(__file__), "model_scores_accessed": False,
            "normalization": "NFKC then casefold then whitespace collapse; full/wrapperless/user-only variants; originals unchanged",
            "near_duplicate": {"gram_size": 5, "jaccard_threshold": 0.90, "integer_condition": "10*intersection>=9*union", "candidate_recall": "complete prefix-filter join under fixed total gram order; exact set verification", "full_source_scan": True, "short_strings": "whole string singleton for length<5"},
            "near_decisions": "unknown semantic equivalence; conservatively exclude entire connected exact/near task group before model selection; no AI judgment is called human",
            "family_policy": "full canonical document, schema excluding recursive description fields, explicit name+required parameter types, name-only weak proxy; absent required metadata remains unknown",
            "source_schema_adapters": "unwrap function; explicit name/api_name and description/api_description aliases; preserve parameters, required/optional_parameters, additional_required/optional_arguments, doc_arguments, api_arguments if present. Missing fields remain absent; no inferred names or required parameters. Complete-document comparison uses these documented core fields, while original full bytes remain hash-bound.",
            "source_fields": "main train/dev/old-test query and complete upstream query; prompt is auxiliary instruction and not used as training query in frozen original code",
            "source_unknown_policy": "no string/signature hit is NOT proof of source-disjointness or unseen pretraining",
            "engineering_exclusions": ["live_multiple_0-0-0", "multiple_0", "parallel_multiple_0", "toolhop_query:0"],
            "allowed_input_fields": {"bfcl_query": "all original role: content messages", "toolhop_query": "question", "document": ["name", "description", "parameters"]}}
    write(locks / "external_audit_plan.json", plan)
    input_manifest = []

    def register(path, expected=None, purpose=None):
        observed = file_sha(path)
        if expected and observed != expected:
            raise ValueError("Source hash mismatch: " + str(path))
        item = {"path": str(Path(path).relative_to(package)).replace("\\", "/"), "bytes": Path(path).stat().st_size, "sha256": observed, "purpose": purpose}
        input_manifest.append(item)
        return item

    for dataset in ("bfcl", "toolhop"):
        root = package / "assets" / dataset
        manifest = read(root / "download_manifest.json")
        register(root / "download_manifest.json", purpose="pinned_source_manifest")
        for item in manifest["files"]:
            register(root / item["path"], item["sha256"], dataset + "_source")
        shutil.copyfile(root / "structural_audit.json", audit / f"{dataset}_structural_audit.json")
    for name in ("train", "dev", "test", "corpus", "test_corpus", "train_tool_ids"):
        register(source / f"data/main_20261025/{name}.json", purpose="original_frozen_" + name)
    raw_manifest = read(source / "data/raw/training_integrity_verified.json")
    register(source / "data/raw/training_integrity_verified.json", purpose="upstream_integrity_manifest")
    for item in raw_manifest:
        register(source / "data/raw/training" / item["path"], item["sha256"], "complete_training_release")
    print("Verified source hashes", flush=True)

    bfcl, exclusions, bfcl_raw_counts = prepare_bfcl(package)
    toolhop, toolhop_corpus = prepare_toolhop(package)
    records = bfcl + toolhop
    record_by_id = {r["id"]: r for r in records}
    if len(record_by_id) != len(records):
        raise ValueError("External ID collision")
    task_groups = DSU(record_by_id)
    uncertainty_groups = DSU(record_by_id)
    variants_by_text = collections.defaultdict(list)
    for row in records:
        row["audit_query_variants"] = variants(row["query"], row.get("messages"))
        for key, text in row["audit_query_variants"].items():
            variants_by_text[text].append((row["id"], key))
    unique_texts = sorted(variants_by_text)
    join = PrefixJoin(unique_texts)
    grouping_relations = []
    for text, members in variants_by_text.items():
        ids = sorted({rid for rid, _ in members})
        for rid in ids[1:]:
            task_groups.union(ids[0], rid)
            grouping_relations.append({"left": ids[0], "right": rid, "relation": "exact_normalized_query_variant", "signature": sha(text)})
    # Structural engineering task-prefix rule from pinned BFCL conversion.
    seen_prefix = {}
    for row in bfcl:
        key = (row["dataset"], row["source_id_prefix_proxy"])
        if key in seen_prefix:
            task_groups.union(row["id"], seen_prefix[key])
            grouping_relations.append({"left": seen_prefix[key], "right": row["id"], "relation": "source_id_prefix_task_proxy"})
        else:
            seen_prefix[key] = row["id"]
    for i, text in enumerate(unique_texts):
        for j, intersection, union in join.find(text):
            if j >= i:
                continue
            left_ids = {rid for rid, _ in variants_by_text[text]}
            right_ids = {rid for rid, _ in variants_by_text[unique_texts[j]]}
            for a, b in itertools.product(sorted(left_ids), sorted(right_ids)):
                if a == b:
                    continue
                task_groups.union(a, b)
                grouping_relations.append({"left": a, "right": b, "relation": "near_query_5gram", "intersection": intersection, "union": union, "jaccard": intersection / union, "semantic_status": "unknown_proxy_group_conservative"})
    # Families affect uncertainty blocks only, not whole-family exclusion.
    seen_family = {}
    for row in records:
        if row["dataset"] == "toolhop":
            continue
        key = (row["dataset"], row["family_signature_proxy"])
        if key in seen_family:
            uncertainty_groups.union(row["id"], seen_family[key])
            grouping_relations.append({"left": seen_family[key], "right": row["id"], "relation": "same_native_menu_function_name_set_proxy"})
        else:
            seen_family[key] = row["id"]
    for rid in record_by_id:
        uncertainty_groups.union(rid, task_groups.find(rid))

    cross_hits = collections.defaultdict(set)
    source_counts = collections.Counter()
    source_provenance = collections.Counter()
    source_schema_issues = []
    seen_query_signatures = set()
    overlap_file = (audit / "overlap_pairs.jsonl").open("w", encoding="utf-8")
    near_file = (audit / "near_duplicate_unknown_review.jsonl").open("w", encoding="utf-8")
    pair_count = 0
    near_count = 0

    def audit_query(row, source_kind, location):
        nonlocal pair_count, near_count
        source_counts[source_kind] += 1
        source_provenance[str(row.get("provenance", "source_unknown"))] += 1
        if not isinstance(row.get("query"), str):
            raise ValueError("Source query field missing or non-string: " + canon(location))
        if not row["query"].strip():
            source_schema_issues.append({"source_kind": source_kind, "source_id": str(row["id"]), "location": location,
                                         "issue": "empty_query_no_readable_text_to_compare", "action": "reported_not_matched; source record and original evaluation unchanged"})
            return
        source_variants = variants(row["query"])
        # The source-record identity remains in every hit; repeated source text
        # is cached only at the candidate search, not dropped from evidence.
        for source_variant, text in sorted(set(source_variants.items())):
            identity = (source_kind, str(row["id"]), text)
            if identity in seen_query_signatures:
                continue
            seen_query_signatures.add(identity)
            for match_index, intersection, union in join.find(text):
                external_text = unique_texts[match_index]
                exact = text == external_text
                for external_id, ext_variant in variants_by_text[external_text]:
                    evidence = {"kind": "query_exact" if exact else "query_near_5gram", "external_id": external_id,
                                "dataset": record_by_id[external_id]["dataset"], "external_variant": ext_variant,
                                "external_normalized_sha256": sha(external_text), "source_kind": source_kind,
                                "source_id": str(row["id"]), "source_location": location, "source_variant": source_variant,
                                "source_normalized_sha256": sha(text), "jaccard": intersection / union,
                                "intersection": intersection, "union": union, "source_provenance": row.get("provenance", "source_unknown"),
                                "decision": "exclude_exact_task_group" if exact else "unknown_conservatively_exclude_task_group"}
                    if not exact:
                        evidence["source_query"] = row["query"]
                        evidence["external_query"] = record_by_id[external_id]["query"]
                        near_file.write(canon(evidence) + "\n")
                        near_count += 1
                    overlap_file.write(canon(evidence) + "\n")
                    pair_count += 1
                    cross_hits[external_id].add(evidence["kind"])

    for split in ("train", "dev", "test"):
        path = source / f"data/main_20261025/{split}.json"
        for i, row in enumerate(read(path)):
            audit_query(row, "main_" + split, {"path": str(path.relative_to(package)).replace("\\", "/"), "row_index": i})
    print("Scanned actual train/dev/old test queries", dict(source_counts), flush=True)

    external_docs = {c["id"]: c for row in bfcl for c in row["candidates"]}
    external_docs.update({c["id"]: c for c in toolhop_corpus})
    signature_index = {k: collections.defaultdict(list) for k in ("document", "schema_without_descriptions", "name_required_types", "name_only")}
    doc_sigs = {}
    for tid, tool in external_docs.items():
        sigs = tool_signatures(tool["raw"])
        doc_sigs[tid] = sigs
        for kind, index in signature_index.items():
            if sigs[kind] is not None:
                index[sigs[kind]].append(tid)
    exposure = {tid: {"signature_status": doc_sigs[tid]["required_signature_status"], "matched_signatures_by_scope": {}, "explicit_provenance": "unknown"} for tid in external_docs}
    tool_pair_path = audit / "tool_overlap_pairs.jsonl"
    tool_pairs = tool_pair_path.open("w", encoding="utf-8")
    tool_seen = set()
    tool_parse_cache = {}
    tool_stats = collections.Counter()

    def audit_tool(tool, source_scope, source_id, location, serialized=None):
        if serialized is None:
            serialized = canon(tool)
        raw_digest = sha(serialized)
        cache_key = (source_scope, raw_digest)
        if cache_key in tool_seen:
            tool_stats[source_scope + "_repeated_tool_occurrences"] += 1
            return
        tool_seen.add(cache_key)
        tool_stats[source_scope + "_unique_serialized_tools"] += 1
        if raw_digest not in tool_parse_cache:
            if tool is None:
                try:
                    tool = json.loads(serialized)
                except (ValueError, TypeError) as exc:
                    raise ValueError(f"Unparseable source tool at {location}") from exc
            tool_parse_cache[raw_digest] = tool_signatures(tool)
        sigs = tool_parse_cache[raw_digest]
        if sigs["name_required_types"] is None:
            tool_stats[source_scope + "_unknown_required_schema"] += 1
        if sigs["description_status"] != "present_string":
            tool_stats[source_scope + "_missing_or_nonstring_description"] += 1
        if sigs["name_status"] != "present_nonempty_string":
            tool_stats[source_scope + "_missing_or_empty_name"] += 1
            source_schema_issues.append({"source_kind": source_scope, "source_id": str(source_id), "location": location,
                                         "issue": "empty_or_missing_tool_name", "action": "document_and_schema_preserved; no family name inferred"})
        for kind, index in signature_index.items():
            for external_tid in index.get(sigs[kind], ()):
                exposure[external_tid]["matched_signatures_by_scope"].setdefault(source_scope, set()).add(kind)
                tool_pairs.write(canon({"external_tool_id": external_tid, "source_scope": source_scope,
                                        "source_tool_or_row_id": str(source_id), "source_location": location,
                                        "signature_kind": kind, "signature_sha256": sigs[kind],
                                        "source_document_signature": sigs["document"],
                                        "evidence_scope": "one representative per exact serialized source document per scope; query-label exposure separate"}) + "\n")
                tool_stats["tool_pair_evidence_rows"] += 1

    train_tool_ids = set(read(source / "data/main_20261025/train_tool_ids.json"))
    for filename, scope in (("corpus", "main_development_catalogue"), ("test_corpus", "old_test_catalogue")):
        path = source / f"data/main_20261025/{filename}.json"
        for i, tool in enumerate(read(path)):
            location = {"path": str(path.relative_to(package)).replace("\\", "/"), "row_index": i}
            audit_tool(tool["raw"], scope, tool["id"], location)
            if filename == "corpus" and tool["id"] in train_tool_ids:
                audit_tool(tool["raw"], "actual_training_tool_catalogue", tool["id"], location)
    print("Scanned frozen tool catalogues", flush=True)
    upstream_schema_records = []
    for item in raw_manifest:
        path = source / "data/raw/training" / item["path"]
        pqfile = pq.ParquetFile(path)
        columns = pqfile.schema.names
        if not {"id", "query"}.issubset(columns):
            raise ValueError("Upstream query schema not supported")
        upstream_schema_records.append({"path": str(path.relative_to(package)).replace("\\", "/"), "schema": str(pqfile.schema), "rows": pqfile.metadata.num_rows, "row_source_field": "absent; id is train ordinal, not provenance"})
        row_index = 0
        for batch in pqfile.iter_batches(batch_size=512, columns=["id", "query", "positive", "negative"]):
            for row in batch.to_pylist():
                location = {"path": str(path.relative_to(package)).replace("\\", "/"), "row_index": row_index}
                audit_query(row, "complete_upstream_training", location)
                for field in ("positive", "negative"):
                    if not isinstance(row[field], list):
                        raise ValueError("Expected upstream tool-list field")
                    for ordinal, serialized in enumerate(row[field]):
                        audit_tool(None, "complete_upstream_training_tools", row["id"], dict(location, field=field, ordinal=ordinal), serialized)
                row_index += 1
        print("Scanned", path.name, row_index, "cumulative pairs", pair_count, flush=True)
    overlap_file.close()
    near_file.close()
    tool_pairs.close()
    write(audit / "upstream_schema_audit.json", upstream_schema_records)
    write(audit / "source_schema_issues.json", source_schema_issues)

    inspected = {"live_multiple_0-0-0", "multiple_0", "parallel_multiple_0", "toolhop_query:0"}
    excluded_roots = collections.defaultdict(set)
    for rid in inspected & set(record_by_id):
        excluded_roots[task_groups.find(rid)].add("engineering_inspected_task_group")
    for rid, kinds in cross_hits.items():
        excluded_roots[task_groups.find(rid)].update(kinds)
    kept = []
    for row in records:
        row["task_duplicate_group_id"] = "external-task:" + task_groups.find(row["id"])
        row["group_id"] = "external-group:" + uncertainty_groups.find(row["id"])
        row["uncertainty_group_id"] = row["group_id"]
        reasons = sorted(excluded_roots.get(task_groups.find(row["id"]), ()))
        if reasons:
            exclusions.append({"id": row["id"], "dataset": row["dataset"], "phase": "pre_score_collision_and_engineering", "reasons": reasons,
                               "direct_cross_hits": sorted(cross_hits.get(row["id"], ())), "task_duplicate_group_id": row["task_duplicate_group_id"],
                               "semantic_review": "unknown_conservative_exclusion" if "query_near_5gram" in reasons else "not_required_for_exact_or_engineering_exclusion"})
        else:
            kept.append(row)

    for tid, info in exposure.items():
        info["matched_signatures_by_scope"] = {scope: sorted(kinds) for scope, kinds in sorted(info["matched_signatures_by_scope"].items())}
        training_hits = set(info["matched_signatures_by_scope"].get("actual_training_tool_catalogue", [])) | set(info["matched_signatures_by_scope"].get("complete_upstream_training_tools", []))
        if training_hits - {"name_only"}:
            info["family_exposure_proxy"] = "seen_signature_family_proxy"
        elif "name_only" in training_hits:
            info["family_exposure_proxy"] = "name_only_overlap_identity_unknown"
        else:
            info["family_exposure_proxy"] = "no_signature_match_source_unknown"
    for row in records:
        row["positive_tool_exposure"] = {tid: exposure[tid] for tid in row["positives"]}
        row["candidate_tool_exposure_summary"] = dict(collections.Counter(exposure[c["id"]]["family_exposure_proxy"] for c in row["candidates"]))
        positive_groups = {exposure[tid]["family_exposure_proxy"] for tid in row["positives"]}
        row["positive_family_exposure_proxy"] = "seen_signature_family_proxy" if "seen_signature_family_proxy" in positive_groups else ("name_only_overlap_identity_unknown" if "name_only_overlap_identity_unknown" in positive_groups else "no_signature_match_source_unknown")
    jsonl(audit / "tool_exposure.jsonl", ({"tool_id": tid, **info} for tid, info in sorted(exposure.items())))
    jsonl(audit / "exclusion_log.jsonl", sorted(exclusions, key=lambda r: (r["dataset"], r["id"])))
    jsonl(audit / "group_relations.jsonl", grouping_relations)
    jsonl(audit / "family_group_membership.jsonl", ({"id": row["id"], "dataset": row["dataset"], "group_id": row["group_id"], "task_duplicate_group_id": row["task_duplicate_group_id"], "family_signature_proxy": row["family_signature_proxy"], "included": row in kept} for row in records))
    jsonl(out / "exposed_external_diagnostic.jsonl", (r for r in records if r not in kept))
    dataset_counts = {}
    for dataset in ("bfcl_live_multiple", "bfcl_multiple", "bfcl_parallel_multiple", "toolhop"):
        selected = [r for r in kept if r["dataset"] == dataset]
        corpus = toolhop_corpus if dataset == "toolhop" else [c for r in selected for c in r["candidates"]]
        # The evaluator encodes only query/text. Labels and audit metadata stay
        # separate fields, never interpolated into those strings.
        queries = [{k: v for k, v in row.items() if k not in {"candidates", "audit_query_variants"}} for row in selected]
        write(out / dataset / "queries.json", queries)
        write(out / dataset / "corpus.json", corpus)
        jsonl(out / dataset / "native_records.jsonl", selected)
        groups = collections.Counter(r["group_id"] for r in selected)
        dataset_counts[dataset] = {"raw_queries": 995 if dataset == "toolhop" else bfcl_raw_counts[dataset.removeprefix("bfcl_")],
                                   "included_queries": len(selected), "excluded_queries": sum(e["dataset"] == dataset for e in exclusions),
                                   "uncertainty_groups": len(groups), "largest_group": max(groups.values(), default=0), "corpus_instances": len(corpus),
                                   "candidate_policy": "pooled_3912_original_instances" if dataset == "toolhop" else "per_query_native_menu_only",
                                   "script_proxy_counts": {"contains_cjk": sum(r["contains_cjk_script"] for r in selected), "contains_non_ascii": sum(r["contains_non_ascii"] for r in selected)},
                                   "positive_exposure_strata": dict(collections.Counter(r["positive_family_exposure_proxy"] for r in selected))}
    live, multiple = dataset_counts["bfcl_live_multiple"], dataset_counts["bfcl_multiple"]
    if live["included_queries"] >= 500 and live["uncertainty_groups"] >= 100:
        branch = "PRIMARY_LIVE_MULTIPLE_CONFIRMATION"
    elif live["included_queries"] >= 100 and live["uncertainty_groups"] >= 30:
        branch = "POWER_LIMITED_LIVE_MULTIPLE_CONFIRMATION"
    elif multiple["included_queries"] >= 100 and multiple["uncertainty_groups"] >= 30:
        branch = "SMALL_MENU_MULTIPLE_CONFIRMATION"
    else:
        branch = "NO_EXTERNAL_VALIDATION"
    source_report = {"inputs": input_manifest, "bfcl_revision": "6ea57973c7a6097fd7c5915698c54c17c5b1b6c8", "bfcl_license": "Apache-2.0",
                     "bfcl_citation": "https://proceedings.mlr.press/v267/patil25a.html", "toolhop_revision": "b439d7279af359fda46e8117ae4f0245b75f5c6b",
                     "toolhop_data_license": "CC-BY-4.0", "toolhop_code_license": "Apache-2.0", "toolhop_citation": "https://aclanthology.org/2025.acl-long.150/",
                     "toolhop_upstream": "MoreHopQA (CC-BY-4.0), itself using HotpotQA, 2Wiki-MultihopQA, MuSiQue",
                     "training_row_provenance": "source_unknown; ordinal IDs are not upstream origin labels", "pretraining_exposure": "unknown"}
    write(audit / "source_manifest.json", source_report)
    stats = {"query_source_counts": dict(source_counts), "source_provenance_counts": dict(source_provenance), "cross_query_pair_rows": pair_count,
             "near_unknown_pair_rows": near_count, "external_queries_directly_hit": len(cross_hits), "tool_scan": dict(tool_stats),
             "near_candidate_pairs_exactly_verified": join.candidates_verified, "external_unique_query_variants": len(unique_texts),
             "full_query_scan_completed": True, "full_upstream_tool_scan_completed": True, "source_identity_verified": True,
             "unreadable_empty_source_queries_explicitly_reported": sum(r["issue"] == "empty_query_no_readable_text_to_compare" for r in source_schema_issues),
             "source_schema_issue_count": len(source_schema_issues),
             "external_group_relation_counts": dict(collections.Counter(r["relation"] for r in grouping_relations)),
             "model_scores_accessed": False, "official_code_executed": False, "seconds": time.time() - started}
    write(audit / "overlap_audit_summary.json", stats)
    specs = {"schema": "external_eval_specs_v1", "branch": branch,
             "selection": "only original development; external scores unopened until root final_lock.json binds all checkpoints and statistics",
             "datasets": {
                 "bfcl_live_multiple": {"role": "primary_external", "primary_metric": "mrr", "secondary": ["top1_accuracy"], "mrr_cutoff": None, "candidate_policy": "native_menu", "tie_break": "candidate_tie_break_keys ascending", "point_estimate": "query_weighted", "uncertainty": "paired seed and frozen group blocks", "sensitivity": "uniform_group_weighted"},
                 "bfcl_multiple": {"role": "secondary_external", "primary_metric": "mrr", "secondary": ["top1_accuracy"], "mrr_cutoff": None, "candidate_policy": "native_menu", "tie_break": "candidate_tie_break_keys ascending"},
                 "bfcl_parallel_multiple": {"role": "exploratory_multi_positive", "metrics": ["mrr", "average_precision", "macro_recall@1", "top1_hit"], "mrr_cutoff": None, "candidate_policy": "native_menu", "tie_break": "candidate_tie_break_keys ascending"},
                 "toolhop": {"role": "descriptive_reference_label_stress_only", "metrics": ["ReferenceToolRecall@1", "ReferenceToolRecall@5", "ReferenceToolRecall@10", "ReferenceAllTools@10", "ReferenceIDMRR@10"], "candidate_policy": "pooled_reference_instances", "tie_break": "tool_id ascending", "sensitivity": {"name": "exact_document_equivalence", "group_key": "document_sha256 = SHA256(canonical name/description/parameters text UTF8)", "ranking": "collapse ranked IDs by document group, retain first occurrence of each group", "gold": "deduplicate original positive IDs into document groups", "recall_denominator": "number of unique gold document groups", "do_not": "expand equivalent_positives and use expanded ID count as denominator", "boundary": "identical documentation only; not same function name or inferred semantic equivalence"}}},
             "bm25": {"k1": 1.5, "b": 0.75, "idf": "positive_Robertson", "tokenizer": "lowercase regex [a-z0-9]+", "native_menu_idf": "per query original candidate menu only"},
             "baselines": ["BM25", "pretrained_e5", "pretrained_bge", "pretrained_qwen"], "stages": ["S0", "S1", "S3", "S5"],
             "excluded_stages": ["S2", "S4"], "confirmation_seeds": [42, 43, 44, 45, 46],
             "no_dataset_score_averaging": True, "no_agent_execution_claim": True}
    write(locks / "external_eval_specs.json", specs)
    report = ("外部数据已完成结构、精确与完整字符5-gram近重复筛查；未计算模型成绩。\n"
              + json.dumps(dataset_counts, ensure_ascii=False, indent=2) + "\n分支：" + branch
              + "\n所有近重复跨集命中未经真实人类语义审判，按协议保守排除其整组。\n"
              + "工具同文档、schema或名称/必需参数命中仅说明暴露代理，不证明查询已见；无命中也不能证明来源独立。\n"
              + "完整上游训练记录未提供可验证来源ID，模型预训练暴露未知。ToolHop只承担参考标签压力诊断。\n"
              + "尚未执行：最终checkpoint锁定、任何模型评分、统计结论、真实人工语义审核。\n")
    (audit / "external_validity.txt").write_text(report, encoding="utf-8")
    output_files = []
    for path in sorted(out.rglob("*")):
        # Technical process logs keep changing until process exit and therefore
        # belong to the return-run manifest, never the immutable dataset lock.
        if path.is_file() and path.suffix != ".log":
            output_files.append({"path": str(path.relative_to(publication)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": file_sha(path)})
    manifest = {"schema": "final_external_dataset_manifest_v1", "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "status": "FROZEN_INPUTS_NO_MODEL_SCORES", "branch": branch, "datasets": dataset_counts, "files": output_files,
                "audit_plan_sha256": file_sha(locks / "external_audit_plan.json"), "eval_specs_sha256": file_sha(locks / "external_eval_specs.json"),
                "unknowns": ["original complete-training row provenance", "model pretraining exposure", "semantic equivalence of near hits conservatively excluded", "true API-family identities", "ToolHop exhaustive relevance"],
                "source_disjoint_claim_permitted": False, "human_labels_created": False}
    write(out / "final_dataset_manifest.json", manifest)
    shutil.copyfile(out / "final_dataset_manifest.json", locks / "final_dataset_manifest.json")
    lock = {"schema": "external_data_lock_v1", "lock_timestamp": manifest["timestamp_utc"], "source_code_sha256": file_sha(__file__),
            "final_dataset_manifest_sha256": file_sha(out / "final_dataset_manifest.json"), "external_eval_specs_sha256": file_sha(locks / "external_eval_specs.json"),
            "audit_plan_sha256": file_sha(locks / "external_audit_plan.json"), "no_model_scores_accessed": True,
            "model_versions_source": {"path": str((package / "model_assets.lock.json").relative_to(package)), "sha256": file_sha(package / "model_assets.lock.json")},
            "selection_policy": "original development only; this data lock does not replace final_lock.json", "actual_model_selection": "not performed by this external audit process",
            "branch": branch, "status": "DATA_FROZEN_FINAL_CHECKPOINT_LOCK_PENDING"}
    write(locks / "external_lock.json", lock)
    print(canon({"branch": branch, "datasets": dataset_counts, "audit": stats}), flush=True)


if __name__ == "__main__":
    main()
