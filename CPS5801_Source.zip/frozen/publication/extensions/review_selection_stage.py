"""Independent, read-only CPU audit of S2/S4 development selection.

Does not call select_on_dev.select or its comparators. Winners are independently
derived by successive admissible-set elimination from rescored raw predictions.
Waiting and process evidence is durable; no approval/repair or queue mutation.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback

from rebuild_all import Resolver, read_json, require, rescore, sha, write_csv, write_json

POLICIES=['R_ID','B_ID','R_UNIQUE','B_UNIQUE','MIXED_2R2B','DENSE_STATIC']
EXTENSIONS=['B_UNIQUE','MIXED_2R2B','DENSE_STATIC','R_UNIQUE']
LRS=[1e-5,2e-5];TEMPERATURES=[.01,.05];STEPS=[312,625,1250];EPS=1e-12


def now():return datetime.now(timezone.utc).isoformat()
def canonical(data):return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def cell_key(row):return (row['policy'],row['lr'],row['temperature'],row['steps'])


def choose_configuration(cells):
    """Set-based specification implementation, independent of selector sort."""
    survivors=list(cells);eliminations=[]
    require(survivors,'No valid configuration for policy')
    rules=[('recall@5','max',True),('mrr@10','max',True),('steps','min',False),('lr','min',False),('temperature','max',False)]
    for field,direction,approximate in rules:
        values=[r[field] for r in survivors];best=(max if direction=='max' else min)(values)
        keep=[r for r in survivors if abs(r[field]-best)<=EPS] if approximate else [r for r in survivors if r[field]==best]
        keep_keys={cell_key(r) for r in keep}
        eliminations.extend({'cell':list(cell_key(r)),'first_losing_rule':field,'winning_value':best,'observed_value':r[field]} for r in survivors if cell_key(r) not in keep_keys)
        survivors=keep
    require(len(survivors)==1,'Duplicate or unresolved configuration identity')
    return survivors[0],eliminations


def choose_extension(selection):
    remaining=[selection[p] for p in EXTENSIONS];ranked=[];evidence=[]
    while remaining:
        best=max(r['recall@5'] for r in remaining)
        tied=[r for r in remaining if abs(r['recall@5']-best)<=EPS]
        winner=min(tied,key=lambda r:EXTENSIONS.index(r['policy']))
        ranked.append(winner['policy'])
        evidence.append({'rank':len(ranked),'max_remaining_recall5':best,'within_tolerance_policies':[r['policy'] for r in tied],
                         'chosen_by_recall_then_fixed_order':winner['policy'],'MRR_used_between_policies':False})
        remaining=[r for r in remaining if r['policy']!=winner['policy']]
    best=selection[ranked[0]];baseline=max(selection[p]['recall@5'] for p in ['R_ID','B_ID'])
    margin=best['recall@5']-baseline;signal=(margin>=.01 or abs(margin-.01)<=EPS)
    return {'policy':best['policy'] if signal else 'B_UNIQUE','branch':'candidate_improver' if signal else 'mechanism_followup_no_development_improver',
            'best_extension_policy':best['policy'],'best_extension_margin':margin,'baseline_best_recall@5':baseline,
            'candidate_signal_met':signal,'ranked_extension_policies':ranked},evidence


class Reviewer:
    def __init__(self,root,output,stage,upstream_review=None):
        self.resolver=Resolver(root);self.pub=self.resolver.publication;self.out=Path(output).resolve();self.stage=stage
        require(not self.out.exists(),'Preserve prior attempts: output must be new')
        self.out.mkdir(parents=True);self.errors=[];self.sources={};self.artifacts=[];self.failed_runs=[]
        bundle=self.resolver.mapping_path.parent if self.resolver.mapping_path else self.pub.parent
        self.repro=bundle/('reproduction' if (bundle/'reproduction').is_dir() else 'repro');self.data=self.repro/'data/main_20261025'
        self.s2_observed=None;self.upstream_review=Path(upstream_review).resolve() if upstream_review else None
        self.upstream_review_required=False
        self.start_bindings={str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('rebuild_all.py'),
            self.pub/'extensions/select_on_dev.py',self.pub/'extensions/encoders.py',self.pub/'extensions/train_configurable.py',
            self.pub/'extensions/evaluate_retrieval.py',self.pub/'locks/analysis_plan.json',self.pub/'locks/execution_decisions.json',
            self.pub/'locks/analysis_plan_identity.json',
            self.pub/'provenance/selection_registry_snapshot_fix/technical_amendment_and_acceptance.json']}
        write_json(self.out/'watcher_identity.json',{'created_at_utc':now(),'worker_pid':os.getpid(),'parent_pid':os.getppid(),
            'argv':sys.argv,'cwd':str(Path.cwd()),'stage':stage,'start_source_hashes':self.start_bindings,
            'no_final_scores':True,'queue_mutation':False,'approval_authority':False})

    def status(self,status,**fields):
        write_json(self.out/'status.json',{'status':status,'stage':self.stage,'at_utc':now(),'worker_pid':os.getpid(),
            'final_scores_read':False,'queue_modified':False,'approval_written':False,**fields})

    def event(self,event,**fields):
        record={'at_utc':now(),'event':event,**fields}
        with (self.out/'events.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(record,ensure_ascii=False)+'\n')
        print(json.dumps(record,ensure_ascii=False),flush=True)

    def source(self,path,expected=None):
        path=Path(path).resolve()
        if path not in self.sources:self.sources[path]={'path':self.resolver.display(path),'bytes':path.stat().st_size,'sha256':sha(path)}
        entry=self.sources[path];require(expected is None or entry['sha256']==expected,'SHA mismatch: '+str(path));return entry

    def load(self,path,expected=None):self.source(path,expected);return read_json(path)
    def resolve(self,path):return self.resolver.resolve(path,self.pub)
    def manifest(self,path):
        path=Path(path)
        return {p.relative_to(path).as_posix():{'bytes':self.source(p)['bytes'],'sha256':self.source(p)['sha256']}
            for p in sorted(path.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.tmp')}

    def table(self,name,rows,formula):
        path=self.out/name;write_csv(path,rows)
        self.artifacts.append({'output':name,'sha256':sha(path),'bytes':path.stat().st_size,'formula':formula,'stage':'EXPLORATORY_DEV','seed':41})

    def wait(self,enabled,poll):
        last=None;lock_wait_started=None;parse_failures=0
        while True:
            raw=(self.pub/'run_registry.json').read_bytes();registry=json.loads(raw.decode('utf-8-sig'))
            rows=[r for r in registry['runs'] if r['stage']==self.stage]
            require(len(rows)==(24 if self.stage=='S2' else 12),'Selection-stage trajectory count differs from plan')
            counts=dict(Counter(r['status'] for r in rows))
            blockers=[r for r in rows if r['status'] not in ['pending','running','completed','failed'] or (r['status']=='failed' and r.get('failure_kind')!='numerical')]
            if self.stage=='S4':
                blockers += [r for r in registry['runs'] if r['stage'] in ['S2','S3'] and r['status'] in ['failed','interrupted','blocked'] and r.get('failure_kind')!='numerical']
                s2_path=self.pub/'locks/S2_selection.json'
                if s2_path.exists() and self.s2_observed is None:
                    try:s2_raw=s2_path.read_bytes();s2=json.loads(s2_raw.decode('utf-8-sig'))
                    except json.JSONDecodeError:time.sleep(poll);continue
                    require(s2['stage']=='S2' and s2['status']=='selected','Invalid upstream S2 lock')
                    self.s2_observed=hashlib.sha256(s2_raw).hexdigest();(self.out/'S2_lock_first_observed.json').write_bytes(s2_raw)
                    self.event('S2_LOCK_OBSERVED',sha256=self.s2_observed,S4_statuses=counts,observed_before_S4_started=all(r['status']=='pending' for r in rows))
            if blockers:
                write_json(self.out/'blocking_run_records.json',blockers)
                raise ValueError('Technical/interrupted upstream or stage run requires root review; independent watcher stops, queue unchanged')
            if counts!=last:
                self.status('WAITING_FOR_STAGE_AND_SELECTION_LOCK',trajectory_statuses=counts)
                self.event('STAGE_METADATA',trajectory_statuses=counts,model_scores_read=False);last=counts
            if all(r['status'] in ['completed','failed'] for r in rows):
                lock_path=self.pub/f'locks/{self.stage}_selection.json'
                if lock_path.exists():
                    try:lock_raw=lock_path.read_bytes();lock=json.loads(lock_raw.decode('utf-8-sig'))
                    except json.JSONDecodeError:
                        parse_failures+=1;require(parse_failures<3,'Selection lock remains malformed across polls')
                    else:
                        (self.out/'registry_snapshot.json').write_bytes(raw);(self.out/'selection_lock_snapshot.json').write_bytes(lock_raw)
                        self.source(self.out/'registry_snapshot.json');self.source(self.out/'selection_lock_snapshot.json')
                        return registry,rows,lock,lock_path,hashlib.sha256(raw).hexdigest()
                if lock_wait_started is None:lock_wait_started=time.monotonic()
                command_status=self.pub/f'logs/{self.stage}_selection.process_status.json'
                if command_status.exists():
                    state=read_json(command_status)
                    require(state['status'] not in ['failed','launch_failed','monitor_failed','monitor_interrupted'],'Selector process failed without a usable lock; root review required')
                require(time.monotonic()-lock_wait_started<120,'All trajectories terminal but selection lock absent/malformed after120 seconds')
            require(enabled,'Stage/lock not ready; use --wait for metadata-only wait')
            time.sleep(poll)

    def audit_trajectory(self,row,queries,corpus,policies):
        config=row['config'];require(isinstance(config,dict),'Executed trajectory config missing')
        family='e5' if self.stage=='S2' else 'bge';policy=config['policy'];lr=config['lr'];temperature=config['temperature']
        require(policy in policies and row['policy']==policy,'Actual policy differs from allowed selected set')
        require(config['run_id']==row['run_id'] and lr==row.get('lr',row.get('learning_rate')) and temperature==row['temperature'],'Config/run identity or hyperparameters differ')
        require((config['stage'],row['family'],config['family'],row['seed'],config['seed'])==(self.stage,family,family,41,41),'Wrong stage/family/development seed')
        require(lr in LRS and temperature in TEMPERATURES and row['optimizer_updates']==config['steps']==1250,'Search recipe/trajectory budget outside fixed grid')
        require((config['microbatch'],config['accumulation'],config['checkpoint_steps'])==(8,4,STEPS),'Microbatch/checkpoint budget differs')
        out=self.resolve(row['output_path']);require(self.load(out/'config.json')==config,'Executed config differs from registry')
        identity=self.load(out/'identity.json');require(all(identity[k]==config[k] for k in ['family','seed','lr','temperature','steps','microbatch','accumulation']),'Scientific identity/config differs')
        adapter={'query_prefix':'query: ','document_prefix':'passage: ','pooling':'masked_mean_float32_then_L2'} if family=='e5' else {
            'query_prefix':'Represent this sentence for searching relevant passages: ','document_prefix':'','pooling':'CLS_float32_then_L2'}
        require(identity['adapter']==adapter,'Encoder input/pooling adapter differs')
        fixed={'optimizer':'AdamW','betas':[.9,.999],'eps':1e-8,'weight_decay':.01,'clip_grad_norm':1.,'effective_batch':32,
            'negative_per_query':4,'precision':'bfloat16_autocast','query_tokens':128,'tool_tokens':384,
            'schedule':'constant_lr_no_warmup','midtraining_evaluation':'separate_process_only'}
        require(identity['fixed_config']==fixed,'Fixed optimizer/objective/precision recipe differs')
        require(identity['code']=={name:self.start_bindings[str(self.pub/'extensions'/name)] for name in ['encoders.py','train_configurable.py']},'Recorded training engine code differs')
        require(identity['runtime']['tf32'] is False and identity['runtime']['cudnn_benchmark'] is False and identity['runtime']['cublas_workspace_config']==':4096:8','Precision/determinism runtime differs')
        for name,value in identity['input_files'].items():self.source(self.resolve(config[name]),value)
        require(self.resolve(config['train_path'])==self.data/'train.json' and self.resolve(config['corpus_path'])==self.data/'corpus.json','Wrong training split/catalogue')
        self.source(self.data/'train.json',self.freeze['data/main_20261025/train.json'])
        for field,name in [('train_tool_ids_path','train_tool_ids.json'),('forbidden_path','forbidden_ids.json')]:
            require(self.resolve(config[field])==self.data/name,'Training-side mask path differs')
            self.source(self.data/name,self.freeze['data/main_20261025/'+name])
        require(self.resolve(config['model_path'])==self.initial_model_path,'Wrong pretrained initialization path/family')
        require(self.resolve(config['schedule_path'])==self.pub/'data/training/schedule_seed41.json','Wrong seed41 schedule path')
        require(self.resolve(config['negatives_path'])==self.pub/f'data/training/{policy}_seed41.json','Wrong realized policy-negative file')
        self.source(self.resolve(config['schedule_path']),self.schedule_sha)
        self.source(self.resolve(config['negatives_path']),self.negative_hashes[str(self.resolve(config['negatives_path']))])
        require(identity['model_files']==self.manifest(self.resolve(config['model_path'])),'Pretrained model identity changed')
        schedule=self.load(self.resolve(config['schedule_path']))[:40000]
        require(len(schedule)==40000 and canonical(schedule)==identity['actual_schedule_prefix_sha256'],'Full exposure schedule differs')
        require(canonical(self.load(self.resolve(config['negatives_path'])))==identity['actual_negatives_sha256'],'Actual negative IDs differ')
        losses=self.load(out/'loss.jsonl');require([r['step'] for r in losses]==list(range(1,len(losses)+1)),'Noncontiguous optimizer trace')
        require(all(math.isfinite(r['loss']) and math.isfinite(r['grad_norm']) for r in losses),'Nonfinite saved loss/gradient')
        require(row['actual_steps']==len(losses)<=1250,'Actual optimizer/loss count differs')
        state=self.load(out/'status.json')
        if row['status']=='completed':
            training=self.load(out/'training.json')
            require(state['status']=='completed' and training['steps']==len(losses)==1250 and training['exposures']==40000,'Completed trajectory budget/status incomplete')
            require(training['identity_sha256']==canonical(identity),'Training identity SHA differs')
            checkpoint_manifest=self.load(out/'checkpoint_manifest.json')
        else:
            require(row['failure_kind']=='numerical' and row.get('failure_reason') and state['status']=='failed','Failure is not an explicit recorded numerical failure')
            require(any(message in row['failure_reason'] and message in state.get('error','') for message in ['Nonfinite loss','Nonfinite gradient']),
                    'Numerical-failure classification lacks matching raw nonfinite loss/gradient evidence')
            self.failed_runs.append({'run_id':row['run_id'],'reason':row['failure_reason'],'actual_updates':len(losses)})
            checkpoint_manifest=None
        evaluations=row['dev_evaluations'];by_step={e['steps']:e for e in evaluations}
        require(len(by_step)==len(evaluations) and set(by_step)<=set(STEPS),'Duplicate/unplanned dev checkpoints')
        if row['status']=='completed':require(set(by_step)==set(STEPS),'Completed trajectory lacks required312/625/1250 dev outputs')
        cells=[]
        for step in STEPS:
            base={'run_id':row['run_id'],'stage':self.stage,'family':family,'policy':policy,'seed':41,'lr':lr,'temperature':temperature,'steps':step,
                  'actual_trajectory_updates':len(losses),'planned_trajectory_updates':1250,'checkpoint_query_exposures':32*step}
            if step not in by_step:
                require(row['status']=='failed','Missing checkpoint without explicit failed trajectory')
                require(step>len(losses) and not (out/'checkpoints'/f'step_{step:04d}'/'checkpoint_provenance.json').exists(),
                        'Completed or saved milestone omitted from development evaluations; root must inspect instead of counting it failed')
                cells.append({**base,'status':'failed','failure_reason':row['failure_reason'],'recall@5':None,'mrr@10':None});continue
            ev=by_step[step];require(step<=len(losses) and ev['split']=='original_dev','Checkpoint exceeds executed budget or wrong split')
            metrics_path=self.resolve(ev['metrics_path']);predictions_path=metrics_path.with_name('predictions.json');checkpoint=self.resolve(ev['checkpoint_path'])
            self.source(metrics_path,ev['metrics_sha256']);self.source(predictions_path,ev['predictions_sha256'])
            manifest=self.manifest(checkpoint);require(manifest['model.safetensors']['sha256']==ev['checkpoint_sha256'],'Checkpoint SHA differs from dev registry')
            if checkpoint_manifest is not None:require(manifest==checkpoint_manifest[f'step_{step:04d}'],'Checkpoint directory manifest differs')
            cp=self.load(checkpoint/'checkpoint_provenance.json')
            require(cp['run_id']==row['run_id'] and cp['step']==step and cp['exposures']==step*32 and cp['identity_sha256']==canonical(identity),'Checkpoint provenance differs')
            evconfig=self.load(metrics_path.parent/'config.json')
            require(self.resolve(evconfig['queries_path'])==self.data/'dev.json' and self.resolve(evconfig['corpus_path'])==self.data/'corpus.json','Not frozen development/corpus')
            require(self.resolve(evconfig['model_path'])==checkpoint and evconfig['split']=='original_development','Scored checkpoint/split differs')
            require(evconfig['family']==family and evconfig['run_id']==row['run_id'],'Evaluation family/run differs')
            require(self.load(metrics_path.parent/'status.json')['status']=='completed','Checkpoint evaluation incomplete')
            report=self.load(metrics_path)
            require(report['n']==1000 and report['candidate_tools']==41732 and report['input_hashes']==self.data_hashes,'Wrong eval dimensions/input identities')
            require(report['model_manifest_sha256']==canonical(manifest),'Scored model differs from saved checkpoint')
            require(report['evaluation_code_sha256']==self.start_bindings[str(self.pub/'extensions/evaluate_retrieval.py')],'Recorded evaluator version differs')
            predictions=self.load(predictions_path)
            require(all({'top50','positive_ranks','candidate_count','query_text_sha256'}<=p.keys() for p in predictions),'New development rows lack required raw ranking/query evidence')
            score=rescore(predictions,queries,corpus)
            require(all(isinstance(report['metrics'][m],(int,float)) and not isinstance(report['metrics'][m],bool) and math.isfinite(report['metrics'][m])
                        for m in ['recall@1','recall@3','recall@5','recall@10','mrr@10']),'Nonfinite/invalid saved aggregate metric')
            error=max(abs(score['metrics'][metric]-report['metrics'][metric]) for metric in ['recall@1','recall@3','recall@5','recall@10','mrr@10'])
            require(error<=EPS,'Saved dev metrics differ from independent raw-rank rescore')
            cells.append({**base,'status':'valid','recall@5':score['metrics']['recall@5'],'mrr@10':score['metrics']['mrr@10'],
                'metrics_path':str(metrics_path),'metrics_sha256':ev['metrics_sha256'],'predictions_sha256':ev['predictions_sha256'],
                'checkpoint_path':str(checkpoint),'checkpoint_sha256':ev['checkpoint_sha256'],'metric_recompute_error':error})
        return cells,{'run_id':row['run_id'],'policy':policy,'lr':lr,'temperature':temperature,'actual_updates':len(losses),
            'schedule_prefix_sha256':canonical(schedule),'initial_model_manifest_sha256':canonical(identity['model_files']),
            'training_runtime_sha256':canonical(identity['runtime']),
            'status':row['status'],'valid_checkpoints':len(by_step),'failed_checkpoint_slots':3-len(by_step)}

    def audit(self,registry,rows,lock,lock_path,registry_sha):
        self.status('AUDITING_RAW_DEVELOPMENT_CHECKPOINTS')
        for path,value in self.start_bindings.items():require(sha(path)==value,'Reviewer/selector/rule source changed during wait: '+path)
        plan_identity=self.load(self.pub/'locks/analysis_plan_identity.json')
        plan=self.load(self.pub/'locks/analysis_plan.json',plan_identity['analysis_plan.json']['sha256'])['development_selection'];decisions=self.load(self.pub/'locks/execution_decisions.json')
        amendment_path=self.pub/'provenance/selection_registry_snapshot_fix/technical_amendment_and_acceptance.json'
        amendment=self.load(amendment_path)
        require(amendment['status']=='PASS_TECHNICAL_PROVENANCE_ONLY' and amendment['before']['sha256']==plan['selector']['sha256'] and
                amendment['after']['sha256']==self.start_bindings[str(self.pub/'extensions/select_on_dev.py')], 'Selector successor lacks plan-to-current logging-only provenance chain')
        before=self.resolve(amendment['before']['path']);after=self.pub/'extensions/select_on_dev.py'
        self.source(before,amendment['before']['sha256']);self.source(after,amendment['after']['sha256'])
        def non_main_ast(path):
            tree=ast.parse(path.read_text(encoding='utf-8-sig'))
            tree.body=[node for node in tree.body if not (isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name=='main')]
            return ast.dump(tree,include_attributes=False)
        require(non_main_ast(before)==non_main_ast(after),'Selector scientific functions/module changed beyond documented main logging wrapper')
        snapshot_path=self.resolve(lock['input_registry']['immutable_snapshot_path'])
        snapshot_sha=lock['input_registry']['immutable_snapshot_sha256']
        require(snapshot_sha==lock['input_registry']['sha256'],'Immutable selector registry SHA disagrees with actual consumed bytes')
        require(lock['input_registry']['same_bytes_used_for_selection_and_snapshot'] is True,'Selector did not declare exact consumed snapshot bytes')
        frozen_registry=self.load(snapshot_path,snapshot_sha)
        frozen_rows=[r for r in frozen_registry['runs'] if r['stage']==self.stage]
        require(len(frozen_rows)==len(rows) and len({r['run_id'] for r in frozen_rows})==len(rows),'Immutable stage snapshot grid differs')
        current={r['run_id']:r for r in rows}
        immutable_fields=['stage','family','policy','seed','lr','learning_rate','temperature','optimizer_updates','actual_steps','config',
            'output_path','dev_evaluations','status','attempts','checkpoint_path','failure_kind','failure_reason']
        for frozen in frozen_rows:
            require(frozen['run_id'] in current and all(frozen.get(k)==current[frozen['run_id']].get(k) for k in immutable_fields),
                    'Stage scientific record changed after selection snapshot: '+frozen['run_id'])
        rows=frozen_rows
        require(plan['absolute_numeric_tie_tolerance']==EPS and plan['policy_tiebreak_order']==EXTENSIONS and plan['minimum_candidate_signal_absolute_recall5']==.01,'Frozen selection rules differ from auditor specification')
        require(plan['remaining_config_tiebreak']==['fewer_updates','lower_learning_rate','temperature_0.05_before_0.01'],'Config tie rule differs')
        require('no cross-policy MRR' in plan['cross_policy_comparator'] and 'B_UNIQUE,MIXED_2R2B,DENSE_STATIC,R_UNIQUE' in decisions['cross_policy_tie_break'],'Execution tie decision absent/different')
        self.freeze=self.load(self.data/'freeze_manifest.json')['files']
        anchor=next(r for r in registry['runs'] if r['stage']=='S0' and r['status']=='completed')
        s0_training=self.load(self.resolve(anchor['output_path'])/'training.json')
        self.source(self.data/'freeze_manifest.json',s0_training['snapshot_manifest_sha256'])
        bindings=self.load(self.pub/'comparison/reproduction_comparison.json')['input_files']
        binding_key='reproduction:'+str((self.resolve(anchor['output_path'])/'training.json').relative_to(self.repro)).replace('\\','/')
        self.source(self.resolve(anchor['output_path'])/'training.json',bindings[binding_key]['sha256'])
        queries=self.load(self.data/'dev.json',self.freeze['data/main_20261025/dev.json']);corpus=self.load(self.data/'corpus.json',self.freeze['data/main_20261025/corpus.json'])
        require(len(queries)==1000 and len(corpus)==41732,'Frozen development dimensions differ')
        self.data_hashes={'queries':sha(self.data/'dev.json'),'corpus':sha(self.data/'corpus.json')}
        schedule_manifest=self.load(self.pub/'data/training/schedule_manifest.json')
        require(schedule_manifest['source_freeze']==s0_training['snapshot_manifest_sha256'],'Schedule provenance freeze differs')
        self.schedule_sha=schedule_manifest['schedules']['41']['sha256']
        diagnostics=self.load(self.pub/'analysis/negative_complete_attempt01/diagnostics_report.json')
        require(diagnostics['status']=='PASS_COMPLETE','Frozen negative identity audit incomplete')
        self.negative_hashes={str(self.resolver.resolve(path,must_exist=False)):value for path,value in diagnostics['input_sha256'].items()}
        if self.stage=='S2':self.initial_model_path=self.repro/'data/raw/model'
        else:
            models=self.load(self.pub/'models/verified_models.json')['models']
            self.initial_model_path=self.resolve(next(m['local_dir'] for m in models if m['repo_id']=='BAAI/bge-small-en-v1.5'))
        s2=None
        if self.stage=='S4':
            s2_path=self.pub/'locks/S2_selection.json';self.source(s2_path,self.s2_observed);s2=self.load(s2_path)
            require(lock['s2_lock']['sha256']==sha(s2_path),'S4 selector used different S2 lock')
            require(self.resolve(lock['s2_lock']['path'])==s2_path,'S4 upstream lock path differs')
            require(self.upstream_review is not None and self.upstream_review.is_file(),'S4 requires the S2 independent review report')
            upstream=self.load(self.upstream_review)
            require(upstream['locked_selection_sha256']==sha(s2_path),'S2 independent review belongs to different lock')
            self.upstream_review_required=upstream['status']!='PASS_INDEPENDENT_SELECTION_REVIEW'
            policies=['R_ID','B_ID',s2['selected_extension']['policy']]
            require(policies[2] in EXTENSIONS,'Invalid inherited extension')
        else:policies=POLICIES
        require(lock['stage']==self.stage and lock['family']==('e5' if self.stage=='S2' else 'bge') and lock['selection_seed']==41 and lock['selection_split']=='original_development_only','Selection lock identity/split differs')
        require(lock['status']=='selected' and lock['code_sha256']==self.start_bindings[str(self.pub/'extensions/select_on_dev.py')],'Selector code/status mismatch')
        cells=[];trajectories=[]
        for row in rows:
            try:
                points,trajectory=self.audit_trajectory(row,queries,corpus,policies);cells.extend(points);trajectories.append(trajectory)
            except (ValueError,KeyError,TypeError,OSError) as exc:
                self.errors.append({'run_id':row['run_id'],'error':str(exc)})
                for step in STEPS:cells.append({'run_id':row['run_id'],'stage':self.stage,'policy':row.get('policy'),'lr':row.get('lr',row.get('learning_rate')),
                    'temperature':row.get('temperature'),'steps':step,'status':'invalid_or_missing','failure_reason':str(exc),'recall@5':None,'mrr@10':None})
        expected={(p,lr,t,step) for p in policies for lr in LRS for t in TEMPERATURES for step in STEPS}
        require(len(cells)==len(expected) and {cell_key(c) for c in cells}==expected,'Missing/duplicated/unexpected grid cells')
        self.table('all_checkpoint_candidates.csv',cells,'Independent checkpoint scores from frozen dev/raw rankings; failed/invalid cells remain visible and are not counted valid')
        self.table('trajectory_budget_and_binding.csv',trajectories,'Actual trajectory optimizer count, checkpoint counts, initialization and shared exposure identities')
        if trajectories:
            require(len({r['initial_model_manifest_sha256'] for r in trajectories})==1 and len({r['schedule_prefix_sha256'] for r in trajectories})==1 and len({r['training_runtime_sha256'] for r in trajectories})==1,'Within-family grid initialization/exposure/runtime controls are not paired')
        summary={'stage':self.stage,'required_trajectories':len(policies)*4,'required_grid_slots':len(expected),
                 'observed_candidate_slots':len(cells),'valid_grid_slots':sum(c['status']=='valid' for c in cells),
                 'explicit_numerical_failed_slots':sum(c['status']=='failed' for c in cells),'invalid_or_missing_slots':sum(c['status']=='invalid_or_missing' for c in cells),
                 'per_policy':{p:dict(Counter(c['status'] for c in cells if c['policy']==p)) for p in policies}}
        write_json(self.out/'grid_coverage.json',summary)
        require(not self.errors,'Raw checkpoint/budget/hash failures; no independent winner approved')
        locked_grid=lock['grid'];require(len(locked_grid)==len(expected) and len({cell_key(c) for c in locked_grid})==len(expected),'Lock grid is incomplete/duplicated')
        lookup={cell_key(c):c for c in locked_grid}
        for cell in cells:
            saved=lookup[cell_key(cell)];require(all(saved[field]==cell[field] for field in ['run_id','stage','family','policy','seed','status']),'Lock grid candidate scientific identity/status differs')
            if cell['status']=='valid':
                require(all(abs(saved['metrics'][metric]-cell[metric])<=EPS for metric in ['recall@5','mrr@10']),'Locked candidate metrics differ from raw rescore')
                require(self.resolve(saved['checkpoint_path'])==Path(cell['checkpoint_path']) and saved['checkpoint_sha256']==cell['checkpoint_sha256'],'Locked checkpoint identity differs')
                require(self.resolve(saved['metrics_source'])==Path(cell['metrics_path']),'Locked metric source differs')
        require(lock['grid_cell_count']==len(expected) and lock['valid_grid_cell_count']==summary['valid_grid_slots'] and lock['failed_grid_cell_count']==summary['explicit_numerical_failed_slots'],'Lock inflated valid checkpoint count')
        referenced={str(self.resolve(path)):value for path,value in lock['referenced_input_sha256'].items()}
        expected_referenced={c['metrics_path']:c['metrics_sha256'] for c in cells if c['status']=='valid'}
        require(referenced==expected_referenced,'Selector metric-source SHA ledger omits or introduces a source outside actual stage dev cells')
        for path,value in referenced.items():self.source(path,value)
        chosen={};eliminations=[]
        for policy in policies:
            candidates=[c for c in cells if c['policy']==policy and c['status']=='valid']
            winner,discarded=choose_configuration(candidates);chosen[policy]=winner;eliminations.extend(discarded)
        require(set(lock['selection'])==set(policies),'Lock selection policy set differs')
        for policy,winner in chosen.items():self.compare_chosen(winner,lock['selection'][policy])
        if self.stage=='S2':branch,branch_trace=choose_extension(chosen)
        else:
            branch={'policy':policies[2],'branch':s2['selected_extension']['branch']};branch_trace=[{'S2_policy_and_branch_inherited':True,'new_policy_search_performed':False,'S2_lock_sha256':sha(self.pub/'locks/S2_selection.json')}]
        actual=lock['selected_extension']
        for key,value in branch.items():
            require(abs(actual[key]-value)<=EPS if isinstance(value,float) else actual[key]==value,'Selected extension/branch differs: '+key)
        self.compare_chosen(chosen[branch['policy']],actual['locked_config'])
        rules=lock['rules']
        require(rules['absolute_tie_tolerance']==EPS and rules['config_order']==['recall@5_desc','mrr@10_desc','steps_asc','lr_asc','temperature_0.05_first'] and rules['extension_order']==['recall@5_desc','fixed_policy_order'] and rules['fixed_policy_order']==EXTENSIONS and rules['candidate_signal_absolute_recall5']==.01 and rules['no_candidate_policy']=='B_UNIQUE','Recorded lock rule descriptions differ')
        self.table('independent_policy_choices.csv',list(chosen.values()),'Successive Recall@5,MRR@10,steps,lr,temperature survivor elimination; no selector function call')
        self.table('configuration_elimination_evidence.csv',eliminations,'First criterion eliminating each nonselected valid configuration; all scores are independently rescored')
        write_json(self.out/'extension_branch_evidence.json',{'independent_branch':branch,'ranking_trace':branch_trace,'actual_locked_branch':actual,
            'threshold_unit':'absolute Recall@5 score; not statistical significance','S4_has_no_second_extension_search':self.stage=='S4'})
        status='REVIEW_REQUIRED_RECORDED_NUMERICAL_FAILURES' if self.failed_runs else ('REVIEW_REQUIRED_UPSTREAM_S2' if self.upstream_review_required else 'PASS_INDEPENDENT_SELECTION_REVIEW')
        report={**summary,'status':status,'created_at_utc':now(),'independent_branch':branch,'all_locked_choices_match':True,
            'failed_trajectories':self.failed_runs,'numeric_failure_requires_root_review':bool(self.failed_runs),
            'locked_selection_sha256':sha(lock_path),'live_registry_snapshot_sha256':registry_sha,
            'selector_recorded_input_registry_sha256':lock['input_registry']['sha256'],
            'selector_immutable_registry_snapshot_verified':True,'selector_immutable_snapshot_path':self.resolver.display(snapshot_path),
            'selector_immutable_snapshot_sha256':snapshot_sha,
            'upstream_S2_review_sha256':sha(self.upstream_review) if self.stage=='S4' else None,
            'upstream_S2_lock_sha256':sha(self.pub/'locks/S2_selection.json') if self.stage=='S4' else None,
            'selector_logging_amendment_sha256':sha(amendment_path),'selector_scientific_AST_unchanged_from_plan':True,
            'full_registry_bytes_match_selector_record':registry_sha==lock['input_registry']['sha256'],
            'registry_hash_scope':'The original consumed registry bytes are verified from immutable snapshot. Live registry may already contain later-stage progress; corresponding stage scientific fields must still match.',
            'selector_function_called':False,'selection_implementation':'independent admissible-set elimination from raw-rank rescoring',
            'new_selection_or_approval_written':False,'queue_modified':False,'final_scores_read':False,'script_sha256':sha(__file__)}
        write_json(self.out/'review_report.json',report)
        self.provenance();self.status(status,coverage=summary,all_locked_choices_match=True,requires_root_review=bool(self.failed_runs) or self.upstream_review_required)
        self.event('AUDIT_TERMINAL',status=status,valid_cells=summary['valid_grid_slots'],failed_cells=summary['explicit_numerical_failed_slots'])
        return not self.failed_runs and not self.upstream_review_required

    @staticmethod
    def compare_chosen(winner,saved):
        require(all(saved[k]==winner[k] for k in ['run_id','stage','family','policy','seed','lr','temperature','steps']),'Locked chosen scientific configuration differs')
        require(all(abs(saved['metrics'][m]-winner[m])<=EPS for m in ['recall@5','mrr@10']),'Locked chosen metrics differ')
        require(saved['checkpoint_sha256']==winner['checkpoint_sha256'],'Chosen weight SHA differs')

    def provenance(self):
        write_json(self.out/'table_provenance.json',{'all_input_files':list(self.sources.values()),'artifacts':self.artifacts,
            'script_sha256':sha(__file__),'start_source_hashes':self.start_bindings,'rescore_reused':True,'selector_logic_reused':False})


def self_test():
    def candidate(policy='B_UNIQUE',lr=1e-5,t=.05,step=312,r=.4,m=.3):return {'policy':policy,'lr':lr,'temperature':t,'steps':step,'recall@5':r,'mrr@10':m}
    grid=[candidate(lr=lr,t=t,step=step) for lr in LRS for t in TEMPERATURES for step in STEPS]
    winner,losers=choose_configuration(grid);require(cell_key(winner)==('B_UNIQUE',1e-5,.05,312) and len(losers)==11,'Configuration tie hierarchy')
    selected={p:candidate(p) for p in POLICIES};selected['DENSE_STATIC']['mrr@10']=.99
    branch,_=choose_extension(selected);require(branch['best_extension_policy']=='B_UNIQUE' and not branch['candidate_signal_met'],'Cross-policy MRR leaked into choice')
    selected['R_UNIQUE']['recall@5']=.41;branch,_=choose_extension(selected);require(branch['policy']=='R_UNIQUE' and branch['candidate_signal_met'],'Inclusive threshold')
    selected['R_UNIQUE']['recall@5']=.41-2*EPS;branch,_=choose_extension(selected);require(branch['policy']=='B_UNIQUE' and not branch['candidate_signal_met'],'Below-threshold fallback')
    grid[0]['mrr@10']=.9;winner,_=choose_configuration(grid);require(winner is grid[0],'MRR within-policy tie priority')
    return {'passed':True,'checks':['all configuration tie levels','11 discarded valid cells retained','policy ties ignore MRR','inclusive0.01','below-boundary fallback','within-policy MRR'],'actual_scores_read':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input-root',type=Path);p.add_argument('--output-dir',type=Path);p.add_argument('--stage',choices=['S2','S4'])
    p.add_argument('--wait',action='store_true');p.add_argument('--poll-seconds',type=float,default=15);p.add_argument('--self-test',action='store_true')
    p.add_argument('--upstream-review',type=Path,help='Required for S4: independently generated S2 review_report.json');a=p.parse_args()
    if a.self_test:print(json.dumps(self_test()));return 0
    if a.input_root is None or a.output_dir is None or a.stage is None:p.error('--input-root --output-dir --stage required')
    require(1<=a.poll_seconds<=60,'Poll interval must be1..60seconds');review=Reviewer(a.input_root,a.output_dir,a.stage,a.upstream_review)
    try:passed=review.audit(*review.wait(a.wait,a.poll_seconds))
    except BaseException as exc:
        review.errors.append({'error':repr(exc),'traceback':traceback.format_exc()});write_json(review.out/'verification_failures.json',review.errors)
        review.provenance();review.status('FAIL_REQUIRES_ROOT_REVIEW',errors=review.errors,requires_root_review=True)
        review.event('AUDIT_TERMINAL',status='FAIL_REQUIRES_ROOT_REVIEW',error=repr(exc));return 2
    return 0 if passed else 2


if __name__=='__main__':sys.exit(main())
