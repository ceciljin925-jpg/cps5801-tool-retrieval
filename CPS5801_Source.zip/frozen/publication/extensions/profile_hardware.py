"""Engineering-only profile of original32-step training and a full E5 index."""
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
sys.path.insert(0, str(REPRO / 'scripts'))
import main_training_engine as old


def main():
    out = ROOT / 'profile' / 'attempt_01'
    out.mkdir(parents=True, exist_ok=False)
    old.R = out / 'training_fixture'
    old.R.mkdir()
    events = []
    def event(kind, **kw):
        row = {'kind': kind, **kw}
        events.append(row)
        with (out / 'events.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(row) + '\n')
        print(kind, kw, flush=True)
    old.event = event
    torch, np = old.torch, old.np
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    assert torch.cuda.is_bf16_supported()
    tok = old.base.AutoTokenizer.from_pretrained(old.base.MODEL, local_files_only=True)
    train = old.read(old.P / 'train.json')
    corpus = old.read(old.P / 'corpus.json')
    schedule = old.read(old.P / 'shared_schedule_seed42.json')[:32*32]
    neg = old.read(old.P / 'negatives_seed42.json')
    name, model, stats = old.train_run('random', 42, tok, train, corpus, schedule, neg)
    del model
    torch.cuda.empty_cache()
    # Index the unchanged initial model; profiling model weights are never scientific runs.
    model = old.base.load_model()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    emb = old.base.encode(model, tok, [d['text'] for d in corpus], 'passage: ', 384, batch=64)
    torch.cuda.synchronize()
    index_seconds = time.perf_counter() - started
    np.save(out / 'initial_e5_corpus_embeddings.npy', emb.numpy())
    old.dump(out / 'index_order.json', [d['id'] for d in corpus])
    losses = [json.loads(line) for line in (old.R/name/'loss.jsonl').read_text().splitlines()]
    steady = (losses[-1]['elapsed_seconds']-losses[3]['elapsed_seconds'])/(len(losses)-4)
    # Upper bound all84 jobs, no cache reuse; confirmation budgets may select fewer steps.
    updates = 18*625 + 36*1250 + 30*1250
    result = {'engineering_fixture_only': True, 'profile_steps': 32, 'profile_exposures':1024,
              'original_train_stats_have_legacy_hardcoded_epoch_label': 'Ignore epochs2 in profile stats; only1024 exposure fixture ran.',
              'gpu': torch.cuda.get_device_name(), 'torch':torch.__version__, 'training_config':{'microbatch':8,'accumulation':4,'bf16':True,'tf32':False},
              'train_seconds':stats['train_seconds'], 'steady_seconds_per_update_after4_warmup':steady,
              'training_peak_GiB':stats['peak_allocated_GiB'], 'index_tools':len(corpus),
              'index_seconds_float32_batch64':index_seconds, 'index_peak_GiB':torch.cuda.max_memory_allocated()/2**30,
              'max_training_updates_before_reuse':updates, 'training_hours_upper_budget_projection':updates*steady/3600,
              'development_index_count_projection':6+1+12+72+15+36+15,
              'development_index_hours_projection':(6+1+12+72+15+36+15)*index_seconds/3600,
              'limitations':'E5 short training profile extrapolation only. BGE, final inference, Qwen, mining, checkpoint IO, CPU work and installation add time. Selection may reduce confirmation budgets. Actual runs determine completion.',
              'disk_reservation_GiB':100, 'source_model_sha256':old.digest(old.base.MODEL/'model.safetensors')}
    old.dump(ROOT/'estimated_resources.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
