"""Independently rescore original and actual new legacy outputs; never fills gaps."""
from __future__ import annotations
import argparse
import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics

RUNS = ["M01_bm25", "M02_pretrained"] + [f"M{3 + 2 * (seed - 42) + (policy == 'bm25'):02}_{policy}_seed{seed}" for seed in (42, 43, 44) for policy in ("random", "bm25")]
METRICS = ["recall@1", "recall@3", "recall@5", "recall@10", "mrr@10"]
GROUPS = {"BM25": RUNS[:1], "Pretrained": RUNS[1:2], "Random": RUNS[2::2], "Hard": RUNS[3::2]}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for part in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    fields = fields or list(dict.fromkeys(k for row in rows for k in row))
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def score(top, positives):
    positive = set(positives)
    if not positive:
        raise ValueError("Empty positive set")
    return {**{f"recall@{k}": len(set(top[:k]) & positive) / len(positive) for k in (1, 3, 5, 10)},
            "mrr@10": next((1 / rank for rank, tid in enumerate(top[:10], 1) if tid in positive), 0.0)}


def validate_predictions(path, labels, corpus, metrics_path=None):
    """Return independently calculated rows and every structural fault."""
    predictions = read(path)
    if not isinstance(predictions, list):
        raise ValueError("Predictions must be a JSON array")
    labels_by_id = {r["id"]: r for r in labels}
    valid_tools = {r["id"] for r in corpus}
    if len(labels_by_id) != len(labels) or len(valid_tools) != len(corpus):
        raise ValueError("Duplicate frozen label/corpus IDs")
    faults = []
    predicted_ids = [r.get("id") for r in predictions]
    if predicted_ids != [r["id"] for r in labels]:
        faults.append({"kind": "query_order_or_id_coverage", "n": len(predictions), "expected_n": len(labels),
                       "duplicate_ids": [k for k, n in collections.Counter(predicted_ids).items() if n > 1],
                       "missing": sorted(set(labels_by_id) - set(predicted_ids)), "foreign": sorted(set(predicted_ids) - set(labels_by_id))})
    calculated = []
    for row in predictions:
        rid = row.get("id")
        if rid not in labels_by_id:
            continue
        truth = labels_by_id[rid]["positives"]
        if not truth or len(truth) != len(set(truth)) or not set(truth) <= valid_tools:
            faults.append({"id": rid, "kind": "invalid_frozen_positives"})
            continue
        if not isinstance(row.get("positives"), list) or set(row["positives"]) != set(truth):
            faults.append({"id": rid, "kind": "positive_identity"})
        top, values = row.get("top10"), row.get("scores")
        if not isinstance(top, list) or len(top) != 10 or not all(isinstance(x, str) for x in top) or len(set(top)) != 10 or not set(top) <= valid_tools:
            faults.append({"id": rid, "kind": "top10_length_uniqueness_or_corpus"})
            continue
        if not isinstance(values, list) or len(values) != 10 or not all(finite(x) for x in values):
            faults.append({"id": rid, "kind": "nonfinite_or_invalid_scores"})
        elif any(a < b for a, b in zip(values, values[1:])) or any(values[i] == values[i + 1] and top[i] > top[i + 1] for i in range(9)):
            faults.append({"id": rid, "kind": "score_or_tool_id_tie_sort"})
        metrics = score(top, truth)
        for key, value in metrics.items():
            if key in row and (not finite(row[key]) or abs(row[key] - value) > 1e-10):
                faults.append({"id": rid, "kind": "stored_row_metric", "metric": key, "calculated": value, "stored": row.get(key)})
        calculated.append({"id": rid, **metrics})
    means = {key: statistics.mean(r[key] for r in calculated) for key in METRICS} if len(calculated) == len(labels) else None
    stored_check = None
    if metrics_path and Path(metrics_path).exists():
        saved = read(metrics_path)
        if means:
            stored_check = {}
            for key in METRICS:
                old = saved.get("metrics", {}).get(key)
                stored_check[key] = {"stored": old, "calculated": means[key], "absolute_difference": abs(old - means[key]) if finite(old) else None}
                if not finite(old) or abs(old - means[key]) > 1e-10:
                    faults.append({"kind": "stored_aggregate_metric", "metric": key})
    return {"path": str(path), "sha256": sha(path), "n": len(predictions), "passed": not faults, "faults": faults,
            "means": means, "saved_aggregate_checks": stored_check, "predictions": predictions, "calculated": calculated}


def fixture():
    assert score(["x", "p", "q", "z"], ["p", "q"])["recall@1"] == 0
    assert score(["x", "p", "q", "z"], ["p", "q"])["recall@3"] == 1
    assert score(["x", "p", "q", "z"], ["p", "q"])["mrr@10"] == 0.5
    assert score(["p", "p"], ["p", "q"])["recall@3"] == 0.5
    return {"status": "PASS", "covered": "multi-positive recall, exact reciprocal rank, duplicate IDs cannot inflate recall"}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--original-root", type=Path, required=True)
    ap.add_argument("--reproduction-root", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--package-root", type=Path)
    ap.add_argument("--allow-partial", action="store_true")
    ap.add_argument("--fixture-only", action="store_true")
    args = ap.parse_args()
    if args.fixture_only:
        print(json.dumps(fixture()))
        return 0
    original, repro, out = args.original_root.resolve(), args.reproduction_root.resolve(), args.output_dir.resolve()
    if out.is_relative_to(original) or out.is_relative_to(repro):
        raise ValueError("Output directory must be separate from both input project roots")
    if not any((repro / "results/main_20261025" / suffix / run / "predictions.json").exists() for suffix in ("", "official_test") for run in RUNS):
        print(json.dumps({"status": "PENDING_REPRODUCTION", "reason": "No new prediction files exist; original files were not substituted"}))
        return 2
    out.mkdir(parents=True, exist_ok=True)
    binding = {}

    def bind(path, side):
        key = side + ":" + str(path.relative_to(original if side == "original" else repro)).replace("\\", "/")
        binding[key] = {"sha256": sha(path), "bytes": path.stat().st_size}

    report = {"created_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "code_sha256": sha(__file__),
              "fixture": fixture(), "runs": [], "training": [], "selection": [], "input_files": binding,
              "limitations": ["Top10 checks cannot establish the exact rank of omitted candidates.", "Historical checkpoint weights were omitted; only their recorded file hashes can be compared.", "Only logged gradient norms are available, not full gradient tensors.", "Metric/byte differences are reported; they are not automatically attributed to randomness or accepted as equivalence."]}
    available = {"original": {}, "reproduction": {}}
    per_query = []
    metric_differences = []
    prediction_differences = []
    missing = []
    for split, label_name, corpus_name, suffix in (("development", "dev", "corpus", ""), ("official_test", "test", "test_corpus", "official_test")):
        labels_path = original / f"data/main_20261025/{label_name}.json"
        corpus_path = original / f"data/main_20261025/{corpus_name}.json"
        labels, corpus = read(labels_path), read(corpus_path)
        bind(labels_path, "original")
        bind(corpus_path, "original")
        for relative in (f"data/main_20261025/{label_name}.json", f"data/main_20261025/{corpus_name}.json"):
            if sha(original / relative) != sha(repro / relative):
                raise ValueError("Reproduction input bytes differ: " + relative)
            bind(repro / relative, "reproduction")
        for run in RUNS:
            audits = {}
            for side, root in (("original", original), ("reproduction", repro)):
                run_dir = root / "results/main_20261025" / suffix / run
                path = run_dir / "predictions.json"
                if not path.exists():
                    missing.append({"side": side, "split": split, "run": run, "path": str(path)})
                    continue
                bind(path, side)
                if (run_dir / "metrics.json").exists():
                    bind(run_dir / "metrics.json", side)
                value = validate_predictions(path, labels, corpus, run_dir / "metrics.json")
                audits[side] = value
                report["runs"].append({"side": side, "split": split, "run_id": run, **{k: v for k, v in value.items() if k not in {"predictions", "calculated"}}})
                if value["passed"]:
                    available[side][(split, run)] = value
                per_query.extend({"side": side, "split": split, "run_id": run, **row} for row in value["calculated"])
            if len(audits) != 2 or not all(a["passed"] for a in audits.values()):
                continue
            a, b = audits["original"], audits["reproduction"]
            exact = top1 = 0
            score_errors = []
            first_mismatch = None
            for ar, br in zip(a["predictions"], b["predictions"], strict=True):
                assert ar["id"] == br["id"]
                equal = ar["top10"] == br["top10"]
                exact += equal
                top1 += ar["top10"][0] == br["top10"][0]
                first_mismatch = first_mismatch or (None if equal else ar["id"])
                orig_scores = dict(zip(ar["top10"], ar["scores"], strict=True))
                new_scores = dict(zip(br["top10"], br["scores"], strict=True))
                common = sorted(set(orig_scores) & set(new_scores))
                differences = [abs(new_scores[t] - orig_scores[t]) for t in common]
                score_errors.extend(differences)
                prediction_differences.append({"split": split, "run_id": run, "query_id": ar["id"], "top10_identical": equal,
                                               "top1_identical": ar["top10"][0] == br["top10"][0], "common_top10_ids": len(common),
                                               "max_abs_same_id_score_difference": max(differences, default=None), "mean_abs_same_id_score_difference": statistics.mean(differences) if differences else None})
            summary = {"split": split, "run_id": run, "n": len(labels), "top10_identical_fraction": exact / len(labels),
                       "top1_identical_fraction": top1 / len(labels), "first_top10_mismatch_query": first_mismatch,
                       "same_id_score_comparisons": len(score_errors), "max_abs_same_id_score_difference": max(score_errors, default=None),
                       "mean_abs_same_id_score_difference": statistics.mean(score_errors) if score_errors else None,
                       "prediction_bytes_identical": a["sha256"] == b["sha256"]}
            for key in METRICS:
                metric_differences.append({**summary, "metric": key, "original": a["means"][key], "reproduction": b["means"][key],
                                           "reproduction_minus_original": b["means"][key] - a["means"][key]})
    write_csv(out / "per_query_recalculated.csv.gz", per_query)
    write_csv(out / "original_vs_reproduction.csv", metric_differences)
    write_csv(out / "prediction_agreement_per_query.csv.gz", prediction_differences)
    historical = {}
    if args.package_root:
        scope = read(args.package_root / "package_scope.json")
        historical = {r["original_relative_path"].removeprefix("CPS5801/"): r for r in scope["excluded_files"]}
    trace_differences = []
    for run in RUNS[2:]:
        paths = {side: root / "results/main_20261025" / run for side, root in (("original", original), ("reproduction", repro))}
        if not all((p / "training.json").exists() and (p / "loss.jsonl").exists() for p in paths.values()):
            report["training"].append({"run_id": run, "status": "PENDING_NEW_TRAINING"})
            continue
        training, traces = {}, {}
        for side, path in paths.items():
            bind(path / "training.json", side)
            bind(path / "loss.jsonl", side)
            training[side] = read(path / "training.json")
            traces[side] = [json.loads(line) for line in (path / "loss.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
            if training[side]["steps"] != 625 or len(traces[side]) != 625 or [r["step"] for r in traces[side]] != list(range(1, 626)):
                raise ValueError("Training update count/sequence invalid: " + side + " " + run)
            if not all(finite(r["loss"]) and finite(r["grad_norm"]) for r in traces[side]) or training[side]["embedding_weight_change_l2"] <= 0:
                raise ValueError("Nonfinite or unchanged training: " + side + " " + run)
        errors = {key: [] for key in ("loss", "grad_norm")}
        for ar, br in zip(traces["original"], traces["reproduction"], strict=True):
            if ar["epoch"] != br["epoch"]:
                raise ValueError("Epoch boundary mismatch")
            row = {"run_id": run, "step": ar["step"], "epoch": ar["epoch"]}
            for key in errors:
                row[key + "_original"] = ar[key]
                row[key + "_reproduction"] = br[key]
                row[key + "_difference"] = br[key] - ar[key]
                errors[key].append(abs(br[key] - ar[key]))
            trace_differences.append(row)
        checkpoint_files = []
        for path in sorted((paths["reproduction"] / "checkpoint").glob("*")):
            if not path.is_file():
                continue
            rel = str(path.relative_to(repro)).replace("\\", "/")
            recorded = historical.get(rel)
            checkpoint_files.append({"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path),
                                     "historical_recorded_sha256": recorded["sha256"] if recorded else None,
                                     "bytes_match_historical_record": sha(path) == recorded["sha256"] if recorded else None,
                                     "old_actual_weights_available": False})
        checks = {key: training["original"].get(key) == training["reproduction"].get(key) for key in ("seed", "policy", "schedule_sha256", "negative_manifest_sha256", "snapshot_manifest_sha256", "experiment_code_sha256")}
        report["training"].append({"run_id": run, "status": "CHECKED", "steps": 625, "field_identity": checks,
                                    "trace": {key: {"max_absolute_difference": max(values), "mean_absolute_difference": statistics.mean(values), "first_different_step": next((i + 1 for i, value in enumerate(values) if value != 0), None)} for key, values in errors.items()},
                                    "checkpoint_files": checkpoint_files, "checkpoint_weights_present": any(x["path"].endswith("model.safetensors") for x in checkpoint_files)})
    write_csv(out / "training_trace_comparison.csv", trace_differences)
    paired = []
    for side in ("original", "reproduction"):
        for split in ("development", "official_test"):
            for seed, rand, hard in zip((42, 43, 44), RUNS[2::2], RUNS[3::2]):
                if (split, rand) in available[side] and (split, hard) in available[side]:
                    for metric in METRICS:
                        a, b = available[side][(split, rand)]["means"][metric], available[side][(split, hard)]["means"][metric]
                        paired.append({"side": side, "split": split, "seed": seed, "metric": metric, "random": a, "hard": b, "hard_minus_random": b - a})
        if not all(("development", run) in available[side] for run in RUNS):
            continue
        target = available[side][("development", "M02_pretrained")]["means"]["recall@10"]
        selection_path = (original if side == "original" else repro) / "results/main_20261025/official_test/development_selection.json"
        saved_selection = read(selection_path) if selection_path.exists() else None
        if selection_path.exists():
            bind(selection_path, side)
        for name, runs in GROUPS.items():
            recalls = {k: statistics.mean(available[side][("development", run)]["means"][f"recall@{k}"] for run in runs) for k in (1, 3, 5, 10)}
            selected = next((k for k, value in recalls.items() if value >= target), None)
            report["selection"].append({"side": side, "group": name, "target_pretrained_dev_recall10": target,
                                        "recall_by_k": recalls, "recomputed_selected_k": selected,
                                        "saved_selected_k": saved_selection["groups"][name]["selected_k"] if saved_selection else None,
                                        "saved_selection_available": saved_selection is not None,
                                        "matches_saved": selected == saved_selection["groups"][name]["selected_k"] if saved_selection else None})
    write_csv(out / "paired_effects_all_seeds.csv", paired)
    complete = len(available["reproduction"]) == 16 and len(available["original"]) == 16
    failures = [r for r in report["runs"] if not r["passed"]]
    report["summary"] = {"status": "PASS_COMPLETE" if complete and not failures else ("FAIL" if failures else "PENDING_REPRODUCTION"),
                         "expected_prediction_sets_per_side": 16, "valid_original": len(available["original"]), "valid_reproduction": len(available["reproduction"]),
                         "missing": missing, "comparison_rows": len(metric_differences), "original_outputs_substituted_for_new": False}
    write(out / "reproduction_comparison.json", report)
    print(json.dumps(report["summary"], ensure_ascii=False))
    return 0 if complete and not failures else (0 if args.allow_partial and not failures else 2)


if __name__ == "__main__":
    raise SystemExit(main())
