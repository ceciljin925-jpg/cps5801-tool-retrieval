"""Wait for S1 and independently audit all fixed-recipe development evidence.

Read-only CPU worker. Opens no new legacy-test predictions or external final
files; never chooses a policy/checkpoint, changes the queue, or runs a model.
S0 comparison is used only for its saved development file-identity bindings.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time
import traceback

from rebuild_all import Resolver, read_json, require, rescore, sha, write_csv, write_json, write_jsonl_gz

POLICIES=['R_ID','B_ID','R_UNIQUE','B_UNIQUE','MIXED_2R2B','DENSE_STATIC']
SEEDS=[42,43,44]
METRICS=['recall@1','recall@3','recall@5','recall@10','mrr@10']
COEFFICIENTS={'delta_R':{'R_UNIQUE':1,'R_ID':-1},'delta_B':{'B_UNIQUE':1,'B_ID':-1},
              'interaction_delta_B_minus_delta_R':{'B_UNIQUE':1,'B_ID':-1,'R_UNIQUE':-1,'R_ID':1}}


def stamp():return datetime.now(timezone.utc).isoformat()


def canonical(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def select_fixed_runs(registry):
    rows=[r for r in registry['runs'] if r['stage'] in ['S0','S1']]
    expected={(policy,seed) for policy in POLICIES for seed in SEEDS}
    require(len(rows)==18 and len({r['run_id'] for r in rows})==18,'Exactly18 unique S0/S1 runs required')
    require({(r['policy'],r['seed']) for r in rows}==expected,'Fixed-recipe policy/seed grid differs')
    require(all(r['stage']==('S0' if r['policy'] in ['R_ID','B_ID'] else 'S1') for r in rows),'Policy stage changed')
    return sorted(rows,key=lambda r:(POLICIES.index(r['policy']),r['seed']))


def descriptive_effects(per_query,query_ids):
    rows=[]
    for name,coefficients in COEFFICIENTS.items():
        for seed in SEEDS:
            differences={metric:[math.fsum(coefficient*per_query[(policy,seed)][qid][metric]
                                          for policy,coefficient in coefficients.items()) for qid in query_ids] for metric in METRICS}
            rows.append({'contrast':name,'seed':seed,'n_queries':len(query_ids),'scope':'fixed-recipe development descriptive effect',
                         **{metric:math.fsum(values)/len(values) for metric,values in differences.items()}})
    summaries=[]
    for name in COEFFICIENTS:
        chosen=[r for r in rows if r['contrast']==name]
        result={'contrast':name,'seeds':'42,43,44','n_seeds':3,'n_queries':len(query_ids),'uncertainty':'sample SD across three paired seed effects; no CI or hypothesis test'}
        for metric in METRICS:
            values=[r[metric] for r in chosen]
            result[metric+'_mean']=statistics.mean(values);result[metric+'_seed_sample_sd']=statistics.stdev(values)
        summaries.append(result)
    return rows,summaries


class S1Review:
    def __init__(self,input_root,output):
        self.resolver=Resolver(input_root);self.pub=self.resolver.publication
        self.out=Path(output).resolve()
        require(not self.out.exists(),'Use a new review directory; preserve existing attempts')
        self.out.mkdir(parents=True)
        bundle=self.resolver.mapping_path.parent if self.resolver.mapping_path else self.pub.parent
        self.repro=bundle/('reproduction' if (bundle/'reproduction').is_dir() else 'repro')
        self.data=self.repro/'data/main_20261025'
        self.inputs={};self.artifacts=[];self.verifications=[]

    def status(self,value,**fields):
        write_json(self.out/'status.json',{'status':value,'updated_at_utc':stamp(),'only_development_evidence':True,
            'external_final_scores_read':False,'new_legacy_test_scores_read':False,'GPU_used':False,**fields})

    def source(self,path,expected=None):
        path=Path(path).resolve()
        if path not in self.inputs:self.inputs[path]={'path':self.resolver.display(path),'bytes':path.stat().st_size,'sha256':sha(path)}
        row=self.inputs[path];require(expected is None or row['sha256']==expected,'SHA mismatch: '+str(path))
        return row

    def load(self,path,expected=None):
        self.source(path,expected);return read_json(path)

    def resolve(self,path):return self.resolver.resolve(path,self.pub)

    def directory_manifest(self,path):
        path=Path(path)
        return {p.relative_to(path).as_posix():{'bytes':self.source(p)['bytes'],'sha256':self.source(p)['sha256']}
                for p in sorted(path.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.tmp')}

    def register(self,path,formula):
        self.artifacts.append({'output':path.relative_to(self.out).as_posix(),'sha256':sha(path),'bytes':path.stat().st_size,
            'formula':formula,'stage':'EXPLORATORY_DEV','seeds':SEEDS,'query_weighting':'equal query',
            'missing_handling':'any omitted run/query/metric fails stage review; no substituted output',
            'script_sha256':sha(__file__)})

    def await_s1(self,wait,poll):
        previous=None
        while True:
            raw=(self.pub/'run_registry.json').read_bytes();registry=json.loads(raw.decode('utf-8-sig'))
            selected=select_fixed_runs(registry);s1=[r for r in selected if r['stage']=='S1']
            counts=dict(Counter(r['status'] for r in s1));failed=[r for r in s1 if r['status'] not in ['pending','running','completed']]
            if failed:
                self.status('S1_FAILED_BEFORE_REVIEW',failed_runs=[{k:r.get(k) for k in ['run_id','status','failure_kind','failure_reason']} for r in failed])
                raise ValueError('S1 has a failed/interrupted/unsupported terminal run; queue not modified')
            if counts=={'completed':12}:
                require(all(r['status']=='completed' for r in selected),'S0 comparison runs are not all completed')
                snapshot=self.out/'registry_snapshot.json';snapshot.write_bytes(raw);self.source(snapshot)
                write_json(self.out/'registry_snapshot_identity.json',{'source':self.resolver.display(self.pub/'run_registry.json'),
                    'captured_at_utc':stamp(),'sha256':hashlib.sha256(raw).hexdigest(),'note':'Immutable bytes captured once; live registry may advance into S2 during this audit'})
                return selected
            if counts!=previous:
                self.status('WAITING_FOR_ALL_12_S1_COMPLETED',s1_statuses=counts)
                print(json.dumps({'at':stamp(),'S1_statuses':counts,'read_scores':False}),flush=True);previous=counts
            require(wait,'S1 incomplete; use --wait to watch metadata only')
            time.sleep(poll)

    def run(self,selected):
        self.status('AUDITING_COMPLETE_S1_DEVELOPMENT')
        freeze=self.load(self.data/'freeze_manifest.json')['files']
        dev_path,corpus_path=self.data/'dev.json',self.data/'corpus.json'
        queries=self.load(dev_path,freeze['data/main_20261025/dev.json'])
        corpus=self.load(corpus_path,freeze['data/main_20261025/corpus.json'])
        require(len(queries)==1000 and len(corpus)==41732,'Frozen development/corpus dimensions differ')
        qids=[q['id'] for q in queries]
        # Read only identity metadata from the already accepted S0 comparison.
        # No test prediction, metric, row, or selected-k field is used.
        comparison_path=self.pub/'comparison/reproduction_comparison.json'
        s0_bindings=self.load(comparison_path)['input_files']
        s0_dev_bindings={key:value for key,value in s0_bindings.items()
                         if key.startswith('reproduction:results/main_20261025/') and '/official_test/' not in key}
        base_manifest=self.directory_manifest(self.repro/'data/raw/model')
        initial_model_digest=canonical(base_manifest)
        per_query={};run_rows=[];budget=[];maximum_error=0.
        for row in selected:
            run_id=row['run_id'];stage=row['stage'];seed=row['seed'];policy=row['policy'];config=row['config']
            require((row['family'],config['family'],config['stage'],config['policy'],config['seed'],config['lr'],config['temperature'],config['steps'])==
                    ('e5','e5',stage,policy,seed,2e-5,.05,625),'Fixed training configuration mismatch: '+run_id)
            require(row['actual_steps']==625 and len(row['dev_evaluations'])==1 and row['dev_evaluations'][0]['steps']==625,'Wrong actual budget/dev checkpoint')
            ev=row['dev_evaluations'][0];out=self.resolve(row['output_path'])
            stats=self.load(out/'training.json');loss=self.load(out/'loss.jsonl')
            require(stats['steps']==len(loss)==625 and [r['step'] for r in loss]==list(range(1,626)),'Incomplete/noncontiguous625-update trace')
            require(all(math.isfinite(r['loss']) and math.isfinite(r['grad_norm']) for r in loss),'Nonfinite saved training loss/grad')
            checkpoint=self.resolve(row['checkpoint_path']);manifest=self.directory_manifest(checkpoint)
            checkpoint_hash=manifest['model.safetensors']['sha256']
            old_schedule_path=self.data/f'shared_schedule_seed{seed}.json'
            old_schedule=self.load(old_schedule_path,freeze[f'data/main_20261025/shared_schedule_seed{seed}.json'])
            require(len(old_schedule)==20000,'Original schedule does not contain20000 exposures')
            prediction_path=self.resolve(ev['metrics_path']).with_name('predictions.json');metrics_path=prediction_path.with_name('metrics.json')
            if stage=='S1':
                require(config['microbatch']==8 and config['accumulation']==4 and config['checkpoint_steps']==[625],'S1 batch/checkpoint settings changed')
                require(self.load(out/'config.json')==config,'Executed/registry S1 config mismatch')
                require(self.load(out/'status.json')['status']=='completed' and stats['exposures']==20000,'S1 training status/exposures incomplete')
                self.source(prediction_path,ev['predictions_sha256']);self.source(metrics_path,ev['metrics_sha256'])
                require(checkpoint_hash==ev['checkpoint_sha256'],'Checkpoint differs from saved dev checkpoint SHA')
                require(manifest==self.load(out/'checkpoint_manifest.json')['step_0625'],'Checkpoint directory changed')
                identity=self.load(out/'identity.json');require(canonical(identity)==stats['identity_sha256'],'Training identity digest changed')
                require(all(identity[field]==config[field] for field in ['family','seed','lr','temperature','steps','microbatch','accumulation']),
                        'Executed scientific identity differs from fixed recipe config')
                require(canonical(identity['model_files'])==initial_model_digest,'S1 initial pretrained files differ across policies')
                for field,value in identity['input_files'].items():self.source(self.resolve(config[field]),value)
                require(self.resolve(config['train_path'])==self.data/'train.json' and self.resolve(config['corpus_path'])==corpus_path,'S1 train/corpus path changed')
                for name in ['train.json','corpus.json','train_tool_ids.json','forbidden_ids.json']:
                    self.source(self.data/name,freeze['data/main_20261025/'+name])
                schedule=self.load(self.resolve(config['schedule_path']))[:20000]
                require(schedule==old_schedule and canonical(schedule)==identity['actual_schedule_prefix_sha256'],'S0/S1 query exposure/positive prefix differs')
                require(canonical(self.load(self.resolve(config['negatives_path'])))==identity['actual_negatives_sha256'],'Executed negative IDs mismatch')
                cp=self.load(checkpoint/'checkpoint_provenance.json')
                require(cp['run_id']==run_id and cp['step']==625 and cp['exposures']==20000 and cp['identity_sha256']==stats['identity_sha256'],'Checkpoint scientific provenance mismatch')
                dev_config=self.load(prediction_path.parent/'config.json')
                require(self.resolve(dev_config['queries_path'])==dev_path and self.resolve(dev_config['corpus_path'])==corpus_path,'Evaluation does not use frozen dev/corpus')
                require(self.resolve(dev_config['model_path'])==checkpoint and dev_config['split']=='original_development','Development checkpoint/split mismatch')
                require(self.load(prediction_path.parent/'status.json')['status']=='completed','Development scoring incomplete')
            else:
                require(checkpoint_hash==row['checkpoint_sha256'],'S0 checkpoint differs from accepted recorded SHA')
                for path in [prediction_path,metrics_path,out/'training.json',out/'loss.jsonl']:
                    key='reproduction:'+path.relative_to(self.repro).as_posix()
                    require(key in s0_dev_bindings,'S0 development file absent in accepted comparison hash ledger')
                    self.source(path,s0_dev_bindings[key]['sha256'])
                old_config=self.load(out/'config.json')
                require(old_config['seed']==seed and old_config['policy']==('random' if policy=='R_ID' else 'bm25'),'S0 recorded identity differs')
                # The accepted comparison binds training.json, but did not bind
                # config.json. Validate only shared scientific identifiers here;
                # inherited environment/build prose is not an equality target.
                scientific=['run_id','policy','seed','schedule_sha256','negative_manifest_sha256',
                            'snapshot_manifest_sha256','experiment_code_sha256','evaluation_code_sha256']
                require(all(old_config[field]==stats[field] for field in scientific),'S0 config scientific fields differ from accepted training record')
                self.source(self.data/'freeze_manifest.json',stats['snapshot_manifest_sha256'])
                require(stats['schedule_sha256']==sha(old_schedule_path),'S0 executed schedule differs')
            report=self.load(metrics_path)
            require(report['n']==1000 and report['candidate_tools']==len(corpus),'Development evaluation dimensions differ')
            if stage=='S1':
                require(report['input_hashes']=={'queries':sha(dev_path),'corpus':sha(corpus_path)},'Evaluation input hash mismatch')
                require(report['model_manifest_sha256']==canonical(manifest),'Development scored a different checkpoint')
            result=rescore(self.load(prediction_path),queries,corpus)
            require(result['n']==1000,'Rescore omitted queries')
            errors={metric:abs(result['metrics'][metric]-report['metrics'][metric]) for metric in METRICS}
            require(max(errors.values())<=1e-10,'Independent metric mismatch')
            maximum_error=max(maximum_error,max(errors.values()),result['verification']['maximum_saved_per_query_metric_error'])
            per_query[(policy,seed)]={r['id']:r for r in result['per_query']}
            run_rows.append({'run_id':run_id,'stage':stage,'policy':policy,'seed':seed,'split':'frozen development',
                             'n_queries':1000,**{metric:result['metrics'][metric] for metric in METRICS}})
            budget.append({'run_id':run_id,'stage':stage,'policy':policy,'seed':seed,'optimizer_updates':625,'loss_rows':len(loss),
                           'query_exposures':20000,'lr':2e-5,'temperature':.05,'effective_batch':32,
                           'checkpoint_sha256':checkpoint_hash,'predictions_sha256':sha(prediction_path),'metrics_sha256':sha(metrics_path),
                           'query_sha256':sha(dev_path),'corpus_sha256':sha(corpus_path),'max_metric_recompute_error':max(errors.values()),
                           'status':'PASS'})
            self.verifications.append({'run_id':run_id,'status':'PASS','per_query_checks':result['verification'],'saved_aggregate_absolute_errors':errors})
        summary=[]
        for policy in POLICIES:
            records=[r for r in run_rows if r['policy']==policy]
            require([r['seed'] for r in records]==SEEDS,'Missing descriptive seed')
            record={'policy':policy,'split':'frozen development','seeds':'42,43,44','n_seeds':3,'n_queries':1000,
                    'uncertainty':'sample SD of three fitted seed scores; not a query/cluster CI'}
            for metric in METRICS:
                values=[r[metric] for r in records];record[metric+'_mean']=statistics.mean(values);record[metric+'_seed_sample_sd']=statistics.stdev(values)
            summary.append(record)
        effects,effect_summary=descriptive_effects(per_query,qids)
        for name,rows,formula in [('development_all_seeds.csv',run_rows,'Five common metrics independently rescored from frozen positive labels and raw ranking IDs; every query equal weight'),
            ('development_policy_summary.csv',summary,'All three fixed seed scores, arithmetic mean and sample SD(ddof1), no seed removal'),
            ('development_mechanism_all_seeds.csv',effects,'Paired per-query DeltaR=R_UNIQUE-R_ID, DeltaB=B_UNIQUE-B_ID, interaction=DeltaB-DeltaR, then query mean'),
            ('development_mechanism_summary.csv',effect_summary,'Mean and sample SD of the three paired development effects; no confidence interval or hypothesis test'),
            ('training_and_input_acceptance.csv',budget,'Actual625 optimizer/loss rows and20000 exposures, frozen config/data/checkpoint identity checks')]:
            path=self.out/name;write_csv(path,rows);self.register(path,formula)
        path=self.out/'development_per_query_recomputed.jsonl.gz'
        write_jsonl_gz(path,({'policy':policy,'seed':seed,'id':qid,**{metric:per_query[(policy,seed)][qid][metric] for metric in METRICS}}
                           for policy in POLICIES for seed in SEEDS for qid in qids))
        self.register(path,'Recomputed per-query common metrics for all18 fixed-recipe runs; no bootstrap repeated')
        result={'status':'PASS_S1_FIXED_RECIPE_DEVELOPMENT_REVIEW','reviewed_at_utc':stamp(),'S1_completed_and_validated':12,'S0_reference_runs_validated':6,
                'policies':POLICIES,'seeds':SEEDS,'n_queries_per_run':1000,'total_recomputed_query_rows':18000,
                'max_saved_metric_absolute_error':maximum_error,'selection_performed':False,'bootstrap_performed':False,
                'external_final_scores_read':False,'new_legacy_test_scores_read':False,'scope':'EXPLORATORY_DEV; three fixed seeds, no method success or confirmatory claim',
                'scientific_decisions_changed':False,'queue_modified':False,'run_verifications':self.verifications,'script_sha256':sha(__file__)}
        result['reviewer_technical_fix']={'record':'provenance/s1_review_preexecution_fix/fix_record.json',
            'scope':'Reviewer only, corrected before any S1 development scores were read',
            'changes':['S0 config is checked against accepted scientific fields, not a nonexistent comparison-ledger config hash',
                       'Frozen manifest is anchored to accepted S0 training hash', 'S1 identity scientific recipe fields are checked against config'],
            'training_selection_and_scoring_changed':False}
        write_json(self.out/'review_report.json',result)
        lines=['S1 的12个实际训练/开发输出与S0六个对照已完成独立CPU验收。仅使用冻结1000题开发集与41732工具目录；共重算18000个逐题输出。',
               '校验625个optimizer updates/625行loss、20000次query暴露、固定lr2e-5/温度0.05/有效batch32、全部policy×seed、冻结数据与已记录预测/指标/checkpoint SHA。S1与S0的每seed查询/正例暴露前缀一致。',
               'S0比较文件仅用于读取已保存的development文件SHA绑定；未使用其测试结果字段，也未打开新legacy test或external final的预测/指标。',
               '表格按固定策略顺序列出全部seed42/43/44、均值及样本标准差；标准差描述这三个已拟合seed，不是查询/cluster置信区间。',
               'DeltaR、DeltaB及DeltaB-DeltaR是同seed同query配对的开发集描述；不重复bootstrap、不做显著性检验、不使用它重新选择策略或停止既定训练。',
               '本阶段通过表示工程完整性通过；不能据此宣布方法成功、识别语义假负例因果机制或替代后续seed41开发搜索与锁定确认。']
        lines.append('本审查器在读取S1开发成绩前修正了技术门禁：S0 config未被旧comparison SHA账本登记，现仅对照已绑定training记录的科学字段；另补冻表SHA锚定与S1 identity配方字段一致检查。原等待记录/旧源码/差异保留，训练、评分、选择和队列均未改动。')
        lines.append('开发集三seed均值（固定展示顺序，无排名/选择）：')
        for row in summary:lines.append(f"{row['policy']}: Recall@5={row['recall@5_mean']:.9f}, MRR@10={row['mrr@10_mean']:.9f}。")
        lines.append('配对开发描述（三seed均值，分数单位）：')
        for row in effect_summary:lines.append(f"{row['contrast']}: Delta Recall@5={row['recall@5_mean']:+.9f}, Delta MRR@10={row['mrr@10_mean']:+.9f}。")
        path=self.out/'验收与开发描述说明.txt';path.write_text('\n'.join(lines)+'\n',encoding='utf-8');self.register(path,'Engineering acceptance and bounded descriptive development summary')
        write_json(self.out/'table_provenance.json',{'schema_version':1,'artifacts':self.artifacts,'all_input_files':list(self.inputs.values()),
            'script_sha256':sha(__file__),'rescore_script_sha256':sha(Path(__file__).with_name('rebuild_all.py')),
            'comparison_metadata_read_scope':'input_files development hashes only, never its test result fields',
            'only_development':True,'no_model_execution':True})
        self.status(result['status'],S1_validated=12,S0_validated=6,total_recomputed_query_rows=18000,max_saved_metric_absolute_error=maximum_error,
                    selection_performed=False,bootstrap_performed=False,queue_modified=False)
        return result


def self_test():
    rows=[]
    for policy in POLICIES:
        for seed in SEEDS:rows.append({'run_id':f'{policy}_{seed}','stage':'S0' if policy in ['R_ID','B_ID'] else 'S1','policy':policy,'seed':seed})
    require(len(select_fixed_runs({'runs':rows}))==18,'Fixed grid fixture failed')
    try:select_fixed_runs({'runs':rows[:-1]})
    except ValueError:pass
    else:raise AssertionError('Missing fixed seed accepted')
    values={'R_ID':.2,'B_ID':.3,'R_UNIQUE':.25,'B_UNIQUE':.5}
    per_query={(policy,seed):{'q':{metric:value for metric in METRICS}} for policy,value in values.items() for seed in SEEDS}
    _,summary=descriptive_effects(per_query,['q'])
    effect=next(r for r in summary if r['contrast']=='interaction_delta_B_minus_delta_R')
    require(abs(effect['recall@5_mean']-.15)<1e-12 and effect['recall@5_seed_sample_sd']==0,'Wrong paired interaction formula')
    return {'passed':True,'checks':['18 policy/seed grid','missing seed rejected','paired difference-in-differences and sample SD'],'no_actual_scores_read':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input-root',type=Path);parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--wait',action='store_true');parser.add_argument('--poll-seconds',type=float,default=15);parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:print(json.dumps(self_test()));return 0
    if args.input_root is None or args.output_dir is None:parser.error('--input-root and --output-dir required')
    require(1<=args.poll_seconds<=60,'Polling interval must be1..60 seconds')
    review=S1Review(args.input_root,args.output_dir)
    try:
        selected=review.await_s1(args.wait,args.poll_seconds);result=review.run(selected)
        print(json.dumps({k:result[k] for k in ['status','S1_completed_and_validated','S0_reference_runs_validated','max_saved_metric_absolute_error','scope']},ensure_ascii=False,indent=2),flush=True)
    except BaseException as error:
        review.status('FAILED_S1_STAGE_REVIEW',error=repr(error),traceback=traceback.format_exc(),queue_modified=False)
        raise
    return 0


if __name__=='__main__':sys.exit(main())
