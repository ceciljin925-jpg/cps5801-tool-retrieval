"""Offline evidence rebuild from saved rankings, frozen labels, and raw logs.

Usage: python rebuild_all.py --input-root PUBLICATION_OR_RETURN_ROOT --output-dir NEW_DIR
       python rebuild_all.py --self-test

Portable bundles may contain path_map.json as {old_prefix: relative_prefix},
{"mappings": [{"source_prefix":..., "target_prefix":...}]}, or a list thereof.
Mapped bundle paths take precedence over the original machine's absolute paths.
Final registry: {"evaluations":[{evaluation_id,run_id,dataset,family,policy,seed,
stage,output_path,queries_path,corpus_path,status}]}. Development evaluations are
also discovered from run_registry runs[*].dev_evaluations. Original/reproduction
M01..M08 dev/test saved rankings are discovered separately and remain labeled.

No training, model loading, network access, human labeling, or test selection.
Missing/pending evidence is listed. Invalid completed evidence yields exit 2
after preserving the valid tables and a machine-readable failure report.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics
import sys
import tempfile
import unicodedata

from publication_statistics import analyze as paired_analyze
from select_on_dev import select as select_dev


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig") as stream:
        if ".jsonl" in path.name:
            return [json.loads(line) for line in stream if line.strip()]
        return json.load(stream)


def normalized_query(text):
    return " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", text).casefold()))


def query_group(query):
    if "group_id" in query:
        return query["group_id"]
    if "uncertainty_group_id" in query:
        return query["uncertainty_group_id"]
    # An empty normalized legacy query is a real, retained text cluster. The
    # namespace prefix gives it a nonempty identifier without changing grouping.
    return "legacy-normalized:" + normalized_query(query["query"])


def dataset_metric_contract(dataset):
    if dataset in ["bfcl_live_multiple", "bfcl_multiple"]:
        return {"mrr":"MRR", "hit@1":"Top1Accuracy"}, "Native-menu documented-function ranking; not official BFCL argument generation, execution, or end-to-end success"
    if dataset == "bfcl_parallel_multiple":
        return {"mrr":"MRR", "average_precision":"AP", "recall@1":"macroRecall@1", "hit@1":"Top1Hit"}, "Exploratory native-menu function ranking; multi-positive coverage is not full call-order/count/argument success"
    if dataset == "toolhop":
        return {"recall@1":"ReferenceToolRecall@1", "recall@5":"ReferenceToolRecall@5", "recall@10":"ReferenceToolRecall@10", "complete@10":"ReferenceAllTools@10", "mrr@10":"ReferenceIDMRR@10"}, "Reference-label stress only; globally incomplete relevance, no tool execution or exhaustive-qrels claim"
    return {name:name for name in ["recall@1","recall@3","recall@5","recall@10","mrr@10"]}, "Original pooled frozen-positive retrieval; previously observed legacy test is not independent confirmation"


def path_string(path):
    return str(path).replace("\\", "/").rstrip("/")


class Resolver:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.publication = self.root / "publication" if (self.root / "publication").is_dir() else self.root
        mapping_path = self.root / "path_map.json"
        if not mapping_path.exists() and self.publication == self.root:
            mapping_path = self.root.parent / "path_map.json"
        self.mapping_path = mapping_path if mapping_path.exists() else None
        self.mappings = []
        if self.mapping_path:
            raw = read_json(self.mapping_path)
            raw = raw.get("mappings", raw.get("path_map", raw)) if isinstance(raw, dict) else raw
            if isinstance(raw, dict):
                raw = [{"source_prefix": key, "target_prefix": value} for key, value in raw.items()]
            require(isinstance(raw, list), "Unsupported path_map schema")
            for row in raw:
                source = row.get("source_prefix", row.get("source", row.get("from")))
                target = row.get("target_prefix", row.get("target", row.get("to")))
                require(isinstance(source, str) and isinstance(target, str), "Invalid path mapping")
                self.mappings.append((path_string(source), target))
            self.mappings.sort(key=lambda x: len(x[0]), reverse=True)

    def resolve(self, value, base=None, must_exist=True):
        require(isinstance(value, (str, Path)) and bool(str(value)), "Missing source path")
        text = path_string(value)
        for prefix, destination in self.mappings:
            if text.lower() == prefix.lower() or text.lower().startswith(prefix.lower() + "/"):
                suffix = text[len(prefix):].lstrip("/")
                target = (self.mapping_path.parent / destination / suffix).resolve()
                require(target == self.mapping_path.parent or self.mapping_path.parent in target.parents, "Mapped path escapes input bundle")
                require(not must_exist or target.exists(), f"Mapped evidence missing: {text} -> {target}")
                return target
        raw = Path(value)
        candidates = [raw] if raw.is_absolute() else []
        if base is not None:
            candidates.append(Path(base) / raw)
        candidates.extend([self.root / raw, self.publication / raw])
        if not raw.is_absolute():
            candidates.append(raw)
        for candidate in candidates:
            if candidate.exists():
                return candidate.resolve()
        require(not must_exist, f"Evidence path unavailable: {value}")
        return candidates[0].resolve()

    def display(self, path):
        path = Path(path).resolve()
        for prefix, label in [(self.root, ""), (self.publication, "publication")]:
            if path == prefix or prefix in path.parents:
                return (Path(label) / path.relative_to(prefix)).as_posix()
        # Local working layout: source is outside publication, but keep a
        # relative path so the provenance itself is not locked to a drive.
        import os
        return Path(os.path.relpath(path, self.root)).as_posix()


def metric_values(ranks, positive_count, candidate_count, *, full_ranks):
    require(positive_count > 0, "Empty positive set")
    result = {}
    for k in ([1, 3, 5, 10, 20, 50] if full_ranks else [1, 3, 5, 10]):
        count = sum(rank <= min(k, candidate_count) for rank in ranks)
        result[f"recall@{k}"] = count / positive_count
        result[f"coverage@{k}"] = count / positive_count
        result[f"hit@{k}"] = float(count > 0)
        result[f"complete@{k}"] = float(count == positive_count)
    first = min(ranks) if ranks else math.inf
    result["mrr@10"] = 1 / first if first <= 10 else 0.
    if full_ranks:
        require(len(ranks) == positive_count and len(set(ranks)) == positive_count, "Full positive ranks incomplete or duplicated")
        result["mrr"] = 1 / first
        result["average_precision"] = math.fsum(i / rank for i, rank in enumerate(sorted(ranks), 1)) / positive_count
        result["mean_positive_rank"] = math.fsum(ranks) / positive_count
    return result


def validate_final_files(entry, resolver, out, queries_path, corpus_path, prediction_path, config):
    """Bind an offline final evaluation to its immutable lock and run registry."""
    lock_path = next((path for path in [resolver.publication / "locks/final_lock.json", resolver.publication / "final_lock.json"] if path.exists()), None)
    require(lock_path is not None, "Refusing final score access before final_lock")
    require(entry.get("registry_lock_sha256") == sha(lock_path), "Final registry no longer matches frozen lock bytes")
    lock = read_json(lock_path)
    locked = [row for row in lock["evaluations"] if row["evaluation_id"] == entry["evaluation_id"]]
    require(len(locked) == 1, "Evaluation absent/duplicated in final lock")
    bound = locked[0]
    require(bound["run_id"] == entry["run_id"] and bound["dataset"] == entry["dataset"], "Final evaluation identity differs from lock")
    require(sha(queries_path) == bound["queries_sha256"] and sha(corpus_path) == bound["corpus_sha256"], "Frozen final query/corpus bytes changed")
    base = Path(entry.get("registry_path", resolver.publication)).parent
    config_path = resolver.resolve(entry["config_path"], base)
    require(sha(config_path) == bound["config_sha256"], "Locked final config bytes changed")
    require(config == read_json(config_path), "Executed config differs from locked configuration")
    require(sha(prediction_path) == entry.get("predictions_sha256"), "Completed final predictions changed after registry binding")
    require((out / "metrics.json").exists() and sha(out / "metrics.json") == entry.get("metrics_sha256"), "Completed final metrics changed after registry binding")
    report = read_json(out / "metrics.json")
    require(report.get("model_manifest_sha256") == bound["checkpoint_manifest_sha256"], "Evaluated model identity differs from final lock")
    require(report.get("input_hashes") == {"queries": bound["queries_sha256"], "corpus": bound["corpus_sha256"]}, "Evaluated input hashes differ from final lock")
    if "models" in lock:
        models = [model for model in lock["models"] if model["run_id"] == entry["run_id"]]
        require(len(models) == 1, "Model absent/duplicated in final model list")
        require(all(entry.get(key) == models[0].get(key) for key in ["family","policy","stage","seed"]), "Evaluation metadata differs from locked model")
    return bound, [lock_path, config_path]


def rescore(predictions, queries, corpus):
    """Independent formulas; no pretrained output metric is trusted."""
    query_map = {row["id"]: row for row in queries}
    corpus_map = {row["id"]: row for row in corpus}
    require(len(query_map) == len(queries) > 0, "Duplicate or empty query set")
    require(len(corpus_map) == len(corpus) > 0, "Duplicate or empty corpus")
    prediction_map = {row["id"]: row for row in predictions}
    require(len(prediction_map) == len(predictions) and set(prediction_map) == set(query_map), "Predictions do not cover exactly frozen query IDs")
    pooled_candidates, pooled_valid = list(corpus_map), set(corpus_map)
    pooled_tie_keys = {tid: tid for tid in pooled_candidates}
    equivalence_keys = {tid: doc.get("document_equivalence_key", hashlib.sha256(doc["text"].encode()).hexdigest()) for tid, doc in corpus_map.items()}
    pooled_equivalence_classes = set(equivalence_keys.values())
    recomputed, maximum_saved_field_error = [], 0.
    for query in queries:
        qid, row = query["id"], prediction_map[query["id"]]
        positives = query["positives"]
        require(positives and len(set(positives)) == len(positives), f"Invalid frozen positives {qid}")
        is_menu = "candidate_ids" in query
        candidates = query["candidate_ids"] if is_menu else pooled_candidates
        valid = set(candidates) if is_menu else pooled_valid
        if is_menu:
            require(len(valid) == len(candidates) and valid <= corpus_map.keys(), f"Invalid candidate menu {qid}")
        require(set(positives) <= valid, f"Frozen positive outside candidate set {qid}")
        require(set(row.get("positives", [])) == set(positives) and len(row["positives"]) == len(positives), f"Saved positive labels differ {qid}")
        rank_field = "ranking" if "candidate_ids" in query and "ranking" in row else ("top50" if "top50" in row else "top10")
        ranking, scores = row.get(rank_field), row.get("scores")
        require(isinstance(ranking, list) and isinstance(scores, list), f"Missing ranking/score arrays {qid}")
        expected_depth = len(candidates) if "candidate_ids" in query else min(50 if rank_field == "top50" else 10, len(candidates))
        require(len(ranking) == expected_depth == len(scores), f"Saved rank depth mismatch {qid}")
        require(len(set(ranking)) == len(ranking) and set(ranking) <= valid, f"Duplicate or invalid ranked tool {qid}")
        require(all(isinstance(score, (int, float)) and not isinstance(score, bool) and math.isfinite(score) for score in scores), f"Nonfinite score {qid}")
        tie_keys = query.get("candidate_tie_break_keys", {tid: tid for tid in candidates}) if is_menu else pooled_tie_keys
        if is_menu:
            require(set(tie_keys) == valid and len(set(tie_keys.values())) == len(valid), f"Invalid tie keys {qid}")
        for index in range(len(ranking) - 1):
            require(scores[index] >= scores[index + 1], f"Scores not descending {qid}")
            if scores[index] == scores[index + 1]:
                require(tie_keys[ranking[index]] < tie_keys[ranking[index + 1]], f"Wrong frozen tie ordering {qid}")
        if "candidate_count" in row:
            require(row["candidate_count"] == len(candidates), f"Candidate count mismatch {qid}")
        if "query_text_sha256" in row:
            require(row["query_text_sha256"] == hashlib.sha256(query["query"].encode()).hexdigest(), f"Query hash mismatch {qid}")
        top_positions = {tid: index + 1 for index, tid in enumerate(ranking)}
        positive_evidence = row.get("positive_ranks")
        full = positive_evidence is not None or "candidate_ids" in query
        if positive_evidence is not None:
            pmap = {entry["id"]: entry for entry in positive_evidence}
            require(len(pmap) == len(positive_evidence) == len(positives) and set(pmap) == set(positives), f"Positive rank evidence incomplete {qid}")
            ranks = []
            for tid in positives:
                entry = pmap[tid]
                rank, score = entry["rank"], entry["score"]
                require(isinstance(rank, int) and not isinstance(rank, bool) and 1 <= rank <= len(candidates), f"Invalid positive global rank {qid}")
                require(isinstance(score, (int, float)) and math.isfinite(score), f"Invalid positive score {qid}")
                if tid in top_positions:
                    require(rank == top_positions[tid] and abs(score - scores[rank - 1]) <= 1e-10, f"Positive rank/score disagrees with saved top list {qid}")
                else:
                    require(rank > len(ranking), f"Positive missing inside saved ranking {qid}")
                    require(score <= scores[-1], f"Outside positive outranks saved tail {qid}")
                    if score == scores[-1]:
                        require(tie_keys[tid] > tie_keys[ranking[-1]], f"Outside positive violates frozen tie order {qid}")
                ranks.append(rank)
        else:
            require(rank_field == "top10" or "candidate_ids" in query, f"New pooled evaluation lacks positive global ranks {qid}")
            ranks = [top_positions[tid] for tid in positives if tid in top_positions]
        metrics = metric_values(ranks, len(positives), len(candidates), full_ranks=full)
        if "candidate_ids" in query:
            metrics["top1_hit"] = metrics["hit@1"]
            if len(positives) == 1:
                metrics["top1_accuracy"] = metrics["hit@1"]
        sensitivity = row.get("equivalence_sensitivity")
        if sensitivity:
            gold_classes = {equivalence_keys[tid] for tid in positives}
            candidate_classes = {equivalence_keys[tid] for tid in candidates} if is_menu else pooled_equivalence_classes
            require(set(sensitivity["gold_document_classes"]) == gold_classes, f"Sensitivity gold class mismatch {qid}")
            require(sensitivity["candidate_document_classes"] == len(candidate_classes), f"Sensitivity candidate class mismatch {qid}")
            sranks = sensitivity["positive_class_ranks"]
            require(all(isinstance(rank, int) and 1 <= rank <= len(candidate_classes) for rank in sranks), f"Invalid sensitivity class ranks {qid}")
            smetrics = metric_values(sranks, len(gold_classes), len(candidate_classes), full_ranks=True)
            metrics.update({"equivalence/" + key: value for key, value in smetrics.items()})
        for key, value in metrics.items():
            if key in row:
                error = abs(float(row[key]) - value)
                maximum_saved_field_error = max(maximum_saved_field_error, error)
                require(error <= 1e-10, f"Saved per-query metric disagrees with independent formula {qid}/{key}: {error}")
        recomputed.append({"id": qid, "n_positives": len(positives), "candidate_count": len(candidates),
                           "group_id": query_group(query),
                           "category": query.get("category", "unknown"), "track": query.get("track", "unknown"), **metrics})
    names = set(recomputed[0]) - {"id", "n_positives", "candidate_count", "group_id", "category", "track"}
    # Do not silently average a metric over only the subset where it happened to
    # exist (e.g. top1_accuracy on a mixed single/multiple-positive task).
    names = {name for name in names if all(name in row for row in recomputed)}
    aggregate = {name: math.fsum(row[name] for row in recomputed) / len(recomputed) for name in sorted(names)}
    return {"per_query": recomputed, "metrics": aggregate, "n": len(queries),
            "verification": {"passed": True, "maximum_saved_per_query_metric_error": maximum_saved_field_error,
                             "formulas_from": "saved rank IDs/global positive rank evidence and frozen labels; prefilled metric fields checked only after recomputation"}}


def write_csv(path, rows, columns=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = columns or sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (list, dict)) else value for key, value in row.items()})


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_jsonl_gz(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
            with io.TextIOWrapper(zipped, encoding="utf-8", newline="\n") as stream:
                for row in rows:
                    stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def registry_runs(registry):
    rows = registry.get("runs", registry)
    return [{"run_id": key, **value} for key, value in rows.items()] if isinstance(rows, dict) else rows


def discover_evaluations(resolver):
    entries, used, sources, runs = [], set(), [], []
    registry_path = resolver.publication / "run_registry.json"
    if registry_path.exists():
        sources.append(registry_path)
        runs = registry_runs(read_json(registry_path))
        for run in runs:
            for index, evaluation in enumerate(run.get("dev_evaluations", [])):
                value = evaluation.get("output_path", evaluation.get("output_dir", evaluation.get("path")))
                if value is None and evaluation.get("metrics_path"):
                    value = str(Path(evaluation["metrics_path"]).parent)
                if value is None:
                    continue
                entries.append({**run, **evaluation, "evaluation_id": evaluation.get("evaluation_id", f"{run['run_id']}:dev:{evaluation.get('steps', index)}"),
                                "dataset": "development", "output_path": value, "status": evaluation.get("status", "completed"),
                                "evidence_type": "EXPLORATORY_DEV", "registry_path": str(registry_path)})
    for filename in ["final_evaluation_registry.json", "evaluation_registry.json"]:
        path = resolver.publication / filename
        if not path.exists():
            continue
        sources.append(path)
        payload = read_json(path)
        rows = payload.get("evaluations", payload) if isinstance(payload, dict) else payload
        if isinstance(rows, dict):
            rows = [{"evaluation_id": key, **value} for key, value in rows.items()]
        if filename == 'final_evaluation_registry.json':
            lock_path=resolver.publication/'locks/final_lock.json'
            require(lock_path.exists() and payload.get('lock_sha256')==sha(lock_path),'Final registry is not bound to an existing immutable lock')
            lock=read_json(lock_path)
            expected={row['evaluation_id'] for row in lock['evaluations'] if row.get('purpose','final_retrieval')=='final_retrieval'}
            actual=[row['evaluation_id'] for row in rows]
            require(len(actual)==len(set(actual)) and set(actual)==expected,'Final evaluation registry omits/duplicates/adds locked retrieval jobs')
        for row in rows:
            entries.append({**row, "registry_path": str(path), "registry_kind": filename,
                            "registry_lock_sha256": payload.get("lock_sha256") if isinstance(payload, dict) else None})
    # Historical and reproduced original Mxx outputs keep separate identity.
    roots = []
    for folder, kind in [(resolver.root / "original_reference", "ORIGINAL"), (resolver.root / "reproduction", "REPRODUCTION"),
                         (resolver.publication.parent / "repro", "REPRODUCTION"),
                         (resolver.publication.parent / "reproduction", "REPRODUCTION"),
                         (resolver.publication.parent / "original_reference", "ORIGINAL")]:
        if folder.is_dir():
            roots.append((folder, kind))
    decisions = resolver.publication / "locks/execution_decisions.json"
    if decisions.exists():
        source_package = read_json(decisions).get("source")
        if source_package:
            try:
                original = resolver.resolve(str(Path(source_package) / "archive/CPS5801_HANDOFF_20261025/CPS5801"))
                roots.append((original, "ORIGINAL"))
            except ValueError:
                pass
    seen_roots = set()
    for root, kind in roots:
        if root.resolve() in seen_roots:
            continue
        seen_roots.add(root.resolve())
        for split, subdir in [("development", ""), ("legacy_observed_test", "official_test")]:
            folder = root / "results/main_20261025" / subdir
            if not folder.exists():
                continue
            for prediction in sorted(folder.glob("M*/predictions.json")):
                name = prediction.parent.name
                seed_match = re.search(r"seed(\d+)", name)
                policy = "R_ID" if "random" in name else ("B_ID" if seed_match else ("pretrained" if "pretrained" in name else "BM25"))
                entries.append({"evaluation_id": f"{kind}:{split}:{name}", "run_id": name, "dataset": split,
                                "family": "bm25" if policy == "BM25" else "e5", "policy": policy,
                                "seed": int(seed_match.group(1)) if seed_match else None,
                                "stage": "S0" if kind == "REPRODUCTION" else "ORIGINAL", "evidence_type": kind,
                                "output_path": str(prediction.parent), "queries_path": str(root / "data/main_20261025" / ("dev.json" if not subdir else "test.json")),
                                "corpus_path": str(root / "data/main_20261025" / ("corpus.json" if not subdir else "test_corpus.json")), "status": "completed"})
    dedup = []
    for row in entries:
        identity = row.get("evaluation_id", row.get("run_id", "unknown") + ":" + row.get("dataset", "unknown"))
        if identity in used:
            raise ValueError(f"Duplicate evaluation identity {identity}")
        used.add(identity)
        row["evaluation_id"] = identity
        dedup.append(row)
    return dedup, runs, sources


class Rebuilder:
    def __init__(self, input_root, output_dir):
        self.resolver, self.out = Resolver(input_root), Path(output_dir).resolve()
        require(not self.out.exists() or not any(self.out.iterdir()), "Use a new empty rebuild output directory; preserve earlier attempts")
        self.out.mkdir(parents=True, exist_ok=True)
        self.provenance, self.failures, self.completed, self.pending = [], [], [], []
        self.hash_cache = {}

    def source_info(self, path):
        path = Path(path).resolve()
        if path not in self.hash_cache:
            self.hash_cache[path] = {"path": self.resolver.display(path), "bytes": path.stat().st_size, "sha256": sha(path)}
        return self.hash_cache[path]

    def register(self, output, sources, formula, **metadata):
        self.provenance.append({"output": output.relative_to(self.out).as_posix(), "output_sha256": sha(output), "output_bytes": output.stat().st_size,
                                "inputs": [self.source_info(path) for path in sorted(set(map(Path, sources)))],
                                "script": {"name": Path(__file__).name, "sha256": sha(__file__)}, "formula": formula,
                                "missing_handling": "explicit pending/failed records; no silent row deletion", **metadata})

    def table(self, filename, rows, sources, formula, columns=None, **metadata):
        path = self.out / filename
        write_csv(path, rows, columns)
        self.register(path, sources, formula, **metadata)
        return path

    def score_evaluation(self, entry):
        resolver = self.resolver
        base = Path(entry.get("registry_path", resolver.publication)).parent
        out = resolver.resolve(entry["output_path"], base)
        config_path = out / "config.json"
        config = read_json(config_path) if config_path.exists() else {}
        prediction_path = next((out / name for name in ["predictions.json", "predictions.jsonl.gz", "predictions.json.gz", "predictions.jsonl"] if (out / name).exists()), None)
        require(prediction_path is not None, "Completed evaluation has no saved predictions")
        queries_path = resolver.resolve(entry.get("queries_path", config.get("queries_path")), out)
        corpus_path = resolver.resolve(entry.get("corpus_path", config.get("corpus_path")), out)
        dataset = entry.get("dataset", config.get("dataset", "unknown"))
        locked_entry = None
        binding_sources = []
        if entry.get("registry_kind") == "final_evaluation_registry.json" or dataset.lower().startswith(("bfcl", "toolhop")):
            locked_entry, binding_sources = validate_final_files({**entry,"dataset":dataset}, resolver, out, queries_path, corpus_path, prediction_path, config)
        queries, corpus = read_json(queries_path), read_json(corpus_path)
        score = rescore(read_json(prediction_path), queries, corpus)
        native_names, metric_scope = dataset_metric_contract(dataset)
        if dataset in ["bfcl_live_multiple","bfcl_multiple"]:
            require(all(len(query['positives'])==1 for query in queries),'Top1Accuracy native-task label requires the frozen single-function gold scope')
        for internal,native in native_names.items():
            if internal in score['metrics']:
                score['metrics'][native]=score['metrics'][internal]
                for row in score['per_query']:row[native]=row[internal]
        sources = [prediction_path, queries_path, corpus_path, *binding_sources]
        if config_path.exists():
            sources.append(config_path)
        report_path = out / "metrics.json"
        report = read_json(report_path) if report_path.exists() else {}
        if report_path.exists():
            sources.append(report_path)
            if locked_entry is not None:
                require(report.get("model_manifest_sha256") == locked_entry["checkpoint_manifest_sha256"], "Evaluated model identity differs from final lock")
                require(report.get("input_hashes") == {"queries": locked_entry["queries_sha256"], "corpus": locked_entry["corpus_sha256"]}, "Evaluated input hashes differ from final lock")
            saved = report.get("metrics", report)
            for name, value in score["metrics"].items():
                if name in saved and isinstance(saved[name], (float, int)):
                    require(abs(value - saved[name]) <= 1e-10, f"Saved aggregate {name} differs from re-score")
        safe_id = re.sub(r"[^a-zA-Z0-9_.-]+", "_", entry["evaluation_id"])
        per_query_path = self.out / "per_query" / f"{safe_id}.jsonl.gz"
        write_jsonl_gz(per_query_path, score["per_query"])
        self.register(per_query_path, sources, "Independently recomputed retrieval metrics from saved ranking/positive global ranks and frozen labels", evaluation_id=entry["evaluation_id"])
        metadata = {**config, **entry, "dataset": dataset, "metric_scope":metric_scope,
                    "dataset_native_metric_names":list(native_names.values())}
        return {"entry": metadata, "score": score, "queries": queries, "sources": sources,
                "query_sha256": sha(queries_path), "corpus_sha256": sha(corpus_path), "report": report, "output_path": out}

    def run(self):
        entries, runs, registry_sources = discover_evaluations(self.resolver)
        self.table("status/all_training_runs.csv", [{key: row.get(key) for key in ["run_id", "stage", "family", "policy", "seed", "learning_rate", "lr", "temperature", "optimizer_updates", "steps", "status", "attempts"]} for row in runs], registry_sources,
                   "Original run_registry rows, including failed/pending/reused runs; no assumed completion")
        for entry in entries:
            if entry.get("status") not in ["completed", "reused"]:
                self.pending.append({"evaluation_id": entry["evaluation_id"], "status": entry.get("status", "unknown"), "reason": "registry not completed"})
                continue
            try:
                self.completed.append(self.score_evaluation(entry))
            except (ValueError, KeyError, TypeError, OSError) as exc:
                self.failures.append({"evaluation_id": entry["evaluation_id"], "error": str(exc), "output_path": entry.get("output_path")})
        self.effect_rows, self.seed_effect_rows, self.grid_rows = [], [], []
        steps = [("performance_tables", lambda: self.performance_tables(registry_sources)),
                 ("development_tables", lambda: self.development_tables(runs, registry_sources)),
                 ("original_reproduction_comparison", self.original_reproduction_tables),
                 ("fixed_mechanism_statistics", self.fixed_mechanism_tables),
                 ("confirmation_statistics", self.confirmation_tables),
                 ("resource_tables", lambda: self.resource_tables(runs, registry_sources)),
                 ("human_review", self.human_status_tables), ("figures", self.figures)]
        for name, action in steps:
            try:
                action()
            except (ValueError, KeyError, TypeError, OSError) as exc:
                self.failures.append({"evaluation_id": "rebuild_component:" + name, "error": str(exc)})
        self.table("status/pending_evaluations.csv", self.pending, registry_sources, "Explicit evaluations not yet complete", columns=["evaluation_id", "status", "reason"])
        write_json(self.out / "verification_failures.json", self.failures)
        write_json(self.out / "table_provenance.json", {"schema_version": "1.0.0", "tables_and_artifacts": self.provenance,
                                                       "source_root": str(self.resolver.root), "script_sha256": sha(__file__),
                                                       "path_map": self.source_info(self.resolver.mapping_path) if self.resolver.mapping_path else None})
        result = {"status": "failed_verification" if self.failures else "available_evidence_rebuilt", "completed_evaluations": len(self.completed),
                  "pending_evaluations": len(self.pending), "verification_failures": len(self.failures),
                  "training_registry_statuses": dict(Counter(row.get("status", "unknown") for row in runs)),
                  "not_a_claim_of_all_experiments_complete": True, "generated_at_utc": datetime.now(timezone.utc).isoformat(), "output_dir": str(self.out)}
        write_json(self.out / "rebuild_status.json", result)
        return result

    def original_reproduction_tables(self):
        old, new, rows, sources = {}, {}, [], []
        for completed in self.completed:
            entry = completed["entry"]
            key = tuple(entry.get(name) for name in ["dataset", "family", "policy", "seed"])
            if entry.get("evidence_type") == "ORIGINAL":
                require(key not in old, "Duplicate original comparison identity")
                old[key] = completed
            elif entry.get("evidence_type") == "REPRODUCTION":
                require(key not in new, "Duplicate reproduced comparison identity")
                new[key] = completed
        for key in sorted(set(old) | set(new), key=str):
            tags = dict(zip(["dataset", "family", "policy", "seed"], key))
            if key not in old or key not in new:
                rows.append({**tags, "status": "missing_original" if key not in old else "reproduction_pending", "metric": None})
                continue
            a, b = old[key], new[key]
            require(a["query_sha256"] == b["query_sha256"] and a["corpus_sha256"] == b["corpus_sha256"], "Reproduction input bytes differ from original; investigate before comparison")
            pa = {row["id"]: row for row in read_json(a["sources"][0])}
            pb = {row["id"]: row for row in read_json(b["sources"][0])}
            identical = sum(pa[qid]["top10"] == pb[qid]["top10"] for qid in pa)
            sources.extend(a["sources"] + b["sources"])
            for metric in sorted(set(a["score"]["metrics"]) & set(b["score"]["metrics"])):
                original, reproduction = a["score"]["metrics"][metric], b["score"]["metrics"][metric]
                rows.append({**tags, "status": "both_independently_rescored", "metric": metric,
                             "original": original, "reproduction": reproduction, "difference": reproduction - original,
                             "n_queries": len(pa), "exact_top10_query_count": identical, "exact_top10_fraction": identical / len(pa),
                             "same_frozen_query_and_corpus_bytes": True, "cross_execution_tolerance": "none; report actual difference"})
        self.table("comparison/original_vs_reproduction.csv", rows, sources, "Independently rescored original and new outputs, matching frozen input bytes; report actual delta and exact top10 agreement without post-hoc tolerance")
        for kind, index in [("ORIGINAL", old), ("REPRODUCTION", new)]:
            datasets = sorted({key[0] for key in index})
            for dataset in datasets:
                selected = [value for key, value in index.items() if key[0] == dataset and key[1] == "e5" and key[2] in ["R_ID", "B_ID"] and key[3] in [42,43,44]]
                if len(selected) != 6:
                    continue
                result, used_sources = self.paired_fixed_result(selected, [42,43,44],
                    [{"contrast_id": "B_ID_minus_R_ID", "coefficients": {"B_ID": 1, "R_ID": -1}}],
                    evidence_stage="original", metrics=["recall@5"], query_seed=50042, cluster_seed=50043)
                original_contrast = result["contrasts"][0]
                original_cluster_used = original_contrast["n_groups"] < original_contrast["n_queries"]
                result["original_protocol_summary"] = {
                    "mean_paired_delta_recall5": original_contrast["mean_paired_effect"],
                    "query_bootstrap_95": original_contrast["paired_query_bootstrap"]["percentile_interval"],
                    "normalized_query_cluster_bootstrap_95": original_contrast["paired_query_weighted_cluster_bootstrap"]["percentile_interval"] if original_cluster_used else None,
                    "normalized_query_groups": original_contrast["n_groups"],
                    "cluster_rule": "Archived code reports cluster interval only when normalized groups fewer than queries; any all-singleton resampling retained above is an additional diagnostic"}
                path = self.out / "statistics" / f"{kind}_{dataset}_original_bootstrap.json"
                write_json(path, result)
                self.register(path, used_sources, "Original5000-query bootstrap seed50042 and normalized-query query-weighted cluster seed50043; original three paired seeds/order retained", seeds=[42,43,44])

    def paired_fixed_result(self, selected, seeds, contrasts, *, evidence_stage, metrics, query_seed=2026111201, cluster_seed=2026111202):
        require(len({c["query_sha256"] for c in selected}) == 1 and len({c["corpus_sha256"] for c in selected}) == 1, "Paired analysis data hashes differ")
        queries = selected[0]["queries"]
        data = {"dataset": selected[0]["entry"]["dataset"], "evidence_stage": evidence_stage, "expected_seeds": seeds,
                "expected_query_ids": [q["id"] for q in queries],
                "query_groups": {q["id"]: query_group(q) for q in queries},
                "metrics": metrics, "contrasts": contrasts,
                "records": [{"method": c["entry"]["policy"], "seed": c["entry"]["seed"], "query_id": row["id"],
                             "metrics": {name: row[name] for name in metrics}} for c in selected for row in c["score"]["per_query"]],
                "bootstrap": {"replicates": 5000, "query_seed": query_seed, "cluster_seed": cluster_seed, "engine": "numpy", "batch_size": 128}}
        return paired_analyze(data), [path for c in selected for path in c["sources"]]

    def fixed_mechanism_tables(self):
        rows, all_sources = [], []
        datasets = sorted({c["entry"]["dataset"] for c in self.completed if c["entry"].get("stage") in ["S0","S1"]})
        for dataset in datasets:
            selected = [c for c in self.completed if c["entry"].get("dataset") == dataset and c["entry"].get("family") == "e5"
                        and c["entry"].get("stage") in ["S0","S1"] and c["entry"].get("policy") in ["R_ID","B_ID","R_UNIQUE","B_UNIQUE"]
                        and c["entry"].get("seed") in [42,43,44] and c["entry"].get("evidence_type") != "ORIGINAL"]
            # A newly exported S0 evaluation and the preserved old-engine top10
            # view may refer to the same fitted checkpoint. Prefer an explicit
            # final-registry view for the mechanism analysis, but keep both in
            # per-evaluation and original/reproduction tables.
            final_keys = {(c["entry"]["policy"],c["entry"]["seed"]) for c in selected if c["entry"].get("registry_path", "").endswith("final_evaluation_registry.json")}
            selected = [c for c in selected if not(c["entry"].get("evidence_type") == "REPRODUCTION" and (c["entry"]["policy"],c["entry"]["seed"]) in final_keys)]
            pairs = [(c["entry"]["policy"],c["entry"]["seed"]) for c in selected]
            expected = {(policy,seed) for policy in ["R_ID","B_ID","R_UNIQUE","B_UNIQUE"] for seed in [42,43,44]}
            if len(pairs) != len(set(pairs)) or set(pairs) != expected:
                self.pending.append({"evaluation_id": "mechanism:" + dataset, "status": "incomplete", "reason": "All12 unique factorial policy/seed evaluations required"})
                continue
            contrasts = [{"contrast_id": "delta_B", "coefficients": {"B_UNIQUE":1,"B_ID":-1}},
                         {"contrast_id": "delta_R", "coefficients": {"R_UNIQUE":1,"R_ID":-1}},
                         {"contrast_id": "interaction_delta_B_minus_delta_R", "coefficients": {"B_UNIQUE":1,"B_ID":-1,"R_UNIQUE":-1,"R_ID":1}}]
            native_names,scope=dataset_metric_contract(dataset)
            fixed_metrics=list(native_names) if dataset.startswith('bfcl') or dataset=='toolhop' else ['recall@5','mrr@10']
            result, sources = self.paired_fixed_result(selected, [42,43,44], contrasts, evidence_stage="fixed_mechanism", metrics=fixed_metrics)
            path = self.out / "statistics" / f"{dataset}_fixed_mechanism.json"
            write_json(path, result); self.register(path, sources, "Three-seed fixed-recipe deltaB,deltaR and paired factorial interaction; conditional query/group bootstrap; policy effect not unique semantic mechanism")
            all_sources.extend(sources)
            for contrast in result["contrasts"]:
                ci = contrast["paired_query_weighted_cluster_bootstrap"]["percentile_interval"]
                rows.append({"dataset":dataset,"contrast":contrast["contrast_id"],"metric":contrast["metric"],"display_metric":native_names.get(contrast['metric'],contrast['metric']),"metric_scope":scope,"mean_effect":contrast["mean_paired_effect"],
                             "seed_sample_sd":contrast["sample_sd_across_seed_effects"],"cluster_ci_low":ci[0] if ci else None,"cluster_ci_high":ci[1] if ci else None,
                             "n_queries":contrast["n_queries"],"n_groups":contrast["n_groups"],"per_seed_effects":contrast["per_seed_effects"],"evidence_level":"prespecified_secondary_fixed_recipe"})
        self.table("comparison/fixed_mechanism_effects.csv", rows, all_sources, "Fixed-recipe three-seed minimal duplicate-repair policy effects and interaction; no semantic false-negative causal assertion")

    def performance_tables(self, registry_sources):
        rows, strata, sources = [], [], list(registry_sources)
        for completed in self.completed:
            entry, score = completed["entry"], completed["score"]
            tags = {key: entry.get(key) for key in ["evaluation_id", "run_id", "dataset", "family", "policy", "seed", "stage", "steps", "evidence_type","metric_scope","dataset_native_metric_names"]}
            rows.append({**tags, "n": score["n"], **score["metrics"], "query_sha256": completed["query_sha256"], "corpus_sha256": completed["corpus_sha256"]})
            sources.extend(completed["sources"])
            for stratifier in ["category", "track", "positive_count"]:
                buckets = defaultdict(list)
                for row in score["per_query"]:
                    group = ("one" if row["n_positives"] == 1 else "multiple") if stratifier == "positive_count" else row[stratifier]
                    buckets[group].append(row)
                for group, group_rows in sorted(buckets.items()):
                    strata.append({**tags, "stratifier": stratifier, "stratum": group, "n": len(group_rows),
                                   **{name: math.fsum(row[name] for row in group_rows) / len(group_rows) for name in score["metrics"]}})
        self.performance_rows = rows
        self.table("tables/recomputed_per_evaluation.csv", rows, sources, "Query-macro retrieval metrics independently recomputed; old top10 cannot supply new full-rank metrics")
        self.table("tables/query_strata.csv", strata, sources, "Original category/track/label-count descriptive strata; each retained query has equal weight")
        grouped = defaultdict(list)
        for row in rows:
            grouped[(row["dataset"], row["evidence_type"], row["stage"], row["family"], row["policy"], row["steps"])].append(row)
        summaries = []
        for group, group_rows in grouped.items():
            native_names,scope=dataset_metric_contract(group[0])
            numeric_metrics = sorted(set(native_names).intersection(*[set(row) for row in group_rows]))
            for metric in numeric_metrics:
                values = [row[metric] for row in group_rows]
                summaries.append(dict(zip(["dataset", "evidence_type", "stage", "family", "policy", "steps"], group)) | {
                    "metric": metric, "display_metric":native_names[metric],"metric_scope":scope,"n_runs": len(values), "seeds": [row["seed"] for row in group_rows], "mean": statistics.mean(values),
                    "sample_sd": statistics.stdev(values) if len(values) > 1 else None,
                    "all_expected_seeds_present": sorted(row["seed"] for row in group_rows if row["seed"] is not None) == ([42,43,44,45,46] if group[2] in ["S3","S5"] else [42,43,44])})
        self.table("tables/method_seed_summary.csv", summaries, sources, "Mean and sample SD of all available independently rescored runs, with explicit seed lists and completeness")

    def development_tables(self, runs, registry_sources):
        grid, dev_sources, rebuilt_runs = [], list(registry_sources), []
        by_run = defaultdict(list)
        for completed in self.completed:
            entry = completed["entry"]
            if entry.get("stage") not in ["S2", "S4"] or entry["dataset"] != "development":
                continue
            steps = entry.get("steps", entry.get("checkpoint_step", entry.get("step")))
            require(steps in [312, 625, 1250], "Development checkpoint step missing/invalid")
            metrics = completed["score"]["metrics"]
            cell = {key: entry.get(key) for key in ["run_id", "stage", "family", "policy", "seed", "temperature"]}
            cell.update(lr=entry.get("lr", entry.get("learning_rate")), steps=steps, **{k: metrics[k] for k in ["recall@5", "mrr@10"]})
            grid.append(cell)
            by_run[entry["run_id"]].append({"steps": steps, "metrics": metrics})
            dev_sources.extend(completed["sources"])
        self.grid_rows = grid
        self.table("tables/development_grid.csv", grid, dev_sources, "Every available screening checkpoint independently rescored; no winner-only filtering")
        for run in runs:
            if run.get("stage") in ["S2", "S4"]:
                row = dict(run)
                config_value = row.get("config", row.get("config_path"))
                if isinstance(config_value, (str, Path)):
                    config_path = self.resolver.resolve(config_value, self.resolver.publication)
                    row["config"] = read_json(config_path)
                    dev_sources.append(config_path)
                rebuilt_runs.append({**row, "dev_evaluations": by_run.get(run["run_id"], [])})
        selection_results = {}
        for stage in ["S2", "S4"]:
            try:
                selection_results[stage] = select_dev(rebuilt_runs, stage, self.resolver.publication, selection_results.get("S2"))
            except (ValueError, KeyError, TypeError) as exc:
                selection_results[stage] = {"status": "not_lockable_from_available_evidence", "reason": str(exc)}
        path = self.out / "comparison/rebuilt_development_selection.json"
        write_json(path, selection_results)
        self.register(path, dev_sources, "Frozen select_on_dev rule applied to independently reconstructed dev metrics; no test values used")

    def confirmation_tables(self):
        self.effect_rows, self.seed_effect_rows = [], []
        datasets = sorted({completed["entry"]["dataset"] for completed in self.completed if completed["entry"].get("stage") in ["S3", "S5"]})
        for dataset in datasets:
            for family, stage in [("e5", "S3"), ("bge", "S5")]:
                selected = [c for c in self.completed if c["entry"].get("dataset") == dataset and c["entry"].get("family") == family and c["entry"].get("stage") == stage]
                policies = sorted({c["entry"]["policy"] for c in selected} - {"R_ID", "B_ID"})
                if len(policies) != 1:
                    self.pending.append({"evaluation_id": f"statistics:{dataset}:{family}", "status": "incomplete", "reason": "Exactly one frozen extension policy unavailable"})
                    continue
                extension = policies[0]
                expected = {(policy, seed) for policy in ["R_ID", "B_ID", extension] for seed in [42,43,44,45,46]}
                actual = [(c["entry"]["policy"], c["entry"].get("seed")) for c in selected]
                if len(actual) != len(set(actual)) or set(actual) != expected:
                    self.pending.append({"evaluation_id": f"statistics:{dataset}:{family}", "status": "incomplete", "reason": "All 15 unique policy/seed evaluations required"})
                    continue
                require(len({c["query_sha256"] for c in selected}) == 1 and len({c["corpus_sha256"] for c in selected}) == 1, "Confirmation paired data hashes differ")
                queries = selected[0]["queries"]
                native_names,metric_scope=dataset_metric_contract(dataset)
                metrics = [name for name in native_names if all(name in c["score"]["metrics"] for c in selected)]
                data = {"dataset": dataset, "evidence_stage": "confirmation", "expected_seeds": [42,43,44,45,46],
                        "expected_query_ids": [q["id"] for q in queries],
                        "query_groups": {q["id"]: query_group(q) for q in queries},
                        "metrics": metrics, "contrasts": [{"contrast_id": family + ":selected_minus_" + policy, "coefficients": {extension: 1, policy: -1}} for policy in ["R_ID", "B_ID"]],
                        "records": [{"method": c["entry"]["policy"], "seed": c["entry"]["seed"], "query_id": row["id"], "metrics": {name: row[name] for name in metrics}} for c in selected for row in c["score"]["per_query"]],
                        "bootstrap": {"replicates": 5000, "query_seed": 2026111201, "cluster_seed": 2026111202, "engine": "numpy", "batch_size": 128}}
                result = paired_analyze(data)
                path = self.out / "statistics" / f"{dataset}_{family}_paired_bootstrap.json"
                write_json(path, result)
                sources = [path for c in selected for path in c["sources"]]
                self.register(path, sources, "Five prescribed paired seeds; seed-mean per-query effects;5000 query-weighted group bootstrap draws, PCG64 seeds2026111201/02; pointwise95%", seeds=[42,43,44,45,46])
                for contrast in result["contrasts"]:
                    ci = contrast["paired_query_weighted_cluster_bootstrap"]["percentile_interval"]
                    primary = dataset == "bfcl_live_multiple" and contrast["metric"] == "mrr"
                    row = {"dataset": dataset, "family": family, "contrast": contrast["contrast_id"], "metric": contrast["metric"], "display_metric":native_names[contrast['metric']],"metric_scope":metric_scope,"primary": primary,
                           "mean_effect": contrast["mean_paired_effect"], "seed_sample_sd": contrast["sample_sd_across_seed_effects"],
                           "cluster_ci_low": ci[0] if ci else None, "cluster_ci_high": ci[1] if ci else None,
                           "n_queries": contrast["n_queries"], "n_groups": contrast["n_groups"], "seeds": contrast["seeds"],
                           "positive_seed_count": contrast["positive_seed_count"], "practical_threshold": .005 if primary else None,
                           "interval_scope": "pointwise conditional on fitted seeds/labels; no p-value"}
                    self.effect_rows.append(row)
                    self.seed_effect_rows.extend({**row, "seed": effect["seed"], "effect": effect["effect"]} for effect in contrast["per_seed_effects"])
        all_sources = [path for c in self.completed for path in c["sources"]]
        self.table("comparison/paired_effects_all_seeds.csv", self.seed_effect_rows, all_sources, "Each fixed-seed paired effect; no adaptive seed removal")
        self.table("comparison/locked_confirmation_effects.csv", self.effect_rows, all_sources, "Only BFCL live_multiple MRR four planned contrasts are primary; other datasets/metrics remain descriptive")

    def resource_tables(self, runs, registry_sources):
        rows, sources = [], list(registry_sources)
        for completed in self.completed:
            entry, report = completed["entry"], completed["report"]
            row = {key: entry.get(key) for key in ["evaluation_id", "run_id", "dataset", "family", "policy", "seed", "stage"]}
            row.update({key: report.get(key) for key in ["index_seconds", "query_encoding_seconds", "search_and_ranking_seconds", "total_evaluation_seconds", "peak_eval_allocated_GiB", "candidate_tools"]})
            row["record_type"] = "evaluation_resource_log"
            rows.append(row)
            sources.extend(completed["sources"])
        train_paths = set()
        for root in [self.resolver.publication / "runs", self.resolver.root / "reproduction/results", self.resolver.publication.parent / "repro/results", self.resolver.publication.parent / "reproduction/results"]:
            if root.exists():
                train_paths.update(root.rglob("training.json"))
        for path in sorted(train_paths):
            obj = read_json(path)
            row = {"record_type": "training_resource_log", "source": self.resolver.display(path), **{key: value for key, value in obj.items() if isinstance(value, (str, int, float)) or value is None}}
            loss_path = path.parent / "loss.jsonl"
            if loss_path.exists():
                losses = read_json(loss_path)
                require(all(math.isfinite(float(row["loss"])) for row in losses), "Nonfinite completed training loss")
                row["observed_loss_rows"] = len(losses)
                row["observed_last_step"] = losses[-1].get("step", losses[-1].get("update")) if losses else None
                sources.append(loss_path)
            rows.append(row)
            sources.append(path)
        self.table("efficiency/indexing_training_and_mining_costs.csv", rows, sources, "Resource fields from raw execution records; loss trace counts separately verified; no historical/new-machine cost mixing")
        timing_rows, timing_sources = [], []
        for path in sorted(self.resolver.publication.rglob("raw_timings.jsonl")):
            if "fixtures" in path.parts or "tests" in path.parts:
                continue
            raw = read_json(path)
            timing_sources.append(path)
            grouped = defaultdict(list)
            for row in raw:
                grouped[row.get("round", row.get("repeat"))].append(row)
            for round_id, values in grouped.items():
                latencies = [float(row.get("end_to_end_ms", row.get("latency_ms"))) for row in values]
                require(all(math.isfinite(v) and v >= 0 for v in latencies), "Invalid raw latency")
                from publication_statistics import percentile_linear
                timing_rows.append({"source": self.resolver.display(path), "round": round_id, "n": len(values),
                                    "median_ms": statistics.median(latencies), "p95_ms": percentile_linear(latencies, .95),
                                    "sequential_batch1_queries_per_second": len(latencies) * 1000 / math.fsum(latencies)})
        self.table("efficiency/recomputed_latency_rounds.csv", timing_rows, timing_sources, "Median, linear p95 and service-time reciprocal from every raw per-query/per-round timing; no summary-only input")

    def human_status_tables(self):
        rows, sources = [], []
        review_root = self.resolver.publication / "human_review"
        if review_root.exists():
            for path in sorted(review_root.glob("*/status.json")):
                data = read_json(path)
                rows.append({"review": path.parent.name, **data})
                sources.append(path)
        self.table("tables/human_review_status.csv", rows, sources, "Actual prepared/completed counts; pending yields no fabricated agreement/kappa or semantic labels")

    def figures(self):
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            import numpy as np
        except ImportError:
            self.pending.append({"evaluation_id": "figures", "status": "dependency_missing", "reason": "matplotlib/numpy required for actual-data figures"})
            return
        primary = [row for row in self.effect_rows if row["primary"]]
        if primary:
            fig, ax = plt.subplots(figsize=(9, max(3.5, len(primary) * .7)))
            for index, row in enumerate(primary):
                mean, lo, hi = row["mean_effect"], row["cluster_ci_low"], row["cluster_ci_high"]
                if lo is not None:
                    ax.plot([lo, hi], [index, index], color="#286a9c", linewidth=2)
                ax.scatter([mean], [index], color="#173d60", s=45, zorder=3)
            ax.axvline(0, color="#777", linewidth=1)
            ax.axvline(.005, color="#aaa", linestyle=":", label="Practical threshold +0.005 MRR")
            ax.set_yticks(range(len(primary)), [row["contrast"] for row in primary])
            ax.set_xlabel("Paired MRR difference; conditional pointwise 95% group-bootstrap interval")
            ax.set_title("BFCL live_multiple: locked primary contrasts")
            ax.legend(loc="best", fontsize=8)
            fig.tight_layout()
            path = self.out / "figures/main_effects.png"
            path.parent.mkdir(exist_ok=True)
            fig.savefig(path, dpi=180); plt.close(fig)
            self.register(path, [self.out / "comparison/locked_confirmation_effects.csv"], "Dots=mean five paired seed effects; lines=conditional group-bootstrap intervals, not p-values")
            seed_rows = [row for row in self.seed_effect_rows if row["primary"]]
            fig, ax = plt.subplots(figsize=(9, 4.8))
            for index, row in enumerate(primary):
                values = [item for item in seed_rows if item["contrast"] == row["contrast"]]
                ax.scatter([item["seed"] for item in values], [item["effect"] for item in values], label=row["contrast"])
            ax.axhline(0, color="#777", linewidth=1); ax.set_xticks([42,43,44,45,46])
            ax.set_xlabel("Prespecified training seed"); ax.set_ylabel("Paired MRR difference")
            ax.set_title("All five paired seeds; no seed selection"); ax.legend(fontsize=8)
            fig.tight_layout(); path = self.out / "figures/confirmation_seed_effects.png"
            fig.savefig(path, dpi=180); plt.close(fig)
            self.register(path, [self.out / "comparison/paired_effects_all_seeds.csv"], "All five seed point effects; no query intervals substituted for seed variability")
        grid = [row for row in self.grid_rows if row["stage"] == "S2"]
        if grid:
            policies = ["R_ID","B_ID","R_UNIQUE","B_UNIQUE","MIXED_2R2B","DENSE_STATIC"]
            configs = [(lr, temp, steps) for lr in [1e-5,2e-5] for temp in [.01,.05] for steps in [312,625,1250]]
            values = np.full((6,12), np.nan)
            for row in grid:
                values[policies.index(row["policy"]), configs.index((row["lr"],row["temperature"],row["steps"]))] = row["recall@5"]
            fig, ax = plt.subplots(figsize=(13,4.8))
            im = ax.imshow(values, aspect="auto", cmap="viridis")
            ax.set_yticks(range(6), policies)
            ax.set_xticks(range(12), [f"lr={lr:g}\nT={temp:g}\nu={step}" for lr,temp,step in configs], fontsize=8)
            ax.set_title("E5 seed41 development grid: independently recomputed Recall@5; missing cells blank")
            fig.colorbar(im, ax=ax, label="Macro Recall@5")
            fig.tight_layout(); path = self.out / "figures/e5_development_grid.png"
            path.parent.mkdir(exist_ok=True); fig.savefig(path, dpi=180); plt.close(fig)
            self.register(path, [self.out / "tables/development_grid.csv"], "Six policies times twelve checkpoint/configuration cells; all available values, missing blank")


def self_test():
    require(dataset_metric_contract('toolhop')[0]['mrr@10']=='ReferenceIDMRR@10' and dataset_metric_contract('toolhop')[0]['complete@10']=='ReferenceAllTools@10','ToolHop native metric contract lost')
    require(dataset_metric_contract('bfcl_live_multiple')[0]['hit@1']=='Top1Accuracy' and dataset_metric_contract('bfcl_parallel_multiple')[0]['hit@1']=='Top1Hit','Single/multiple BFCL metric naming confused')
    require(query_group({"query":"?!"}) == query_group({"query":""}) == "legacy-normalized:", "Empty normalized legacy group must be retained")
    corpus = [{"id": tid, "text": tid} for tid in ["a","b","c","d"]]
    queries = [{"id": "q1", "query": "request", "positives": ["b","d"]}]
    prediction = [{"id": "q1", "positives": ["b","d"], "top50": ["a","b","c","d"], "scores": [1.,.8,.8,.1], "candidate_count": 4,
                   "positive_ranks": [{"id":"b","rank":2,"score":.8},{"id":"d","rank":4,"score":.1}]}]
    score = rescore(prediction, queries, corpus)
    require(score["metrics"]["recall@1"] == 0 and score["metrics"]["recall@3"] == .5 and score["metrics"]["mrr"] == .5, "Multi-positive formula fixture failed")
    require(abs(score["metrics"]["average_precision"] - .5) < 1e-12, "Average precision formula failed")
    menu_queries = [{**queries[0], "candidate_ids": ["a","b","c","d"], "candidate_tie_break_keys": {"a":"1","b":"3","c":"2","d":"4"}}]
    bad = json.loads(json.dumps(prediction))
    try:
        rescore(bad, menu_queries, corpus)
        raise AssertionError("Menu-specific wrong tie accepted")
    except ValueError:
        pass
    for corruption in ["missing", "duplicate_candidate", "wrong_positive_rank", "forged_metric", "nonfinite"]:
        bad = json.loads(json.dumps(prediction))
        if corruption == "missing":
            bad = []
        elif corruption == "duplicate_candidate":
            bad[0]["top50"][0] = "b"
        elif corruption == "wrong_positive_rank":
            bad[0]["positive_ranks"][0]["rank"] = 3
        elif corruption == "forged_metric":
            bad[0]["recall@1"] = 1
        else:
            bad[0]["scores"][0] = float("nan")
        try:
            rescore(bad, queries, corpus)
            raise AssertionError(f"Corruption accepted: {corruption}")
        except ValueError:
            pass
    fixture_root = Path(__file__).resolve().parents[2] / "fixtures"
    fixture_root.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="cps5801_rebuild_fixture_", dir=fixture_root) as tmp:
        root = Path(tmp)
        (root / "publication/data").mkdir(parents=True)
        (root / "publication/data/example.json").write_text("{}", encoding="utf-8")
        write_json(root / "path_map.json", {"Z:\\old\\publication": "publication"})
        resolver = Resolver(root)
        require(resolver.resolve("Z:\\old\\publication\\data\\example.json") == root / "publication/data/example.json", "Portable Windows-prefix mapping failed")
        try:
            resolver.resolve("Z:\\old\\publication\\..\\..\\outside.json", must_exist=False)
            raise AssertionError("Escaping mapping accepted")
        except ValueError:
            pass
        # End-to-end relocated synthetic evidence: 2 families x3 policies x5
        # seeds, actual ranks, paired bootstrap, figures and source mapping.
        pub = root / "publication"
        full_queries = [{"id": f"q{i}", "query": f"synthetic request {i}", "positives": ["b"],
                         "candidate_ids": ["a","b","c","d"],
                         "candidate_tie_break_keys": {"a":"1","b":"2","c":"3","d":"4"},
                         "group_id": f"g{i//2}"} for i in range(4)]
        write_json(pub / "data/queries.json", full_queries)
        write_json(pub / "data/corpus.json", corpus)
        write_json(pub / "run_registry.json", {"runs": []})
        evaluations, lock_evaluations = [], []
        for family, stage in [("e5","S3"),("bge","S5")]:
            for policy in ["R_ID","B_ID","B_UNIQUE"]:
                for seed in [42,43,44,45,46]:
                    eid = f"fixture_{family}_{policy}_{seed}"
                    directory = pub / "evaluations" / eid
                    ranking = ["b","a","c","d"] if policy == "B_UNIQUE" else (["a","b","c","d"] if policy == "R_ID" else ["a","c","b","d"])
                    rows = [{"id": q["id"],"positives":["b"],"top50":ranking,"ranking":ranking,"scores":[1.,.8,.6,.4],"candidate_count":4,
                             "positive_ranks":[{"id":"b","rank":ranking.index("b")+1,"score":[1.,.8,.6,.4][ranking.index("b")]}]} for q in full_queries]
                    write_json(directory / "predictions.json", rows)
                    config={"run_id":eid,"family":family,"policy":policy,"seed":seed,"stage":stage,"dataset":"bfcl_live_multiple",
                            "queries_path":"Z:\\old\\publication\\data\\queries.json","corpus_path":"Z:\\old\\publication\\data\\corpus.json"}
                    write_json(directory / "config.json",config)
                    write_json(directory / "metrics.json",{"metrics":rescore(rows,full_queries,corpus)["metrics"],"model_manifest_sha256":"f"*64,
                                                            "input_hashes":{"queries":sha(pub/'data/queries.json'),"corpus":sha(pub/'data/corpus.json')}})
                    evaluations.append({"evaluation_id":eid,"run_id":eid,"dataset":"bfcl_live_multiple","family":family,"policy":policy,"seed":seed,"stage":stage,
                                        "output_path":f"Z:\\old\\publication\\evaluations\\{eid}",
                                        "config_path":f"Z:\\old\\publication\\evaluations\\{eid}\\config.json",
                                        "queries_path":"Z:\\old\\publication\\data\\queries.json","corpus_path":"Z:\\old\\publication\\data\\corpus.json","status":"completed",
                                        "predictions_sha256":sha(directory/'predictions.json'),"metrics_sha256":sha(directory/'metrics.json')})
                    lock_evaluations.append({"evaluation_id":eid,"run_id":eid,"dataset":"bfcl_live_multiple","checkpoint_manifest_sha256":"f"*64,
                                             "queries_sha256":sha(pub/'data/queries.json'),"corpus_sha256":sha(pub/'data/corpus.json'),"config_sha256":sha(directory/'config.json')})
        write_json(pub / "locks/final_lock.json", {"fixture_only": True, "no_real_final_scores": True,"evaluations":lock_evaluations})
        write_json(pub / "final_evaluation_registry.json", {"evaluations": evaluations,"lock_sha256":sha(pub/'locks/final_lock.json')})
        rebuilt = Rebuilder(root, root / "rebuilt").run()
        require(rebuilt["completed_evaluations"] == 30 and rebuilt["verification_failures"] == 0, f"Portable end-to-end fixture failed: {rebuilt}")
        with (root / "rebuilt/comparison/locked_confirmation_effects.csv").open(encoding="utf-8-sig", newline="") as stream:
            effects = list(csv.DictReader(stream))
        primary = [row for row in effects if row["primary"] == "True"]
        require(len(primary) == 4 and all(float(row["mean_effect"]) >= .5 for row in primary), "Four primary contrasts missing from end-to-end fixture")
        provenance = read_json(root / "rebuilt/table_provenance.json")
        require(len(provenance["tables_and_artifacts"]) >= 30, "End-to-end source provenance missing")
        modified_queries=json.loads(json.dumps(full_queries));modified_queries[0]['positives']=['a']
        write_json(pub/'data/queries.json',modified_queries)
        discovered,_,_=discover_evaluations(Resolver(root))
        try:
            Rebuilder(root,root/'tamper_check').score_evaluation(discovered[0])
            raise AssertionError('Changed frozen labels accepted')
        except ValueError as exc:
            require('query/corpus bytes changed' in str(exc),'Wrong tamper rejection gate')
        for folder in ['original_reference','reproduction']:
            write_json(root/folder/'results/main_20261025/M01_bm25/predictions.json',[])
        root_entries,_,_=discover_evaluations(Resolver(root));child_entries,_,_=discover_evaluations(Resolver(pub))
        require(len(root_entries)==len(child_entries)==32,'Publication-subdirectory discovery dropped original/reproduction')
    return {"passed": True, "checks": ["multi_positive_recall_mrr_AP", "menu_hash_tie", "missing_query", "duplicate_candidate", "positive_global_rank_consistency", "forged_saved_metric", "nonfinite", "portable_path_map", "mapping_escape_rejection", "relocated_30_eval_full_rebuild", "four_primary_effects", "raw_evidence_provenance","frozen_label_hash_gate","publication_child_root_discovery"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2))
        return
    require(args.input_root is not None and args.output_dir is not None, "--input-root and --output-dir required")
    result = Rebuilder(args.input_root, args.output_dir).run()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["verification_failures"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
