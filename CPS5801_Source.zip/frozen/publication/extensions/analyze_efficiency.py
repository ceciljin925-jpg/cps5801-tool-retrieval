"""Rebuild measured retrieval efficiency and frozen raw-document token curves.

--input-root PUBLICATION_OR_RETURN_ROOT --output-dir NEW_DIR
[--tokenizer-json PATH_TO_PINNED_E5_tokenizer.json]
--self-test

Requires final_evaluation_registry.json; its efficiency entries bind dataset
plans and measured seed42/baseline outputs. Pending inputs yield explicit
pending status, never invented timing or token counts. No model/GPU loading.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import tempfile

from rebuild_all import (Resolver, read_json, require, rescore, sha, write_csv,
                         write_json, write_jsonl_gz, registry_runs, validate_final_files, dataset_metric_contract)
from publication_statistics import percentile_linear

KS = [1, 3, 5, 10, 20, 50]


def raw_documents(corpus, dataset):
    texts, ids = [], []
    for document in corpus:
        require("raw" in document and isinstance(document["raw"], dict), "Raw tool metadata required; serialized retrieval text is not an authorized replacement")
        raw = document["raw"]
        if dataset.startswith("bfcl") or dataset == "toolhop":
            require(set(raw) <= {"name", "description", "parameters"}, "External raw document contains fields beyond frozen metadata projection")
        ids.append(document["id"])
        texts.append(json.dumps(raw, sort_keys=True, ensure_ascii=False))
    require(len(ids) == len(set(ids)), "Duplicate token-length corpus IDs")
    return ids, texts


def token_curves(predictions, queries, corpus, token_lengths):
    verified = rescore(predictions, queries, corpus)
    predictions_by_id = {row["id"]: row for row in predictions}
    require(set(token_lengths) == {doc["id"] for doc in corpus}, "Token lengths do not exactly cover frozen corpus")
    per_query = []
    for scored in verified["per_query"]:
        prediction = predictions_by_id[scored["id"]]
        ranking = prediction.get("ranking", prediction.get("top50"))
        require(ranking is not None, "New token curves require top50 or complete native-menu ranking; old top10 must remain separate")
        row = {"query_id": scored["id"], "candidate_count": scored["candidate_count"]}
        for k in KS:
            require(len(ranking) >= min(k, scored["candidate_count"]), "Insufficient saved depth for requested k")
            row[f"recall@{k}"] = scored[f"recall@{k}"]
            row[f"returned_count@{k}"] = min(k, scored["candidate_count"])
            row[f"raw_document_tokens@{k}"] = sum(token_lengths[tid] for tid in ranking[:k])
        row["mrr"] = scored["mrr"]
        row['mrr@10']=scored['mrr@10']
        per_query.append(row)
    curves = [{"k": k, "n_queries": len(per_query),
               "recall": statistics.mean(row[f"recall@{k}"] for row in per_query),
               "mean_returned_count": statistics.mean(row[f"returned_count@{k}"] for row in per_query),
               "mean_raw_document_tokens": statistics.mean(row[f"raw_document_tokens@{k}"] for row in per_query),
               "menu_saturated_query_fraction": statistics.mean(row["candidate_count"] <= k for row in per_query),
               "mrr_complete_ranking": statistics.mean(row["mrr"] for row in per_query),
               'mrr@10':statistics.mean(row['mrr@10'] for row in per_query)} for k in KS]
    return curves, per_query


def summarize_timings(rows, plan, summary, warmups):
    require(plan["rounds"] == 5 and plan["warmups"] == 50 and plan["batch_size"] == 1, "Profiling plan differs from frozen5-round/50-warmup/batch1 protocol")
    require(len(warmups) == 50, "Warmup evidence incomplete")
    ids = plan["query_ids"]
    require(ids and len(set(ids)) == len(ids), "Invalid frozen timing IDs")
    require(len(rows) == len(ids) * 5, "Per-query timing rows incomplete")
    round_summaries = []
    for round_id in range(1, 6):
        current = [row for row in rows if row.get("round") == round_id]
        require([row["query_id"] for row in current] == ids, "Timing query order differs from frozen plan")
        require([row["query_order"] for row in current] == list(range(len(ids))), "Timing query cursor differs")
        values = [float(row["end_to_end_ms"]) for row in current]
        require(all(math.isfinite(value) and value > 0 for value in values), "Invalid measured end-to-end latency")
        round_summaries.append({"round": round_id, "n": len(values), "median_ms": statistics.median(values),
                                "p95_ms": percentile_linear(values, .95), "mean_ms": statistics.mean(values),
                                "sequential_batch1_queries_per_second": len(values) * 1000 / math.fsum(values)})
    all_values = [float(row["end_to_end_ms"]) for row in rows]
    result = {"query_count_per_round": len(ids), "rounds": 5, "warmups": 50,
              "median_ms": statistics.median(all_values), "p95_ms": percentile_linear(all_values, .95),
              "mean_ms": statistics.mean(all_values), "sequential_batch1_queries_per_second": len(all_values) * 1000 / math.fsum(all_values),
              "minimum_round_median_ms": min(row["median_ms"] for row in round_summaries),
              "maximum_round_median_ms": max(row["median_ms"] for row in round_summaries), "per_round": round_summaries}
    saved = summary.get("metrics_ms", {}).get("end_to_end_ms", {})
    for key, name in [("median", "median_ms"), ("p95", "p95_ms"), ("mean", "mean_ms")]:
        if key in saved:
            require(abs(float(saved[key]) - result[name]) <= 1e-8, "Saved latency summary does not match all raw timing rows")
    return result


def pareto_flags(points, cost="cost", accuracy="accuracy"):
    """Observed numerical frontier only; no claim of noise-robust dominance."""
    for point in points:
        require(math.isfinite(point[cost]) and math.isfinite(point[accuracy]), "Nonfinite Pareto coordinate")
    return [not any(other[accuracy] >= point[accuracy] and other[cost] <= point[cost]
                    and (other[accuracy] > point[accuracy] or other[cost] < point[cost])
                    for other in points) for point in points]


class EfficiencyAnalyzer:
    def __init__(self, input_root, output_dir, tokenizer_json=None):
        self.resolver, self.out = Resolver(input_root), Path(output_dir).resolve()
        require(not self.out.exists() or not any(self.out.iterdir()), "Use a fresh efficiency output directory")
        self.out.mkdir(parents=True, exist_ok=True)
        self.tokenizer_json, self.tokenizer = tokenizer_json, None
        self.token_cache, self.hash_cache, self.provenance = {}, {}, []
        self.pending, self.failures, self.curves, self.profiles, self.training = [], [], [], [], []

    def source(self, path):
        path = Path(path).resolve()
        if path not in self.hash_cache:
            self.hash_cache[path] = {"path": self.resolver.display(path), "bytes": path.stat().st_size, "sha256": sha(path)}
        return self.hash_cache[path]

    def register(self, output, inputs, formula, **metadata):
        self.provenance.append({"output": output.relative_to(self.out).as_posix(), "sha256": sha(output), "bytes": output.stat().st_size,
                                "inputs": [self.source(path) for path in sorted(set(inputs))], "script_sha256": sha(__file__),
                                "formula": formula, "missing_handling": "pending/failed explicitly retained", **metadata})

    def table(self, name, rows, inputs, formula, columns=None):
        path = self.out / name
        write_csv(path, rows, columns)
        self.register(path, inputs, formula)
        return path

    def get_tokenizer(self):
        if self.tokenizer is not None:
            return self.tokenizer
        candidates = []
        if self.tokenizer_json:
            candidates.append(self.resolver.resolve(self.tokenizer_json))
        candidates.extend([self.resolver.root / "original_reference/data/raw/model/tokenizer.json",
                           self.resolver.root / "reproduction/data/raw/model/tokenizer.json",
                           self.resolver.publication.parent / "repro/data/raw/model/tokenizer.json"])
        decisions = self.resolver.publication / "locks/execution_decisions.json"
        if decisions.exists():
            try:
                original_path = str(Path(read_json(decisions)["source"]) / "archive/CPS5801_HANDOFF_20261025/CPS5801/data/raw/model/tokenizer.json")
                candidates.append(self.resolver.resolve(original_path))
            except ValueError:
                pass
        found = next((path for path in candidates if path.exists()), None)
        require(found is not None, "Pinned E5 tokenizer.json missing; include its verified bytes in portable return package")
        from tokenizers import Tokenizer
        self.tokenizer_json = found.resolve()
        self.tokenizer = Tokenizer.from_file(str(found))
        self.tokenizer.no_truncation(); self.tokenizer.no_padding()
        return self.tokenizer

    def lengths(self, corpus_path, corpus, dataset):
        digest = sha(corpus_path)
        if digest in self.token_cache:
            return self.token_cache[digest]
        tokenizer = self.get_tokenizer()
        reference_root=self.resolver.publication/'analysis/reference_document_tokens'
        reference_manifest=reference_root/'manifest.json'
        if reference_manifest.exists():
            reference=read_json(reference_manifest)
            entry=reference.get('datasets',{}).get(dataset)
            if entry and entry['corpus_sha256']==digest and reference['tokenizer']['sha256']==sha(self.tokenizer_json):
                cached_path=reference_root/entry['cache_path']
                require(sha(cached_path)==entry['cache_sha256'] and cached_path.stat().st_size==entry['cache_bytes'],'Precomputed token cache changed')
                cached=read_json(cached_path)
                require(cached['corpus_sha256']==digest and cached['tokenizer_sha256']==sha(self.tokenizer_json)
                        and cached['add_special_tokens'] is False and cached['truncation'] is False,'Token-cache contract differs')
                mapping=cached['lengths']
                require(set(mapping)=={document['id'] for document in corpus} and all(isinstance(value,int) and value>=0 for value in mapping.values()),'Token-cache corpus mapping invalid')
                path=self.out/'token_lengths'/f'{digest}.json';write_json(path,cached)
                self.register(path,[corpus_path,self.tokenizer_json,cached_path,reference_manifest],'Verified score-free complete-corpus cache; raw metadata SHA,tokenizer SHA and no-special/no-truncation contract match')
                self.token_cache[digest]=(mapping,path);return mapping,path
        ids, texts = raw_documents(corpus, dataset)
        lengths = []
        for offset in range(0, len(texts), 256):
            lengths.extend(len(row.ids) for row in tokenizer.encode_batch(texts[offset:offset+256], add_special_tokens=False))
        mapping = dict(zip(ids, lengths))
        path = self.out / "token_lengths" / f"{digest}.json"
        write_json(path, {"corpus_sha256": digest, "tokenizer_sha256": sha(self.tokenizer_json),
                          "text_scope": "json.dumps(raw,sort_keys=True,ensure_ascii=False), default separators, no special tokens, no truncation", "lengths": mapping})
        self.register(path, [corpus_path, self.tokenizer_json], "Exact frozen E5 tokenizer IDs for complete raw tool JSON; never substitute serialized retrieval text")
        self.token_cache[digest] = (mapping, path)
        return mapping, path

    def eval_curves(self, entry):
        out = self.resolver.resolve(entry["output_path"])
        queries_path, corpus_path = self.resolver.resolve(entry["queries_path"]), self.resolver.resolve(entry["corpus_path"])
        prediction = next((out / name for name in ["predictions.json","predictions.jsonl.gz","predictions.json.gz"] if (out / name).exists()), None)
        require(prediction is not None, "Completed final evaluation lacks predictions")
        _, binding_sources = validate_final_files(entry,self.resolver,out,queries_path,corpus_path,prediction,read_json(out/'config.json'))
        queries, corpus = read_json(queries_path), read_json(corpus_path)
        lengths, lengths_path = self.lengths(corpus_path, corpus, entry["dataset"])
        curves, per_query = token_curves(read_json(prediction), queries, corpus, lengths)
        tags = {key: entry.get(key) for key in ["evaluation_id","run_id","dataset","stage","family","policy","seed"]}
        sources = [prediction, queries_path, corpus_path, lengths_path, self.tokenizer_json, *binding_sources]
        for curve in curves:
            self.curves.append({**tags, **curve, "corpus_sha256": sha(corpus_path), "queries_sha256": sha(queries_path),
                                "tokenizer_sha256": sha(self.tokenizer_json), "token_scope": "complete_raw_JSON_no_specials_no_truncation",
                                'native_recall_metric':('ReferenceToolRecall@' if entry['dataset']=='toolhop' else 'macroRecall@')+str(curve['k']),
                                'metric_scope':dataset_metric_contract(entry['dataset'])[1],
                                'ReferenceIDMRR@10':curve['mrr@10'] if entry['dataset']=='toolhop' else None})
        per_query_path = self.out / "per_query" / (entry["evaluation_id"].replace(":","_").replace("/","_") + ".jsonl.gz")
        write_jsonl_gz(per_query_path, per_query)
        self.register(per_query_path, sources, "Per-query saved top-k IDs -> sum full raw token counts; independently recomputed Recall@k and full-ranking MRR")
        return sources

    def profile(self, dataset, model, plan_path, plan, final_entries):
        run_id = model["run_id"]
        metadata = next((entry for entry in final_entries if entry["dataset"] == dataset and entry["run_id"] == run_id), None)
        require(metadata is not None, "Timing model has no corresponding frozen accuracy evaluation")
        require(metadata.get("seed") in [None,42], "Unplanned seed timing must not be substituted")
        out = self.resolver.resolve(model["output_path"])
        raw_path, summary_path, warmup_path = out / "raw_timings.jsonl", out / "summary.json", out / "warmup_timings.json"
        evidence = model.get('evidence_manifest',{})
        for path in [raw_path,summary_path,warmup_path,out/'status.json']:
            require(path.name in evidence and path.stat().st_size == evidence[path.name]['bytes'] and sha(path)==evidence[path.name]['sha256'], 'Measured profile artifact changed after registry binding')
        summary = read_json(summary_path)
        require(summary["run_id"] == run_id and summary["seed"] == metadata.get("seed"), "Timing run/seed identity mismatch")
        require(summary["profiling_plan_sha256"] == sha(plan_path), "Timing does not match frozen plan hash")
        model_spec = next(row for row in plan["models"] if row["run_id"] == run_id)
        require(summary["model_manifest_sha256"] == model_spec["model_manifest_sha256"], "Timing model identity differs from plan")
        locked_model=next(row for row in self.final_lock['models'] if row['run_id']==run_id)
        require(summary['model_manifest_sha256']==locked_model['checkpoint_manifest_sha256'], 'Timing checkpoint differs from locked accuracy checkpoint')
        require(plan["queries_sha256"] == sha(self.resolver.resolve(metadata["queries_path"])) and plan["corpus_sha256"] == sha(self.resolver.resolve(metadata["corpus_path"])), "Accuracy and timing candidate/query inputs differ")
        query_ids=sorted(row['id'] for row in read_json(self.resolver.resolve(metadata['queries_path'])))
        expected_ids=random.Random(2026111203).sample(query_ids,1000) if len(query_ids)>1000 else query_ids
        require(plan['query_ids']==expected_ids,'Profile sample/order differs from frozen sorted-ID sampling rule')
        raw = read_json(raw_path)
        stats = summarize_timings(raw, plan, summary, read_json(warmup_path))
        tags = {key: metadata.get(key) for key in ["run_id","dataset","stage","family","policy","seed"]}
        row = {**tags, **{key:value for key,value in stats.items() if key != "per_round"},
               **{key:summary.get(key) for key in ["load_seconds","index_seconds","embedding_persistence_seconds","query_independent_preparation_seconds","vector_or_sparse_index_bytes","index_memory_note","retrieval_peak_allocated_GiB","retrieval_peak_reserved_GiB","total_wall_seconds","timing_boundary","contention_status"]},
               "setup_peak_allocated_GiB": summary.get("setup_peak",{}).get("allocated_GiB"),
               "setup_peak_reserved_GiB": summary.get("setup_peak",{}).get("reserved_GiB"),
               "compute_device": "CPU lexical scoring (GPU synchronization recorded)" if metadata["family"] == "bm25" else "GPU dense encoding/scoring; CPU stable full-sort",
               "profile_query_ids_sha256": plan["query_order_sha256"], "accuracy_query_population": "full evaluation set; timing fixed subset", "raw_source": self.resolver.display(raw_path)}
        self.profiles.append(row)
        for round_row in stats["per_round"]:
            self.rounds.append({**tags, **round_row})
        return [raw_path, summary_path, warmup_path, plan_path]

    def training_costs(self):
        sources = []
        path = self.resolver.publication / "run_registry.json"
        if path.exists():
            sources.append(path)
            for row in registry_runs(read_json(path)):
                tags = {key: row.get(key) for key in ["run_id","stage","family","policy","seed","status"]}
                if row.get("status") not in ["completed","reused"] or not row.get("output_path"):
                    self.training.append({**tags,"training_seconds":None,"cost_status":"not_completed_or_missing"}); continue
                try:
                    training_path = self.resolver.resolve(str(Path(row["output_path"]) / "training.json"))
                    training = read_json(training_path); sources.append(training_path)
                    tags['policy']=training.get('policy',tags['policy'])
                    seconds = training.get("train_seconds_including_checkpoint_io",training.get("train_seconds",training.get("seconds")))
                    require(seconds is not None and math.isfinite(float(seconds)) and seconds >= 0, "No measured training duration in training record")
                    self.training.append({**tags,"training_seconds":seconds,"actual_steps":training.get("steps"),
                                          "peak_allocated_GiB":training.get("peak_allocated_GiB"),
                                          "training_boundary":"including checkpoint IO" if "train_seconds_including_checkpoint_io" in training else "original engine measured boundary; see raw source",
                                          "source":self.resolver.display(training_path),"cost_status":"measured"})
                except (ValueError,KeyError,OSError) as exc:
                    self.training.append({**tags,"training_seconds":None,"cost_status":"missing_measured_field","reason":str(exc)})
        mining = self.resolver.publication / "data/training/dense_mining_manifest.json"
        mining_rows = []
        if mining.exists():
            data = read_json(mining);sources.append(mining)
            mining_rows.append({"operation":"fixed_pretrained_E5_dense_mining","seconds":data.get("seconds"),"peak_allocated_GiB":data.get("peak_allocated_GiB"),
                                "allocation":"one shared preprocessing operation for all DENSE_STATIC runs; never multiplied by run count","source":self.resolver.display(mining)})
        else:
            mining_rows.append({"operation":"fixed_pretrained_E5_dense_mining","seconds":None,"allocation":"measurement unavailable/pending"})
        self.table("training_costs.csv",self.training,sources,"Per-run measured fine-tuning duration; no pretraining cost assumed; pending/failed remain missing")
        self.table("shared_mining_costs.csv",mining_rows,sources,"Measured shared mining cost separate from training/indexing/query serving; no invented amortization")
        totals = []
        for stage in ["S0","S1","S2","S3","S4","S5"]:
            selected = [row for row in self.training if row["stage"] == stage]
            measured = [row for row in selected if row["training_seconds"] is not None]
            totals.append({"stage":stage,"registry_runs":len(selected),"measured_runs":len(measured),"missing_runs":len(selected)-len(measured),
                           "measured_training_seconds_sum":sum(row["training_seconds"] for row in measured),
                           "role":"development_search" if stage in ["S2","S4"] else "fixed_recipe_or_confirmation",
                           "reuse_note":"reused run rows require unique-execution accounting before reporting whole-study total; stage sums describe associated models"})
        self.table("stage_training_costs.csv",totals,sources,"Separate search from confirmation compute; sum only measured durations and show missing count")

    def aggregate_and_pareto(self, sources):
        grouped = defaultdict(list)
        for row in self.curves:
            grouped[(row["dataset"],row["stage"],row["family"],row["policy"],row["k"])].append(row)
        profiles = {(row["dataset"],row["stage"],row["family"],row["policy"]):row for row in self.profiles}
        require(len(profiles) == len(self.profiles), "Duplicate timing condition; do not select a favorable retry")
        aggregate, latency_points, token_points = [], [], []
        for key, rows in sorted(grouped.items(),key=str):
            dataset,stage,family,policy,k = key
            seeds = [row["seed"] for row in rows]
            require(len(seeds)==len(set(seeds)), "Duplicate accuracy seed within efficiency condition")
            expected = [42,43,44,45,46] if stage in ["S3","S5"] else ([42,43,44] if stage in ["S0","S1"] else [None])
            complete = set(seeds)==set(expected)
            mean_recall=statistics.mean(row["recall"] for row in rows)
            mean_mrr=statistics.mean(row["mrr_complete_ranking"] for row in rows)
            tag={"dataset":dataset,"stage":stage,"family":family,"policy":policy,"k":k,"seeds":seeds,"n_seeds":len(rows),"all_expected_seeds_present":complete}
            record={**tag,"mean_recall":mean_recall,"sample_sd_recall":statistics.stdev(row["recall"] for row in rows) if len(rows)>1 else None,
                    "mean_mrr":mean_mrr,"sample_sd_mrr":statistics.stdev(row["mrr_complete_ranking"] for row in rows) if len(rows)>1 else None,
                    "mean_raw_document_tokens":statistics.mean(row["mean_raw_document_tokens"] for row in rows),
                    "mean_returned_count":statistics.mean(row["mean_returned_count"] for row in rows),
                    "mean_menu_saturated_query_fraction":statistics.mean(row["menu_saturated_query_fraction"] for row in rows)}
            profile=profiles.get(key[:4])
            if profile:
                record.update(measured_latency_seed=profile["seed"],median_ms=profile["median_ms"],p95_ms=profile["p95_ms"],
                              latency_scope="One fixed full-sort/top50 materialization path; not separately measured per k",
                              minimum_round_median_ms=profile["minimum_round_median_ms"],maximum_round_median_ms=profile["maximum_round_median_ms"])
            else:
                record.update(measured_latency_seed=None,median_ms=None,p95_ms=None,latency_scope="not measured; no borrowed seed speed")
            aggregate.append(record)
            if complete:
                if not dataset.startswith("bfcl"):
                    token_points.append({**record,"accuracy_metric":"ReferenceToolRecall@k" if dataset=="toolhop" else "macro_recall",
                                         "accuracy":mean_recall,"cost":record["mean_raw_document_tokens"],"cost_metric":"complete_raw_document_tokens"})
                # Pooled main latency comparison fixes k5. Native-menu accuracy
                # is full-ranking MRR and therefore is represented once, not
                # repeated as a saturated Recall@5 success claim.
                if profile and (k==1 if dataset.startswith("bfcl") else k==5):
                    latency_points.append({**record,"accuracy_metric":"MRR" if dataset.startswith("bfcl") else ("ReferenceToolRecall@5" if dataset=="toolhop" else "macro_recall@5"),
                                           "accuracy":mean_mrr if dataset.startswith("bfcl") else mean_recall,"cost":profile["median_ms"],"cost_metric":"measured_batch1_median_ms",
                                           "display_k":None if dataset.startswith("bfcl") else 5,
                                           "accuracy_sd":record["sample_sd_mrr"] if dataset.startswith("bfcl") else record["sample_sd_recall"],
                                           'metric_scope':dataset_metric_contract(dataset)[1]})
        for points in [latency_points,token_points]:
            for dataset in sorted({row["dataset"] for row in points}):
                subset=[row for row in points if row["dataset"]==dataset]
                for row,flag in zip(subset,pareto_flags(subset)):
                    row["on_observed_frontier"]=flag
                    row["dominance_scope"]="Numerical observed frontier; timing noise and limited seeds prevent automatic stable-superiority claim"
        self.table("all_seed_k_curves.csv",self.curves,sources,"Each actual final run/seed at k1,3,5,10,20,50; Recall independent of raw token budget")
        self.table("seed_aggregate_k_curves.csv",aggregate,sources,"All prescribed seed means/sample SD, explicit missing-seed state; measured seed42/baseline timing only")
        self.table("recall_or_mrr_latency_pareto.csv",latency_points,sources,"Full-set accuracy with fixed-subset measured seed42 latency; pooledR@5 vs BFCL full-menuMRR; no k-dependent speed assumption")
        self.table("recall_document_tokens_pareto.csv",token_points,sources,"Pooled Recall@k vs full raw document tokens; ToolHop remains reference-label stress")
        self.plots(latency_points,token_points)

    def plots(self,latency,token):
        if not latency and not token:return
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        for dataset in sorted({row["dataset"] for row in latency}):
            points=[row for row in latency if row["dataset"]==dataset]
            fig,ax=plt.subplots(figsize=(10,6.5))
            for row in points:
                label=f"{row['family']} {row['policy']} {row['stage']}"
                xerr=[[max(0,row['cost']-row['minimum_round_median_ms'])],[max(0,row['maximum_round_median_ms']-row['cost'])]]
                ax.errorbar(row['cost'],row['accuracy'],xerr=xerr,yerr=row['accuracy_sd'] or 0,fmt='o',capsize=2,label=label)
            ax.set_xlabel("Measured batch1 median latency (ms); x bars = range of five round medians")
            ax.set_ylabel(points[0]['accuracy_metric']+"; y bars = sample SD over fitted seeds")
            ax.set_title(dataset+": observed accuracy–latency comparison\n"+('Native-menu ranking, not official BFCL execution success' if dataset.startswith('bfcl') else ('Reference labels are incomplete; stress diagnostic only' if dataset=='toolhop' else 'Previously observed pooled test; historical diagnostic')))
            ax.legend(fontsize=7,ncol=2,loc='best');ax.grid(alpha=.2);fig.tight_layout()
            path=self.out/'figures'/f'{dataset}_accuracy_latency.png';path.parent.mkdir(exist_ok=True);fig.savefig(path,dpi=180);plt.close(fig)
            self.register(path,[self.out/'recall_or_mrr_latency_pareto.csv'],"Actual measured points only; seed42 latency plus all-seed mean accuracy explicitly distinguished")
        for dataset in sorted({row['dataset'] for row in token}):
            points=[row for row in token if row['dataset']==dataset];conditions=defaultdict(list)
            for row in points:conditions[(row['family'],row['policy'],row['stage'])].append(row)
            fig,ax=plt.subplots(figsize=(10,6.5))
            for condition,rows in sorted(conditions.items()):
                rows.sort(key=lambda row:row['k']);ax.plot([r['cost'] for r in rows],[r['accuracy'] for r in rows],marker='o',markersize=3,label=' '.join(condition))
            ax.set_xlabel("Mean complete raw tool-document tokens (fixed E5 tokenizer; no special tokens)")
            ax.set_ylabel("ReferenceToolRecall@k (incomplete reference labels)" if dataset=='toolhop' else "Macro Recall@k")
            ax.set_title(dataset+": k = 1, 3, 5, 10, 20, 50; context volume only")
            ax.legend(fontsize=7,ncol=2);ax.grid(alpha=.2);fig.tight_layout();path=self.out/'figures'/f'{dataset}_recall_tokens.png';path.parent.mkdir(exist_ok=True);fig.savefig(path,dpi=180);plt.close(fig)
            self.register(path,[self.out/'recall_document_tokens_pareto.csv'],"Context-volume curves, not API cost or agent success and not a serving-speed claim")

    def run(self):
        registry_path=self.resolver.publication/'final_evaluation_registry.json'
        if not registry_path.exists():
            status={"status":"PENDING_FINAL_RESULTS","reason":"No final evaluation registry exists; no scores or timings inferred","completed_accuracy_evaluations":0,"completed_profiles":0}
            write_json(self.out/'status.json',status);return status
        lock_path=self.resolver.publication/'locks/final_lock.json'
        require(lock_path.exists(),"No final_lock; refuse external accuracy/timing access")
        registry=read_json(registry_path);entries=[{**entry,'registry_lock_sha256':registry.get('lock_sha256'),'registry_path':str(registry_path)} for entry in registry['evaluations']];sources=[registry_path];self.rounds=[]
        require(registry.get('lock_sha256')==sha(lock_path),'Final registry does not match final_lock bytes')
        self.final_lock=read_json(lock_path);sources.append(lock_path)
        expected_eval_ids={row['evaluation_id'] for row in self.final_lock['evaluations'] if row.get('purpose','final_retrieval')=='final_retrieval'}
        require(len(entries)==len({entry['evaluation_id'] for entry in entries}) and {entry['evaluation_id'] for entry in entries}==expected_eval_ids,'Efficiency accuracy registry omits/duplicates locked jobs')
        require({group['dataset'] for group in registry.get('efficiency',[])}=={group['dataset'] for group in self.final_lock.get('efficiency_plans',[])},'Profiling registry omits locked dataset plans')
        for entry in entries:
            if entry['status'] not in ['completed','reused']:
                self.pending.append({"kind":"accuracy","id":entry['evaluation_id'],"status":entry['status']});continue
            try:sources.extend(self.eval_curves(entry))
            except (ValueError,KeyError,TypeError,OSError) as exc:self.failures.append({"kind":"accuracy","id":entry['evaluation_id'],"reason":str(exc)})
        for group in registry.get('efficiency',[]):
            plan_path=self.resolver.resolve(group['plan_path']);plan=read_json(plan_path)
            require(sha(plan_path)==group['plan_sha256'],"Profiling plan changed after registry binding")
            locked_plans=[row for row in self.final_lock.get('efficiency_plans',[]) if row['dataset']==group['dataset']]
            require(len(locked_plans)==1 and locked_plans[0]['plan_sha256']==sha(plan_path),'Profiling plan not bound to final lock')
            require(len(group['models'])==len({model['run_id'] for model in group['models']}) and {model['run_id'] for model in group['models']}=={model['run_id'] for model in plan['models']},'Profiling registry omits/duplicates frozen model conditions')
            for model in group['models']:
                if model['status']!='completed':self.pending.append({"kind":"profiling","id":group['dataset']+':'+model['run_id'],"status":model['status']});continue
                try:sources.extend(self.profile(group['dataset'],model,plan_path,plan,entries))
                except (ValueError,KeyError,TypeError,OSError) as exc:self.failures.append({"kind":"profiling","id":group['dataset']+':'+model['run_id'],"reason":str(exc)})
        self.training_costs()
        self.table('measured_profiles.csv',self.profiles,sources,"Full raw timing reconstruction plus actual one-time load/index/persistence/preparation and memory resource logs; each boundary separate")
        self.table('latency_all_five_rounds.csv',self.rounds,sources,"Recompute median/p95/mean/service-time reciprocal separately for every complete round")
        self.aggregate_and_pareto(sources)
        self.table('pending.csv',self.pending,[registry_path],"Explicit incomplete evidence",columns=['kind','id','status'])
        write_json(self.out/'failures.json',self.failures)
        write_json(self.out/'table_provenance.json',{'artifacts':self.provenance,'script_sha256':sha(__file__)})
        (self.out/'measurement_boundaries.txt').write_text('Accuracy uses full frozen evaluation sets. Latency uses prespecified seed42 or a baseline, five repeats of one fixed query subset,50warmups,batch1 and stable full sorting.\nAll k curves share the measured full-sort/top50 path; reducing k is not demonstrated to reduce search time.\nTraining, shared negative mining, model load, index construction, persistence and per-query service are separate costs. Pretraining and paid API bills are not measured.\nRaw-document tokens use one fixed E5 tokenizer, full sorted-key raw JSON, no truncation or special tokens. No raw metadata means missing evidence, never substitution of retrieval text.\nBFCL latency accuracy is full-menu MRR. ToolHop is reference-label stress. Pareto frontiers are observed coordinates, not stable dominance in the presence of timing noise.\n',encoding='utf-8')
        status={'status':'FAILED_VERIFICATION' if self.failures else ('PARTIAL_PENDING' if self.pending else 'AVAILABLE_EVIDENCE_ANALYZED'),
                'completed_accuracy_evaluations':len(self.curves)//len(KS),'completed_profiles':len(self.profiles),'pending':len(self.pending),'failures':len(self.failures),
                'tokenizer_sha256':sha(self.tokenizer_json) if self.tokenizer_json else None,'not_a_claim_of_all_research_complete':True}
        write_json(self.out/'status.json',status);return status


def self_test():
    corpus=[{'id':x,'text':'not the raw text','raw':{'name':x,'description':'full metadata '+x,'parameters':{}}} for x in ['a','b','c','d']]
    ids,texts=raw_documents(corpus,'legacy_observed_test')
    require(ids==['a','b','c','d'] and all('not the raw text' not in text for text in texts),'Raw serialization incorrectly uses retrieval text')
    try:raw_documents([{'id':'x','text':'fallback'}],'toolhop');raise AssertionError('Missing raw metadata accepted')
    except ValueError:pass
    try:raw_documents([{'id':'x','raw':{'name':'x','gold_label':True}}],'bfcl_live_multiple');raise AssertionError('Gold label leaked into raw document proxy')
    except ValueError:pass
    q=[{'id':'q','query':'x','positives':['b','d']}]
    p=[{'id':'q','positives':['b','d'],'top50':['a','b','c','d'],'scores':[4.,3.,2.,1.],'candidate_count':4,
        'positive_ranks':[{'id':'b','rank':2,'score':3.},{'id':'d','rank':4,'score':1.}]}]
    curves,rows=token_curves(p,q,corpus,dict(zip(ids,[10,20,30,40])))
    require(curves[0]['recall']==0 and curves[1]['recall']==.5 and curves[1]['mean_raw_document_tokens']==60,'Independent recall/token sum wrong')
    require(curves[-1]['mean_returned_count']==4 and curves[-1]['mean_raw_document_tokens']==100,'Small menu/corpus clipping wrong')
    plan={'rounds':5,'warmups':50,'batch_size':1,'query_ids':['q1','q2']}
    raw=[{'round':r,'query_order':i,'query_id':qid,'end_to_end_ms':r+i} for r in range(1,6) for i,qid in enumerate(plan['query_ids'])]
    summary=summarize_timings(raw,plan,{},[{}]*50)
    require(summary['median_ms']==3.5 and len(summary['per_round'])==5,'Raw five-round median incorrect')
    try:summarize_timings(raw[:-1],plan,{},[{}]*50);raise AssertionError('Missing timing accepted')
    except ValueError:pass
    try:summarize_timings(raw,plan,{'metrics_ms':{'end_to_end_ms':{'median':999}}},[{}]*50);raise AssertionError('Forged timing summary accepted')
    except ValueError:pass
    require(pareto_flags([{'cost':2,'accuracy':.5},{'cost':1,'accuracy':.6},{'cost':3,'accuracy':.9}])==[False,True,True],'Observed frontier relation incorrect')
    fixtures=Path(__file__).resolve().parents[2]/'fixtures';fixtures.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=fixtures,prefix='efficiency_pending_') as tmp:
        result=EfficiencyAnalyzer(Path(tmp)/'input',Path(tmp)/'output').run()
        require(result['status']=='PENDING_FINAL_RESULTS' and result['completed_profiles']==0,'No-final case invented evidence')
    with tempfile.TemporaryDirectory(dir=fixtures,prefix='efficiency_bound_fixture_') as tmp:
        from tokenizers import Tokenizer
        from tokenizers.models import WordLevel
        from tokenizers.pre_tokenizers import Whitespace
        root=Path(tmp)/'input';pub=root/'publication';out=pub/'evaluations/fixture_baseline';profile=pub/'efficiency/fixture_baseline'
        tokenizer=Tokenizer(WordLevel({'[UNK]':0,'name':1,'description':2,'parameters':3,'a':4,'b':5,'c':6,'d':7},unk_token='[UNK]'));tokenizer.pre_tokenizer=Whitespace()
        root.mkdir(parents=True);tokenizer_path=root/'fixture_only_tokenizer.json';tokenizer.save(str(tokenizer_path))
        queries=[{'id':qid,'query':'synthetic request','positives':['b'],'candidate_ids':ids,'candidate_tie_break_keys':{tid:tid for tid in ids},'group_id':qid} for qid in ['q1','q2']]
        predictions=[{'id':query['id'],'positives':['b'],'ranking':['b','a','c','d'],'top50':['b','a','c','d'],'scores':[4.,3.,2.,1.],'candidate_count':4,
                      'positive_ranks':[{'id':'b','rank':1,'score':4.}]} for query in queries]
        qpath,cpath=pub/'data/queries.json',pub/'data/corpus.json';write_json(qpath,queries);write_json(cpath,corpus)
        config={'run_id':'fixture_baseline','dataset':'bfcl_live_multiple','stage':'BASELINE','family':'bm25','policy':'BM25','seed':None,'queries_path':str(qpath),'corpus_path':str(cpath)}
        write_json(out/'config.json',config);write_json(out/'predictions.json',predictions)
        write_json(out/'metrics.json',{'metrics':rescore(predictions,queries,corpus)['metrics'],'model_manifest_sha256':'f'*64,'input_hashes':{'queries':sha(qpath),'corpus':sha(cpath)}})
        timing_plan={'rounds':5,'warmups':50,'batch_size':1,'query_ids':['q1','q2'],'query_order_sha256':'fixture_order',
                     'queries_sha256':sha(qpath),'corpus_sha256':sha(cpath),'models':[{'run_id':'fixture_baseline','model_manifest_sha256':'f'*64}]}
        plan_path=pub/'efficiency/plan.json';write_json(plan_path,timing_plan)
        write_json(profile/'summary.json',{'run_id':'fixture_baseline','seed':None,'profiling_plan_sha256':sha(plan_path),'model_manifest_sha256':'f'*64,
                                           'load_seconds':0,'index_seconds':.1,'vector_or_sparse_index_bytes':100,'setup_peak':{'allocated_GiB':0,'reserved_GiB':0},
                                           'timing_boundary':'synthetic fixture only'})
        write_json(profile/'warmup_timings.json',[{'warmup':i} for i in range(50)])
        (profile/'raw_timings.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in raw),encoding='utf-8')
        write_json(profile/'status.json',{'status':'completed'})
        manifest={path.name:{'bytes':path.stat().st_size,'sha256':sha(path)} for path in profile.iterdir()}
        lock={'fixture_only':True,'models':[{'run_id':'fixture_baseline','stage':'BASELINE','family':'bm25','policy':'BM25','seed':None,'checkpoint_manifest_sha256':'f'*64}],
              'evaluations':[{'evaluation_id':'fixture_eval','run_id':'fixture_baseline','dataset':'bfcl_live_multiple','queries_sha256':sha(qpath),'corpus_sha256':sha(cpath),'config_sha256':sha(out/'config.json'),'checkpoint_manifest_sha256':'f'*64}],
              'efficiency_plans':[{'dataset':'bfcl_live_multiple','plan_sha256':sha(plan_path)}]}
        lock_path=pub/'locks/final_lock.json';write_json(lock_path,lock)
        entry={**config,'evaluation_id':'fixture_eval','output_path':str(out),'config_path':str(out/'config.json'),'status':'completed','predictions_sha256':sha(out/'predictions.json'),'metrics_sha256':sha(out/'metrics.json')}
        write_json(pub/'final_evaluation_registry.json',{'lock_sha256':sha(lock_path),'evaluations':[entry],
                   'efficiency':[{'dataset':'bfcl_live_multiple','plan_path':str(plan_path),'plan_sha256':sha(plan_path),'models':[{'run_id':'fixture_baseline','status':'completed','output_path':str(profile),'evidence_manifest':manifest}]}]})
        actual=EfficiencyAnalyzer(root,Path(tmp)/'output',tokenizer_path).run()
        require(actual['status']=='AVAILABLE_EVIDENCE_ANALYZED' and actual['completed_accuracy_evaluations']==1 and actual['completed_profiles']==1,'Bound end-to-end efficiency fixture failed')
        import csv
        with (Path(tmp)/'output/recall_or_mrr_latency_pareto.csv').open(encoding='utf-8-sig',newline='') as stream:points=list(csv.DictReader(stream))
        require(len(points)==1 and points[0]['accuracy_metric']=='MRR' and float(points[0]['median_ms'])==3.5,'BFCL MRR/actual latency join failed')
    return {'passed':True,'checks':['raw_only_no_text_fallback','no_label_fields_external_raw','multi_positive_recall','all_k_token_sums','candidate_count_clipping','five_round_raw_latency','missing_timing_rejected','forged_summary_rejected','observed_pareto','no_final_pending','bound_end_to_end_tokenizer_profile_join','BFCL_MRR_latency_not_saturated_recall']}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input-root',type=Path);parser.add_argument('--output-dir',type=Path);parser.add_argument('--tokenizer-json',type=Path);parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:print(json.dumps(self_test(),indent=2));return
    require(args.input_root is not None and args.output_dir is not None,'--input-root and --output-dir required')
    result=EfficiencyAnalyzer(args.input_root,args.output_dir,args.tokenizer_json).run();print(json.dumps(result,ensure_ascii=False,indent=2))
    if result.get('failures'):raise SystemExit(2)


if __name__=='__main__':main()
