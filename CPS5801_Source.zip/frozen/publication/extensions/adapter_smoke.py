"""GPU encoder-adapter engineering checks on synthetic inputs only.

No training/dev/external query is read, no weights are updated. Explicitly tests
the family prefix, capped token budget, padding mask, independent pooling and
float32 behavior for the actual pinned local model assets.
"""
from __future__ import annotations

import argparse
import collections
import pathlib
import time
import traceback

from encoders import Encoder, directory_manifest, dump, ensure_output, now, read, setup_runtime, sha_file, sha_json, sync, torch

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
EXPECTED = {
    'e5': {'repo_id': 'intfloat/e5-small-v2', 'revision': 'ffb93f3bd4047442299a41ebb6fa998a38507c52',
           'dimension': 384, 'query_prefix': 'query: ', 'document_prefix': 'passage: '},
    'bge': {'repo_id': 'BAAI/bge-small-en-v1.5', 'revision': '5c38ec7c405ec4b44b94cc5a9bb96e735b38267a',
            'dimension': 384, 'query_prefix': 'Represent this sentence for searching relevant passages: ', 'document_prefix': ''},
    'qwen_reference': {'repo_id': 'Qwen/Qwen3-Embedding-0.6B', 'revision': '97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3',
             'dimension': 1024, 'query_prefix': 'Instruct: Given a user request, retrieve tools whose documented capabilities can satisfy the request.\nQuery:',
             'document_prefix': ''},
}
QUERY_TEXTS = ['Find the temperature.', 'Find a timetable for a fictional train between two invented stations.',
               'Synthetic calibration request for a fictional lookup service. ' * 220]
DOCUMENT_TEXTS = ['name: mock_temperature\ndescription: Returns a fictional temperature.\nparameters: city: string',
                  'name: mock_timetable\ndescription: Reads a fictional station timetable without contacting a real service.\nparameters: origin: string; destination: string',
                  'name: synthetic_calibration\ndescription: ' + 'Synthetic documentation for an invented tool; no real external operation. ' * 220 + '\nparameters: label: string']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def independent_pool(hidden, mask, family):
    """Per-row indexing is intentionally independent of the adapter's vectorized mask."""
    vectors, positions = [], []
    for row, row_mask in zip(hidden.float(), mask):
        valid = torch.nonzero(row_mask, as_tuple=False).flatten()
        require(len(valid) > 0, 'Empty synthetic input mask')
        positions.append(int(valid[-1]))
        if family == 'e5':
            vectors.append(row[valid].mean(dim=0))
        elif family == 'bge':
            vectors.append(row[0])
        else:
            vectors.append(row[valid[-1]])
    values = torch.stack(vectors)
    reference = values / torch.sqrt(torch.sum(values * values, dim=1, keepdim=True)).clamp_min(1e-12)
    return reference, positions


def local_model_paths(verified_manifest):
    verified = read(verified_manifest)
    result = {'e5': REPRO / 'data/raw/model'}
    identities = {'e5': {'source': 'copied archived original model; bundle and37-file snapshot verification held separately',
                         'revision': EXPECTED['e5']['revision']}}
    for family in ('bge', 'qwen_reference'):
        item = next(model for model in verified['models'] if model['repo_id'] == EXPECTED[family]['repo_id'])
        require(item['revision'] == EXPECTED[family]['revision'], f'Wrong revision for {family}')
        directory = pathlib.Path(item['local_dir']).resolve(strict=True)
        for entry in item['verified_files']:
            path = (directory / entry['path']).resolve(strict=True)
            require(directory in path.parents, 'Verified model path escaped asset root')
            require(path.stat().st_size == entry['bytes'] and sha_file(path) == entry['sha256'], f'Verified asset changed: {path}')
        result[family] = directory
        identities[family] = {'revision': item['revision'], 'verified_file_count': len(item['verified_files']),
                              'verified_models_manifest_sha256': sha_file(verified_manifest)}
    return result, identities


def test_family(family, model_path, output):
    torch.cuda.reset_peak_memory_stats()
    sync('cuda')
    began = time.perf_counter()
    encoder = Encoder(family, model_path, 'cuda')
    encoder.model.eval()
    sync('cuda')
    load_seconds = time.perf_counter() - began
    dtypes = collections.Counter(str(parameter.dtype) for parameter in encoder.model.parameters() if parameter.is_floating_point())
    require(set(dtypes) == {'torch.float32'}, f'Parameters are not float32: {family} {dtypes}')
    masks_to_test = ['left', 'right'] if family == 'qwen_reference' else ['right']
    checks, encoded_by_side = [], {}
    for padding_side in masks_to_test:
        encoder.tokenizer.padding_side = padding_side
        for kind, texts, cap in [('query', QUERY_TEXTS, 128), ('document', DOCUMENT_TEXTS, 384)]:
            expected_texts = [EXPECTED[family][kind + '_prefix'] + text for text in texts]
            require([encoder.format(text, kind) for text in texts] == expected_texts, f'Wrong {family} {kind} prefix')
            full_ids = encoder.tokenizer(expected_texts, truncation=False)['input_ids']
            tokens = encoder.tokenizer(expected_texts, truncation=True, padding=True, max_length=cap, return_tensors='pt')
            require(tokens['input_ids'].shape[1] == cap, 'Synthetic long input did not exercise the cap')
            mask = tokens['attention_mask']
            require(set(mask.flatten().tolist()) == {0, 1}, 'Synthetic batch must test real padding mask zeros and ones')
            lengths = mask.sum(1).tolist()
            require(lengths == [min(len(ids), cap) for ids in full_ids], 'Cap did not include special tokens/prefix')
            for index, text in enumerate(texts):
                direct = encoder.tokenize(text, kind)['input_ids']
                actual = tokens['input_ids'][index][mask[index].bool()].tolist()
                require(actual == direct, 'Adapter single-input tokenization differs from explicit prefixed batch')
            if padding_side == 'left':
                require(bool(torch.all(mask[:, -1] == 1)), 'Left padding must retain the last real token')
            else:
                require(bool(torch.all(mask[:, 0] == 1)), 'Right padding must retain the first real token')
            tokens_gpu = tokens.to('cuda')
            sync('cuda')
            inference_started = time.perf_counter()
            with torch.inference_mode():
                hidden = encoder.model(**tokens_gpu).last_hidden_state
                reference, positions = independent_pool(hidden, tokens_gpu['attention_mask'], family)
                actual = encoder.pool(tokens_gpu)
            sync('cuda')
            inference_seconds = time.perf_counter() - inference_started
            require(actual.shape == (len(texts), EXPECTED[family]['dimension']), 'Unexpected output dimension')
            require(actual.dtype == reference.dtype == torch.float32, 'Output is not float32')
            require(bool(torch.isfinite(actual).all()), 'Nonfinite embeddings')
            maximum_error = float(torch.max(torch.abs(actual - reference)))
            norm_error = float(torch.max(torch.abs(torch.linalg.vector_norm(actual, dim=1) - 1)))
            # Different equivalent float32 reduction orders can differ by ulps.
            # This tolerance is fixed for the independent formula fixture, not
            # used to accept changed ranking or cross-run training differences.
            require(maximum_error <= 2e-6, f'Independent pooling mismatch: {family}/{padding_side}/{kind} {maximum_error}')
            require(norm_error <= 1e-5, f'L2 normalization failed: {norm_error}')
            encoded_by_side[(padding_side, kind)] = actual.detach().cpu()
            record = {'family': family, 'kind': kind, 'padding_side': padding_side,
                      'full_token_lengths_including_prefix': list(map(len, full_ids)), 'capped_real_token_lengths': lengths,
                      'input_ids': tokens['input_ids'].cpu().tolist(), 'attention_mask': mask.cpu().tolist(),
                      'last_nonpadding_positions': positions, 'output_shape': list(actual.shape), 'output_dtype': str(actual.dtype),
                      'independent_pooling_max_abs_error': maximum_error, 'normalization_max_abs_error': norm_error,
                      'reference_abs_tolerance': 2e-6, 'norm_abs_tolerance': 1e-5,
                      'inference_seconds_two_forward_passes': inference_seconds,
                      'output_vectors': actual.cpu().tolist()}
            checks.append(record)
    padding_comparison = {}
    if family == 'qwen_reference':
        for kind in ('query', 'document'):
            left, right = encoded_by_side[('left', kind)], encoded_by_side[('right', kind)]
            padding_comparison[kind] = {'max_abs_difference': float(torch.max(torch.abs(left - right))),
                                        'paired_cosines': (left * right).sum(1).tolist(),
                                        'scope': 'Engineering description only; production stays left-padded, each padding formula independently passed'}
    report = {'family': family, 'passed': True, 'model_path': str(model_path), 'expected': EXPECTED[family],
              'parameter_dtypes': dict(dtypes), 'parameter_count': sum(parameter.numel() for parameter in encoder.model.parameters()),
              'model_load_seconds': load_seconds, 'total_seconds': time.perf_counter() - began,
              'peak_allocated_GiB': torch.cuda.max_memory_allocated() / 2**30,
              'peak_reserved_GiB': torch.cuda.max_memory_reserved() / 2**30,
              'asset_manifest': directory_manifest(model_path), 'checks': checks,
              'qwen_padding_comparison': padding_comparison}
    dump(output, report)
    del encoder
    torch.cuda.empty_cache()
    return {key: report[key] for key in ('family', 'passed', 'model_load_seconds', 'total_seconds', 'peak_allocated_GiB', 'peak_reserved_GiB')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verified-models', type=pathlib.Path, default=ROOT / 'models/verified_models.json')
    parser.add_argument('--output', required=True, type=pathlib.Path)
    args = parser.parse_args()
    out = ensure_output(args.output)
    require(not out.exists(), 'Choose a new engineering smoke-test attempt')
    out.mkdir(parents=True)
    dump(out / 'status.json', {'status': 'running', 'started_at': now(), 'synthetic_only': True})
    try:
        setup_runtime('cuda')
        paths, identities = local_model_paths(args.verified_models)
        reports = []
        for family in ('e5', 'bge', 'qwen_reference'):
            print('ADAPTER_SMOKE_STARTED', family, flush=True)
            reports.append(test_family(family, paths[family], out / f'{family}_checks.json'))
            print('ADAPTER_SMOKE_COMPLETED', family, flush=True)
        report = {'passed': True, 'completed_at': now(), 'engineering_fixture_only': True,
                  'data_access': 'hardcoded synthetic query/document strings only; no external or development records read',
                  'identities': identities, 'families': reports, 'code_sha256': sha_file(__file__),
                  'adapter_sha256': sha_file(pathlib.Path(__file__).with_name('encoders.py')),
                  'query_fixture_sha256': sha_json(QUERY_TEXTS), 'document_fixture_sha256': sha_json(DOCUMENT_TEXTS)}
        dump(out / 'adapter_smoke_report.json', report)
        dump(out / 'status.json', {'status': 'completed', 'completed_at': now(), 'passed': True})
    except Exception as error:
        dump(out / 'status.json', {'status': 'failed', 'failed_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise


if __name__ == '__main__':
    main()
