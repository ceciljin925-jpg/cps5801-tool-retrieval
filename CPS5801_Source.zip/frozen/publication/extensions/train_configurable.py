"""Explicit-negative training. See CONFIG_SCHEMA below; no final-data evaluation.

All paths in a configuration are absolute or relative to the launching directory.
Milestone weights are retained; latest_resume.pt is atomically replaced by design.
Evaluation runs in a separate process, avoiding checkpoint-time dropout changes.
"""
from __future__ import annotations

import argparse
import math
import pathlib
import time
import traceback

from encoders import (Encoder, FAMILIES, directory_manifest, dump, ensure_output, get_rng,
                      now, preserve_rng_and_mode, read, runtime_record, seed_all,
                      set_rng, setup_runtime, sha_file, sha_json, sync, np, torch)

CONFIG_SCHEMA = {
    'required': ['run_id', 'stage', 'family', 'policy', 'seed', 'model_path', 'train_path', 'corpus_path',
                 'schedule_path', 'negatives_path', 'lr', 'temperature', 'steps'],
    'optional': {'checkpoint_steps': 'default [steps]; subset of 312,625,1250', 'microbatch': 8, 'accumulation': 4,
                 'resume_every': 100, 'train_tool_ids_path': 'training-side tools only',
                 'forbidden_path': 'query_id -> [forbidden IDs]', 'input_hashes': 'absolute path -> SHA256',
                 'fixture': 'true ONLY for explicitly labelled engineering fixture', 'device': 'cuda'},
    'fixed': {'optimizer': 'AdamW', 'betas': [0.9, 0.999], 'eps': 1e-8, 'weight_decay': 0.01,
              'clip_grad_norm': 1.0, 'effective_batch': 32, 'negative_per_query': 4,
              'precision': 'bfloat16_autocast', 'query_tokens': 128, 'tool_tokens': 384,
              'schedule': 'constant_lr_no_warmup', 'midtraining_evaluation': 'separate_process_only'},
}


def validate_config(config):
    for key in CONFIG_SCHEMA['required']:
        if key not in config:
            raise ValueError(f'Missing config field: {key}')
    if config['family'] not in ('e5', 'bge'):
        raise ValueError('Only E5 and BGE are trainable')
    if not config.get('fixture') and config['stage'] not in ('S1', 'S2', 'S3', 'S4', 'S5'):
        raise ValueError('S0 must use frozen original engine')
    microbatch = config.get('microbatch', 8)
    accumulation = config.get('accumulation', 4)
    if not isinstance(microbatch, int) or microbatch < 1 or microbatch * accumulation != 32:
        raise ValueError('Effective batch must be exactly 32')
    if config['stage'] == 'S1' and (microbatch, accumulation) != (8, 4):
        raise ValueError('S1 requires original microbatch 8, accumulation 4')
    if config['lr'] not in (1e-5, 2e-5) or config['temperature'] not in (0.01, 0.05):
        raise ValueError('Learning rate/temperature outside authorized matrix')
    if not config.get('fixture') and config['steps'] not in (312, 625, 1250):
        raise ValueError('Step count outside authorized matrix')
    if config['steps'] < 1:
        raise ValueError('steps must be positive')
    if not isinstance(config.get('resume_every', 100), int) or config.get('resume_every', 100) < 1:
        raise ValueError('resume_every must be a positive integer')
    if not config.get('fixture'):
        stage = config['stage']
        expected_family = 'bge' if stage in ('S4', 'S5') else 'e5'
        if config['family'] != expected_family:
            raise ValueError('Encoder family does not match stage')
        if stage == 'S1' and (config['seed'] not in (42, 43, 44) or config['steps'] != 625
                             or config['lr'] != 2e-5 or config['temperature'] != 0.05):
            raise ValueError('S1 must preserve original fixed recipe and three seeds')
        if stage in ('S2', 'S4') and (config['seed'] != 41 or config['steps'] != 1250):
            raise ValueError('Screening requires seed41 and 1250 updates')
        if stage in ('S3', 'S5') and config['seed'] not in (42, 43, 44, 45, 46):
            raise ValueError('Confirmation seed outside frozen five-seed set')
    checkpoints = sorted(set(config.get('checkpoint_steps', [config['steps']]) + [config['steps']]))
    if any(step < 1 or step > config['steps'] for step in checkpoints):
        raise ValueError('Invalid checkpoint step')
    if not config.get('fixture') and any(step not in (312, 625, 1250) for step in checkpoints):
        raise ValueError('Unauthorized checkpoint')
    if not config.get('fixture') and config['stage'] in ('S2', 'S4') and checkpoints != [312, 625, 1250]:
        raise ValueError('Screening must retain every predefined development checkpoint')
    for path, expected in config.get('input_hashes', {}).items():
        if sha_file(path) != expected:
            raise ValueError(f'Input identity changed: {path}')
    return microbatch, accumulation, checkpoints


def prepare_inputs(config, encoder):
    train, corpus = read(config['train_path']), read(config['corpus_path'])
    schedule = read(config['schedule_path'])[:config['steps'] * 32]
    negative_data = read(config['negatives_path'])
    if len(schedule) != config['steps'] * 32:
        raise ValueError('Schedule is shorter than requested number of full effective batches')
    gs = {g['id']: g for g in train}
    docs = {d['id']: d['text'] for d in corpus}
    if len(gs) != len(train) or len(docs) != len(corpus):
        raise ValueError('Duplicate query or corpus IDs')
    if not config.get('fixture') and len(train) != 10000:
        raise ValueError('Authorized training query count is 10,000')
    negatives = {}
    policy = config['policy']
    for qid, value in negative_data.items():
        ids = value[policy] if isinstance(value, dict) else value
        if len(ids) != 4 or len(set(ids)) != 4:
            raise ValueError(f'Expected four unique negative IDs for {qid}')
        negatives[qid] = ids
    allowed = set(read(config['train_tool_ids_path'])) if config.get('train_tool_ids_path') else None
    forbidden = read(config['forbidden_path']) if config.get('forbidden_path') else {}
    used = set()
    for row in schedule:
        for key in ('query_id', 'positive', 'epoch'):
            if key not in row:
                raise ValueError(f'Missing schedule field {key}')
        qid, positive = row['query_id'], row['positive']
        if qid not in gs or qid not in negatives:
            raise ValueError(f'Unmapped training query {qid}')
        if positive not in gs[qid]['positives']:
            raise ValueError(f'Scheduled positive is not known positive: {qid}')
        neg = negatives[qid]
        if set(neg) & (set(gs[qid]['positives']) | set(forbidden.get(qid, []))):
            raise ValueError(f'Forbidden negative for {qid}')
        if allowed is not None and not set(neg + [positive]) <= allowed:
            raise ValueError(f'Nontraining tool used by {qid}')
        used.update(neg + [positive])
    if not used <= docs.keys():
        raise ValueError('Tool mapping missing')
    qtokens = {g['id']: encoder.tokenize(g['query'], 'query') for g in train}
    dtokens = {tid: encoder.tokenize(docs[tid], 'document') for tid in sorted(used)}
    return train, corpus, schedule, negatives, qtokens, dtokens


def optimizer_for(model, config):
    return torch.optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=0.01,
                            betas=(0.9, 0.999), eps=1e-8)


def train_update(encoder, optimizer, batch, negatives, qtokens, dtokens, microbatch, temperature):
    """Exactly preserves original ordering, loss weighting, bf16 boundary and AdamW."""
    model, tok, device = encoder.model, encoder.tokenizer, encoder.device
    optimizer.zero_grad(set_to_none=True)
    weighted = 0
    for a in range(0, len(batch), microbatch):
        mb = batch[a:a + microbatch]
        qs = tok.pad([qtokens[s['query_id']] for s in mb], padding=True, return_tensors='pt').to(device)
        ids = [tid for s in mb for tid in [s['positive']] + negatives[s['query_id']]]
        ds = tok.pad([dtokens[tid] for tid in ids], padding=True, return_tensors='pt').to(device)
        with torch.autocast('cuda', dtype=torch.bfloat16):
            q = encoder.pool(qs)
            d = encoder.pool(ds).view(len(mb), 5, -1)
            logits = (q[:, None, :] * d).sum(-1) / temperature
            loss = torch.nn.functional.cross_entropy(logits, torch.zeros(len(mb), dtype=torch.long, device=device))
        if not torch.isfinite(loss):
            raise RuntimeError('Nonfinite loss')
        (loss * len(mb) / len(batch)).backward()
        weighted += loss.item() * len(mb) / len(batch)
    grad = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0))
    if not math.isfinite(grad):
        raise RuntimeError('Nonfinite gradient norm')
    optimizer.step()
    return weighted, grad


def source_manifest():
    root = pathlib.Path(__file__).resolve().parent
    return {name: sha_file(root / name) for name in ('encoders.py', 'train_configurable.py')}


def scientific_identity(config, schedule, negatives):
    inputs = {key: sha_file(config[key]) for key in ('train_path', 'corpus_path', 'schedule_path', 'negatives_path')}
    for key in ('forbidden_path', 'train_tool_ids_path'):
        if config.get(key):
            inputs[key] = sha_file(config[key])
    return {'family': config['family'], 'adapter': FAMILIES[config['family']], 'model_files': directory_manifest(config['model_path']),
            'input_files': inputs, 'actual_schedule_prefix_sha256': sha_json(schedule),
            'actual_negatives_sha256': sha_json(negatives), 'seed': config['seed'], 'lr': config['lr'],
            'temperature': config['temperature'], 'steps': config['steps'],
            'microbatch': config.get('microbatch', 8), 'accumulation': config.get('accumulation', 4),
            'fixed_config': CONFIG_SCHEMA['fixed'], 'code': source_manifest(),
            'runtime': {k: v for k, v in runtime_record().items() if k not in ('created_at', 'executable')},
            'checkpoint_rng': 'save_restore_all_RNG_and_mode; evaluation_in_separate_process'}


def write_resume(path, encoder, optimizer, step, elapsed, identity, initial_embedding):
    with preserve_rng_and_mode(encoder.model):
        state = {'model': encoder.model.state_dict(), 'optimizer': optimizer.state_dict(), 'step': step, 'cursor': step * 32,
                 'rng': get_rng(), 'elapsed_training_seconds': elapsed, 'identity_sha256': sha_json(identity),
                 'model_training': encoder.model.training, 'initial_embedding': initial_embedding.cpu()}
        temporary = path.with_name(path.name + '.tmp')
        torch.save(state, temporary)
        temporary.replace(path)


def train(config, output, resume=False, after_update=None):
    microbatch, accumulation, milestones = validate_config(config)
    device = config.get('device', 'cuda')
    if not device.startswith('cuda'):
        raise ValueError('Authorized training requires CUDA bf16')
    setup_runtime(device)
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError('Device does not support bf16')
    out = ensure_output(output)
    if out.exists() and any(out.iterdir()) and not resume:
        raise FileExistsError('Nonempty attempt directory; preserve it and choose a new attempt or explicit --resume')
    out.mkdir(parents=True, exist_ok=True)
    seed_all(config['seed'])
    encoder = Encoder(config['family'], config['model_path'], device)
    model = encoder.model
    model.train()
    optimizer = optimizer_for(model, config)
    initial_embedding = model.get_input_embeddings().weight.detach().clone()
    train_rows, corpus, schedule, negatives, qtokens, dtokens = prepare_inputs(config, encoder)
    identity = scientific_identity(config, schedule, negatives)
    losses, start_step, prior_elapsed = [], 0, 0
    if resume:
        state = torch.load(out / 'latest_resume.pt', map_location=device, weights_only=False)
        if state['identity_sha256'] != sha_json(identity):
            raise ValueError('Resume identity mismatch; code/assets/config/environment changed')
        losses = [__import__('json').loads(line) for line in (out / 'loss.jsonl').read_text().splitlines()]
        if len(losses) < state['step']:
            raise ValueError('Loss log is shorter than committed recovery state; cannot reconstruct missing evidence')
        if len(losses) > state['step']:
            # Keep all evidence before rolling the active log back to the last
            # committed model/optimizer/RNG cursor. Uncommitted updates are replayed.
            backup = out / 'interrupted_tails' / now().replace(':', '').replace('+', '_')
            backup.mkdir(parents=True, exist_ok=False)
            original_log = out / 'loss.jsonl'
            raw_lines = original_log.read_bytes().splitlines(keepends=True)
            (backup / 'complete_pre_resume_loss.jsonl').write_bytes(original_log.read_bytes())
            (backup / 'uncommitted_loss_tail.jsonl').write_bytes(b''.join(raw_lines[state['step']:]))
            dump(backup / 'recovery.json', {'created_at': now(), 'recovery_step': state['step'],
                 'uncommitted_updates': len(losses) - state['step'], 'action': 'preserve original log and tail; replay from committed optimizer/RNG state',
                 'original_log_sha256': sha_file(original_log), 'recovery_state_sha256': sha_file(out / 'latest_resume.pt')})
            temporary = original_log.with_name('loss.jsonl.rollback.tmp')
            temporary.write_bytes(b''.join(raw_lines[:state['step']]))
            temporary.replace(original_log)
            losses = losses[:state['step']]
            future_checkpoints = []
            for checkpoint in (out / 'checkpoints').glob('step_*'):
                checkpoint_step = int(checkpoint.name.split('_')[-1])
                if checkpoint_step > state['step']:
                    # A crash between milestone save and recovery-state commit
                    # leaves a future checkpoint. Move it intact into the evidence
                    # backup so replay cannot silently overwrite that attempt.
                    if out.resolve() not in checkpoint.resolve().parents:
                        raise ValueError('Checkpoint path escaped attempt directory')
                    target = backup / checkpoint.name
                    checkpoint.rename(target)
                    future_checkpoints.append({'step': checkpoint_step, 'preserved_path': str(target), 'files': directory_manifest(target)})
            dump(backup / 'preserved_future_checkpoints.json', future_checkpoints)
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        start_step, prior_elapsed = state['step'], state['elapsed_training_seconds']
        initial_embedding = state['initial_embedding'].to(device)
        model.train(state['model_training'])
        # torch.load(map_location=cuda) also moves CPU RNG byte tensors; restore those to CPU.
        state['rng']['torch_cpu'] = state['rng']['torch_cpu'].cpu()
        state['rng']['torch_cuda'] = [x.cpu() for x in state['rng']['torch_cuda']]
        set_rng(state['rng'])
    else:
        dump(out / 'config.json', config)
        dump(out / 'identity.json', identity)
        dump(out / 'environment.json', runtime_record())
    dump(out / 'status.json', {'status': 'running', 'started_at': now(), 'resumed_at_step': start_step,
                              'storage_policy': 'retain milestone weights; atomically replace latest full recovery state'})
    torch.cuda.reset_peak_memory_stats()
    sync(device)
    start = time.perf_counter()
    try:
        for step in range(start_step + 1, config['steps'] + 1):
            batch = schedule[(step - 1) * 32:step * 32]
            weighted, grad = train_update(encoder, optimizer, batch, negatives, qtokens, dtokens, microbatch, config['temperature'])
            row = {'step': step, 'epoch': batch[0]['epoch'] + 1, 'loss': weighted, 'grad_norm': grad,
                   'elapsed_seconds': prior_elapsed + time.perf_counter() - start}
            losses.append(row)
            with (out / 'loss.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(__import__('json').dumps(row, allow_nan=False) + '\n')
                stream.flush()
            if after_update is not None:
                after_update(step, encoder, optimizer, row)
            if step % 16 == 0 or step == config['steps']:
                print(config['run_id'], row, flush=True)
            if step in milestones:
                checkpoint = out / 'checkpoints' / f'step_{step:04d}'
                with preserve_rng_and_mode(model):
                    model.save_pretrained(checkpoint)
                    encoder.tokenizer.save_pretrained(checkpoint)
                    dump(checkpoint / 'checkpoint_provenance.json', {'run_id': config['run_id'], 'step': step, 'exposures': step * 32,
                         'identity_sha256': sha_json(identity), 'created_at': now()})
            if step in milestones or step % config.get('resume_every', 100) == 0:
                write_resume(out / 'latest_resume.pt', encoder, optimizer, step,
                             prior_elapsed + time.perf_counter() - start, identity, initial_embedding)
        sync(device)
        elapsed = prior_elapsed + time.perf_counter() - start
        stats = {'run_id': config['run_id'], 'family': config['family'], 'policy': config['policy'], 'seed': config['seed'],
                 'steps': len(losses), 'exposures': len(schedule), 'train_queries': len(train_rows),
                 'train_seconds_including_checkpoint_io': elapsed, 'seconds_per_step': elapsed / len(losses),
                 'peak_allocated_GiB': torch.cuda.max_memory_allocated() / 2**30,
                 'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
                 'embedding_weight_change_l2': float((model.get_input_embeddings().weight.detach() - initial_embedding).norm()),
                 'first_loss': losses[0]['loss'], 'last_loss': losses[-1]['loss'], 'mean_loss': float(np.mean([x['loss'] for x in losses])),
                 'checkpoint_steps': milestones, 'identity_sha256': sha_json(identity), 'completed_at': now()}
        if stats['embedding_weight_change_l2'] <= 0:
            raise RuntimeError('Model parameters did not change')
        dump(out / 'training.json', stats)
        dump(out / 'checkpoint_manifest.json', {f'step_{step:04d}': directory_manifest(out / 'checkpoints' / f'step_{step:04d}') for step in milestones})
        dump(out / 'status.json', {'status': 'completed', 'completed_at': now(), 'actual_steps': len(losses), 'exposures': len(schedule)})
        return stats
    except Exception as error:
        dump(out / 'status.json', {'status': 'failed', 'failed_at': now(), 'actual_steps': len(losses),
                                  'error': repr(error), 'traceback': traceback.format_exc()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=pathlib.Path)
    parser.add_argument('--output', type=pathlib.Path)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--schema', action='store_true')
    args = parser.parse_args()
    if args.schema:
        print(__import__('json').dumps(CONFIG_SCHEMA, indent=2))
        return
    if args.config is None or args.output is None:
        parser.error('--config and --output are required')
    existed_before = args.output.exists()
    try:
        train(read(args.config), args.output, args.resume)
    except Exception as error:
        # Include initialization/tokenization/identity failures in attempt evidence.
        output = ensure_output(args.output)
        output.mkdir(parents=True, exist_ok=True)
        status_path = output / 'status.json'
        existing = read(status_path) if status_path.exists() else {}
        if existing.get('status') != 'completed' and (not existed_before or args.resume):
            dump(status_path, {**existing, 'status': 'failed', 'failed_at': now(),
                               'error': repr(error), 'traceback': traceback.format_exc()})
        raise


if __name__ == '__main__':
    main()
