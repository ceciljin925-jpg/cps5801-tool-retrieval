"""Read-only Windows power-throttling metadata for this workspace's GPU Python."""
import argparse
import csv
import ctypes
from ctypes import wintypes
import io
import os
import pathlib
import subprocess

from execute_logged import dump, now

ROOT = pathlib.Path(__file__).resolve().parents[1]


class PowerState(ctypes.Structure):
    _fields_ = [('Version', wintypes.ULONG), ('ControlMask', wintypes.ULONG), ('StateMask', wintypes.ULONG)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Keep prior snapshots')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.GetProcessInformation.restype = wintypes.BOOL
    kernel.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel.QueryFullProcessImageNameW.restype = wintypes.BOOL
    kernel.GetPriorityClass.argtypes = [wintypes.HANDLE]
    kernel.GetPriorityClass.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    query = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader'],
                           capture_output=True, text=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    expected_root = (ROOT.parent / 'python').resolve()
    observations = []
    for fields in csv.reader(io.StringIO(query.stdout)):
        if len(fields) != 2 or not fields[1].strip().lower().endswith('python.exe'):
            continue
        pid = int(fields[0].strip())
        handle = kernel.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION only
        if not handle:
            continue
        try:
            image = ctypes.create_unicode_buffer(32768)
            size = wintypes.DWORD(len(image))
            if not kernel.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(size)):
                continue
            resolved = pathlib.Path(image.value).resolve()
            if expected_root not in resolved.parents:
                continue
            state = PowerState(1, 0, 0)
            ok = kernel.GetProcessInformation(handle, 4, ctypes.byref(state), ctypes.sizeof(state))
            observations.append({'pid': pid, 'workspace_python_identity_verified': True,
                'query_success': bool(ok), 'error': None if ok else ctypes.get_last_error(),
                'Version': state.Version, 'ControlMask': state.ControlMask, 'StateMask': state.StateMask,
                'execution_speed_state_bit': bool(state.StateMask & 1) if ok else None,
                'priority_class': kernel.GetPriorityClass(handle)})
        finally:
            kernel.CloseHandle(handle)
    dump(args.output, {'captured_at': now(), 'read_only': True, 'processes': observations,
        'sources': ['https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocessinformation',
                    'https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-process_power_throttling_state',
                    'https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ne-processthreadsapi-process_information_class'],
        'limits': 'Raw process policy fields only; not a complete observation of OS scheduling, CPU frequency, GPU contention or the cause of throughput changes. No settings modified.'})
    print(observations)


if __name__ == '__main__':
    main()
