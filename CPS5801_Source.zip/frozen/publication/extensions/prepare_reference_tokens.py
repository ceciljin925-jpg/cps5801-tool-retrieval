"""Prepare full-corpus, score-free pinned-E5 raw-document token caches.

Reads only frozen corpus metadata and tokenizer assets, never predictions.
No special tokens, truncation, prefixes or fallback to serialized retrieval text.
"""
import argparse
import json
from pathlib import Path
import statistics

from analyze_efficiency import raw_documents
from rebuild_all import Resolver, read_json, require, sha, write_json

SERIALIZATION = "json.dumps(raw,sort_keys=True,ensure_ascii=False), default separators; no special tokens; no truncation; no prefix"


def first_existing(candidates, label):
    result = next((path for path in candidates if path.exists()), None)
    require(result is not None, f"Missing {label}")
    return result.resolve()


def prepare(input_root, output_dir, tokenizer_json=None):
    resolver=Resolver(input_root);root=resolver.publication;output=Path(output_dir).resolve()
    require(not output.exists() or not any(output.iterdir()),"Use fresh reference token-cache directory")
    tokenizer_path=resolver.resolve(tokenizer_json) if tokenizer_json else first_existing([
        resolver.root/'original_reference/data/raw/model/tokenizer.json',resolver.root/'reproduction/data/raw/model/tokenizer.json',
        root.parent/'repro/data/raw/model/tokenizer.json',root.parent/'reproduction/data/raw/model/tokenizer.json'],'pinned E5 tokenizer.json')
    legacy=first_existing([resolver.root/'original_reference/data/main_20261025/test_corpus.json',
                           resolver.root/'reproduction/data/main_20261025/test_corpus.json',root.parent/'repro/data/main_20261025/test_corpus.json',
                           root.parent/'reproduction/data/main_20261025/test_corpus.json'],'legacy frozen test corpus')
    from tokenizers import Tokenizer
    tokenizer=Tokenizer.from_file(str(tokenizer_path));tokenizer.no_padding();tokenizer.no_truncation()
    tokenizer_hash=sha(tokenizer_path)
    sources={'legacy_observed_test':legacy,**{name:root/'data/external'/name/'corpus.json' for name in ['bfcl_live_multiple','bfcl_multiple','bfcl_parallel_multiple','toolhop']}}
    manifest={'schema_version':'reference_document_token_cache_v1','score_accessed':False,'model_inference_performed':False,
              'tokenizer':{'path':resolver.display(tokenizer_path),'sha256':tokenizer_hash,'bytes':tokenizer_path.stat().st_size},
              'serialization':SERIALIZATION,'reference_model':'intfloat/e5-small-v2','reference_revision':'ffb93f3bd4047442299a41ebb6fa998a38507c52',
              'script_sha256':sha(__file__),'datasets':{}}
    for dataset,path in sources.items():
        corpus=read_json(path);ids,texts=raw_documents(corpus,dataset);lengths=[]
        for offset in range(0,len(texts),256):
            lengths.extend(len(encoding.ids) for encoding in tokenizer.encode_batch(texts[offset:offset+256],add_special_tokens=False))
        require(len(ids)==len(lengths)==len(corpus),'Token cache coverage mismatch')
        require(all(isinstance(value,int) and value>=0 for value in lengths),'Invalid token count')
        record={'schema_version':'reference_document_token_cache_v1','dataset':dataset,'corpus_sha256':sha(path),
                'tokenizer_sha256':tokenizer_hash,'serialization':SERIALIZATION,'add_special_tokens':False,'truncation':False,
                'document_count':len(corpus),'lengths':dict(zip(ids,lengths)),'score_accessed':False,'script_sha256':sha(__file__)}
        cache_path=output/dataset/'token_lengths.json';write_json(cache_path,record)
        manifest['datasets'][dataset]={'source_corpus':resolver.display(path),'source_bytes':path.stat().st_size,'corpus_sha256':record['corpus_sha256'],
                                      'document_count':len(corpus),'raw_metadata_count':len(corpus),'min_tokens':min(lengths),'max_tokens':max(lengths),
                                      'mean_tokens':statistics.mean(lengths),'sum_tokens':sum(lengths),
                                      'cache_path':str(cache_path.relative_to(output)).replace('\\','/'),'cache_sha256':sha(cache_path),'cache_bytes':cache_path.stat().st_size}
        print(json.dumps({'dataset':dataset,'documents':len(corpus),'max_tokens':max(lengths),'mean_tokens':statistics.mean(lengths)},ensure_ascii=False),flush=True)
    write_json(output/'manifest.json',manifest)
    return {'status':'COMPLETE_STRUCTURAL_TOKEN_CACHE','datasets':len(sources),'documents':sum(x['document_count'] for x in manifest['datasets'].values()),
            'manifest_sha256':sha(output/'manifest.json'),'no_model_scores_read':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input-root',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--tokenizer-json',type=Path);args=parser.parse_args()
    print(json.dumps(prepare(args.input_root,args.output_dir,args.tokenizer_json),indent=2))


if __name__=='__main__':main()
