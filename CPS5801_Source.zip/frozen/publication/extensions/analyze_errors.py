"""Frozen descriptive query/lexical/error sampling analyses from saved rankings.

No test labels change. Original and reproduction results remain separate, and
the original-fixed 60-case sample is reused for reproduction comparisons.
Semantic reviewer fields remain empty until actual documented review is added.
"""
from __future__ import annotations
import argparse
import collections
import datetime as dt
import gzip
import html
import json
import math
from pathlib import Path
import random
import re
import statistics
import sys
import unicodedata

from compare_reproduction import RUNS, METRICS, GROUPS, read, sha, write, write_csv, validate_predictions


def normalize_query(text):
    # Exact original common.py normalization, distinct from external collision
    # screening's whitespace-preserving normalization.
    return " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", text).casefold()))


def lexical_tokens(text):
    return frozenset(re.findall(r"[a-z0-9]+", unicodedata.normalize("NFKC", text).casefold()))


def similarity(a, b):
    union = a | b
    return len(a & b) / len(union) if union else None


def similarity_stratum(value, status="available"):
    if status != "available":
        return status
    if value is None:
        return "missing"
    if value == 1:
        return "exact_1"
    for upper, label in ((0.1, "[0,0.1)"), (0.3, "[0.1,0.3)"), (0.6, "[0.3,0.6)"), (1, "[0.6,1)")):
        if value < upper:
            return label
    raise ValueError("Jaccard out of range")


def largest_remainder(counts, n):
    total = sum(counts.values())
    if n > total or n < 0:
        raise ValueError("Impossible sample quota")
    if total == 0:
        return {k: 0 for k in counts}
    raw = {k: n * count / total for k, count in counts.items()}
    quotas = {k: int(math.floor(value)) for k, value in raw.items()}
    for key in sorted(counts, key=lambda k: (-(raw[k] - quotas[k]), k))[:n - sum(quotas.values())]:
        quotas[key] += 1
    assert sum(quotas.values()) == n and all(quotas[k] <= counts[k] for k in counts)
    return quotas


def fixtures():
    assert normalize_query("Hello, ＷＯＲＬＤ!") == "hello world"
    assert lexical_tokens("Café FOO-123") == {"caf", "foo", "123"}
    assert similarity({"a", "b"}, {"b", "c"}) == 1 / 3
    assert similarity(set(), set()) is None
    assert largest_remainder({"a": 1, "b": 1, "c": 1}, 2) == {"a": 1, "b": 1, "c": 0}
    assert [similarity_stratum(x) for x in [0, .1, .3, .6, 1]] == ["[0,0.1)", "[0.1,0.3)", "[0.3,0.6)", "[0.6,1)", "exact_1"]
    return {"status": "PASS", "checks": "normalization, tokenization, Jaccard, bin boundaries, largest-remainder tie rule"}


def case_sample(labels, metrics):
    by_id = {r["id"]: r for r in labels}
    normalized = collections.defaultdict(list)
    for row in labels:
        normalized[normalize_query(row["query"])].append(row["id"])
    representatives = {min(ids): sorted(ids) for ids in normalized.values()}
    population = collections.defaultdict(lambda: collections.defaultdict(list))
    group_by_id = {}
    for rid in sorted(representatives):
        random_mean = statistics.mean(metrics[r][rid]["recall@5"] for r in RUNS[2::2])
        hard_mean = statistics.mean(metrics[r][rid]["recall@5"] for r in RUNS[3::2])
        delta = hard_mean - random_mean
        group = "hard_wins" if delta > 1e-12 else ("hard_losses" if delta < -1e-12 else "ties")
        if group == "ties" and random_mean >= 1 and hard_mean >= 1:
            continue
        group_by_id[rid] = {"group": group, "random_mean_recall5": random_mean, "hard_mean_recall5": hard_mean, "hard_minus_random": delta}
        population[group][by_id[rid]["category"]].append(rid)
    rng = random.Random(20261111)
    samples, design = [], []
    target = {group: min(20, sum(map(len, population[group].values()))) for group in ("hard_wins", "hard_losses", "ties")}
    remaining = 60 - sum(target.values())
    if remaining:
        capacities = {group: sum(map(len, population[group].values())) - target[group] for group in target}
        supplements = largest_remainder(capacities, min(remaining, sum(capacities.values())))
        target = {group: target[group] + supplements[group] for group in target}
    for group in ("hard_wins", "hard_losses", "ties"):
        counts = {category: len(ids) for category, ids in population[group].items()}
        quotas = largest_remainder(counts, target[group])
        for category in sorted(quotas):
            ids = sorted(population[group][category])
            selected = sorted(rng.sample(ids, quotas[category]))
            design.append({"group": group, "category": category, "population_size": len(ids), "sample_n": len(selected),
                           "inclusion_probability": len(selected) / len(ids) if ids else None, "population_ids": ids, "selected_ids": selected})
            samples.extend({"id": rid, "category": category, **group_by_id[rid], "inclusion_probability": len(selected) / len(ids),
                            "normalized_query_member_ids": representatives[rid]} for rid in selected)
    return {"seed": 20261111, "selection_uses": "original three-seed hard-minus-random per-query Recall@5 only",
            "status": "SAMPLE_FROZEN_BEFORE_SEMANTIC_REVIEW", "sample_n": len(samples), "samples": samples, "design": design,
            "normalized_query_representatives": representatives, "not_a_population_error_rate_sample": True,
            "deduplication": "global normalized-query group representative is lexicographically smallest ID; only qualitative sample is deduplicated"}


def uncertainty(labels, metric_maps, np):
    differences = np.asarray([[metric_maps[hard][q["id"]]["recall@5"] - metric_maps[rand][q["id"]]["recall@5"] for q in labels]
                              for rand, hard in zip(RUNS[2::2], RUNS[3::2])], dtype=np.float64)
    delta = differences.mean(axis=0)
    rng = np.random.default_rng(50042)
    boot = np.asarray([delta[rng.integers(0, len(delta), len(delta))].mean() for _ in range(5000)])
    groups = collections.defaultdict(list)
    for i, row in enumerate(labels):
        groups[normalize_query(row["query"])].append(i)
    sums = np.asarray([delta[ix].sum() for ix in groups.values()])
    sizes = np.asarray([len(ix) for ix in groups.values()])
    rng = np.random.default_rng(50043)
    cluster_boot = []
    for _ in range(5000):
        ix = rng.integers(0, len(groups), len(groups))
        cluster_boot.append(float(sums[ix].sum() / sizes[ix].sum()))
    return {"metric": "hard_minus_random_macro_recall@5", "seed_effects": {str(seed): float(differences[i].mean()) for i, seed in enumerate((42, 43, 44))},
            "mean_effect": float(delta.mean()), "sample_sd_seed_effect": float(differences.mean(axis=1).std(ddof=1)),
            "query_bootstrap_95": np.quantile(boot, [.025, .975]).tolist(),
            "normalized_query_cluster_bootstrap_95": np.quantile(cluster_boot, [.025, .975]).tolist(),
            "normalized_query_groups": len(groups), "bootstrap_replicates": 5000, "query_seed": 50042, "cluster_seed": 50043,
            "point_estimate": "query weighted; block resampling weights each sampled block by its original query count",
            "scope": "conditional on the three fitted seed pairs; query/cluster sampling uncertainty is not independent training-seed uncertainty"}


def summarize_strata(strata_rows, metric_maps):
    groups = collections.defaultdict(list)
    fields = ("category", "track", "positive_count_stratum", "query_length_stratum", "query_truncated_at128", "reference_similarity_stratum")
    for row in strata_rows:
        groups[("all", "all")].append(row["id"])
        for field in fields:
            groups[(field, str(row[field]))].append(row["id"])
    per_run, per_policy, paired = [], [], []
    for (dimension, label), ids in sorted(groups.items()):
        run_metrics = {}
        for run in RUNS:
            run_metrics[run] = {metric: statistics.mean(metric_maps[run][rid][metric] for rid in ids) for metric in METRICS}
            per_run.append({"dimension": dimension, "stratum": label, "n": len(ids), "run_id": run, **run_metrics[run]})
        for name, runs in GROUPS.items():
            for metric in METRICS:
                values = [run_metrics[r][metric] for r in runs]
                per_policy.append({"dimension": dimension, "stratum": label, "n": len(ids), "policy": name, "metric": metric,
                                   "mean": statistics.mean(values), "sample_sd_across_fitted_seeds": statistics.stdev(values) if len(values) > 1 else None})
        effects = [run_metrics[h]["recall@5"] - run_metrics[r]["recall@5"] for r, h in zip(RUNS[2::2], RUNS[3::2])]
        paired.append({"dimension": dimension, "stratum": label, "n": len(ids), "hard_minus_random_recall5_mean": statistics.mean(effects),
                       "sample_sd_across_three_seed_differences": statistics.stdev(effects), **{f"seed{seed}": effects[i] for i, seed in enumerate((42, 43, 44))}})
    return per_run, per_policy, paired


def make_cases(labels, corpus_map, prediction_maps, metric_maps, sample, strata_map, side):
    label_map = {r["id"]: r for r in labels}
    cases = []
    for index, chosen in enumerate(sample["samples"], 1):
        rid = chosen["id"]
        source = label_map[rid]
        runs = {}
        for run in RUNS[2:]:
            pred = prediction_maps[run][rid]
            runs[run] = {"metrics": metric_maps[run][rid], "top5": [{"id": tid, "score": pred["scores"][i],
                           "labelled_positive": tid in source["positives"], "text": corpus_map[tid]["text"], "raw": corpus_map[tid].get("raw")} for i, tid in enumerate(pred["top10"][:5])]}
        cases.append({"case_id": f"CASE{index:03d}", "query_id": rid, "query": source["query"], "category": source["category"], "track": source["track"],
                      "sample_design": chosen, "result_source": side, "positives": [{"id": tid, "text": corpus_map[tid]["text"], "raw": corpus_map[tid].get("raw")} for tid in source["positives"]],
                      "reference_similarity": strata_map[rid]["reference_similarity"], "reference_similarity_stratum": strata_map[rid]["reference_similarity_stratum"],
                      "six_run_evidence": runs,
                      "query_semantic_review": {"status": "PENDING_DOCUMENTED_AI_OR_HUMAN_REVIEW", "operation_structure": None, "context_dependent": None, "explicit_constraints": None, "rationale": None},
                      "candidate_semantic_review": [], "reviewer_type": None, "human_review_status": "HUMAN_PENDING", "uncertainty": "Unlabelled candidates are not established irrelevant tools; documentation does not prove execution validity."})
    return cases


def render_cases(cases, target):
    parts = ["<!doctype html><html lang='zh'><meta charset='utf-8'><title>固定60例检索错误证据</title><style>body{font-family:system-ui;max-width:1100px;margin:2rem auto;line-height:1.5}pre{white-space:pre-wrap;background:#f5f5f5;padding:1rem}article{border-top:2px solid #999;padding-top:1rem;margin-top:2rem}summary{cursor:pointer}small{color:#555}</style><h1>固定60例检索错误证据</h1><p>原方案预定样本；原与复现结果分开。语义审核字段为空时表示尚未实际审阅，不是已完成人工判断。下列六个模型均保留原始前5名及分数。</p>"]
    for case in cases:
        parts.append("<article><h2>" + html.escape(case["case_id"] + " / " + case["query_id"]) + "</h2><p>" + html.escape(case["sample_design"]["group"] + " · " + case["category"] + " · " + case["track"]) + "</p><pre>" + html.escape(case["query"]) + "</pre><h3>冻结正例</h3>")
        for tool in case["positives"]:
            parts.append("<pre>" + html.escape(tool["id"] + "\n" + tool["text"]) + "</pre>")
        for run, evidence in case["six_run_evidence"].items():
            parts.append("<details><summary>" + html.escape(run + " R@5=" + str(evidence["metrics"]["recall@5"])) + "</summary>")
            for tool in evidence["top5"]:
                parts.append("<pre>" + html.escape(tool["id"] + " / score=" + str(tool["score"]) + " / labelled_positive=" + str(tool["labelled_positive"]) + "\n" + tool["text"]) + "</pre>")
            parts.append("</details>")
        parts.append("<small>语义审阅状态：" + html.escape(case["query_semantic_review"]["status"]) + "</small></article>")
    Path(target).write_text("\n".join(parts) + "</html>", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-root", type=Path, required=True)
    parser.add_argument("--reproduction-root", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--extra-python-path", type=Path)
    parser.add_argument("--fixture-only", action="store_true")
    args = parser.parse_args()
    if args.fixture_only:
        print(json.dumps(fixtures()))
        return
    if args.extra_python_path:
        sys.path.insert(0, str(args.extra_python_path.resolve()))
    import numpy as np
    from tokenizers import Tokenizer
    original, out = args.original_root.resolve(), args.output_dir.resolve()
    if out.is_relative_to(original) or (args.reproduction_root and out.is_relative_to(args.reproduction_root.resolve())):
        raise ValueError("Analysis output must be outside source projects")
    inputs = [original / "data/main_20261025/test.json", original / "data/main_20261025/test_corpus.json", original / "data/raw/model/tokenizer.json"]
    inputs += [original / "results/main_20261025/official_test" / run / "predictions.json" for run in RUNS]
    identities = {str(path.relative_to(original)).replace("\\", "/"): {"sha256": sha(path), "bytes": path.stat().st_size} for path in inputs}
    plan_path = out / "analysis_plan.json"
    plan = {"created_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "code_sha256": sha(__file__), "scorer_code_sha256": sha(Path(__file__).with_name("compare_reproduction.py")),
            "status": "POST_HOC_DESCRIPTIVE_PLAN_AFTER_ORIGINAL_STUDY_NOT_ORIGINAL_PREREGISTRATION", "input_files": identities,
            "query_strata": ["upstream category", "track", "one vs multiple original labels", "actual E5 tokenizer length with query prefix and special tokens", "truncation at128"],
            "query_token_length_bins": ["<=32", "33-64", "65-128", ">128"],
            "lexical_similarity": "NFKC, casefold, [a-z0-9]+ token sets on frozen serialized tool text; exact Jaccard; empty union is missing",
            "reference": "original pretrained E5 top10 unlabelled candidates vs all labelled positives; maximum Jaccard; fixed for original and reproduction",
            "similarity_bins": ["[0,0.1)", "[0.1,0.3)", "[0.3,0.6)", "[0.6,1)", "exact_1", "no_unlabelled_candidate", "missing"],
            "case_sampling": {"seed": 20261111, "groups": ["hard_wins", "hard_losses", "ties"], "nominal_per_group": 20, "tie_tolerance": 1e-12,
                              "ties_exclude": "both policy three-seed means equal full recall", "text_dedup": "original common.py normalize query; globally smallest query ID per text", "category_quota": "largest remainder; alphabetical category tie-break", "sampling": "one Python random.Random(seed), fixed group order then sorted categories, sorted IDs before sample", "shortfall": "proportional largest-remainder allocation to remaining group capacities"},
            "semantics": {"operation_structure": ["single_operation", "multiple_operations", "unclear"], "flags": ["context_dependent", "explicit_constraints"], "candidate_labels": ["clear_function_mismatch", "constraint_or_context_mismatch", "plausible_unlabelled_alternative", "insufficient_or_conflicting_metadata", "mixed_or_no_single_explanation"], "default": "empty until actual review; AI-only labels separate from human"},
            "uncertainty": {"replicates": 5000, "query_seed": 50042, "normalized_query_cluster_seed": 50043, "aggregation": "three fitted seed differences averaged per query before resampling; query-weighted cluster mean"},
            "new_strategy_error_plan": "exploratory after final lock and final scores, never changes configuration or gold; same fixed 60 query IDs may be reused for aligned qualitative comparisons", "primary_test_labels_unchanged": True,
            "fixtures": fixtures()}
    if plan_path.exists():
        existing = read(plan_path)
        if existing["input_files"] != identities or existing["code_sha256"] != plan["code_sha256"]:
            raise ValueError("Existing analysis plan/source identity differs; preserve and explicitly version before rerunning")
    else:
        # Must happen before reading model rankings or selecting case IDs.
        write(plan_path, plan)
    labels = read(inputs[0])
    corpus = read(inputs[1])
    corpus_map = {r["id"]: r for r in corpus}
    tokenizer = Tokenizer.from_file(str(inputs[2]))
    tokenizer.no_truncation()
    tokenizer.no_padding()
    full_lengths = {q["id"]: len(tokenizer.encode("query: " + q["query"], add_special_tokens=True).ids) for q in labels}
    token_sets = {tid: lexical_tokens(row["text"]) for tid, row in corpus_map.items()}
    audits = {}
    for run in RUNS:
        path = original / "results/main_20261025/official_test" / run / "predictions.json"
        audits[run] = validate_predictions(path, labels, corpus, path.with_name("metrics.json"))
        if not audits[run]["passed"]:
            raise ValueError("Original saved predictions invalid: " + run)
    original_maps = {run: {r["id"]: r for r in a["predictions"]} for run, a in audits.items()}
    original_metric_maps = {run: {r["id"]: r for r in a["calculated"]} for run, a in audits.items()}
    sample_path = out / "sample_manifest.json"
    if sample_path.exists():
        sample = read(sample_path)
    else:
        sample = case_sample(labels, original_metric_maps)
        sample["plan_sha256"] = sha(plan_path)
        sample["original_prediction_sha256"] = {run: audits[run]["sha256"] for run in RUNS}
        write(sample_path, sample)
    strata = []
    reference_pairs = []
    for query in labels:
        rid = query["id"]
        unlabelled = [tid for tid in original_maps["M02_pretrained"][rid]["top10"] if tid not in query["positives"]]
        triples = [(similarity(token_sets[tid], token_sets[pos]), tid, pos) for tid in unlabelled for pos in query["positives"]]
        available_pairs = [(s, t, p) for s, t, p in triples if s is not None]
        if available_pairs:
            value, candidate, positive = min(available_pairs, key=lambda item: (-item[0], item[1], item[2]))
            status = "available"
        else:
            value = candidate = positive = None
            status = "no_unlabelled_candidate" if not unlabelled else "missing"
        length = full_lengths[rid]
        length_bin = "<=32" if length <= 32 else ("33-64" if length <= 64 else ("65-128" if length <= 128 else ">128"))
        strata.append({"id": rid, "category": query["category"], "track": query["track"], "n_original_positives": len(query["positives"]),
                       "positive_count_stratum": "one" if len(query["positives"]) == 1 else "multiple", "query_tokens_with_prefix_and_specials": length,
                       "query_length_stratum": length_bin, "query_truncated_at128": length > 128, "query_empty": not bool(query["query"].strip()),
                       "reference_similarity": value, "reference_similarity_stratum": similarity_stratum(value, status),
                       "reference_candidate_id": candidate, "reference_positive_id": positive})
        reference_pairs.append({"query_id": rid, "reference_similarity": value, "status": status, "max_candidate_id": candidate, "max_positive_id": positive,
                                "reference_unlabelled_top10_count": len(unlabelled), "compared_candidate_positive_pairs": len(triples)})
    write_csv(out / "query_strata.csv", strata)
    write_csv(out / "text_similarity.csv", reference_pairs)
    strata_map = {r["id"]: r for r in strata}
    overall = {}
    for side, root in [("original", original)] + ([("reproduction", args.reproduction_root.resolve())] if args.reproduction_root else []):
        side_out = out / side
        missing = [run for run in RUNS if not (root / "results/main_20261025/official_test" / run / "predictions.json").exists()]
        if missing:
            write(side_out / "status.json", {"status": "PENDING_REAL_REPRODUCTION_OUTPUTS", "missing_runs": missing, "substituted_original": False})
            overall[side] = "PENDING"
            continue
        prediction_maps, metric_maps, side_audits = {}, {}, {}
        for run in RUNS:
            path = root / "results/main_20261025/official_test" / run / "predictions.json"
            audit = audits[run] if side == "original" else validate_predictions(path, labels, corpus, path.with_name("metrics.json"))
            if not audit["passed"]:
                raise ValueError("Prediction validation failed: " + side + " " + run)
            prediction_maps[run] = {r["id"]: r for r in audit["predictions"]}
            metric_maps[run] = {r["id"]: r for r in audit["calculated"]}
            side_audits[run] = {k: v for k, v in audit.items() if k not in {"predictions", "calculated"}}
        side_out.mkdir(parents=True, exist_ok=True)
        write(side_out / "metric_recalculation.json", side_audits)
        write_csv(side_out / "per_query_metrics.csv.gz", ({"run_id": run, **row} for run in RUNS for row in metric_maps[run].values()))
        tables = summarize_strata(strata, metric_maps)
        for name, rows in zip(("strata_by_run", "strata_by_policy", "strata_paired_effects"), tables, strict=True):
            write_csv(side_out / (name + ".csv"), rows)
        write(side_out / "uncertainty.json", uncertainty(labels, metric_maps, np))
        with gzip.open(side_out / "unlabelled_top5_lexical_pairs.jsonl.gz", "wt", encoding="utf-8") as f:
            for run in RUNS[2:]:
                for query in labels:
                    for rank, tid in enumerate(prediction_maps[run][query["id"]]["top10"][:5], 1):
                        if tid in query["positives"]:
                            continue
                        pairs = [(similarity(token_sets[tid], token_sets[pos]), pos) for pos in query["positives"]]
                        valid = [(s, pos) for s, pos in pairs if s is not None]
                        maximum, best = min(valid, key=lambda item: (-item[0], item[1])) if valid else (None, None)
                        f.write(json.dumps({"run_id": run, "query_id": query["id"], "rank": rank, "candidate_id": tid, "max_jaccard": maximum, "matching_labelled_positive_id": best, "meaning": "unlabelled is not verified irrelevant"}, ensure_ascii=False) + "\n")
        cases = make_cases(labels, corpus_map, prediction_maps, metric_maps, sample, strata_map, side)
        # Never overwrite a subsequently supplied real semantic review.
        case_path = side_out / "cases.json"
        if case_path.exists() and any(c.get("reviewer_type") is not None for c in read(case_path)):
            write(side_out / "cases_evidence_rebuilt.json", cases)
        else:
            write(case_path, cases)
            render_cases(cases, side_out / "cases_readable.html")
        status = {"status": "NUMERICAL_DESCRIPTIVE_ANALYSIS_COMPLETE", "query_n": len(labels), "sample_n": len(cases),
                  "semantic_review": "PENDING_DOCUMENTED_REVIEW", "human_review": "HUMAN_PENDING", "source": side,
                  "primary_test_labels_modified": False, "sample_ids_match_original_frozen_manifest": True}
        write(side_out / "status.json", status)
        overall[side] = status["status"]
    provenance = {"code_sha256": sha(__file__), "plan_sha256": sha(plan_path), "sample_sha256": sha(sample_path), "input_files": identities,
                  "tables": {"query_strata.csv": "frozen original test metadata; actual fixed E5 tokenizer; original pretrained top10 reference",
                             "text_similarity.csv": "maximum exact lexical Jaccard between pretrained unlabelled top10 and known positives",
                             "*/strata_by_run.csv": "independently rescored original/new predictions joined by query ID to fixed shared strata",
                             "*/strata_by_policy.csv": "per-run stratified metrics; means/sample SD across actual fitted seeds",
                             "*/strata_paired_effects.csv": "paired hard-minus-random per seed, same fixed strata"},
                  "sample_legacy_24_cases": "archive paper_diagnostics/error_review_sample.json has 24 cases and is not substituted for the new required 60-case seed20261111 design"}
    write(out / "table_provenance.json", provenance)
    report = "已完成三维错误分析中的可复算统计：上游category/track、原正例数、真实token长度/截断分层；固定原pretrained参考的工具文本Jaccard分层；固定60例及全部六个run证据。\n"
    report += "语义操作类型、具体候选错误类别和依据必须在实际阅读后另行填入；本脚本未自动冒充完成AI或人类语义审核。原标签始终不变。\n"
    report += "词面相似度不是语义等价；负例/错误分组是事后描述证据，不能推出因果。20/20/20样本比例不是全体测试错误率。\n"
    report += "原研究与新复现分别保存，未完成新复现时明确PENDING。三种子波动与给定模型的查询bootstrap区间分开报告。\n"
    (out / "analysis_report.txt").write_text(report, encoding="utf-8")
    write(out / "status.json", overall)
    print(json.dumps({"status": overall, "sample_n": sample["sample_n"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
