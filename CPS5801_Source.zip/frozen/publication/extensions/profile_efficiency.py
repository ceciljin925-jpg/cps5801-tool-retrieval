"""Frozen batch-one efficiency protocol: seed2026111203, 50 warmups, five rounds.

Prepare: --config CONFIG --plan NEW_PLAN --prepare
Run one serial model: --plan PLAN --run-id RUN_ID --output NEW_ATTEMPT
CONFIG: queries_path,corpus_path,task_type(pooled/menu),models:[{run_id,family,
model_path,seed(42 or null),evaluation_id(optional)}]. Optional external_final,
final_lock_path,access_log_path,allowed_empty_query_ids,batch_size(for indexing).
The same stable full-sort helper used for predictions is timed for every model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import random
import subprocess
import time
import traceback

from encoders import (Encoder, directory_manifest, dump, ensure_output, now, read, runtime_record,
                      setup_runtime, sha_file, sha_json, sync, np, torch)
from evaluate_retrieval import BM25, final_access_gate, stable_full_sort, validate_data

SEED = 2026111203
WARMUPS = 50
ROUNDS = 5


def code_manifest():
    root = pathlib.Path(__file__).resolve().parent
    return {name: sha_file(root / name) for name in ('profile_efficiency.py', 'encoders.py', 'evaluate_retrieval.py')}


def device_snapshot():
    fields = 'name,driver_version,memory.total,memory.used,utilization.gpu,temperature.gpu,power.draw'
    try:
        command = subprocess.run(['nvidia-smi', '--query-gpu=' + fields, '--format=csv,noheader,nounits'],
                                 check=True, capture_output=True, text=True, timeout=20)
        processes = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory', '--format=csv,noheader'],
                                   capture_output=True, text=True, timeout=20)
        return {'captured_at': now(), 'gpu_fields': fields, 'gpu_values': command.stdout.strip(),
                'compute_processes': processes.stdout.strip(), 'process_query_returncode': processes.returncode}
    except Exception as error:
        return {'captured_at': now(), 'snapshot_error': repr(error)}


def freeze_plan(config, destination):
    destination = ensure_output(destination)
    if destination.exists():
        raise FileExistsError('Profiling plan already exists; do not replace a frozen measurement plan')
    queries, corpus = read(config['queries_path']), read(config['corpus_path'])
    task_type = config.get('task_type', 'pooled')
    qids, cids = validate_data(queries, corpus, task_type, config.get('allowed_empty_query_ids', []))
    canonical_ids = sorted(qids)
    ids = random.Random(SEED).sample(canonical_ids, 1000) if len(canonical_ids) > 1000 else canonical_ids
    models = []
    for model in config['models']:
        if model.get('seed') not in (None, 42):
            raise ValueError('Default efficiency protocol uses predesignated seed42, never a selected fastest seed')
        if model['family'] not in ('e5', 'bge', 'qwen_reference', 'bm25'):
            raise ValueError('Unrecognized family')
        model = dict(model)
        index_batch = model.get('index_batch_size', config.get('batch_size', 32))
        if not isinstance(index_batch, int) or isinstance(index_batch, bool) or index_batch < 1:
            raise ValueError('Model index_batch_size must be a positive integer')
        model['index_batch_size'] = index_batch
        if model['family'] == 'bm25':
            manifest = {'family': 'bm25', 'code_sha256': sha_file(pathlib.Path(__file__).with_name('evaluate_retrieval.py'))}
        else:
            model['model_path'] = str(pathlib.Path(model['model_path']).resolve(strict=True))
            manifest = directory_manifest(model['model_path'])
        model['model_manifest_sha256'] = sha_json(manifest)
        models.append(model)
    if len({m['run_id'] for m in models}) != len(models):
        raise ValueError('Duplicate profile run IDs')
    for family in ('e5', 'bge', 'qwen_reference'):
        if len({model['index_batch_size'] for model in models if model['family'] == family}) > 1:
            raise ValueError('All strategies in one family must use the same frozen indexing batch size')
    setup_runtime('cuda')
    plan = {'schema_version': 1, 'created_at': now(), 'protocol': 'publication_v1_fixed_batch1_efficiency',
            'sampling_seed': SEED, 'query_ids': ids, 'query_order_sha256': sha_json(ids),
            'warmups': WARMUPS, 'rounds': ROUNDS, 'batch_size': 1, 'concurrency': 1,
            'encoding_dtype': 'float32', 'scoring_dtype': 'float32', 'tf32': False,
            'rank_implementation': 'evaluate_retrieval.stable_full_sort; all candidate scores sorted, explicit frozen tie order',
            'timing_boundary': 'synchronous query tokenization, device transfer+encoding, exact scores+host transfer, stable full-sort+top50 ID materialization; end-to-end includes synchronization overhead',
            'one_time_costs': 'model/tokenizer load; all evaluation corpus vector/index construction; query-independent tie/menu preparation',
            'query_count_total': len(queries), 'corpus_count': len(corpus), 'task_type': task_type,
            'queries_path': str(pathlib.Path(config['queries_path']).resolve(strict=True)),
            'corpus_path': str(pathlib.Path(config['corpus_path']).resolve(strict=True)),
            'queries_sha256': sha_file(config['queries_path']), 'corpus_sha256': sha_file(config['corpus_path']),
            'models': models, 'index_batch_size': config.get('batch_size', 32),
            'allowed_empty_query_ids': config.get('allowed_empty_query_ids', []),
            'machine': runtime_record(), 'device_snapshot': device_snapshot(), 'code': code_manifest(),
            'external_final': config.get('external_final', False),
            'final_lock_path': config.get('final_lock_path'), 'access_log_path': config.get('access_log_path')}
    dump(destination, plan)
    return plan


def sparse_bytes(index):
    return int(index.mat.data.nbytes + index.mat.indices.nbytes + index.mat.indptr.nbytes)


def summarize(values):
    return {'median': float(np.median(values)), 'p95': float(np.percentile(values, 95)),
            'mean': float(np.mean(values)), 'min': float(np.min(values)), 'max': float(np.max(values))}


def profile_model(plan_path, run_id, output):
    plan = read(plan_path)
    if plan['code'] != code_manifest():
        raise ValueError('Profiling code changed after plan freeze')
    if (plan['sampling_seed'], plan['warmups'], plan['rounds'], plan['batch_size'], plan['concurrency']) != (SEED, WARMUPS, ROUNDS, 1, 1):
        raise ValueError('Profiling protocol differs from fixed plan')
    for key in ('queries', 'corpus'):
        if sha_file(plan[key + '_path']) != plan[key + '_sha256']:
            raise ValueError(f'{key} changed since profiling plan freeze')
    matching = [m for m in plan['models'] if m['run_id'] == run_id]
    if len(matching) != 1:
        raise ValueError('Run must appear exactly once in frozen profile plan')
    model_spec = matching[0]
    family = model_spec['family']
    index_batch_size = model_spec.get('index_batch_size', plan['index_batch_size'])
    if not isinstance(index_batch_size, int) or isinstance(index_batch_size, bool) or index_batch_size < 1:
        raise ValueError('Invalid frozen model index_batch_size')
    model_manifest = directory_manifest(model_spec['model_path']) if family != 'bm25' else {
        'family': 'bm25', 'code_sha256': sha_file(pathlib.Path(__file__).with_name('evaluate_retrieval.py'))}
    if sha_json(model_manifest) != model_spec['model_manifest_sha256']:
        raise ValueError('Model changed since profiling plan freeze')
    out = ensure_output(output)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Profile attempt directory must be new; retain earlier measurement')
    gate = {**plan, **model_spec, 'external_final': plan['external_final']}
    if plan['external_final']:
        final_access_gate(gate, out, model_manifest)
    out.mkdir(parents=True, exist_ok=True)
    dump(out / 'status.json', {'status': 'running', 'started_at': now(), 'run_id': run_id})
    setup_runtime('cuda')
    queries, corpus = read(plan['queries_path']), read(plan['corpus_path'])
    validate_data(queries, corpus, plan['task_type'], plan.get('allowed_empty_query_ids', []))
    by_query = {q['id']: q for q in queries}
    selected = [by_query[qid] for qid in plan['query_ids']]
    corpus_ids = [doc['id'] for doc in corpus]
    corpus_index = {tid: i for i, tid in enumerate(corpus_ids)}
    documents = {doc['id']: doc['text'] for doc in corpus}
    task_type = plan['task_type']
    encoder, bm25, menus, doc_gpu = None, None, {}, None
    snapshots = [device_snapshot()]
    started = time.perf_counter()
    try:
        torch.cuda.reset_peak_memory_stats()
        sync('cuda')
        load_started = time.perf_counter()
        if family != 'bm25':
            encoder = Encoder(family, model_spec['model_path'], 'cuda')
            encoder.model.eval()
        sync('cuda')
        load_seconds = time.perf_counter() - load_started
        index_started = time.perf_counter()
        if encoder:
            embeddings = encoder.encode([doc['text'] for doc in corpus], 'document', index_batch_size)
            doc_gpu = torch.from_numpy(embeddings).cuda()
            vector_bytes = int(embeddings.nbytes)
        else:
            if task_type == 'pooled':
                bm25 = BM25([doc['text'] for doc in corpus])
                vector_bytes = sparse_bytes(bm25)
            else:
                for query in queries:
                    menus[query['id']] = BM25([documents[tid] for tid in query['candidate_ids']])
                vector_bytes = sum(sparse_bytes(index) for index in menus.values())
        sync('cuda')
        index_seconds = time.perf_counter() - index_started
        persistence_started = time.perf_counter()
        if encoder:
            np.save(out / 'profile_corpus_embeddings.npy', embeddings, allow_pickle=False)
            dump(out / 'profile_embedding_provenance.json', {'corpus_ids': corpus_ids,
                 'corpus_file_sha256': plan['corpus_sha256'], 'model_manifest_sha256': sha_json(model_manifest),
                 'embedding_sha256': sha_file(out / 'profile_corpus_embeddings.npy'), 'dtype': 'float32'})
        persistence_seconds = time.perf_counter() - persistence_started
        preparation_started = time.perf_counter()
        if task_type == 'pooled':
            tie_orders = {'all': np.argsort(np.asarray(corpus_ids), kind='stable')}
            candidate_indices = {}
        else:
            tie_orders = {q['id']: np.argsort(np.asarray([q['candidate_tie_break_keys'][tid] for tid in q['candidate_ids']]), kind='stable') for q in queries}
            candidate_indices = {q['id']: torch.tensor([corpus_index[tid] for tid in q['candidate_ids']], dtype=torch.long, device='cuda') for q in queries} if encoder else {}
        preparation_seconds = time.perf_counter() - preparation_started
        setup_peak = {'allocated_GiB': torch.cuda.max_memory_allocated() / 2**30, 'reserved_GiB': torch.cuda.max_memory_reserved() / 2**30}
        torch.cuda.reset_peak_memory_stats()

        def timed_query(query):
            tie_order = tie_orders[query['id']] if task_type == 'menu' else tie_orders['all']
            candidate_ids = query['candidate_ids'] if task_type == 'menu' else corpus_ids
            sync('cuda')
            begin = time.perf_counter()
            if encoder:
                tokens = encoder.tokenizer(encoder.format(query['query'], 'query'), truncation=True, max_length=128, return_tensors='pt')
                token_done = time.perf_counter()
                tokens = tokens.to('cuda')
                q = encoder.pool(tokens)
                sync('cuda')
                encoding_done = time.perf_counter()
                candidates = doc_gpu[candidate_indices[query['id']]] if task_type == 'menu' else doc_gpu
                scores = (q @ candidates.T).flatten().cpu().numpy()
                sync('cuda')
                score_done = time.perf_counter()
            else:
                # BM25 scoring naturally fuses lexical token lookup and sparse sum;
                # isolate those operations without changing the frozen formula.
                index = menus[query['id']] if task_type == 'menu' else bm25
                columns = index.query_columns(query['query'])
                token_done = time.perf_counter()
                encoding_done = token_done
                scores = index.scores_from_columns(columns)
                score_done = time.perf_counter()
            ordered = stable_full_sort(scores, tie_order)
            retrieved_ids = [candidate_ids[i] for i in ordered[:min(50, len(candidate_ids))]]
            if len(retrieved_ids) != min(50, len(candidate_ids)):
                raise RuntimeError('Full sort returned wrong number of candidates')
            sync('cuda')
            end = time.perf_counter()
            return {'query_id': query['id'], 'candidate_count': len(candidate_ids),
                    'tokenization_ms': (token_done - begin) * 1000,
                    'encoding_ms': (encoding_done - token_done) * 1000,
                    'exact_score_and_transfer_ms': (score_done - encoding_done) * 1000,
                    'full_sort_and_materialization_ms': (end - score_done) * 1000,
                    'end_to_end_ms': (end - begin) * 1000}

        rows, warmup_rows = [], []
        with torch.inference_mode():
            for i in range(WARMUPS):
                warmup_rows.append({'warmup': i, **timed_query(selected[i % len(selected)])})
            dump(out / 'warmup_timings.json', warmup_rows)
            with (out / 'raw_timings.jsonl').open('w', encoding='utf-8') as stream:
                for round_index in range(ROUNDS):
                    for order, query in enumerate(selected):
                        row = {'round': round_index + 1, 'query_order': order, **timed_query(query)}
                        rows.append(row)
                        stream.write(json.dumps(row, allow_nan=False) + '\n')
                    stream.flush()
                    snapshots.append(device_snapshot())
                    print('profile round', round_index + 1, '/', ROUNDS, 'run', run_id, flush=True)
        timing_fields = [key for key in rows[0] if key.endswith('_ms')]
        per_round = []
        for round_index in range(1, ROUNDS + 1):
            subset = [row for row in rows if row['round'] == round_index]
            per_round.append({'round': round_index, 'metrics_ms': {key: summarize([row[key] for row in subset]) for key in timing_fields},
                              'sequential_batch1_queries_per_second': len(subset) * 1000 / sum(row['end_to_end_ms'] for row in subset)})
        report = {'run_id': run_id, 'family': family, 'seed': model_spec.get('seed'), 'created_at': now(),
                  'profiling_plan_sha256': sha_file(plan_path), 'model_manifest_sha256': sha_json(model_manifest),
                  'task_type': task_type, 'query_count_per_round': len(selected), 'rounds': ROUNDS, 'warmups': WARMUPS,
                  'index_batch_size': index_batch_size if encoder else None,
                  'retrieval_query_batch_size': 1,
                  'index_batch_scope': 'one-time document encoding only; frozen uniformly within family; every latency query remains batch1',
                  'load_seconds': load_seconds, 'index_seconds': index_seconds,
                  'embedding_persistence_seconds': persistence_seconds,
                  'query_independent_preparation_seconds': preparation_seconds,
                  'vector_or_sparse_index_bytes': vector_bytes,
                  'index_memory_note': 'dense float32 vector bytes or sparse matrix data/indices/indptr; excludes Python vocabulary overhead',
                  'setup_peak': setup_peak, 'retrieval_peak_allocated_GiB': torch.cuda.max_memory_allocated() / 2**30,
                  'retrieval_peak_reserved_GiB': torch.cuda.max_memory_reserved() / 2**30,
                  'metrics_ms': {key: summarize([row[key] for row in rows]) for key in timing_fields},
                  'per_round': per_round,
                  'sequential_batch1_queries_per_second': len(rows) * 1000 / sum(row['end_to_end_ms'] for row in rows),
                  'throughput_scope': 'reciprocal observed sequential batch1 service time; not batched-throughput experiment',
                  'total_wall_seconds': time.perf_counter() - started,
                  'timing_boundary': plan['timing_boundary'], 'rank_implementation': plan['rank_implementation'],
                  'device_snapshots': snapshots, 'environment': runtime_record(),
                  'contention_status': 'device/process snapshots retained for review; other desktop GPU workloads cannot be proved absent'}
        dump(out / 'summary.json', report)
        dump(out / 'status.json', {'status': 'completed', 'completed_at': now(), 'timing_rows': len(rows)})
        return report
    except Exception as error:
        dump(out / 'status.json', {'status': 'failed', 'failed_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=pathlib.Path)
    parser.add_argument('--plan', required=True, type=pathlib.Path)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--run-id')
    parser.add_argument('--output', type=pathlib.Path)
    args = parser.parse_args()
    if args.prepare:
        if args.config is None:
            parser.error('--prepare requires --config')
        result = freeze_plan(read(args.config), args.plan)
        print(json.dumps({'plan': str(args.plan), 'query_count': len(result['query_ids']), 'models': len(result['models'])}))
    else:
        if args.run_id is None or args.output is None:
            parser.error('--run-id and --output are required')
        result = profile_model(args.plan, args.run_id, args.output)
        print(json.dumps({'run_id': result['run_id'], 'status': 'completed', 'output': str(args.output)}))


if __name__ == '__main__':
    main()
