"""Freeze machine-readable analysis/profiling rules before new scientific results.

Existing execution decisions are referenced by hash and copied as a snapshot;
they are never overwritten. Dataset/checkpoint identities are resolved in the
later final_lock, without changing these score-independent rules.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT.parent / "handoff" / "CPS5801_PUBLICATION_HANDOFF_20261112"
SOURCE = PACKAGE / "archive/CPS5801_HANDOFF_20261025/CPS5801"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def record(path, root):
    return {"path": str(path.relative_to(root)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": sha(path)}


def write_new(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"Preserve frozen plan: {path}")
    path.write_text(json.dumps(content, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    stamp = datetime.now(timezone(timedelta(hours=8))).isoformat()
    decisions_path = ROOT / "locks/execution_decisions.json"
    decisions = read(decisions_path)
    matrix_path = PACKAGE / "experiment_matrix.json"
    matrix = read(matrix_path)
    assert decisions["cross_policy_tie_break"].startswith("Best policy Recall@5")
    assert decisions["s1_s5_batch"] == {"microbatch": 8, "accumulation": 4, "effective": 32}
    plan_path = ROOT / "locks/analysis_plan.json"
    profile_path = ROOT / "locks/profiling_plan.json"
    if plan_path.exists() or profile_path.exists():
        raise FileExistsError("Analysis/profiling plan already exists; preserve it and explicitly version any justified amendment")
    profile = {
        "schema_version": "1.0.0", "frozen_at": stamp, "timezone": "Asia/Shanghai", "before_new_efficiency_results": True,
        "machine": "This local NVIDIA RTX A5000 24GB; bind exact hardware/driver/software hashes from measured environment in final_lock",
        "scenarios": ["legacy_observed_test_pooled", "BFCL_live_multiple_native_menu", "BFCL_multiple_native_menu", "BFCL_parallel_multiple_native_menu", "ToolHop_pooled_reference_stress"],
        "model_selection": "All final_lock conditions at prespecified seed42, including fixed-recipe models and selected-configuration models, plus BM25/pretrained E5/BGE/Qwen; exact identical checkpoints may share a measured result with an explicit mapping",
        "query_sampling": {"seed": 2026111203, "rng": "Python random.Random", "frame_order": "query ID ascending",
                           "sample_size": 1000, "under_1000": "all queries", "without_replacement": True,
                           "dataset_streams": "reset Random(2026111203) independently for each dataset; save resulting fixed ID order before timing", "same_order_all_methods_and_rounds": True},
        "warmup": {"queries": 50, "rule": "first50 fixed IDs, cycle only if dataset has fewer than50; exclude from reported rounds"},
        "repeats": 5, "batch_size": 1, "concurrency": 1, "inference_dtype": "float32", "score_dtype": "float32", "tf32": False,
        "timing_boundary": {"start": "after CUDA synchronization, immediately before query tokenization",
                            "included": ["query tokenization", "device transfer", "query encoding", "full frozen corpus or native-menu scoring", "stable complete ranking: score descending; pooled tool-ID ascending ties; BFCL candidate_tie_break_keys SHA256 ascending ties"],
                            "end": "after scores/ranking needed for retrieval are materialized and CUDA synchronization completes",
                            "excluded_but_separately_measured": ["model loading", "tool document tokenization and embedding/index build", "training", "negative mining", "file serialization"]},
        "candidate_scope": "Exactly the task's frozen catalogue or original per-query menu; no cross-menu pooling for BFCL",
        "contention": "No simultaneous GPU training; record background usage; retain first affected timing and repeat impacted round with reason",
        "raw_records": ["query_id", "repeat", "method", "seed", "latency_ms", "candidate_count", "timestamp", "GPU_allocated_peak", "GPU_reserved_peak"],
        "aggregates": ["median_ms", "p95_ms_linear_quantile", "per_repeat_statistics", "queries_per_second", "actual_index_bytes", "peak_allocated_bytes", "peak_reserved_bytes"],
        "throughput": "Optional separately labeled fixed-batch scenario only; never mix with batch1 latency",
        "token_proxy": {"ks": [1, 3, 5, 10, 20, 50], "all_final_training_seeds": True,
                        "reference_tokenizer": "archived intfloat/e5-small-v2 pinned tokenizer",
                        "text": "json.dumps(raw_tool, sort_keys=True, ensure_ascii=False) with Python default separators",
                        "add_special_tokens": False, "truncation": False, "per_query_cost": "sum token lengths of actually returned documents (min(k, menu/corpus size))",
                        "not": ["API bill", "agent execution success", "proof that smaller k makes full-corpus scoring faster"],
                        "legacy_difference": "Original pilot tokenizer disabled special tokens; expanded main_representation_stats.py left tokenizer default enabled. Rebuild original tables with saved original lengths, report separate new no-special-token curves."},
        "pareto_panels": ["Recall versus measured batch1 latency", "Recall versus full raw documentation tokens / returned candidate count", "training+mining cost or index memory versus Recall where materially different"],
        "pareto_annotation": "Every point states encoder/policy/k/seed aggregation and timing boundary; five-seed mean Recall with seed42 latency is explicitly labeled",
        "dominance": "Within declared dimensions, accuracy no lower and cost no higher with at least one strict improvement; within timing noise use observed frontier, not stable superiority",
        "legacy_timing": "Original saved timing and stable full-sort ranking boundaries differ; retain historical values separately, never mix as same implementation",
        "code_sha256": sha(__file__),
    }
    write_new(profile_path, profile)
    source_files = [matrix_path, PACKAGE / "00_从这里开始_投稿研究任务.txt", PACKAGE / "01_研究问题与分阶段实验.txt",
                    PACKAGE / "02_外部数据与独立评测.txt", PACKAGE / "03_统计验收与结果触发规则.txt", PACKAGE / "04_人工审核与完整返还要求.txt",
                    PACKAGE / "06_工程实现与自动推进.txt", PACKAGE / "model_assets.lock.json", PACKAGE / "external_assets_manifest.json"]
    plan = {
        "schema_version": "1.0.0", "plan_id": "cps5801_publication_v1_analysis", "frozen_at": stamp, "timezone": "Asia/Shanghai",
        "status": "rules_frozen_before_new_scientific_results; final dataset/checkpoint manifests pending",
        "registration_scope": "Post-hoc new study plan written after original 2026-10-25 results were known; not preregistration of the original research",
        "preparer_access_statement": {"new_scientific_scores_inspected": False, "external_model_scores_inspected": False,
                                     "known_material": ["historical protocol/results described in handoff", "historical audit structure and item metadata", "historical analysis code", "new code structure only"]},
        "source_documents": [record(path, PACKAGE) for path in source_files],
        "execution_decisions": {**record(decisions_path, ROOT), "snapshot": decisions, "precedence": "This immutable snapshot supplies concrete pre-execution engineering decisions; no silent overrides"},
        "research_questions": [
            {"id": "RQ1", "estimand": "Fixed-recipe effect of minimal E5-input duplicate repair and the B-versus-R interaction; three paired seeds"},
            {"id": "RQ2", "estimand": "Practical negative-policy comparison after equal development search opportunities over learning rate, temperature and updates"},
            {"id": "RQ3", "estimand": "Transfer of the S2-locked extension identity to BGE and locked collision-screened BFCL native-menu ranking"}],
        "evidence_types": {"ORIGINAL": "Original evidence and this machine's unchanged-protocol reproduction; already observed dataset",
                           "EXPLORATORY_DEV": "All tuning, diagnostics and legacy-observed-test extension results",
                           "LOCKED_CONFIRMATION": "BFCL live_multiple after validity/collision audit and pre-score final lock"},
        "data_roles": matrix["data_roles"],
        "dataset_contract": {"train_queries": 10000, "development_queries": 1000, "legacy_test_queries_expected": 7961,
                             "legacy_test_candidates_expected": 44453, "counts_must_be_verified": True,
                             "external_final": "Resolve actual counts, IDs, groups and hashes from external_eval_specs/final_dataset_manifest before final_lock; do not copy pre-audit counts as final",
                             "primary_external": "BFCL live_multiple native menus", "secondary_external": "BFCL multiple native menus",
                             "exploratory_external": "BFCL parallel_multiple native menus", "stress_only": "ToolHop pooled reference-label coverage",
                             "no_training_label_changes": True, "no_external_selection": True,
                             "independence_claim": "collision-screened external evaluation, not proof of source-disjointness or unseen pretraining"},
        "models": matrix["models"], "arms": matrix["policy_definitions"], "shared_training": matrix["shared_training"],
        "stage_counts": matrix["stage_counts"], "training_job_upper_bound": 84,
        "seeds": {"screening": [41], "fixed_mechanism": [42, 43, 44], "confirmation": [42, 43, 44, 45, 46]},
        "grid": matrix["grid"], "checkpoint_rule": "Screen312/625/1250; selected checkpoint frozen separately for each policy and family; no confirmation early stopping",
        "early_stopping_rule": "No scientific early stopping. Nonfinite loss stops affected attempt and records invalid cells; no substituted hyperparameters",
        "development_selection": {**matrix["development_selection"],
                                  "cross_policy_comparator": "Best configuration Recall@5; absolute ties<=1e-12 use B_UNIQUE,MIXED_2R2B,DENSE_STATIC,R_UNIQUE directly; no cross-policy MRR tie break",
                                  "inclusive_candidate_threshold": "0.01 absolute Recall margin, with 1e-12 numerical-equality handling at boundary only",
                                  "failure_handling": "All grid slots present or explicitly failed; missing/pending rows forbid lock. Valid saved pre-failure checkpoints retain their observed step identity; later failed slots remain failed. A policy with no valid checkpoint blocks its confirmation.",
                                  "selector": record(ROOT / "extensions/select_on_dev.py", ROOT)},
        "primary_contrasts": [{"id": family + ":selected_minus_" + reference, "family": family,
                               "difference": "selected_extension-" + reference, "dataset": "BFCL_live_multiple", "metric": "MRR", "seeds": [42, 43, 44, 45, 46]}
                              for family in ["e5", "bge"] for reference in ["R_ID", "B_ID"]],
        "secondary_fixed_recipe_contrasts": ["B_UNIQUE-B_ID", "R_UNIQUE-R_ID", "(B_UNIQUE-B_ID)-(R_UNIQUE-R_ID)"],
        "metrics": {"pooled_primary": "macro Recall@5 = mean_q |top5 intersect frozen positives|/|frozen positives|",
                    "pooled_secondary": ["Recall@1", "Recall@3", "Recall@10", "MRR@10"],
                    "pooled_additional_curves": ["Recall@20", "Recall@50", "raw_document_token_volume"],
                    "BFCL_primary": "MRR over complete native menu using frozen gold-set alternatives; not official end-to-end BFCL success",
                    "BFCL_secondary": "R@1 and external_eval_specs native gold-set measures",
                    "ToolHop": "Reference-label coverage; incomplete relevance prevents full-qrels confirmation claim",
                    "tie_rule": "score descending; pooled stable tool-ID ascending; BFCL candidate_tie_break_keys ascending (SHA256 of publication_v1|tie|query_id|function_name), never original menu ordinal", "original_saved_rescore_tolerance": 1e-12,
                    "tolerance_note": "Existing execution_decisions uses 1e-12, stricter than document03 default1e-10; no tolerance is imposed on new-vs-old training to manufacture agreement",
                    "incomplete_outputs": "Reject missing queries/positives/candidates, duplicates and nonfinite scores; never silently drop rows"},
        "practical_threshold": {"metric": "BFCL_live_multiple_MRR", "absolute_difference": .005,
                                "meaning": "Project-specific meaningful magnitude, separate from development .01 Recall signal and statistical uncertainty"},
        "uncertainty": {"statistic": "Paired per-query method contrast for each seed, then mean over all prescribed fitted seeds",
                        "seed_reporting": "Every paired seed effect, mean, sample SD(ddof1), signs; no seed optional stopping",
                        "bootstrap_replicates": 5000, "query_seed": 2026111201, "cluster_seed": 2026111202,
                        "engine": "numpy Generator(PCG64)", "batch_size": 128,
                        "group_weighting": "Uniform groups with replacement; include every query row in drawn groups including repetitions; divide contrast sum by actual sampled row count",
                        "interval": "Pointwise95% percentile, linear interpolation at(n-1)*p; not simultaneous four-comparison coverage",
                        "primary_unit": "Frozen task/query-family groups from external audit for BFCL; archived normalized-query grouping for legacy",
                        "legacy_normalization": "NFKC+casefold, regex Unicode \\w+ tokens joined by single spaces (archived common.norm)",
                        "few_groups": "One group: no inferential CI; 2–9 groups: fragile descriptive interval flag; group sizes/counts and every replicate denominator preserved",
                        "conditional_scope": "Given fitted models and labels; excludes full training, selection, labeling and dataset uncertainty",
                        "query_bootstrap": "Sensitivity only where dependence groups exist; never prefer narrower interval after seeing outcomes",
                        "original_rebuild": {"replicates": 5000, "query_seed": 50042, "cluster_seed": 50043,
                                             "engine": "archived numpy default_rng(PCG64)", "grouping_and_order": "preserve archived query order and first-occurrence group order"},
                        "p_values": "None; no significance test inferred from CI. Any later p-value method would require a versioned pre-final-lock amendment, four-contrast Holm, and no five-seed two-sided p<.05 claim",
                        "implementation": record(ROOT / "extensions/publication_statistics.py", ROOT)},
        "error_analysis": {
            "evidence_level": "descriptive/exploratory; fixed labels unchanged",
            "query_strata": {"category": "all original category values", "track": "all original track values, including small groups",
                             "positive_count": ["one labelled positive", "more than one labelled positive"],
                             "query_length": "E5 query-prefix included untruncated token length bins<=32,33–64,65–128,>128, plus actual truncation flag; no character-count proxy"},
            "reference_similarity": {"text": "test_corpus serialized text", "tokens": "NFKC then casefold then set of regex[a-z0-9]+",
                                     "score": "Jaccard intersection/union; empty union missing",
                                     "reference": "Original pretrained E5 top10 unlabelled candidates vs every frozen positive; maximum pair Jaccard per query",
                                     "bins": ["[0,.1)", "[.1,.3)", "[.3,.6)", "[.6,1)", "exact1", "missing", "no_unlabelled_candidate"],
                                     "additional": "Per random/hard seed top5 unlabelled candidate max overlap, matched positive ID and tool IDs; lexical evidence not semantic equivalence"},
            "legacy_60_cases": {"sample_seed": 20261111, "target": 60,
                                "strata": {"hard_wins": 20, "hard_losses": 20, "incomplete_ties": 20},
                                "effect": "Original three-seed mean hard-Random R@5; abs<=1e-12 ties; ties need at least one policy mean<1",
                                "duplicate_texts": "Archived norm groups, minimum query-ID representative, retain full representative map; only case sample changes, not scoring",
                                "category_quotas": "Hamilton largest remainder within effect stratum, category-name ascending ties",
                                "insufficient_stratum": "take all; redistribute deficit by largest remainder over other strata remaining populations, effect-name ascending ties, then same category quota rule",
                                "sampling_order": "effect strata hard_wins,hard_losses,incomplete_ties; categories sorted; query IDs sorted; one Random(20261111) stream",
                                "freeze_before_interpretation": True,
                                "payload": ["query/category/track", "positive metadata", "all six original runs top5 and independently rescored metrics", "fixed lexical similarity", "AI-only operation/context/constraint labels and quoted evidence", "uncertainties and counterexamples"],
                                "operation_labels": ["single_operation", "multiple_operations", "unclear"],
                                "optional_flags": ["context_dependent", "explicit_constraints"],
                                "error_labels": ["clear_function_mismatch", "constraint_or_context_mismatch", "plausible_unlabelled_alternative", "insufficient_or_conflicting_metadata", "mixed_or_no_single_explanation"],
                                "no_population_error_rate_from_quota_sample": True,
                                "existing_24_cases": "Historical seed60042 sample is a separate original artifact; do not substitute it for this fixed60 design"}},
        "human_review": {"status": "HUMAN_PENDING", "original_50": record(ROOT / "human_review/original_50_pair_review/sample_manifest.json", ROOT),
                         "new_mechanism_plan": record(ROOT / "human_review/new_mechanism_review/sample_plan.json", ROOT),
                         "new_mechanism_target": "Four strata up to20 each; no top-up if R_UNIQUE repair population is small; unique pair dedup plus exact inclusion probabilities",
                         "labels": ["N", "V", "C", "U"], "prohibited": "AI labels entered as human; sending messages to reviewers; silently adding human labels to official test ground truth",
                         "when_responses_arrive": "Preserve originals/hash/date/source, validate IDs/labels/reasons without filling omissions, then unblind; confusion table/n/raw agreement before optional kappa; initial labels and adjudication separate",
                         "rates": "V,C,U separately; V+C potential document-supported false negatives, U uncertainty; no fabricated agreement while pending"},
        "efficiency": record(profile_path, ROOT),
        "confirmation_lock": {**matrix["final_evaluation"], "canonical_filename": "locks/final_lock.json",
                              "manifest_alias_policy": "confirmation_lock names in return layout map to this one canonical lock, not a second conflicting configuration",
                              "complete_before_open": ["data validity and overlap audit", "all S2/S4 selections", "all applicable S3/S5 fitted checkpoints", "engineering fixtures", "all scoring/analysis code hashes", "all expected model/dataset/seed manifests"],
                              "first_access": "durable OPENED marker plus append-only external_access_log; retain first outputs and all technical retries"},
        "stop_rules": {"STOP_BUG": "Stop affected comparisons/confirmation; preserve attempts; minimal code fix and paired reruns; unaffected work continues",
                       "RESOURCE_LIMIT": "No reduced lengths/negatives/query pool/seed count hidden as same protocol; only preauthorized consistent resource adaptation",
                       "NO_EFFECT_INCONCLUSIVE_REVERSED": "Complete locked analysis and return; no new search, threshold, seed, model or dataset shopping",
                       "HUMAN_PENDING": "Continue all independent training/evaluation/analysis; block only human-supported semantic claims",
                       "EXTERNAL_INVALID": "NO_EXTERNAL_VALIDATION/CONFIRMATION_UNAVAILABLE; complete other work, never relabel legacy test independent",
                       "FINAL_TECHNICAL_REPAIR": "Retain first exposure, diff and all affected rescoring; scientific revision after exposure is exploratory"},
        "return_acceptance": {"all84_statuses": True, "all_grids_and_attempts": True,
                              "new_predictions": "pooled top50+all positives exact global rank/score; native menu full ranking; S0 original top10 unchanged",
                              "local_large_evidence": "all completed weights/tokenizer/config plus final query/corpus embeddings, ordered IDs,dtypes,size,sha,machine path; no deletion",
                              "offline_rebuild": "single input-root/output-dir entry from raw rankings/labels/resources/review originals with per-table source hashes and formulas",
                              "zip": "all main evidence included, return_manifest excluding itself, readable Chinese README, CRC and ZIP SHA256; any separately retained large artifacts clearly listed",
                              "claim_ledger": "supported/qualified/unsupported, evidence level, effect/interval/seeds, alternative explanations, human state and prohibited overclaims"},
        "code_sha256": sha(__file__),
    }
    write_new(plan_path, plan)
    readable = ROOT / "locks/analysis_plan_readable.txt"
    readable.write_text("CPS5801 新一轮分析计划（本轮结果出现前冻结）\n\n这是已知旧研究结果之后制定的新实验计划，不称为旧研究预注册。\n"
                        "唯一机器配置为同目录 analysis_plan.json；具体已有执行决定由 execution_decisions.json 原件及其哈希承接。\n"
                        "开发选择仅原dev；跨政策R@5同分直接固定政策序，政策内依次MRR、步数、lr、温度。\n"
                        "主外部确认只有BFCL live_multiple的四项MRR对比，五个固定seed；默认报告效应、seed样本SD、成组bootstrap区间，不做p值声明。\n"
                        "外部数据实际纳入数量与模型哈希在final_lock统一绑定；不得用预审数字代替实际最终数量。\n"
                        "人工审核始终保留空白，收到真实答复才生成一致性。所有GPU工作不因人工待办停止。\n"
                        "下面完整列出机器规则，字段值与 analysis_plan.json 一致：\n\n" + json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_new(ROOT / "locks/analysis_plan_identity.json", {"analysis_plan": record(plan_path, ROOT), "profiling_plan": record(profile_path, ROOT),
                                                          "readable": record(readable, ROOT), "frozen_at": stamp})
    print(json.dumps({"analysis_plan": str(plan_path), "sha256": sha(plan_path), "profiling_plan_sha256": sha(profile_path)}, indent=2))


if __name__ == "__main__":
    main()
