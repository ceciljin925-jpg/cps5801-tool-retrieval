"""Frozen family-specific encoders and shared auditable runtime helpers.

Model loading is offline and uses the eager attention implementation. Evaluation
does not perturb Python/NumPy/Torch RNG or the caller's train/eval mode.
"""
from __future__ import annotations

import contextlib
import datetime
import hashlib
import json
import os
import pathlib
import platform
import random
import subprocess
import sys
import time

os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer

FAMILIES = {
    'e5': {'query_prefix': 'query: ', 'document_prefix': 'passage: ', 'pooling': 'masked_mean_float32_then_L2'},
    'bge': {'query_prefix': 'Represent this sentence for searching relevant passages: ', 'document_prefix': '', 'pooling': 'CLS_float32_then_L2'},
    'qwen_reference': {'query_prefix': 'Instruct: Given a user request, retrieve tools whose documented capabilities can satisfy the request.\nQuery:', 'document_prefix': '', 'pooling': 'last_nonpadding_float32_then_L2'},
}


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def dump(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def sha_file(path):
    with pathlib.Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def sha_json(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def directory_manifest(path):
    path = pathlib.Path(path).resolve(strict=True)
    return {str(p.relative_to(path)).replace('\\', '/'): {'bytes': p.stat().st_size, 'sha256': sha_file(p)}
            for p in sorted(path.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.tmp')}


def ensure_output(path):
    path = pathlib.Path(path).resolve()
    work = pathlib.Path(__file__).resolve().parents[2]
    if path == work or work not in path.parents:
        raise ValueError(f'Output must be a descendant of task work directory: {work}')
    if 'handoff' in path.relative_to(work).parts or 'repro' in path.relative_to(work).parts:
        raise ValueError('Extension outputs cannot write to handoff or original reproduction paths')
    return path


def setup_runtime(device='cuda'):
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    if device.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA is unavailable')


def sync(device):
    if str(device).startswith('cuda'):
        torch.cuda.synchronize()


def seed_all(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)


def get_rng():
    return {'python': random.getstate(), 'numpy': np.random.get_state(), 'torch_cpu': torch.get_rng_state(),
            'torch_cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def set_rng(state):
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch_cpu'])
    if state['torch_cuda']:
        torch.cuda.set_rng_state_all(state['torch_cuda'])


@contextlib.contextmanager
def preserve_rng_and_mode(model=None):
    state = get_rng()
    training = model.training if model is not None else None
    try:
        yield
    finally:
        set_rng(state)
        if model is not None:
            model.train(training)


def runtime_record():
    import transformers
    import tokenizers
    import safetensors
    driver = None
    if torch.cuda.is_available():
        try:
            driver = subprocess.run(['nvidia-smi', '--query-gpu=driver_version', '--format=csv,noheader'],
                                    capture_output=True, text=True, check=True, timeout=15).stdout.strip()
        except Exception as error:
            driver = 'unavailable: ' + repr(error)
    return {'created_at': now(), 'python': sys.version, 'executable': sys.executable,
            'torch': torch.__version__, 'cuda': torch.version.cuda, 'transformers': transformers.__version__,
            'tokenizers': tokenizers.__version__, 'numpy': np.__version__, 'safetensors': safetensors.__version__,
            'gpu': torch.cuda.get_device_name() if torch.cuda.is_available() else None,
            'gpu_driver': driver, 'platform': platform.platform(),
            'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'), 'tf32': False,
            'cudnn_benchmark': torch.backends.cudnn.benchmark, 'num_threads': torch.get_num_threads()}


class Encoder:
    def __init__(self, family, model_path, device='cuda', load_weights=True):
        if family not in FAMILIES:
            raise ValueError(f'Unknown encoder family: {family}')
        self.family, self.device = family, device
        self.model_path = pathlib.Path(model_path).resolve(strict=True)
        self.spec = FAMILIES[family]
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, local_files_only=True)
        if family == 'qwen_reference':
            self.tokenizer.padding_side = 'left'
        self.model = AutoModel.from_pretrained(self.model_path, local_files_only=True, attn_implementation='eager').to(device) if load_weights else None
        if self.model is not None and any(p.dtype != torch.float32 for p in self.model.parameters() if p.is_floating_point()):
            self.model.float()

    def format(self, text, kind):
        if not isinstance(text, str):
            raise TypeError('Model input must be a string')
        if kind not in ('query', 'document'):
            raise ValueError(kind)
        return self.spec[kind + '_prefix'] + text

    def tokenize(self, text, kind):
        return self.tokenizer(self.format(text, kind), truncation=True, max_length=128 if kind == 'query' else 384)

    def pool(self, tokens):
        h = self.model(**tokens).last_hidden_state.float()
        if self.family == 'e5':
            mask = tokens['attention_mask'].unsqueeze(-1)
            vectors = (h * mask).sum(1) / mask.sum(1)
        elif self.family == 'bge':
            vectors = h[:, 0]
        else:
            mask = tokens['attention_mask']
            positions = torch.arange(mask.shape[1], device=mask.device).unsqueeze(0).expand_as(mask)
            last = positions.masked_fill(mask == 0, -1).max(1).values
            if torch.any(last < 0):
                raise ValueError('Empty Qwen token sequence')
            vectors = h[torch.arange(h.shape[0], device=h.device), last]
        result = torch.nn.functional.normalize(vectors, dim=-1)
        if self.family == 'qwen_reference' and result.shape[1] != 1024:
            raise ValueError(f'Unexpected Qwen embedding dimension: {result.shape[1]}')
        return result

    def encode(self, texts, kind, batch_size=32, return_stats=False):
        if not texts or batch_size < 1:
            raise ValueError('Nonempty texts and positive batch_size required')
        vectors, lengths = [], []
        start = time.perf_counter()
        with preserve_rng_and_mode(self.model):
            self.model.eval()
            with torch.inference_mode():
                for i in range(0, len(texts), batch_size):
                    formatted = [self.format(x, kind) for x in texts[i:i + batch_size]]
                    if return_stats:
                        lengths.extend(map(len, self.tokenizer(formatted, truncation=False)['input_ids']))
                    tokens = self.tokenizer(formatted, padding=True, truncation=True,
                                            max_length=128 if kind == 'query' else 384, return_tensors='pt').to(self.device)
                    vec = self.pool(tokens)
                    if not torch.isfinite(vec).all():
                        raise ValueError('Nonfinite embeddings')
                    vectors.append(vec.cpu())
            sync(self.device)
        encoded = torch.cat(vectors).float().numpy()
        if not return_stats:
            return encoded
        cap = 128 if kind == 'query' else 384
        stats = {'kind': kind, 'n': len(texts), 'token_cap_including_prefix': cap, 'full_token_lengths': lengths,
                 'truncated_count': sum(x > cap for x in lengths), 'mean_full_tokens': float(np.mean(lengths)),
                 'max_full_tokens': max(lengths), 'encoding_seconds': time.perf_counter() - start, 'batch_size': batch_size,
                 'dtype': 'float32', 'family': self.family, 'adapter': self.spec}
        return encoded, stats
