"""Lock all eligible models, then execute the single predeclared final batch.

No screening checkpoint is eligible. Technical retries require an explicit new
attempt and are retained; this program never changes a scientific configuration.
"""
import argparse
import json
import pathlib
import sys

from encoders import directory_manifest, dump, now, read, sha_file, sha_json
from execute_logged import execute
from selection_review_gate import verify_selection_reviews

ROOT=pathlib.Path(__file__).resolve().parents[1]
EXT=ROOT/'extensions'
REPRO=ROOT.parent/'repro'
DATA=REPRO/'data/main_20261025'
REGISTRY=ROOT/'final_evaluation_registry.json'
LOCK=ROOT/'locks/final_lock.json'


def datasets():
    answer=[{'dataset':'legacy_observed_test','queries_path':str(DATA/'test.json'),
             'corpus_path':str(DATA/'test_corpus.json'),'task_type':'pooled','external_final':False,
             'allowed_empty_query_ids':['mnms_query_17']}]
    for name in ('bfcl_live_multiple','bfcl_multiple','bfcl_parallel_multiple','toolhop'):
        path=ROOT/'data/external'/name
        answer.append({'dataset':name,'queries_path':str(path/'queries.json'),'corpus_path':str(path/'corpus.json'),
                       'task_type':'menu' if name.startswith('bfcl') else 'pooled','external_final':True,
                       'document_equivalence_sensitivity':name=='toolhop'})
    return answer


def final_models():
    registry=read(ROOT/'run_registry.json')
    missing=[r['run_id'] for r in registry['runs'] if r['status'] not in ('completed','failed','reused','not_applicable')]
    if missing:raise RuntimeError(f'Cannot freeze with unfinished training jobs: {missing}')
    answer=[]
    for row in registry['runs']:
        if row['stage'] not in ('S0','S1','S3','S5'):continue
        if row['status'] not in ('completed','reused'):
            raise RuntimeError('Applicable final model unavailable; explicitly resolve branch: '+row['run_id'])
        out=pathlib.Path(row['output_path'])
        training=read(out/'training.json')
        steps=row['config']['steps']
        if training['steps']!=steps or len((out/'loss.jsonl').read_text().splitlines())!=steps:
            raise RuntimeError('Actual training budget disagrees with registry: '+row['run_id'])
        checkpoint=pathlib.Path(row['checkpoint_path'])
        if row['stage']=='S0':
            if sha_file(checkpoint/'model.safetensors')!=row['checkpoint_sha256']:
                raise RuntimeError('S0 checkpoint changed after training validation')
        else:
            expected=read(out/'checkpoint_manifest.json')[f'step_{steps:04d}']
            if directory_manifest(checkpoint)!=expected:
                raise RuntimeError('Checkpoint differs from original completed-run manifest: '+row['run_id'])
            expected_ev=next(ev for ev in row['dev_evaluations'] if ev['steps']==steps)
            if sha_file(checkpoint/'model.safetensors')!=expected_ev['checkpoint_sha256']:
                raise RuntimeError('Final checkpoint differs from development checkpoint')
        answer.append({'run_id':row['run_id'],'stage':row['stage'],'family':row['family'],
                       'policy':row['config']['policy'],'seed':row['seed'],'model_path':row['checkpoint_path']})
    models=read(ROOT/'models/verified_models.json')['models']
    bge=next(m['local_dir'] for m in models if m['repo_id']=='BAAI/bge-small-en-v1.5')
    qwen=next(m['local_dir'] for m in models if m['repo_id']=='Qwen/Qwen3-Embedding-0.6B')
    for family,path in [('bm25',None),('e5',str(REPRO/'data/raw/model')),('bge',bge),('qwen_reference',qwen)]:
        answer.append({'run_id':'baseline_'+family,'stage':'BASELINE','family':family,'policy':'PRETRAINED' if path else 'BM25',
                       'seed':None,**({'model_path':path} if path else {})})
    if len(answer)!=52:raise ValueError(f'Unexpected final model count {len(answer)}; investigate, do not silently omit')
    for model in answer:
        manifest=directory_manifest(model['model_path']) if model['family']!='bm25' else {'family':'bm25','code_sha256':sha_file(EXT/'evaluate_retrieval.py')}
        model['checkpoint_manifest']=manifest
        model['checkpoint_manifest_sha256']=sha_json(manifest)
    return answer


def prepare():
    if LOCK.exists() or REGISTRY.exists():raise FileExistsError('Final lock/registry already exists; inspect/resume instead of replace')
    if (ROOT/'EXTERNAL_FINAL_OPENED.json').exists() or (ROOT/'external_access_log.jsonl').exists():
        raise RuntimeError('External results have already been opened; cannot claim a fresh lock')
    independent_reviews=verify_selection_reviews(ROOT)
    frozen_data=read(ROOT/'locks/final_dataset_manifest.json')
    for item in frozen_data['files']:
        path=(ROOT/item['path']).resolve(strict=True)
        if ROOT not in path.parents or path.stat().st_size!=item['bytes'] or sha_file(path)!=item['sha256']:
            raise RuntimeError('Previously frozen external artifact changed: '+item['path'])
    models=final_models()
    sources=datasets()
    jobs,entries=[],[]
    for dataset in sources:
        queries_sha=sha_file(dataset['queries_path']);corpus_sha=sha_file(dataset['corpus_path'])
        for model in models:
            evaluation_id=dataset['dataset']+'__'+model['run_id']
            configuration={**dataset,**{k:v for k,v in model.items() if k not in ('checkpoint_manifest','checkpoint_manifest_sha256')},
                           'evaluation_id':evaluation_id,'final_lock_path':str(LOCK),
                           'access_log_path':str(ROOT/'external_access_log.jsonl'),
                           'batch_size':4 if model['family']=='qwen_reference' else 64,
                           'query_block_size':32,'save_embeddings':True,'latency_count':0,'latency_warmups':0}
            directory=ROOT/'evaluations'/dataset['dataset']/model['run_id']
            config_path=directory/'config_attempt_01.json'
            output=directory/'attempt_01'
            dump(config_path,configuration)
            jobs.append({**{k:v for k,v in configuration.items() if k not in ('checkpoint_manifest',)},
                         'config_path':str(config_path),'config_sha256':sha_file(config_path),'output_path':str(output),'status':'pending'})
            entry={'evaluation_id':evaluation_id,'run_id':model['run_id'],'dataset':dataset['dataset'],
                   'checkpoint_manifest_sha256':model['checkpoint_manifest_sha256'],
                   'queries_sha256':queries_sha,'corpus_sha256':corpus_sha,'config_sha256':sha_file(config_path),'purpose':'final_retrieval'}
            entries.append(entry)
            if model['stage']=='BASELINE' or (model['stage'] in ('S0','S1','S3','S5') and model['seed']==42):
                entries.append({**entry,'evaluation_id':'efficiency__'+evaluation_id,'purpose':'predeclared_efficiency_5_rounds'})
    # The fixed batch-one timing plans are prepared now, before any final result.
    efficiency=[]
    for dataset in sources:
        models_for_timing=[{k:v for k,v in m.items() if k not in ('checkpoint_manifest','checkpoint_manifest_sha256')}
                           for m in models if m['stage']=='BASELINE' or (m['stage'] in ('S0','S1','S3','S5') and m['seed']==42)]
        for model in models_for_timing:
            model['evaluation_id']='efficiency__'+dataset['dataset']+'__'+model['run_id']
            model['index_batch_size']=4 if model['family']=='qwen_reference' else 64
        config={**dataset,'models':models_for_timing,'final_lock_path':str(LOCK),
                'access_log_path':str(ROOT/'external_access_log.jsonl'),'batch_size':64}
        config_path=ROOT/'efficiency'/dataset['dataset']/'config.json'
        plan_path=config_path.with_name('plan.json')
        dump(config_path,config)
        execute([sys.executable,str(EXT/'profile_efficiency.py'),'--prepare','--config',str(config_path),'--plan',str(plan_path)],
                ROOT,config_path.parent,'prepare_plan')
        efficiency.append({'dataset':dataset['dataset'],'plan_path':str(plan_path),'plan_sha256':sha_file(plan_path),
                           'models':[{'run_id':m['run_id'],'status':'pending'} for m in models_for_timing]})
        for entry in entries:
            if entry['purpose'].startswith('predeclared_efficiency') and entry['dataset']==dataset['dataset']:
                entry.pop('config_sha256',None)
                entry['profiling_plan_sha256']=sha_file(plan_path)
    lock={'schema_version':1,'lock_timestamp':now(),'no_prior_external_final_scores':True,
          'selected_extension_and_branch':read(ROOT/'locks/S2_selection.json')['selected_extension'],
          'all_selected_configs':{'e5':read(ROOT/'locks/S2_selection.json')['selection'],
                                  'bge':read(ROOT/'locks/S4_selection.json')['selection']},
          'five_confirmatory_seeds':[42,43,44,45,46],'models':models,'evaluations':entries,
          'data_and_corpus_hashes':{d['dataset']:{'query':sha_file(d['queries_path']),'corpus':sha_file(d['corpus_path'])} for d in sources},
          'external_dataset_manifest_sha256':sha_file(ROOT/'locks/final_dataset_manifest.json'),
          'analysis_plan_sha256':sha_file(ROOT/'locks/analysis_plan.json'),
          'external_eval_specs_sha256':sha_file(ROOT/'locks/external_eval_specs.json'),
          'selection_hashes':{name:sha_file(ROOT/'locks'/name) for name in ('S2_selection.json','S4_selection.json')},
          'independent_selection_reviews':independent_reviews,
          'code_sha256':{p.name:sha_file(p) for p in sorted(EXT.glob('*.py'))},
          'efficiency_plans':efficiency,
          'encoding_and_scoring_rules':'E5 mean, BGE CLS, Qwen last nonpadding;float32 eval;128/384 caps;pooled ID ties;BFCL per-menu SHA ties;BM25 native-menu IDF',
          'confirmatory_comparisons':['e5:selected-R_ID','e5:selected-B_ID','bge:selected-R_ID','bge:selected-B_ID'],
          'data_access_log':'external_access_log.jsonl; structure-only audited inputs; no prelock model scores',
          'legacy_role':'Previously observed test, exploratory historical evidence',
          'human_status':'HUMAN_PENDING'}
    dump(LOCK,lock)
    dump(LOCK.with_suffix('.sha256.json'),{'sha256':sha_file(LOCK),'created_at':now()})
    dump(REGISTRY,{'created_at':now(),'lock_sha256':sha_file(LOCK),'evaluations':jobs,'efficiency':efficiency})
    print('FINAL_LOCK_CREATED',sha_file(LOCK),'models',len(models),'evaluations',len(jobs),flush=True)


def run(include_efficiency=False):
    registry=read(REGISTRY);lock=read(LOCK)
    if registry['lock_sha256']!=sha_file(LOCK):raise RuntimeError('Final lock bytes changed')
    if verify_selection_reviews(ROOT)!=lock['independent_selection_reviews']:
        raise RuntimeError('Independent selection review evidence changed after final lock')
    for name,expected in lock['code_sha256'].items():
        if sha_file(EXT/name)!=expected:raise RuntimeError('Locked code changed: '+name)
    for job in registry['evaluations']:
        output=pathlib.Path(job['output_path'])
        entry=next(e for e in lock['evaluations'] if e['evaluation_id']==job['evaluation_id'])
        if sha_file(job['config_path'])!=entry['config_sha256']:
            raise RuntimeError('Locked evaluation config changed: '+job['evaluation_id'])
        if job['status']=='completed':
            assert read(output/'status.json')['status']=='completed'
            assert sha_file(output/'predictions.json')==job['predictions_sha256']
            assert sha_file(output/'metrics.json')==job['metrics_sha256']
            continue
        if job['status']!='pending':raise RuntimeError('Inspect technical interruption before retry: '+job['evaluation_id'])
        job.update(status='running',started_at=now());dump(REGISTRY,registry)
        try:
            execute([sys.executable,str(EXT/'evaluate_retrieval.py'),'--config',job['config_path'],'--output',job['output_path']],
                    ROOT,output.parent,'evaluate_attempt01')
            expected=len(read(job['queries_path']))
            assert read(output/'metrics.json')['n']==expected
            assert len(read(output/'predictions.json'))==expected
            job.update(status='completed',completed_at=now(),predictions_sha256=sha_file(output/'predictions.json'),
                       metrics_sha256=sha_file(output/'metrics.json'))
        except BaseException as error:
            job.update(status='interrupted' if isinstance(error,KeyboardInterrupt) else 'failed',failure_reason=repr(error),failed_at=now(),
                       process_status_path=str(output.parent/'evaluate_attempt01.process_status.json'));dump(REGISTRY,registry)
            raise
        dump(REGISTRY,registry)
        print('FINAL_EVALUATION_COMPLETED',job['evaluation_id'],flush=True)
    if include_efficiency:
        for dataset in registry['efficiency']:
            locked_plan=next(p for p in lock['efficiency_plans'] if p['dataset']==dataset['dataset'])
            if sha_file(dataset['plan_path'])!=locked_plan['plan_sha256']:
                raise RuntimeError('Locked efficiency plan changed: '+dataset['dataset'])
            for model in dataset['models']:
                if model['status']=='completed':
                    output=pathlib.Path(model['output_path'])
                    if directory_manifest(output)!=model['evidence_manifest']:
                        raise RuntimeError('Completed efficiency evidence changed')
                    continue
                if model['status']!='pending':raise RuntimeError('Inspect interrupted efficiency attempt')
                output=ROOT/'efficiency'/dataset['dataset']/model['run_id']/'attempt_01'
                model.update(status='running',started_at=now());dump(REGISTRY,registry)
                try:
                    execute([sys.executable,str(EXT/'profile_efficiency.py'),'--plan',dataset['plan_path'],'--run-id',model['run_id'],'--output',str(output)],
                            ROOT,output.parent,'profile_attempt01')
                    if read(output/'status.json')['status']!='completed':raise RuntimeError('Efficiency evidence incomplete')
                    model.update(status='completed',output_path=str(output),completed_at=now(),evidence_manifest=directory_manifest(output))
                except BaseException as error:
                    model.update(status='failed',failure_reason=repr(error),failed_at=now());dump(REGISTRY,registry)
                    raise
                dump(REGISTRY,registry)
    dump(ROOT/'final_evaluations_completed.json',{'completed_at':now(),'evaluations':len(registry['evaluations']),
                                               'efficiency_included':include_efficiency,'lock_sha256':sha_file(LOCK)})


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--efficiency',action='store_true')
    args=parser.parse_args()
    if args.prepare:prepare()
    if args.run:run(args.efficiency)
    if not args.prepare and not args.run:parser.error('Choose --prepare and/or --run')
