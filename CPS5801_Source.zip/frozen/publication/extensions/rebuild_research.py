"""One portable CPU entry point for all available research tables and figures.

Uses saved predictions, frozen labels, raw timings and source records. It does
not load model weights, train models, or rescore held-out data with a model.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', required=True, type=pathlib.Path)
    parser.add_argument('--output-dir', required=True, type=pathlib.Path)
    args = parser.parse_args()
    root, output = args.input_root.resolve(strict=True), args.output_dir.resolve()
    publication = root / 'publication' if (root / 'publication').is_dir() else root
    if output == root or output in root.parents:
        raise ValueError('Output must not replace the input root or an ancestor')
    if output.exists() and any(output.iterdir()):
        raise FileExistsError('Preserve prior rebuilds; choose an empty output directory')
    registry = read(publication / 'final_evaluation_registry.json')
    evaluations = registry['evaluations']
    profiles = [model for dataset in registry['efficiency'] for model in dataset['models']]
    if len(evaluations) != 260 or len(profiles) != 80:
        raise ValueError('Full protocol requires 260 retrieval and 80 profiling records')
    unfinished = [row for row in evaluations + profiles if row['status'] != 'completed']
    if unfinished:
        raise ValueError('Full rebuild requires all final outputs; no missing results are substituted')
    output.mkdir(parents=True, exist_ok=True)
    scripts = pathlib.Path(__file__).resolve().parent
    stages = [
        ('research', 'rebuild_all.py', []),
        ('legacy_tables', 'rebuild_legacy_tables.py', ['--include-reproduction']),
        ('efficiency', 'analyze_efficiency.py', []),
        ('negative_tables', 'rebuild_negative_tables.py', []),
    ]
    status = {'started_at': now(), 'input_root': str(root), 'output_dir': str(output),
              'status': 'running', 'stages': [], 'model_execution': False,
              'human_review': 'Read actual records; missing independent labels remain HUMAN_PENDING'}
    write(output / 'rebuild_status.json', status)
    for name, script, extra in stages:
        command = [sys.executable, str(scripts / script), '--input-root', str(root),
                   '--output-dir', str(output / name), *extra]
        record = {'name': name, 'command': command, 'cwd': str(output),
                  'script_sha256': sha(scripts / script), 'started_at': now()}
        status['stages'].append(record)
        write(output / 'rebuild_status.json', status)
        started = time.perf_counter()
        try:
            with (output / (name + '.stdout.log')).open('w', encoding='utf-8') as stdout, \
                 (output / (name + '.stderr.log')).open('w', encoding='utf-8') as stderr:
                process = subprocess.run(command, cwd=output, stdout=stdout, stderr=stderr,
                                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            record.update(exit_code=process.returncode, seconds=time.perf_counter() - started,
                          ended_at=now())
            if process.returncode:
                raise RuntimeError('Rebuild failed: ' + name + '; inspect preserved stderr/stdout')
            if name == 'research':
                evidence = read(output / name / 'rebuild_status.json')
                if evidence.get('pending_evaluations') or evidence.get('verification_failures'):
                    raise RuntimeError('Research tables contain pending or invalid evidence')
            if name == 'legacy_tables':
                evidence = read(output / name / 'rebuild_status.json')
                if evidence.get('original_main_prediction_files') != 16 or evidence.get('reproduction_prediction_files') != 16 or evidence.get('status') != 'PASS_COMPLETE_AVAILABLE_LEGACY_TABLES':
                    raise RuntimeError('Original and reproduction tables are incomplete')
            if name == 'efficiency':
                evidence = read(output / name / 'status.json')
                if evidence.get('completed_accuracy_evaluations') != 260 or evidence.get('completed_profiles') != 80 or evidence.get('pending') or evidence.get('failures'):
                    raise RuntimeError('Efficiency analysis did not validate all frozen evidence')
            if name == 'negative_tables':
                evidence = read(output / name / 'status.json')
                if evidence.get('status') != 'PASS_COMPLETE_NEGATIVE_INPUT_TABLES' or evidence.get('policy_seed_cells') != 36 or evidence.get('replacement_slots') != 4830:
                    raise RuntimeError('Negative input and replacement diagnostics are incomplete')
            record['status'] = 'completed'
        except BaseException as error:
            record.update(status='failed_or_interrupted', error=repr(error), ended_at=now())
            status.update(status='failed_or_interrupted', ended_at=now())
            write(output / 'rebuild_status.json', status)
            raise
        write(output / 'rebuild_status.json', status)
    status.update(status='PASS_COMPLETE_PORTABLE_REBUILD', ended_at=now(),
                  retrieval_records=260, profiling_records=80,
                  source_maps=['research/table_provenance.json', 'legacy_tables/table_evidence_map.json',
                               'efficiency/table_provenance.json', 'negative_tables/table_provenance.json'])
    write(output / 'rebuild_status.json', status)
    print(json.dumps(status, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
