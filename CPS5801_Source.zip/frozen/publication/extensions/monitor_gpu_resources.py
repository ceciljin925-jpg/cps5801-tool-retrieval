"""Read-only local GPU telemetry until the research workers finish or stop.

No model, service/API, power-plan change, or GPU setting mutation is performed.
"""
import json
import pathlib
import shutil
import subprocess
import time

from execute_logged import now, dump

ROOT = pathlib.Path(__file__).resolve().parents[1]
FIELDS = ['timestamp', 'name', 'pstate', 'temperature.gpu', 'utilization.gpu',
          'utilization.memory', 'memory.used', 'memory.total', 'clocks.sm',
          'clocks.mem', 'power.draw', 'power.limit', 'fan.speed']


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    output = ROOT / 'provenance/gpu_resource_timeseries.jsonl'
    if output.exists():
        raise FileExistsError('Keep the existing resource timeline')
    started = time.monotonic()
    count = 0
    reason = None
    with output.open('x', encoding='utf-8') as stream:
        while time.monotonic() - started < 48 * 3600:
            record = {'observed_at': now(), 'fields': FIELDS}
            try:
                controller = read(ROOT / 'research_controller_status.json')
                cpu = read(ROOT / 'finish_cpu_status.json')
                registry = read(ROOT / 'run_registry.json')
                record.update(controller_phase=controller['phase'], cpu_phase=cpu['phase'],
                              active_runs=[{'run_id': row['run_id'], 'phase': row.get('active_phase')}
                                           for row in registry['runs'] if row['status'] == 'running'],
                              disk_free_bytes=shutil.disk_usage(ROOT).free)
                result = subprocess.run(['nvidia-smi', '--query-gpu=' + ','.join(FIELDS),
                                         '--format=csv,noheader,nounits'], capture_output=True,
                                        text=True, timeout=10,
                                        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                record.update(exit_code=result.returncode, gpu_rows=result.stdout.strip().splitlines(),
                              stderr=result.stderr.strip())
                if controller['phase'] == 'failed_or_interrupted' or cpu['phase'] == 'failed_or_interrupted':
                    reason = 'worker_reported_failure'
                elif cpu['phase'] == 'ready_for_agent_scientific_review_and_final_packaging':
                    reason = 'workers_finished_for_review'
            except Exception as error:
                record['observation_error'] = repr(error)
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
            stream.flush()
            count += 1
            if reason:
                break
            time.sleep(60)
    dump(ROOT / 'provenance/gpu_resource_monitor_status.json',
         {'ended_at': now(), 'samples': count, 'stop_reason': reason or '48_hour_bound',
          'scope': 'Observed telemetry only. Does not establish the cause of speed changes.'})


if __name__ == '__main__':
    main()
