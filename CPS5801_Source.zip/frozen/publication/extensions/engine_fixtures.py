"""Scientific engineering fixtures. CPU scoring, or GPU old/new/RNG trajectories.

GPU fixture runs three updates across an actual frozen epoch boundary and never
changes production data. It invokes the ORIGINAL frozen train_run function.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import pathlib
import random
import sys

from encoders import (Encoder, dump, ensure_output, now, preserve_rng_and_mode, read,
                      setup_runtime, sha_file, sha_json, np, torch)
from evaluate_retrieval import prepare_rank_context, rank_scores, rank_with_context, row_metrics
from train_configurable import train


def tensor_list_digest(tensors):
    digest = hashlib.sha256()
    for tensor in tensors:
        if tensor is None:
            digest.update(b'None')
        else:
            array = tensor.detach().cpu().contiguous().numpy()
            digest.update(str(array.shape).encode())
            digest.update(str(array.dtype).encode())
            digest.update(array.tobytes())
    return digest.hexdigest()


@contextlib.contextmanager
def capture_updates(trace):
    old_step = torch.optim.AdamW.step
    old_clip = torch.nn.utils.clip_grad_norm_
    pending = {}
    def clip(parameters, *args, **kwargs):
        parameters = list(parameters)
        norm = old_clip(parameters, *args, **kwargs)
        pending['clipped_gradient_sha256'] = tensor_list_digest([p.grad for p in parameters])
        return norm
    def step(optimizer, *args, **kwargs):
        result = old_step(optimizer, *args, **kwargs)
        parameters = [p for group in optimizer.param_groups for p in group['params']]
        trace.append({'step': len(trace) + 1, 'parameter_sha256': tensor_list_digest(parameters), **pending})
        return result
    torch.optim.AdamW.step = step
    torch.nn.utils.clip_grad_norm_ = clip
    try:
        yield
    finally:
        torch.optim.AdamW.step = old_step
        torch.nn.utils.clip_grad_norm_ = old_clip


def cpu_fixtures():
    ids = [f't{i:03d}' for i in range(60)]
    scores = np.linspace(1, 0, 60, dtype=np.float32)
    scores[0:3] = 1
    scores[55:58] = -1
    scores[59] = -2
    positives = ['t001', 't059']
    actual = rank_scores(scores, ids, positives)
    reference_order = sorted(range(60), key=lambda i: (-float(scores[i]), ids[i]))
    reference = [ids[i] for i in reference_order]
    assert actual['top50'] == reference[:50]
    assert [p['rank'] for p in actual['positive_ranks']] == [2, 60]
    assert actual['recall@1'] == 0 and actual['recall@3'] == 0.5 and actual['mrr@10'] == 0.5
    assert actual['average_precision'] == (1 / 2 + 2 / 60) / 2
    menu = ['t002', 't000', 't001']
    keys = {'t002': 'a', 't000': 'c', 't001': 'b'}
    result = rank_scores(scores, ids, ['t001'], menu, keys, 3)
    assert result['top50'] == ['t002', 't001', 't000']
    assert result['mrr'] == 0.5
    duplicate_rejected = False
    try:
        rank_scores(scores, ids, ['t001', 't001'])
    except ValueError:
        duplicate_rejected = True
    assert duplicate_rejected
    assert rank_with_context(scores, positives, prepare_rank_context(ids)) == actual
    assert rank_with_context(scores, ['t001'], prepare_rank_context(ids, menu, keys), 3) == result
    # Unsorted/noncontiguous string IDs, ties, multigold, positive beyond top50.
    scrambled = ids[::2] + ids[1::2]
    context = prepare_rank_context(scrambled)
    assert rank_with_context(scores, ['t001', 't058', 't003'], context) == rank_scores(scores, scrambled, ['t001', 't058', 't003'])
    for offset in range(5):
        deterministic_scores = np.asarray([(i * 13 + offset) % 7 for i in range(60)], dtype=np.float32)
        assert rank_with_context(deterministic_scores, positives, context) == rank_scores(deterministic_scores, scrambled, positives)
    # Integer-valued float32 dot products guarantee exact reference equality;
    # compare blocked matrix scoring and stable ranking including tied inputs.
    qs = np.array([[1, 0, 1], [0, 1, 1], [1, 1, 0]], np.float32)
    ds = np.array([[i % 3, i % 5, i % 7] for i in range(60)], np.float32)
    full = qs @ ds.T
    for qblock in (1, 2, 3):
        blocked = np.concatenate([qs[i:i + qblock] @ ds.T for i in range(0, 3, qblock)])
        assert np.array_equal(full, blocked)
        for a, b in zip(full, blocked):
            assert rank_scores(a, ids, positives) == rank_scores(b, ids, positives)
    return {'passed': True, 'fixtures': ['macro multigold coverage', 'MRR cutoff vs untruncated', 'AP',
            'duplicate positive rejection', 'positive beyond saved top50 has exact rank',
            'per-menu frozen ties independent of original order', 'blocked scores vs full matrix sort'],
            'scope': 'CPU deterministic scoring fixtures; not neural numerical cross-hardware equivalence'}


def gpu_fixtures(repro, output):
    repro = pathlib.Path(repro).resolve(strict=True)
    out = ensure_output(output)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Fixture attempt must be new')
    out.mkdir(parents=True, exist_ok=True)
    setup_runtime('cuda')
    scripts = repro / 'scripts'
    sys.path.insert(0, str(scripts))
    original = importlib.import_module('main_training_engine')
    original.R = out / 'original_engine'
    original.event = lambda kind, **kw: print('legacy_fixture', kind, kw, flush=True)
    data = repro / 'data/main_20261025'
    schedule = read(data / 'shared_schedule_seed42.json')[9976:9976 + 96]
    assert len({s['epoch'] for s in schedule[:32]}) == 2
    qids = {s['query_id'] for s in schedule}
    train_rows = [q for q in read(data / 'train.json') if q['id'] in qids]
    corpus = read(data / 'corpus.json')
    all_neg = read(data / 'negatives_seed42.json')
    negatives = {qid: all_neg[qid] for qid in qids}
    dump(out / 'fixture_schedule.json', schedule)
    dump(out / 'fixture_train.json', train_rows)
    dump(out / 'fixture_negatives.json', negatives)
    tokenizer = original.base.AutoTokenizer.from_pretrained(original.base.MODEL, local_files_only=True)
    legacy_trace = []
    with capture_updates(legacy_trace):
        run_id, model, legacy_stats = original.train_run('random', 42, tokenizer, train_rows, corpus, schedule, negatives)
    del model
    torch.cuda.empty_cache()
    config = {'run_id': 'engineering_fixture', 'stage': 'fixture', 'family': 'e5', 'policy': 'random', 'seed': 42,
              'model_path': str(original.base.MODEL), 'train_path': str(out / 'fixture_train.json'),
              'corpus_path': str(data / 'corpus.json'), 'schedule_path': str(out / 'fixture_schedule.json'),
              'negatives_path': str(out / 'fixture_negatives.json'), 'lr': 2e-5, 'temperature': 0.05,
              'steps': 3, 'checkpoint_steps': [3], 'resume_every': 1, 'fixture': True}
    dump(out / 'fixture_config.json', config)
    new_trace = []
    with capture_updates(new_trace):
        new_stats = train(config, out / 'new_engine')
    torch.cuda.empty_cache()
    perturbed_trace = []
    def intervening_eval(step, encoder, optimizer, row):
        if step == 1:
            with preserve_rng_and_mode(encoder.model):
                random.random()
                np.random.random(7)
                torch.rand(7)
                torch.rand(7, device='cuda')
                encoder.encode([train_rows[0]['query']], 'query', 1)
            assert encoder.model.training
    with capture_updates(perturbed_trace):
        rng_stats = train(config, out / 'new_engine_with_guarded_eval', after_update=intervening_eval)
    torch.cuda.empty_cache()
    interrupted_trace, resumed_trace = [], []
    def interrupt_after_uncommitted_update(step, encoder, optimizer, row):
        if step == 2:
            raise RuntimeError('INTENTIONAL_ENGINEERING_INTERRUPTION_AFTER_UNCOMMITTED_UPDATE')
    try:
        with capture_updates(interrupted_trace):
            train(config, out / 'resume_fixture', after_update=interrupt_after_uncommitted_update)
    except RuntimeError as error:
        if str(error) != 'INTENTIONAL_ENGINEERING_INTERRUPTION_AFTER_UNCOMMITTED_UPDATE':
            raise
    else:
        raise AssertionError('Expected controlled interruption')
    torch.cuda.empty_cache()
    with capture_updates(resumed_trace):
        resume_stats = train(config, out / 'resume_fixture', resume=True)
    torch.cuda.empty_cache()
    legacy_loss = [__import__('json').loads(line) for line in (original.R / run_id / 'loss.jsonl').read_text().splitlines()]
    new_loss = [__import__('json').loads(line) for line in (out / 'new_engine/loss.jsonl').read_text().splitlines()]
    perturbed_loss = [__import__('json').loads(line) for line in (out / 'new_engine_with_guarded_eval/loss.jsonl').read_text().splitlines()]
    differences = []
    for i in range(3):
        differences.append({'step': i + 1, 'loss_abs_difference': abs(legacy_loss[i]['loss'] - new_loss[i]['loss']),
                            'grad_norm_abs_difference': abs(legacy_loss[i]['grad_norm'] - new_loss[i]['grad_norm']),
                            'parameters_exact': legacy_trace[i]['parameter_sha256'] == new_trace[i]['parameter_sha256'],
                            'clipped_gradients_exact': legacy_trace[i]['clipped_gradient_sha256'] == new_trace[i]['clipped_gradient_sha256'],
                            'guarded_eval_parameters_exact': new_trace[i]['parameter_sha256'] == perturbed_trace[i]['parameter_sha256'],
                            'guarded_eval_loss_abs_difference': abs(new_loss[i]['loss'] - perturbed_loss[i]['loss'])})
    passed = all(row['loss_abs_difference'] == 0 and row['grad_norm_abs_difference'] == 0
                 and row['parameters_exact'] and row['clipped_gradients_exact'] and row['guarded_eval_parameters_exact']
                 and row['guarded_eval_loss_abs_difference'] == 0 for row in differences)
    resume_exact = all(resumed_trace[i]['parameter_sha256'] == new_trace[i + 1]['parameter_sha256']
                       and resumed_trace[i]['clipped_gradient_sha256'] == new_trace[i + 1]['clipped_gradient_sha256']
                       for i in range(2))
    preserved_tail = list((out / 'resume_fixture/interrupted_tails').glob('*/uncommitted_loss_tail.jsonl'))
    assert len(preserved_tail) == 1 and len(preserved_tail[0].read_text().splitlines()) == 1
    passed = passed and resume_exact
    report = {'passed': passed, 'created_at': now(), 'scope': 'three-update same-environment fixture; does not prove 625/1250-step cache equivalence',
              'cross_epoch_first_batch': True, 'microbatch': 8, 'accumulation': 4, 'schedule_original_slice': [9976, 10072],
              'original_engine_sha256': sha_file(scripts / 'main_training_engine.py'), 'differences': differences,
              'legacy_trace': legacy_trace, 'new_trace': new_trace, 'guarded_eval_trace': perturbed_trace,
              'resume_exact': resume_exact, 'resume_trace': resumed_trace, 'interrupted_trace': interrupted_trace,
              'preserved_uncommitted_tail': str(preserved_tail[0]), 'resume_training_stats': resume_stats,
              'legacy_training_stats': legacy_stats, 'new_training_stats': new_stats, 'guarded_eval_training_stats': rng_stats}
    dump(out / 'gpu_fixture_report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', required=True, choices=['cpu', 'gpu'])
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--repro-root', type=pathlib.Path)
    args = parser.parse_args()
    if args.mode == 'cpu':
        report = cpu_fixtures()
        dump(ensure_output(args.output), report)
    else:
        if args.repro_root is None:
            parser.error('--repro-root is required for GPU fixture')
        report = gpu_fixtures(args.repro_root, args.output)
    print(__import__('json').dumps({'passed': report['passed'], 'output': str(args.output)}, indent=2))
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
