"""Read-only CPU diagnosis of historical BM25 float32/set-order differences.

Uses the unchanged reproduction common.BM25 implementation, controlled child
PYTHONHASHSEED values, canonical/reversed column orders and float64 references.
No S0 file is modified and no GPU/model/external-final data is accessed.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import hashlib
import importlib.util
import json
import math
import os
import pathlib
import platform
import subprocess
import sys
import time

import numpy as np
import scipy

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
PACKAGE = ROOT.parent / 'handoff/CPS5801_PUBLICATION_HANDOFF_20261112'
ORIGINAL = PACKAGE / 'archive/CPS5801_HANDOFF_20261025/CPS5801'


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def stamp():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()


def score_columns(index, columns, dtype=None):
    matrix = index.mat[:, columns]
    if dtype is not None:
        matrix = matrix.astype(dtype)
    return np.asarray(matrix.sum(axis=1)).ravel()


def top_record(scores, corpus_ids, k=10):
    order = np.argsort(-scores, kind='stable')[:k]
    return {'top10': [corpus_ids[i] for i in order], 'scores': scores[order].tolist()}


def score_agreement(result, saved):
    actual = dict(zip(result['top10'], result['scores'], strict=True))
    expected = dict(zip(saved['top10'], saved['scores'], strict=True))
    shared = set(actual) & set(expected)
    return {'top10_exact': result['top10'] == saved['top10'],
            'top10_scores_exact': result['top10'] == saved['top10'] and result['scores'] == saved['scores'],
            'maximum_same_ID_score_difference': max((abs(actual[tid] - expected[tid]) for tid in shared), default=None)}


def investigate(output, seeds):
    out = pathlib.Path(output).resolve()
    if ROOT not in out.parents or out.exists():
        raise ValueError('Choose a new diagnostic attempt below publication work directory')
    out.mkdir(parents=True)
    started = time.perf_counter()
    paths = {'original_common': ORIGINAL / 'scripts/common.py', 'reproduction_common': REPRO / 'scripts/common.py',
             'original_corpus': ORIGINAL / 'data/main_20261025/corpus.json', 'reproduction_corpus': REPRO / 'data/main_20261025/corpus.json',
             'original_dev': ORIGINAL / 'data/main_20261025/dev.json', 'reproduction_dev': REPRO / 'data/main_20261025/dev.json',
             'original_prediction': ORIGINAL / 'results/main_20261025/M01_bm25/predictions.json',
             'reproduction_prediction': REPRO / 'results/main_20261025/M01_bm25/predictions.json'}
    hashes = {name: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in paths.items()}
    for key in ('common', 'corpus', 'dev'):
        if hashes['original_' + key]['sha256'] != hashes['reproduction_' + key]['sha256']:
            raise ValueError('Cannot attribute numerical differences with changed input/code: ' + key)
    original, reproduction = read(paths['original_prediction']), read(paths['reproduction_prediction'])
    if [row['id'] for row in original] != [row['id'] for row in reproduction]:
        raise ValueError('Prediction row order differs')
    corpus, queries = read(paths['reproduction_corpus']), read(paths['reproduction_dev'])
    if [row['id'] for row in queries] != [row['id'] for row in original]:
        raise ValueError('Prediction/query alignment differs')
    corpus_ids = [doc['id'] for doc in corpus]
    if corpus_ids != sorted(corpus_ids):
        raise ValueError('Original stable sort requires sorted corpus IDs')
    spec = importlib.util.spec_from_file_location('unchanged_bm25_diagnostic_common', paths['reproduction_common'])
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    index_started = time.perf_counter()
    bm25 = common.BM25([doc['text'] for doc in corpus])
    index_seconds = time.perf_counter() - index_started
    corpus_map = {tid: i for i, tid in enumerate(corpus_ids)}
    metrics = ['recall@1', 'recall@3', 'recall@5', 'recall@10', 'mrr@10']
    ranking_changed, score_changed, maximum_delta = [], [], 0.0
    aggregate_metric_difference = {key: float(np.mean([row[key] for row in reproduction]) - np.mean([row[key] for row in original])) for key in metrics}
    per_query = []
    for old, new in zip(original, reproduction, strict=True):
        shared = set(old['top10']) & set(new['top10'])
        old_scores, new_scores = dict(zip(old['top10'], old['scores'])), dict(zip(new['top10'], new['scores']))
        delta = max((abs(old_scores[tid] - new_scores[tid]) for tid in shared), default=0.0)
        maximum_delta = max(maximum_delta, delta)
        if old['top10'] != new['top10']:
            ranking_changed.append(old['id'])
        if delta != 0:
            score_changed.append(old['id'])
        per_query.append({'query_id': old['id'], 'top10_exact': old['top10'] == new['top10'], 'maximum_same_ID_score_difference': delta,
                          'metric_differences': {key: new[key] - old[key] for key in metrics}})
    dump(out / 'all_saved_prediction_differences.json', per_query)
    by_query, by_old, by_new = ({row['id']: row for row in data} for data in (queries, original, reproduction))
    diagnoses = []
    for qid in ranking_changed:
        query, old, new = by_query[qid], by_old[qid], by_new[qid]
        folder = out / qid
        folder.mkdir()
        query_words = common.words(query['query'])
        word_path = folder / 'query_word_sequence.json'
        dump(word_path, query_words)
        query_unique_words = set(query_words)
        controlled = []
        for seed in seeds:
            environment = os.environ.copy()
            environment['PYTHONHASHSEED'] = str(seed)
            child = subprocess.run([sys.executable, '-c',
                 'import json,sys; print(json.dumps(list(set(json.load(open(sys.argv[1],encoding="utf-8"))))))', str(word_path)],
                 env=environment, capture_output=True, text=True, check=True,
                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            words = json.loads(child.stdout)
            if set(words) != query_unique_words:
                raise ValueError('Controlled hash worker changed lexical terms')
            controlled.append({'name': f'PYTHONHASHSEED_{seed}', 'python_hash_seed': seed, 'words': words})
        controlled.extend([
            {'name': 'lexical_word_ascending', 'words': sorted(query_unique_words)},
            {'name': 'lexical_word_descending', 'words': sorted(query_unique_words, reverse=True)},
            {'name': 'vocabulary_column_ascending', 'words': sorted([w for w in query_unique_words if w in bm25.vocab], key=bm25.vocab.get)},
            {'name': 'vocabulary_column_descending', 'words': sorted([w for w in query_unique_words if w in bm25.vocab], key=bm25.vocab.get, reverse=True)},
        ])
        candidate_ids = sorted(set(old['top10']) | set(new['top10']))
        candidate_indices = [corpus_map[tid] for tid in candidate_ids]
        records, all_candidate_scores = [], []
        for order in controlled:
            columns = [bm25.vocab[word] for word in order['words'] if word in bm25.vocab]
            scores = score_columns(bm25, columns)
            if scores.dtype != np.float32:
                raise ValueError('Original accumulation unexpectedly not float32')
            top = top_record(scores, corpus_ids)
            candidate_scores = {tid: float(scores[corpus_map[tid]]) for tid in candidate_ids}
            records.append({**order, 'vocabulary_columns': columns, **top, 'candidate_scores': candidate_scores,
                            'matches_original': score_agreement(top, old), 'matches_reproduction': score_agreement(top, new)})
            all_candidate_scores.append(scores[candidate_indices])
        canonical_words = sorted([word for word in query_unique_words if word in bm25.vocab], key=bm25.vocab.get)
        canonical_columns = [bm25.vocab[word] for word in canonical_words]
        float64_scores = score_columns(bm25, canonical_columns, np.float64)
        float64_reverse = score_columns(bm25, canonical_columns[::-1], np.float64)
        quantized_weights = bm25.mat[candidate_indices, :][:, canonical_columns].toarray()
        doc_lengths = np.asarray([len(common.words(doc['text'])) for doc in corpus], dtype=np.float64)
        mean_length = float(doc_lengths.mean())
        document_frequencies = np.diff(bm25.mat.indptr)
        terms = []
        analytical_sums = {}
        for row_index, tid in enumerate(candidate_ids):
            document_index = corpus_map[tid]
            counts = collections.Counter(common.words(corpus[document_index]['text']))
            double_terms = []
            for term_index, word in enumerate(canonical_words):
                frequency = counts[word]
                df = int(document_frequencies[bm25.vocab[word]])
                idf = math.log1p((len(corpus) - df + 0.5) / (df + 0.5))
                analytical = idf * frequency * 2.5 / (frequency + 1.5 * (0.25 + 0.75 * doc_lengths[document_index] / mean_length)) if frequency else 0.0
                double_terms.append(analytical)
                terms.append({'candidate_id': tid, 'query_term': word, 'vocabulary_column': bm25.vocab[word],
                              'document_term_count': frequency, 'document_length': int(doc_lengths[document_index]),
                              'document_frequency': df, 'float32_stored_term_weight': float(quantized_weights[row_index, term_index]),
                              'analytical_float64_term_weight': analytical})
            analytical_sums[tid] = math.fsum(double_terms)
        with (folder / 'candidate_term_contributions.csv').open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(terms[0]))
            writer.writeheader()
            writer.writerows(terms)
        numerical_values = np.stack(all_candidate_scores)
        score_ranges = {tid: {'minimum': float(numerical_values[:, i].min()), 'maximum': float(numerical_values[:, i].max()),
                              'range': float(np.ptp(numerical_values[:, i])), 'float32_ulp_at_score': float(np.spacing(np.float32(old['scores'][0]))),
                              'float64_sum_of_stored_float32_weights': float(float64_scores[corpus_map[tid]]),
                              'analytical_float64_BM25_before_term_quantization': analytical_sums[tid]}
                        for i, tid in enumerate(candidate_ids)}
        original_rank_orders = [record['name'] for record in records if record['matches_original']['top10_exact']]
        reproduction_rank_orders = [record['name'] for record in records if record['matches_reproduction']['top10_exact']]
        diagnosis = {'query_id': qid, 'query': query['query'], 'positives': query['positives'],
                     'original_saved': old, 'reproduction_saved': new,
                     'controlled_orders': records, 'original_top10_recreated_by': original_rank_orders,
                     'reproduction_top10_recreated_by': reproduction_rank_orders,
                     'both_observed_rankings_created_by_changing_only_term_accumulation_order': bool(original_rank_orders and reproduction_rank_orders),
                     'candidate_score_ranges': score_ranges,
                     'float64_quantized_weight_reference': {**top_record(float64_scores, corpus_ids),
                         'forward_vs_reverse_max_abs_difference': float(np.max(np.abs(float64_scores - float64_reverse))),
                         'meaning': 'same existing float32 term weights promoted tofloat64 before summing; separates accumulation order from BM25 weight construction'},
                     'source_documents': [corpus[corpus_map[tid]] for tid in candidate_ids]}
        dump(folder / 'order_experiment.json', diagnosis)
        diagnoses.append({key: diagnosis[key] for key in ('query_id', 'original_top10_recreated_by', 'reproduction_top10_recreated_by',
                         'both_observed_rankings_created_by_changing_only_term_accumulation_order')})
        print('DIAGNOSED_BM25_QUERY', qid, diagnoses[-1], flush=True)
    # Canonical column order is chosen independently of measured quality. Record
    # its development-only numerical consequences without changing any result.
    canonical_predictions = []
    for query in queries:
        columns = sorted(bm25.vocab[word] for word in set(common.words(query['query'])) if word in bm25.vocab)
        top = top_record(score_columns(bm25, columns), corpus_ids)
        canonical_predictions.append({'id': query['id'], 'positives': query['positives'], **top,
                                      **common.metrics(top['top10'], query['positives'])})
    dump(out / 'diagnostic_only_canonical_column_dev_predictions.json', canonical_predictions)
    canonical_means = {key: float(np.mean([row[key] for row in canonical_predictions])) for key in metrics}
    canonical_comparison = {'metrics': canonical_means,
        'delta_from_original_saved': {key: canonical_means[key] - float(np.mean([row[key] for row in original])) for key in metrics},
        'delta_from_reproduction_saved': {key: canonical_means[key] - float(np.mean([row[key] for row in reproduction])) for key in metrics},
        'scope': 'engineering diagnostic on already-observed development set, not substituted into S0 results'}
    matrix_hashes = {name: hashlib.sha256(getattr(bm25.mat, name).tobytes()).hexdigest() for name in ('data', 'indices', 'indptr')}
    report = {'created_at': stamp(), 'status': 'DIAGNOSED' if all(x['both_observed_rankings_created_by_changing_only_term_accumulation_order'] for x in diagnoses) else 'PARTIALLY_DIAGNOSED',
              'data_scope': 'original development BM25 only; no GPU, training, test, or external-final inference',
              'source_files_unchanged_and_identical': hashes, 'queries': len(queries), 'corpus': len(corpus),
              'saved_top10_changed_queries': ranking_changed, 'saved_same_ID_score_changed_query_count': len(score_changed),
              'saved_maximum_same_ID_score_difference': maximum_delta,
              'saved_aggregate_metric_differences': aggregate_metric_difference,
              'diagnoses': diagnoses, 'controlled_python_hash_seeds': seeds, 'canonical_column_order_dev': canonical_comparison,
              'sparse_matrix_identity': {'dtype': str(bm25.mat.dtype), 'shape': list(bm25.mat.shape), 'component_sha256': matrix_hashes},
              'environment': {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__, 'platform': platform.platform(),
                              'parent_PYTHONHASHSEED': os.environ.get('PYTHONHASHSEED', 'not explicitly fixed')},
              'mechanism': 'common.BM25.scores iterates a Python set of query words; process hash salt changes selected sparse-column order; SciPy sums stored float32 term weights in that order; nonassociative float32 accumulation can split near ties before stable ID tie-breaking.',
              'limitations': ['Historical process hash salt was not logged, so the historical exact token permutation cannot be recovered.',
                              'Controlled order intervention diagnoses this observed ranking mismatch; it does not justify attributing unrelated model differences to numerical randomness.',
                              'Float64 references are diagnostics, not a change to the authorized float32 primary scoring precision.'],
              'recommended_extension_fix_pending_approval': 'Use sorted vocabulary column indices before float32 sparse summation in extension BM25 and matching efficiency scoring. Keep frozen S0 unchanged. Prove cross-PYTHONHASHSEED equality on synthetic and development inputs, record code change before final lock.',
              'index_seconds': index_seconds, 'total_seconds': time.perf_counter() - started,
              'diagnostic_code_sha256': sha(__file__)}
    # Verify this read-only diagnostic did not touch any source file byte.
    for name, path in paths.items():
        if sha(path) != hashes[name]['sha256']:
            raise RuntimeError('A source file changed during read-only diagnosis: ' + name)
    dump(out / 'bm25_numerical_diagnosis.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--hash-seeds', nargs='+', type=int, default=list(range(32)))
    args = parser.parse_args()
    result = investigate(args.output, args.hash_seeds)
    print(json.dumps({key: result[key] for key in ('status', 'saved_top10_changed_queries', 'saved_maximum_same_ID_score_difference', 'saved_aggregate_metric_differences', 'total_seconds')}, indent=2))


if __name__ == '__main__':
    main()
