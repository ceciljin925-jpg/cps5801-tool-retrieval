"""Link existing AI notes only after exact original/reproduction case evidence checks."""
import hashlib
import json
import pathlib

from execute_logged import dump, now

ROOT = pathlib.Path(__file__).resolve().parents[1] / 'analysis/legacy_errors'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    original_path, reproduction_path = ROOT / 'original/cases.json', ROOT / 'reproduction/cases.json'
    original = {case['case_id']: case for case in read(original_path)}
    reproduction = {case['case_id']: case for case in read(reproduction_path)}
    assert len(original) == len(reproduction) == 60 and original.keys() == reproduction.keys()
    fields = ['query_id', 'query', 'category', 'track', 'sample_design', 'positives',
              'reference_similarity', 'reference_similarity_stratum', 'six_run_evidence']
    for case_id in original:
        assert all(original[case_id][field] == reproduction[case_id][field] for field in fields)
        assert original[case_id]['reviewer_type'] == 'AI-only'
    review = read(ROOT / 'ai_proxy/review_status.json')
    assert review['status'] == 'AI_ONLY_REVIEW_COMPLETED_HUMAN_PENDING'
    target = ROOT / 'reproduction/semantic_annotation_reuse.json'
    if target.exists():
        raise FileExistsError('Preserve existing annotation reuse record')
    dump(target, {'recorded_at': now(), 'status': 'EXISTING_AI_NOTES_APPLY_TO_IDENTICAL_CASE_EVIDENCE',
                  'case_count': 60, 'exact_evidence_fields': fields,
                  'case_ids': sorted(original), 'original_case_path': '../original/cases.json',
                  'original_case_sha256': sha(original_path),
                  'reproduction_case_sha256': sha(reproduction_path),
                  'existing_AI_review_status_sha256': sha(ROOT / 'ai_proxy/review_status.json'),
                  'actual_AI_review_completed_at': review['completion_utc'],
                  'new_semantic_reviews_performed': 0, 'independent_human_reviews': 0,
                  'primary_labels_changed': False,
                  'limitations': 'Original AI-only notes are reused through this explicit link because all query/documents/six-model rankings and scores are identical. This is neither fresh independent validation nor human review. New methods are not covered.'})
    status_path = ROOT / 'reproduction/status.json'
    status = read(status_path)
    status.update(semantic_review='EXISTING_AI_REVIEW_LINKED_AFTER_EXACT_EVIDENCE_IDENTITY',
                  semantic_review_link='semantic_annotation_reuse.json', human_review='HUMAN_PENDING',
                  human_completed_count=0, new_semantic_reviews_performed=0)
    dump(status_path, status)
    print('Linked existing AI notes to exactly identical60-case reproduction evidence; no new labels created.')


if __name__ == '__main__':
    main()
