"""Create an explicit, durable task registry and pre-execution decisions."""
import datetime
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
PACKAGE = ROOT.parent / 'handoff' / 'CPS5801_PUBLICATION_HANDOFF_20261112'


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write_new(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    matrix = json.loads((PACKAGE / 'experiment_matrix.json').read_text(encoding='utf-8'))
    stamp = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
    write_new(ROOT / 'run_registry.json', {
        'plan_id': matrix['plan_id'], 'created_at': stamp,
        'matrix_sha256': sha(PACKAGE / 'experiment_matrix.json'),
        'runs': [{**job, 'status': 'pending', 'attempts': [], 'dev_evaluations': []}
                 for job in matrix['planned_training_jobs']]})
    write_new(ROOT / 'locks' / 'execution_decisions.json', {
        'created_at': stamp, 'before_new_training_and_development_scores': True,
        'source': str(PACKAGE), 'source_archive_read_only': True,
        's0_engine': 'unchanged archived scripts in isolated work/repro',
        's1_s5_batch': {'microbatch': 8, 'accumulation': 4, 'effective': 32},
        'precision': {'training': 'bf16 autocast', 'eval': 'float32', 'tf32': False},
        'checkpoint_storage': 'Each requested milestone keeps model/tokenizer weights. Latest full recovery state includes optimizer, RNG and cursor; not every milestone keeps duplicate optimizer state. No completed weights deleted.',
        'reuse_policy': 'No S0/new-engine trajectory cache reuse unless full key equality proved; conservative fresh runs allowed within84 job matrix.',
        'dev_evaluation': 'Separate process after completed training trajectory; no RNG interference with continuation',
        'cross_policy_tie_break': 'Best policy Recall@5 within1e-12 then B_UNIQUE,MIXED_2R2B,DENSE_STATIC,R_UNIQUE. Within-policy uses matrix config tie-break.',
        'unique_repair': 'Preserve first occurrence of every original input signature, reserve those signatures before filling duplicate positions so replacements cannot displace later original unique entries.',
        'external_access': 'No external model scores until all methods, checkpoints, data and analysis frozen in final_lock.json.',
        'human_review': 'HUMAN_PENDING; no AI output counted as a second human reviewer.',
        'significance': 'Default descriptive paired effects and bootstrap intervals, no p-value significance claim.',
        'reproduction_comparison': {
            'input_budget': 'Exact frozen identity and625 updates required',
            'recompute_metrics_abs_tolerance': 1e-12,
            'cross_execution_numeric_tolerance': None,
            'report': 'Parameter hashes, loss/gradient traces, aligned score differences, top10 agreement, metric deltas and conclusion separately; investigate rather than post-hoc tolerance.'}})
    print('Initialized84 pending jobs and pre-result execution decisions.')


if __name__ == '__main__':
    main()
