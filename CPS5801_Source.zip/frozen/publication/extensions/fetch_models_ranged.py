"""Retry a pinned official asset with validated HTTP ranges, then verify all files."""
import concurrent.futures
import hashlib
import json
import pathlib
import time
from datetime import datetime, timezone

import requests

ROOT=pathlib.Path(__file__).resolve().parents[1]
PACKAGE=ROOT.parent/'handoff/CPS5801_PUBLICATION_HANDOFF_20261112'
OUT=ROOT/'models'
PARTS=ROOT.parent/'download_parts/qwen_attempt02'


def digest(path, algorithm='sha256'):
    h=hashlib.new(algorithm)
    if algorithm=='sha1':h.update(f'blob {path.stat().st_size}\0'.encode())
    with path.open('rb') as f:
        while block:=f.read(4*1024*1024):h.update(block)
    return h.hexdigest()


def verify(path,item):
    if not path.is_file() or path.stat().st_size!=item['bytes']:return False
    return digest(path)==item['sha256'] if item.get('sha256') else digest(path,'sha1')==item['git_blob_sha1']


def ranged(model,item,path):
    size=item['bytes'];chunk=16*1024*1024
    url=f'https://huggingface.co/{model["repo_id"]}/resolve/{model["revision"]}/{item["path"]}'
    PARTS.mkdir(parents=True,exist_ok=True)
    ranges=[(i,start,min(size-1,start+chunk-1)) for i,start in enumerate(range(0,size,chunk))]
    def one(info):
        i,start,end=info;part=PARTS/f'{i:04d}_{start}_{end}.part'
        if part.exists() and part.stat().st_size==end-start+1:return part
        for attempt in range(5):
            try:
                # A byte-range cache key prevents intermediary reuse of a different range.
                response=requests.get(url+f'?download=true&range_start={start}',headers={'Range':f'bytes={start}-{end}'},
                                      stream=True,timeout=(20,60))
                response.raise_for_status()
                if response.status_code!=206 or response.headers.get('Content-Range')!=f'bytes {start}-{end}/{size}':
                    raise ValueError('Server did not honor exact requested range')
                tmp=part.with_suffix('.downloading')
                with tmp.open('wb') as stream:
                    for data in response.iter_content(1024*1024):stream.write(data)
                response.close()
                if tmp.stat().st_size!=end-start+1:raise ValueError('Truncated range')
                tmp.replace(part)
                print('range_completed',i,len(ranges),end-start+1,flush=True)
                return part
            except Exception as error:
                with (PARTS/'attempts.jsonl').open('a',encoding='utf-8') as log:
                    log.write(json.dumps({'range':info,'attempt':attempt+1,'error':repr(error),'time':time.time()})+'\n')
                if attempt==4:raise
                time.sleep(min(2**attempt,16))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        parts=list(executor.map(one,ranges))
    assembled=path.with_suffix(path.suffix+'.assembled')
    with assembled.open('wb') as dest:
        for part in parts:
            with part.open('rb') as source:
                while block:=source.read(4*1024*1024):dest.write(block)
    if not verify(assembled,item):raise ValueError('Assembled asset failed pinned size/hash')
    if path.exists():raise FileExistsError('Refuse to replace existing model asset')
    assembled.replace(path)
    (PARTS/'range_manifest.json').write_text(json.dumps({'official_url':url,'revision':model['revision'],
        'parts':[{'file':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in parts],
        'assembled_sha256':digest(path)},indent=2),encoding='utf-8')


def main():
    lock=json.loads((PACKAGE/'model_assets.lock.json').read_text(encoding='utf-8'))
    records=[]
    for model in lock['models']:
        folder=OUT/(model['key']+'-'+model['revision'][:12]);folder.mkdir(parents=True,exist_ok=True)
        checked=[]
        for item in model['files']:
            path=folder/item['path']
            if not verify(path,item):
                if path.exists():raise ValueError('Existing model asset has wrong pinned identity: '+str(path))
                if item['bytes']<16*1024*1024:raise RuntimeError('Unexpected missing small asset: '+str(path))
                ranged(model,item,path)
            checked.append({'path':item['path'],'bytes':path.stat().st_size,'sha256':digest(path)})
        records.append({'repo_id':model['repo_id'],'revision':model['revision'],'local_dir':str(folder),'verified_files':checked})
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'models':records,
            'model_loading_or_inference_performed':False,'retry_transfer':'same official pinned revision, exact validated HTTP ranges, all LFS SHA256/Git blob checks passed'}
    (OUT/'verified_models.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('ALL_PINNED_MODELS_VERIFIED',flush=True)


if __name__=='__main__':main()
