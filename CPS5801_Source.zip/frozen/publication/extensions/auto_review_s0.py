"""CPU-only, independent S0 audit candidate. Never grants publication approval.

Reads actual S0 artifacts only after s0_completed.json; compares all 14 neural
prediction sets, all 6 625-update traces, and all 6 archived checkpoint hashes.
BM25 differences are isolated. A known development diagnosis is accepted only
as matching evidence, never as a numeric tolerance or blanket test exemption.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import pathlib
import statistics
import sys
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPRO = ROOT.parent / 'repro'
PACKAGE = ROOT.parent / 'handoff/CPS5801_PUBLICATION_HANDOFF_20261112'
ORIGINAL = PACKAGE / 'archive/CPS5801_HANDOFF_20261025/CPS5801'
RUNS = ['M01_bm25', 'M02_pretrained'] + [f'M{3 + 2 * (s - 42) + (p == "bm25"):02}_{p}_seed{s}' for s in (42, 43, 44) for p in ('random', 'bm25')]
METRICS = ('recall@1', 'recall@3', 'recall@5', 'recall@10', 'mrr@10')


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def dump(path, value):
    path = pathlib.Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temp.replace(path)


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def metrics(top, positives):
    gold = set(positives)
    return {**{f'recall@{k}': len(set(top[:k]) & gold) / len(gold) for k in (1, 3, 5, 10)},
            'mrr@10': next((1 / rank for rank, item in enumerate(top[:10], 1) if item in gold), 0.0)}


def compare_predictions(old, new, labels, valid_ids):
    failures, differences, old_metrics, new_metrics = [], [], [], []
    expected_ids = [row['id'] for row in labels]
    if len(expected_ids) != len(set(expected_ids)):
        raise ValueError('Frozen query IDs are not unique')
    for side, records in (('original', old), ('reproduction', new)):
        if [row.get('id') for row in records] != expected_ids:
            failures.append({'side': side, 'kind': 'query_ID_order_or_coverage'})
    if failures:
        return {'structural_failures': failures, 'rankings_and_scores_exact': False}, differences
    rank_changed, score_changed = [], []
    maximum = 0.0
    for a, b, label in zip(old, new, labels, strict=True):
        qid, gold = label['id'], label['positives']
        if not gold or len(gold) != len(set(gold)) or not set(gold) <= valid_ids:
            raise ValueError('Frozen positive IDs invalid: ' + qid)
        for side, row in (('original', a), ('reproduction', b)):
            top, scores = row.get('top10'), row.get('scores')
            if row.get('positives') != gold:
                failures.append({'side': side, 'query_id': qid, 'kind': 'positive_ID_order_or_identity'})
            if not isinstance(top, list) or len(top) != 10 or len(set(top)) != 10 or not set(top) <= valid_ids:
                failures.append({'side': side, 'query_id': qid, 'kind': 'top10_ID_validity'})
                continue
            if not isinstance(scores, list) or len(scores) != 10 or not all(finite(x) for x in scores):
                failures.append({'side': side, 'query_id': qid, 'kind': 'score_validity'})
                continue
            if any(scores[i] < scores[i + 1] or (scores[i] == scores[i + 1] and top[i] > top[i + 1]) for i in range(9)):
                failures.append({'side': side, 'query_id': qid, 'kind': 'stable_score_ID_sort'})
            calculated = metrics(top, gold)
            if any(row.get(key) != value for key, value in calculated.items()):
                failures.append({'side': side, 'query_id': qid, 'kind': 'stored_per_query_metric_not_exact'})
            (old_metrics if side == 'original' else new_metrics).append(calculated)
        if failures:
            # Invalid data must never enter arithmetic or the exact gate.
            continue
        shared = sorted(set(a['top10']) & set(b['top10']))
        sa, sb = dict(zip(a['top10'], a['scores'])), dict(zip(b['top10'], b['scores']))
        deltas = {tid: sb[tid] - sa[tid] for tid in shared if sa[tid] != sb[tid]}
        max_delta = max((abs(x) for x in deltas.values()), default=0.0)
        maximum = max(maximum, max_delta)
        rank_exact = a['top10'] == b['top10']
        score_exact = rank_exact and a['scores'] == b['scores']
        if not rank_exact:
            rank_changed.append(qid)
        if deltas:
            score_changed.append(qid)
        if not score_exact:
            differences.append({'query_id': qid, 'top10_exact': rank_exact,
                                'maximum_same_ID_score_difference': max_delta,
                                'same_ID_score_differences': deltas,
                                'original_top10': a['top10'], 'original_scores': a['scores'],
                                'reproduction_top10': b['top10'], 'reproduction_scores': b['scores'],
                                'metric_differences': {key: b[key] - a[key] for key in METRICS}})
    aggregate = None if failures else {
        key: statistics.mean(row[key] for row in new_metrics) - statistics.mean(row[key] for row in old_metrics)
        for key in METRICS}
    return {'query_count': len(labels), 'structural_failures': failures,
            'rankings_and_scores_exact': not failures and not differences,
            'rank_changed_query_ids': rank_changed, 'score_changed_query_count': len(score_changed),
            'maximum_same_ID_score_difference': maximum,
            'independently_recomputed_aggregate_metric_differences': aggregate}, differences


def compare_trace(old, new, steps=625):
    if len(old) != steps or len(new) != steps:
        return {'exact': False, 'reason': 'wrong_update_count', 'original_count': len(old), 'reproduction_count': len(new)}
    mismatches = []
    for i, (a, b) in enumerate(zip(old, new, strict=True), 1):
        if a.get('step') != i or b.get('step') != i:
            mismatches.append({'step': i, 'kind': 'update_sequence'})
        for field in ('epoch', 'loss', 'grad_norm'):
            if not finite(a.get(field)) or not finite(b.get(field)) or a[field] != b[field]:
                mismatches.append({'step': i, 'field': field, 'original': a.get(field), 'reproduction': b.get(field)})
    return {'exact': not mismatches, 'update_count': steps, 'mismatches': mismatches,
            'scope': 'Exact logged losses and global gradient norms, not unavailable full gradient tensors.'}


def audit(output):
    out = pathlib.Path(output)
    consumed = {}
    failures = []

    def bind(path):
        path = pathlib.Path(path).resolve()
        fingerprint = {'sha256': sha(path), 'bytes': path.stat().st_size}
        consumed[str(path)] = fingerprint
        return fingerprint

    def load(path):
        bind(path)
        return read(path)

    marker = load(ROOT / 's0_completed.json')
    if any(marker.get(key) != value for key, value in {'trained_runs': 6, 'dev_evaluations': 8, 'legacy_evaluations': 8,
                                                     'external_final_scored': False, 'source_results_reused': False}.items()):
        failures.append({'kind': 'invalid_s0_completion_marker', 'marker': marker})
    # Rehash actual frozen input/code trees, rather than trusting comparison booleans.
    identity = []
    files = (sorted((ORIGINAL / 'scripts').rglob('*.py')) + sorted((ORIGINAL / 'data/main_20261025').glob('*.json'))
             + sorted(path for path in (ORIGINAL / 'data/raw/model').rglob('*') if path.is_file()))
    for old_path in files:
        relative = old_path.relative_to(ORIGINAL)
        new_path = REPRO / relative
        a, b = bind(old_path), bind(new_path)
        row = {'relative_path': relative.as_posix(), 'original': a, 'reproduction': b, 'exact': a == b}
        identity.append(row)
        if not row['exact']:
            failures.append({'kind': 'frozen_source_or_input_changed', **row})

    report = {'created_utc': now(), 'audit_code_sha256': sha(__file__),
              'approval_written': False, 'approval_mode': 'candidate_only_root_signoff_required',
              'numeric_tolerance_for_reproduction_equality': 0,
              'source_identity': identity, 'prediction_sets': [], 'training': [], 'bm25': [],
              'failures': failures, 'input_files': consumed,
              'limitations': ['Historical fitted weights were omitted from the package; comparison uses archived SHA256 and byte count.',
                              'Exact logged gradient norms do not establish equality of unavailable full historical gradient tensors.',
                              'Only saved top10 scores/ranks are checked; omitted-candidate full ranks cannot be recovered.',
                              'No report from this script authorizes continuation. reproduction_review.json is never written.']}
    bm25_actual = {}
    for split, query_name, corpus_name, suffix in (('development', 'dev', 'corpus', ''), ('official_test', 'test', 'test_corpus', 'official_test')):
        labels = load(ORIGINAL / f'data/main_20261025/{query_name}.json')
        corpus = load(ORIGINAL / f'data/main_20261025/{corpus_name}.json')
        valid_ids = {row['id'] for row in corpus}
        if len(valid_ids) != len(corpus):
            raise ValueError('Duplicate corpus IDs')
        for run in RUNS:
            a_path = ORIGINAL / 'results/main_20261025' / suffix / run / 'predictions.json'
            b_path = REPRO / 'results/main_20261025' / suffix / run / 'predictions.json'
            a, b = load(a_path), load(b_path)
            result, differences = compare_predictions(a, b, labels, valid_ids)
            result.update(split=split, run_id=run, original_prediction_sha256=consumed[str(a_path.resolve())]['sha256'],
                          reproduction_prediction_sha256=consumed[str(b_path.resolve())]['sha256'])
            report['prediction_sets'].append(result)
            if result['structural_failures']:
                failures.append({'kind': 'invalid_prediction_structure', 'split': split, 'run_id': run})
            if run == 'M01_bm25':
                bm25_actual[split] = {'original': {row['id']: row for row in a},
                                     'reproduction': {row['id']: row for row in b}, 'corpus': corpus,
                                     'labels': {row['id']: row for row in labels}}
                dump(out / f'bm25_{split}_differences.json', differences)
                report['bm25'].append({**result, 'detail_file': f'bm25_{split}_differences.json'})
            elif not result['rankings_and_scores_exact']:
                failures.append({'kind': 'neural_prediction_not_exact', 'split': split, 'run_id': run,
                                 'first_differences': differences[:3]})

    scope = load(PACKAGE / 'package_scope.json')
    historical = {row['original_relative_path'].removeprefix('CPS5801/'): row for row in scope['excluded_files']}
    fields = ('seed', 'steps', 'epochs', 'queries', 'trainable_parameters', 'embedding_weight_change_l2', 'first_loss', 'last_loss',
              'mean_loss', 'checkpoint', 'audit', 'run_id', 'policy', 'schedule_sha256', 'negative_manifest_sha256',
              'snapshot_manifest_sha256', 'experiment_code_sha256', 'evaluation_code_sha256')
    for run in RUNS[2:]:
        original_run, new_run = [root / 'results/main_20261025' / run for root in (ORIGINAL, REPRO)]
        old_stats, new_stats = load(original_run / 'training.json'), load(new_run / 'training.json')
        traces = []
        for folder in (original_run, new_run):
            path = folder / 'loss.jsonl'
            bind(path)
            traces.append([json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()])
        trace = compare_trace(*traces)
        field_identity = {key: key in old_stats and key in new_stats and old_stats[key] == new_stats[key] for key in fields}
        if new_stats.get('steps') != 625 or new_stats.get('embedding_weight_change_l2', 0) <= 0:
            field_identity['valid_steps_and_nonzero_weight_update'] = False
        # Bind actual schedule and negative manifests to both historical and new training metadata.
        for field, filename in (('schedule_sha256', f'shared_schedule_seed{new_stats["seed"]}.json'),
                                ('negative_manifest_sha256', f'negatives_seed{new_stats["seed"]}.json'),
                                ('snapshot_manifest_sha256', 'freeze_manifest.json')):
            field_identity[field + '_matches_actual_input'] = sha(REPRO / 'data/main_20261025' / filename) == new_stats[field]
        field_identity['experiment_code_sha256_matches_actual'] = sha(REPRO / 'scripts/main_training_engine.py') == new_stats['experiment_code_sha256']
        field_identity['evaluation_code_sha256_matches_actual'] = sha(REPRO / 'scripts/experiment.py') == new_stats['evaluation_code_sha256']
        weight = new_run / 'checkpoint/model.safetensors'
        recorded = historical.get(weight.relative_to(REPRO).as_posix())
        actual = bind(weight)
        weight_exact = bool(recorded and actual['sha256'] == recorded['sha256'] and actual['bytes'] == recorded['bytes'])
        row = {'run_id': run, 'field_identity': field_identity, 'trace': trace,
               'checkpoint': {'path': str(weight), **actual, 'historical_record': recorded, 'exact_sha256_and_bytes': weight_exact}}
        report['training'].append(row)
        if not trace['exact'] or not all(field_identity.values()) or not weight_exact:
            failures.append({'kind': 'training_or_checkpoint_not_exact', 'run_id': run})

    # Strictly bind the known DEVELOPMENT evidence to the still-identical artifacts.
    fix = load(ROOT / 'provenance/bm25_numerical_fix.json')
    diagnostic_path = pathlib.Path(fix['diagnostic_report'])
    diagnosis = load(diagnostic_path)
    known_ok = sha(diagnostic_path) == fix['diagnostic_report_sha256']
    diagnostic_checks = {'diagnostic_report_matches_provenance': known_ok}
    for name, record in diagnosis['source_files_unchanged_and_identical'].items():
        actual = bind(pathlib.Path(record['path']))
        diagnostic_checks[name + '_still_matches'] = actual == {key: record[key] for key in ('sha256', 'bytes')}
    diagnostic_checks['diagnostic_code_matches'] = sha(ROOT / 'extensions/investigate_bm25_numerics.py') == diagnosis['diagnostic_code_sha256']
    dev = next(row for row in report['bm25'] if row['split'] == 'development')
    diagnostic_checks['actual_rank_changed_ids_match'] = dev['rank_changed_query_ids'] == diagnosis['saved_top10_changed_queries']
    diagnostic_checks['actual_score_changed_count_matches'] = dev['score_changed_query_count'] == diagnosis['saved_same_ID_score_changed_query_count']
    diagnostic_checks['actual_max_delta_matches'] = dev['maximum_same_ID_score_difference'] == diagnosis['saved_maximum_same_ID_score_difference']
    # Re-execute the finite controlled-order intervention on CPU. Do not merely
    # trust the diagnostic report's booleans or widen a score tolerance.
    import importlib.util
    import numpy as np
    specification = importlib.util.spec_from_file_location('unchanged_s0_bm25_audit', REPRO / 'scripts/common.py')
    common = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(common)
    dev_actual = bm25_actual['development']
    corpus_ids = [row['id'] for row in dev_actual['corpus']]
    diagnostic_checks['corpus_ID_sort_for_stable_ties'] = corpus_ids == sorted(corpus_ids)
    index = common.BM25([row['text'] for row in dev_actual['corpus']])
    for component, recorded_sha in diagnosis['sparse_matrix_identity']['component_sha256'].items():
        diagnostic_checks['rebuilt_matrix_' + component + '_matches'] = hashlib.sha256(getattr(index.mat, component).tobytes()).hexdigest() == recorded_sha
    details = []
    for saved in diagnosis['diagnoses']:
        detail_path = diagnostic_path.parent / saved['query_id'] / 'order_experiment.json'
        detail = load(detail_path)
        controls = detail['controlled_orders']
        qid = saved['query_id']
        expected_columns = sorted(index.vocab[word] for word in set(common.words(dev_actual['labels'][qid]['query'])) if word in index.vocab)
        control_rechecks = []
        for control in controls:
            columns = [index.vocab[word] for word in control['words'] if word in index.vocab]
            scores = np.asarray(index.mat[:, columns].sum(axis=1)).ravel()
            positions = np.argsort(-scores, kind='stable')[:10]
            calculated_top = [corpus_ids[position] for position in positions]
            control_rechecks.append(sorted(columns) == expected_columns and columns == control['vocabulary_columns']
                                    and scores.dtype == np.float32 and calculated_top == control['top10']
                                    and scores[positions].tolist() == control['scores'])
        diagnostic_checks[qid + '_actual_saved_outputs_match_diagnostic'] = (
            detail['original_saved'] == dev_actual['original'][qid]
            and detail['reproduction_saved'] == dev_actual['reproduction'][qid])
        diagnostic_checks[qid + '_controlled_CPU_scores_recomputed_exactly'] = bool(control_rechecks) and all(control_rechecks)
        original_matches = [row['name'] for row in controls if row['top10'] == detail['original_saved']['top10']]
        replay_matches = [row['name'] for row in controls if row['top10'] == detail['reproduction_saved']['top10']]
        good = bool(original_matches and replay_matches)
        details.append({'query_id': saved['query_id'], 'controlled_orders': len(controls),
                        'original_rankings_recreated_by': original_matches, 'reproduction_rankings_recreated_by': replay_matches,
                        'both_rankings_recreated': good, 'evidence_sha256': sha(detail_path)})
        diagnostic_checks[saved['query_id'] + '_rank_order_intervention_present'] = good
    fix_checks = {}
    for name, item in fix['changes'].items():
        fix_checks[name + '_current_matches_recorded_fix'] = bind(ROOT / 'extensions' / name)['sha256'] == item['after_sha256']
    for key in ('cpu_scoring_fixture', 'hash_seed_fixture'):
        item = fix[key]
        fixture_path = pathlib.Path(item['path'])
        fixture = load(fixture_path)
        fix_checks[key] = sha(fixture_path) == item['sha256'] and item['passed'] is True and fixture.get('passed') is True
    report['known_bm25_development_diagnosis'] = {'checks': diagnostic_checks, 'all_bound_evidence_matches': all(diagnostic_checks.values()),
                                               'controlled_rank_evidence': details, 'mechanism': diagnosis['mechanism'],
                                               'historical_word_order_unknown': True,
                                               'all_historical_score_bytes_reconstructed': False,
                                               'numeric_tolerance_or_test_exemption_granted': False}
    report['extension_bm25_fix_checks'] = fix_checks
    if not all(diagnostic_checks.values()) or not all(fix_checks.values()):
        failures.append({'kind': 'known_bm25_evidence_or_recorded_fix_changed'})
    report['unresolved_bm25_splits'] = [row['split'] for row in report['bm25']
                                     if not row['rankings_and_scores_exact'] and row['split'] != 'development']
    report['comparison_report_reference'] = {'path': str(ROOT / 'comparison/reproduction_comparison.json'),
                                             **bind(ROOT / 'comparison/reproduction_comparison.json')}
    # Reject a concurrent mutation rather than certifying a moving snapshot.
    changed = [path for path, expected in consumed.items() if not pathlib.Path(path).exists() or sha(path) != expected['sha256']]
    if changed:
        failures.append({'kind': 'input_changed_during_audit', 'paths': changed})
    neural = [row for row in report['prediction_sets'] if row['run_id'] != 'M01_bm25']
    report['strict_checks'] = {
        'all14_neural_prediction_rankings_and_scores_exact': len(neural) == 14 and all(row['rankings_and_scores_exact'] for row in neural),
        'all6_training_trace_and_input_fields_exact': len(report['training']) == 6 and all(row['trace']['exact'] and all(row['field_identity'].values()) for row in report['training']),
        'all6_checkpoint_weight_sha256_and_bytes_exact': len(report['training']) == 6 and all(row['checkpoint']['exact_sha256_and_bytes'] for row in report['training']),
        'actual_source_and_data_hashes_identical': all(row['exact'] for row in identity),
        'inputs_unchanged_during_audit': not changed}
    report['status'] = ('FAILED_STRICT_CHECKS' if failures else
                        'NEURAL_EXACT_BM25_NEW_DIFFERENCES_REQUIRE_DIAGNOSIS' if report['unresolved_bm25_splits'] else
                        'CANDIDATE_READY_FOR_ROOT_REVIEW')
    report['finished_utc'] = now()
    dump(out / 'auto_review_s0_candidate.json', report)
    return report


def fixture():
    ids = [f't{i:02}' for i in range(12)]
    labels = [{'id': 'q', 'positives': [ids[0], ids[11]]}]
    row = {'id': 'q', 'positives': labels[0]['positives'], 'top10': ids[:10], 'scores': list(range(10, 0, -1)),
           **metrics(ids[:10], labels[0]['positives'])}
    import copy
    base = [row]
    assert compare_predictions(base, copy.deepcopy(base), labels, set(ids))[0]['rankings_and_scores_exact']
    changed = copy.deepcopy(base); changed[0]['scores'][3] += 1e-12
    assert not compare_predictions(base, changed, labels, set(ids))[0]['rankings_and_scores_exact']
    changed = copy.deepcopy(base); changed[0]['top10'][0], changed[0]['top10'][1] = changed[0]['top10'][1], changed[0]['top10'][0]
    assert not compare_predictions(base, changed, labels, set(ids))[0]['rankings_and_scores_exact']
    trace = [{'step': i, 'epoch': 1 + (i > 1), 'loss': .1, 'grad_norm': .2} for i in (1, 2)]
    assert compare_trace(trace, copy.deepcopy(trace), steps=2)['exact']
    changed = copy.deepcopy(trace); changed[1]['grad_norm'] += 1e-12
    assert not compare_trace(trace, changed, steps=2)['exact']
    changed = copy.deepcopy(trace); changed[1]['epoch'] = 1
    assert not compare_trace(trace, changed, steps=2)['exact']
    assert not compare_trace(trace, trace[:1], steps=2)['exact']
    return {'passed': True, 'scope': 'CPU exact-gate mutation tests: tiny score/gradient change, ranking, epoch, truncated trace; no GPU/data inference',
            'approval_written': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=pathlib.Path)
    parser.add_argument('--wait', action='store_true')
    parser.add_argument('--fixture-only', action='store_true')
    args = parser.parse_args()
    output = args.output.resolve()
    if ROOT / 'analysis' not in output.parents or output.exists():
        raise ValueError('Choose a NEW attempt directory below publication/analysis')
    output.mkdir(parents=True)
    if args.fixture_only:
        result = fixture(); result['audit_code_sha256'] = sha(__file__)
        dump(output / 'fixture_report.json', result)
        print(json.dumps(result)); return 0
    try:
        while not (ROOT / 's0_completed.json').exists():
            if not args.wait:
                raise RuntimeError('S0 completion marker is not present; no partial acceptance')
            status_path = ROOT / 'logs/s0_pipeline.process_status.json'
            if status_path.exists():
                status = read(status_path)
                if status.get('status') not in ('running', 'starting'):
                    raise RuntimeError('S0 ended without completion marker: ' + str(status.get('status')))
            dump(output / 'audit_status.json', {'phase': 'waiting_for_s0', 'updated_utc': now(), 'approval_written': False})
            time.sleep(5)
        result = audit(output)
        dump(output / 'audit_status.json', {'phase': 'candidate_report_completed', 'updated_utc': now(),
                                          'audit_result': result['status'], 'approval_written': False,
                                          'candidate_report_sha256': sha(output / 'auto_review_s0_candidate.json')})
        print(json.dumps({'status': result['status'], 'strict_checks': result['strict_checks'],
                          'unresolved_bm25_splits': result['unresolved_bm25_splits'], 'approval_written': False}, indent=2))
        return 2 if result['failures'] else 0
    except BaseException as error:
        dump(output / 'audit_status.json', {'phase': 'failed_or_interrupted', 'updated_utc': now(),
                                          'error': repr(error), 'traceback': traceback.format_exc(), 'approval_written': False})
        raise


if __name__ == '__main__':
    raise SystemExit(main())
