"""Post-lock S0 legacy-view compatibility; all scientific functions stay locked.

Two views identify each of six original-engine S0 development outputs. The run
registry view omits query/corpus metadata; the separately discovered legacy view
has both paths. Fill only those six in-memory metadata records. Retain both views
in all-evaluation tables, but use the canonical legacy view once in development
mechanism statistics. Never edit live registries, locks, EXT or model outputs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys

PUBLICATION=Path(__file__).resolve().parents[1]
EXT=PUBLICATION/'extensions'
BASE_PATH=EXT/'rebuild_all.py'
ADAPTER_PATH=Path(__file__).resolve()


def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def require(value,message):
    if not value:raise ValueError('S0 post-lock compatibility: '+message)


# Bind scientific source before import, including the functions imported by the
# original module. The final lock remains the authority; it is never rewritten.
_IMPORT_LOCK=load(PUBLICATION/'locks/final_lock.json')
for _name in ['rebuild_all.py','publication_statistics.py','select_on_dev.py']:
    require(digest(EXT/_name)==_IMPORT_LOCK['code_sha256'][_name],'Locked source mismatch: '+_name)
sys.path.insert(0,str(EXT))
_spec=importlib.util.spec_from_file_location('_locked_rebuild_all_for_s0_compat',BASE_PATH)
BASE=importlib.util.module_from_spec(_spec)
sys.modules[_spec.name]=BASE
_spec.loader.exec_module(BASE)
ORIGINAL_DISCOVER=BASE.discover_evaluations
EXPECTED_PAIRS={(policy,seed) for policy in ['R_ID','B_ID'] for seed in [42,43,44]}


class Rebuilder(BASE.Rebuilder):
    def __init__(self,input_root,output_dir):
        super().__init__(input_root,output_dir)
        self.adapter_sha=digest(ADAPTER_PATH)
        self.lock_path=self.resolver.publication/'locks/final_lock.json'
        self.lock_sha=digest(self.lock_path)
        lock=load(self.lock_path)
        self.locked_sources={name:lock['code_sha256'][name]
            for name in ['rebuild_all.py','publication_statistics.py','select_on_dev.py']}
        for name,value in self.locked_sources.items():require(digest(EXT/name)==value,'Input lock/source mismatch: '+name)
        self.aliases=[];self.alias_inputs=[];self.mechanism_filter=None
        self.original_discovery_count=None

    def producer(self):
        return {'name':'analysis_tools/rebuild_all.py','sha256':self.adapter_sha,
            'locked_base_name':'extensions/rebuild_all.py','locked_base_sha256':self.locked_sources['rebuild_all.py'],
            'scope':'Six S0 development metadata aliases only; scientific scoring/selection/bootstrap/figures use unchanged locked functions.'}

    def register(self,output,sources,formula,**metadata):
        super().register(output,sources,formula,**metadata)
        self.provenance[-1]['technical_adapter_producer']=self.producer()

    def resolved_output(self,row):
        base=Path(row.get('registry_path',self.resolver.publication)).parent
        return self.resolver.resolve(row['output_path'],base)

    def discover(self,resolver):
        require(resolver.publication==self.resolver.publication,'Resolver changed within rebuild')
        entries,runs,sources=ORIGINAL_DISCOVER(resolver)
        self.original_discovery_count=len(entries)
        candidates=[row for row in entries if row.get('stage')=='S0' and row.get('dataset')=='development'
            and row.get('evidence_type')=='EXPLORATORY_DEV' and row.get('registry_path','').endswith('run_registry.json')
            and (not row.get('queries_path') or not row.get('corpus_path'))]
        require(len(candidates)==6 and {(r['policy'],r['seed']) for r in candidates}==EXPECTED_PAIRS,
            'Exactly the six known S0 development aliases must require metadata compatibility')
        aliases=[]
        for row in candidates:
            require(row.get('queries_path') is None and row.get('corpus_path') is None,'Only two absent metadata fields may be supplied')
            require(row['family']=='e5' and row.get('steps')==625,'S0 identity/budget differs')
            out=self.resolved_output(row)
            matches=[other for other in entries if other.get('evidence_type')=='REPRODUCTION'
                and other.get('dataset')=='development'
                and all(other.get(k)==row.get(k) for k in ['policy','seed','family','stage'])
                and self.resolved_output(other)==out]
            require(len(matches)==1,'Canonical legacy view must match uniquely: '+row['evaluation_id'])
            canonical=matches[0]
            paths={key:resolver.resolve(canonical[key],out) for key in ['queries_path','corpus_path']}
            require(paths['queries_path'].name=='dev.json' and paths['corpus_path'].name=='corpus.json'
                and paths['queries_path'].parent==paths['corpus_path'].parent,'Canonical development paths differ')
            data=paths['queries_path'].parent
            require(data.name=='main_20261025' and data.parent.name=='data','Unexpected legacy data layout')
            repro=data.parent.parent
            freeze=data/'freeze_manifest.json';training=out/'training.json'
            stats=load(training);frozen=load(freeze)
            require(digest(freeze)==stats['snapshot_manifest_sha256'],'S0 frozen snapshot does not match training record')
            require(stats['seed']==row['seed'] and stats['steps']==625
                and stats['policy']==('random' if row['policy']=='R_ID' else 'bm25'),'Canonical S0 training identity differs')
            require(resolver.resolve(row['checkpoint_path'],out)==out/'checkpoint','S0 checkpoint path does not belong to shared output')
            bindings={}
            for key,path in paths.items():
                require(digest(path)==frozen['files'][path.relative_to(repro).as_posix()],'Canonical input differs from frozen bytes')
                bindings[key]=self.source_info(path)
            evidence=[out/'predictions.json',out/'metrics.json',out/'config.json',training,freeze,*paths.values()]
            aliases.append({'registry_evaluation_id':row['evaluation_id'],'canonical_evaluation_id':canonical['evaluation_id'],
                'dataset':'development','family':'e5','stage':'S0','policy':row['policy'],'seed':row['seed'],'steps':625,
                'same_resolved_output':resolver.display(out),'added_fields':{key:canonical[key] for key in paths},
                'frozen_input_bindings':bindings,'shared_output_file_bindings':[self.source_info(path) for path in evidence],
                'whole_table_identity_policy':'Both evaluation IDs are retained.',
                'mechanism_identity_policy':'Exclude this registry alias only within development fixed-recipe mechanism statistics; retain its unique canonical legacy view.'})
            self.alias_inputs.extend(evidence)
        by_id={row['registry_evaluation_id']:row for row in aliases}
        adapted=[dict(row,**by_id[row['evaluation_id']]['added_fields']) if row['evaluation_id'] in by_id else row for row in entries]
        require(len(adapted)==len(entries),'Discovery identity was dropped or added')
        for before,after in zip(entries,adapted):
            changed={key for key in set(before)|set(after) if before.get(key)!=after.get(key)}
            require(changed==({'queries_path','corpus_path'} if before['evaluation_id'] in by_id else set()),'Unexpected in-memory metadata change')
        self.aliases=aliases
        return adapted,runs,sources

    def mechanism_membership(self,entries):
        excluded={row['registry_evaluation_id'] for row in self.aliases}
        kept=[entry for entry in entries if entry['evaluation_id'] not in excluded]
        candidates=[r for r in kept if r.get('dataset')=='development' and r.get('family')=='e5'
            and r.get('stage') in ['S0','S1'] and r.get('policy') in ['R_ID','B_ID','R_UNIQUE','B_UNIQUE']
            and r.get('seed') in [42,43,44] and r.get('evidence_type')!='ORIGINAL']
        pairs=[(r['policy'],r['seed']) for r in candidates]
        expected={(policy,seed) for policy in ['R_ID','B_ID','R_UNIQUE','B_UNIQUE'] for seed in [42,43,44]}
        require(len(pairs)==12 and set(pairs)==expected,'Development mechanism must have exactly twelve unique policy/seed cells')
        return {'excluded_registry_aliases':sorted(excluded),'kept_development_evaluation_ids':[r['evaluation_id'] for r in candidates],
            'development_unique_factorial_cells':12,'only_development_aliases_excluded':True,
            'all_other_datasets_membership_unchanged':True}

    def fixed_mechanism_tables(self):
        original=self.completed
        by_id={c['entry']['evaluation_id']:c for c in original}
        for alias in self.aliases:
            require(alias['registry_evaluation_id'] in by_id and alias['canonical_evaluation_id'] in by_id,
                'Both aliases must independently score successfully before mechanism deduplication')
            a,b=by_id[alias['registry_evaluation_id']],by_id[alias['canonical_evaluation_id']]
            require(a['output_path']==b['output_path'] and a['query_sha256']==b['query_sha256']
                and a['corpus_sha256']==b['corpus_sha256'] and a['score']==b['score'],
                'Views of shared S0 output do not carry identical scored evidence')
        self.mechanism_filter=self.mechanism_membership([c['entry'] for c in original])
        excluded=set(self.mechanism_filter['excluded_registry_aliases'])
        self.completed=[c for c in original if c['entry']['evaluation_id'] not in excluded]
        try:return BASE.Rebuilder.fixed_mechanism_tables(self)
        finally:self.completed=original

    def identities(self):
        functions={'score_evaluation':BASE.Rebuilder.score_evaluation,'rescore':BASE.rescore,
            'paired_analyze':BASE.paired_analyze,'select_dev':BASE.select_dev,
            'confirmation_tables':BASE.Rebuilder.confirmation_tables,'fixed_mechanism_tables':BASE.Rebuilder.fixed_mechanism_tables,
            'figures':BASE.Rebuilder.figures}
        require(type(self).score_evaluation is BASE.Rebuilder.score_evaluation,'Scoring method was overridden')
        require(type(self).confirmation_tables is BASE.Rebuilder.confirmation_tables,'Confirmation method was overridden')
        require(type(self).figures is BASE.Rebuilder.figures,'Figure method was overridden')
        return {name:{'module':fn.__module__,'source_file':str(Path(inspect.getsourcefile(fn)).resolve()),
            'source_sha256':digest(inspect.getsourcefile(fn)),
            'function_source_sha256':hashlib.sha256(inspect.getsource(fn).encode()).hexdigest()} for name,fn in functions.items()}

    def write_compatibility(self,mode):
        require(digest(self.lock_path)==self.lock_sha and digest(ADAPTER_PATH)==self.adapter_sha,'Lock/adapter changed during run')
        for name,value in self.locked_sources.items():require(digest(EXT/name)==value,'Locked source changed during run: '+name)
        folder=self.out/'compatibility';folder.mkdir(exist_ok=True)
        aliases=folder/'s0_development_aliases.json'
        BASE.write_json(aliases,{'status':'SIX_EXPLICIT_S0_DEVELOPMENT_ALIASES','aliases':self.aliases,
            'in_memory_fields_added':12,'source_registry_modified':False,'mode':mode})
        sources=[self.resolver.publication/'run_registry.json',self.lock_path,ADAPTER_PATH,BASE_PATH,*self.alias_inputs]
        self.register(aliases,sources,'Only six pre-existing S0 registry views receive two canonical frozen input paths; no prediction, metric, training or policy changed')
        evidence=folder/'technical_compatibility.json'
        BASE.write_json(evidence,{'status':'POST_LOCK_ANALYSIS_COMPATIBILITY_RECORDED','mode':mode,
            'created_at_utc':datetime.now(timezone.utc).isoformat(),'producer':self.producer(),'final_lock_sha256':self.lock_sha,
            'reason':'Legacy S0 dev registry views omit query/corpus paths and duplicate separately discovered REPRODUCTION views.',
            'original_discovered_evaluation_count':self.original_discovery_count,'alias_count':len(self.aliases),
            'mechanism_filter':self.mechanism_filter,'unchanged_scientific_functions':self.identities(),
            'registry_EXT_locks_raw_outputs_modified':False,'new_model_runs_or_bootstrap_rules':False,
            'scope':'Analysis-only metadata routing and duplicate-view accounting; all raw scoring, statistics, selection rules and figures call the final-lock-pinned implementation.'})
        self.register(evidence,sources,'Explicit post-lock producer and source-function identity; not a new scientific analysis rule')
        return {'producer':self.producer(),'alias_map':aliases.relative_to(self.out).as_posix(),
            'alias_map_sha256':digest(aliases),'technical_evidence':evidence.relative_to(self.out).as_posix(),
            'technical_evidence_sha256':digest(evidence),'alias_count':len(self.aliases)}

    def run(self):
        require(BASE.discover_evaluations is ORIGINAL_DISCOVER,'Unexpected discovery override already installed')
        BASE.discover_evaluations=self.discover
        try:result=BASE.Rebuilder.run(self)
        finally:BASE.discover_evaluations=ORIGINAL_DISCOVER
        compatibility=self.write_compatibility('complete_rebuild')
        manifest_path=self.out/'table_provenance.json';manifest=load(manifest_path)
        manifest['tables_and_artifacts']=self.provenance
        manifest['technical_adapter_producer']=compatibility
        BASE.write_json(manifest_path,manifest)
        result['technical_adapter_producer']=compatibility
        BASE.write_json(self.out/'rebuild_status.json',result)
        return result

    def preflight(self):
        entries,_,_=self.discover(self.resolver)
        selected={row['registry_evaluation_id'] for row in self.aliases}
        scored=[self.score_evaluation(row) for row in entries if row['evaluation_id'] in selected]
        require(len(scored)==6 and all(row['score']['n']==1000 for row in scored),'All six actual S0 development views must re-score1000 queries')
        self.mechanism_filter=self.mechanism_membership(entries)
        compatibility=self.write_compatibility('six_actual_S0_development_views_only')
        result={'status':'PASS_SIX_S0_DEVELOPMENT_VIEWS_COMPATIBILITY_ONLY','six_actual_recomputed_views':6,
            'recomputed_query_rows':6000,'all_discovered_identities_retained':len(entries)==self.original_discovery_count,
            'mechanism_development_unique_cells':12,'technical_adapter_producer':compatibility,
            'external_scores_read':False,'GPU_used':False,'full_rebuild_executed':False,'final_scientific_acceptance':False}
        BASE.write_json(self.out/'table_provenance.json',{'schema_version':'1.0.0','tables_and_artifacts':self.provenance,
            'source_root':str(self.resolver.root),'script_sha256':self.locked_sources['rebuild_all.py'],'technical_adapter_producer':compatibility})
        BASE.write_json(self.out/'status.json',result)
        return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root',required=True,type=Path)
    parser.add_argument('--output-dir',required=True,type=Path)
    parser.add_argument('--preflight',action='store_true')
    args=parser.parse_args()
    builder=Rebuilder(args.input_root,args.output_dir)
    result=builder.preflight() if args.preflight else builder.run()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result.get('verification_failures') or result.get('pending_evaluations'):raise SystemExit(2)


if __name__=='__main__':main()
