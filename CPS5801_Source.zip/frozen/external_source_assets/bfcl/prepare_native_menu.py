"""Audit and derive retrieval-only views of pinned BFCL native menus.

No model calls, training, or function execution. Original files are unchanged.
The outputs are preliminary to cross-dataset collision screening on the GPU host.
"""
from __future__ import annotations

import collections
import hashlib
import json
from pathlib import Path
import re
import unicodedata

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "berkeley-function-call-leaderboard" / "bfcl_eval" / "data"
CATEGORIES = ("live_multiple", "multiple", "parallel_multiple")
INSPECTED = {"live_multiple_0-0-0", "multiple_0", "parallel_multiple_0"}


def canon(x: object) -> str:
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha(x: str) -> str:
    return hashlib.sha256(x.encode("utf-8")).hexdigest()


def norm(x: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", x).casefold().split())


def lines(path: Path) -> list[dict]:
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()]


def main() -> None:
    manifest = json.loads((ROOT / "download_manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        if hashlib.sha256((ROOT / item["path"]).read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError("Source hash mismatch: " + item["path"])
    records, rejected = [], []
    for category in CATEGORIES:
        original = lines(DATA / f"BFCL_v4_{category}.json")
        answers_list = lines(DATA / "possible_answer" / f"BFCL_v4_{category}.json")
        answers = {r["id"]: r for r in answers_list}
        if len(answers) != len(answers_list) or len({r["id"] for r in original}) != len(original):
            raise ValueError("Duplicate original ids in " + category)
        if set(answers) != {r["id"] for r in original}:
            raise ValueError("Question/gold ID mismatch in " + category)
        for row in original:
            rid = row["id"]
            messages = [m for turn in row["question"] for m in turn]
            if len(row["question"]) != 1 or any(set(m) != {"role", "content"} or not isinstance(m["content"], str) or m["role"] not in {"user", "system"} for m in messages):
                rejected.append({"id": rid, "category": category, "reason": "unsupported_context_requires_explicit_review"})
                continue
            # Preserve every original context message. Labels are never query text.
            query = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
            tools = row["function"]
            names = [t["name"] for t in tools]
            calls = answers[rid]["ground_truth"]
            if not isinstance(calls, list) or any(not isinstance(c, dict) or len(c) != 1 for c in calls):
                rejected.append({"id": rid, "category": category, "reason": "unsupported_gold_structure"})
                continue
            gold_names = sorted({name for call in calls for name in call})
            if len(names) != len(set(names)) or not gold_names or not set(gold_names).issubset(names):
                rejected.append({"id": rid, "category": category, "reason": "ambiguous_or_missing_function_mapping"})
                continue
            if len(names) < 2 or not set(names).difference(gold_names):
                rejected.append({"id": rid, "category": category, "reason": "no_nonrelevant_native_candidate"})
                continue
            candidates = []
            for ordinal, t in enumerate(tools):
                payload = {k: t[k] for k in ("name", "description", "parameters")}
                tid = f"bfcl:{rid}:{ordinal}"
                candidates.append({"id": tid, "name": t["name"], "text": canon(payload),
                                   "document_sha256": sha(canon(payload)),
                                   "tie_break_key": sha("publication_v1|tie|" + rid + "|" + t["name"])})
            records.append({"id": rid, "category": category, "query": query,
                            "normalized_query_sha256": sha(norm(query)),
                            "user_only_query_sha256": sha(norm("\n".join(m["content"] for m in messages if m["role"] == "user"))),
                            "messages": messages,
                            "source_id_prefix_proxy": rid.split("-", 1)[0] if category == "live_multiple" else rid,
                            "menu_sha256": sha(canon(sorted(c["document_sha256"] for c in candidates))),
                            "family_signature_proxy": sha(canon(sorted(norm(n) for n in names))),
                            "contains_cjk_script": bool(re.search(r"[\u3400-\u9fff]", query)),
                            "contains_non_ascii": any(ord(c) > 127 for c in query),
                            "candidates": candidates,
                            "positives": [c["id"] for c in candidates if c["name"] in gold_names],
                            "gold_function_names": gold_names,
                            "label_scope": "official_function_name_projection_not_argument_or_execution_score"})
    # Exposure exclusion uses task prefix and normalized user/full-query equality,
    # not candidate texts: catalogue documents are observable retrieval inputs.
    excluded = set(INSPECTED)
    changed = True
    while changed:
        changed = False
        exposed = [r for r in records if r["id"] in excluded]
        prefixes = {r["source_id_prefix_proxy"] for r in exposed}
        qhashes = {r[k] for r in exposed for k in ("normalized_query_sha256", "user_only_query_sha256")}
        for r in records:
            if r["id"] not in excluded and (r["source_id_prefix_proxy"] in prefixes or any(r[k] in qhashes for k in ("normalized_query_sha256", "user_only_query_sha256"))):
                excluded.add(r["id"])
                changed = True
    final = [r for r in records if r["id"] not in excluded]
    # Shared exact queries or native menu function-name sets form conservative
    # uncertainty blocks. This is a grouping proxy, not a relevance judgment.
    parent = {r["id"]: r["id"] for r in final}
    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    seen = {}
    for row in final:
        for field in ("normalized_query_sha256", "user_only_query_sha256", "family_signature_proxy"):
            key = (row["category"], field, row[field])
            if key in seen:
                a, b = find(row["id"]), find(seen[key])
                parent[max(a, b)] = min(a, b)
            else:
                seen[key] = row["id"]
    for row in final:
        row["uncertainty_group_id"] = "bfcl-group:" + find(row["id"])
    out = ROOT / "derived_pre_overlap"
    out.mkdir(exist_ok=True)
    for category in CATEGORIES:
        selected = [r for r in final if r["category"] == category]
        (out / f"{category}.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in selected), encoding="utf-8")
    report = {
        "source_revision": manifest["revision"],
        "status": "STRUCTURALLY_VALID_PRE_OVERLAP_SCREEN_NO_MODEL_SCORES",
        "raw_counts": {c: len(lines(DATA / f"BFCL_v4_{c}.json")) for c in CATEGORIES},
        "eligible_native_menu_counts": dict(collections.Counter(r["category"] for r in records)),
        "post_engineering_exclusion_counts": dict(collections.Counter(r["category"] for r in final)),
        "engineering_excluded_eligible_ids": sorted(r["id"] for r in records if r["id"] in excluded),
        "engineering_rule": "transitive original-id-prefix proxy and exact normalized full/user query group of inspected cases; proxy is not verified upstream provenance",
        "rejected": rejected,
        "candidate_count_distribution": {c: dict(sorted(collections.Counter(len(r["candidates"]) for r in final if r["category"] == c).items())) for c in CATEGORIES},
        "context_message_count_distribution": {c: dict(collections.Counter(len(r["messages"]) for r in final if r["category"] == c)) for c in CATEGORIES},
        "script_proxy_counts": {c: {"contains_cjk_script": sum(r["contains_cjk_script"] for r in final if r["category"] == c), "contains_non_ascii": sum(r["contains_non_ascii"] for r in final if r["category"] == c)} for c in CATEGORIES},
        "unique_proxy_group_counts": {c: {k: len({r[k] for r in final if r["category"] == c}) for k in ("normalized_query_sha256", "source_id_prefix_proxy", "menu_sha256", "family_signature_proxy")} for c in CATEGORIES},
        "uncertainty_groups": {c: {"count": len({r["uncertainty_group_id"] for r in final if r["category"] == c}), "largest": max(collections.Counter(r["uncertainty_group_id"] for r in final if r["category"] == c).values(), default=0)} for c in CATEGORIES},
        "cross_dataset_collision_screen": "PENDING_REQUIRED_BEFORE_MODEL_SELECTION",
        "language_filter": "none; all source languages preserved; Unicode flags are script proxies not language labels",
        "gold_interpretation": "one function key per official gold call; parallel calls unioned over function names; value lists encode accepted parameter values, not interchangeable function names",
        "execution": "no official functions or evaluation code executed",
        "derived_files": [{"path": str(p.relative_to(ROOT)).replace('\\', '/'), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "size_bytes": p.stat().st_size} for p in sorted(out.glob("*.jsonl"))]
    }
    (ROOT / "structural_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("post_engineering_exclusion_counts", "engineering_excluded_eligible_ids", "script_proxy_counts", "unique_proxy_group_counts")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
