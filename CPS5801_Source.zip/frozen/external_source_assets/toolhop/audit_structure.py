"""Read-only structural audit of pinned ToolHop. Never execute dataset code."""
from __future__ import annotations

import ast
import collections
import hashlib
import json
from pathlib import Path
import unicodedata
import warnings

EXPECTED_SHA256 = "0a51f71a44b7025645e452123af3caf2e348301922af91778e268db0188a7fab"
ROOT = Path(__file__).resolve().parent


def normalized_text(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def main() -> None:
    source = ROOT / "data" / "ToolHop.json"
    raw = source.read_bytes()
    observed = hashlib.sha256(raw).hexdigest()
    if observed != EXPECTED_SHA256:
        raise ValueError(f"Unexpected source hash: {observed}")
    data = json.loads(raw)
    queries = collections.defaultdict(list)
    docs = collections.defaultdict(list)
    names = collections.defaultdict(list)
    functions = collections.defaultdict(list)
    mismatches = []
    syntax_errors = []
    missing_fields = []
    reference_rows = []
    for row in data:
        rid = row["id"]
        queries[digest(normalized_text(row["question"]))].append(rid)
        tools = list(row["tools"].values())
        if len(tools) != len(row["functions"]):
            mismatches.append({"id": rid, "kind": "tool_function_count"})
        observed_names = []
        for j, code in enumerate(row["functions"]):
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", SyntaxWarning)
                    tree = ast.parse(code)
                functions[digest(ast.dump(tree, include_attributes=False))].append([rid, j])
                observed_names.extend(n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
            except SyntaxError as exc:
                syntax_errors.append({"id": rid, "ordinal": j, "message": str(exc)})
        for ordinal, tool in enumerate(tools):
            tid = f"toolhop:{rid}:{ordinal}"
            if set(tool) != {"name", "description", "parameters"}:
                missing_fields.append({"id": rid, "ordinal": ordinal, "keys": sorted(tool)})
            payload = {k: tool.get(k) for k in ("name", "description", "parameters")}
            doc_hash = digest(canonical_json(payload))
            docs[doc_hash].append(tid)
            names[tool["name"]].append(tid)
            if tool["name"] not in observed_names:
                mismatches.append({"id": rid, "kind": "tool_name_not_top_level_function", "name": tool["name"]})
            reference_rows.append({"tool_id": tid, "source_id": rid, "ordinal": ordinal,
                                   "name": tool["name"], "document_sha256": doc_hash,
                                   "family_proxy": normalized_text(tool["name"])})
    duplicates = [v for v in queries.values() if len(v) > 1]
    exclusion = next(v for v in queries.values() if 0 in v)
    report = {
        "source_sha256": observed,
        "audit_kind": "schema_and_static_ast_only_no_model_scores_no_code_execution",
        "rows": len(data), "tool_instances": len(reference_rows),
        "unique_normalized_queries": len(queries), "query_duplicate_groups": duplicates,
        "unique_exact_document_payloads": len(docs),
        "exact_document_duplicate_groups": [v for v in docs.values() if len(v) > 1],
        "unique_tool_names": len(names),
        "tool_names_with_multiple_instances": sum(len(v) > 1 for v in names.values()),
        "top_tool_name_counts": dict(sorted(((k, len(v)) for k, v in names.items()), key=lambda x: (-x[1], x[0]))[:15]),
        "distinct_static_function_asts": len(functions),
        "static_function_ast_duplicate_groups": [v for v in functions.values() if len(v) > 1],
        "schema_issues": missing_fields, "function_syntax_issues": syntax_errors,
        "tool_function_mapping_issues": mismatches,
        "reference_tool_count_distribution": dict(sorted(collections.Counter(len(r["tools"]) for r in data).items())),
        "engineering_query_exclusions": exclusion,
        "engineering_exclusion_reason": "Query id 0 inspected during handoff schema preparation; exclude its exact normalized-query group from final query metrics.",
        "candidate_catalogue_policy": "All 3912 document instances retained, including engineering-query tools; catalogue text is indexable but labels never training data.",
        "reference_query_count_after_engineering_exclusion": len(data) - len(exclusion),
        "validity_boundary": "Official per-task associated-tool lists are not exhaustive relevance judgments for pooled global retrieval; duplicate names are family proxies, not proof of equivalence.",
        "training_overlap_audit": "NOT_RUN_ON_THIS_MACHINE",
        "semantic_relevance_audit": "PENDING_HUMAN_REVIEW",
        "evaluation_status": "NO_MODEL_EVALUATION_PERFORMED"
    }
    (ROOT / "structural_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (ROOT / "tool_reference_index.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in reference_rows), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("rows", "tool_instances", "unique_exact_document_payloads", "unique_tool_names", "reference_query_count_after_engineering_exclusion", "schema_issues", "function_syntax_issues", "tool_function_mapping_issues")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
