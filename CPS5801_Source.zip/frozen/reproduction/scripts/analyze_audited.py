"""Independently validate saved predictions, then summarize the three paired seeds."""
import csv, hashlib, math, shutil
from common import *
R=ROOT/'results/audited_pilot_20261025';P=ROOT/'data/prepared';A=ROOT/'data/audited_pilot_20261025'
runs=['A01_bm25','A02_pretrained']+[f'A{3+2*(s-42)+(p=="bm25"):02}_{p}_seed{s}' for s in (42,43,44) for p in ('random','bm25')]
dev=read(P/'dev.json');ms=[];pred={};checks=[]
for run in runs:
    m=read(R/run/'metrics.json');rows=read(R/run/'predictions.json');pred[run]=rows
    assert [x['id'] for x in rows]==[x['id'] for x in dev]
    computed=[]
    for row,g in zip(rows,dev):
        assert row['positives']==g['positives'];truth=set(g['positives']);top=row['top10']
        assert len(set(top))==len(top)==10
        assert all(math.isfinite(v) for v in row['scores'])
        assert all(a>=b for a,b in zip(row['scores'],row['scores'][1:]))
        vals={f'recall@{k}':sum(t in truth for t in top[:k])/len(truth) for k in (1,3,5,10)}
        hits=[i+1 for i,t in enumerate(top) if t in truth];vals['mrr@10']=1/min(hits) if hits else 0
        assert all(abs(vals[k]-row[k])<1e-12 for k in vals)
        computed.append(vals)
    assert all(abs(np.mean([x[k] for x in computed])-m['metrics'][k])<1e-12 for k in computed[0])
    if m['training']:
        losses=[json.loads(x) for x in (R/run/'loss.jsonl').read_text().splitlines()]
        assert len(losses)==m['training']['steps']==64
        assert all(math.isfinite(x['loss']) and math.isfinite(x['grad_norm']) for x in losses)
        assert m['training']['embedding_weight_change_l2']>0
        assert m['training']['snapshot_manifest_sha256']==read(R/run/'config.json')['snapshot_manifest_sha256']
    ms.append(m);checks.append(run)
baseline_checks={}
for new,old in [('A01_bm25','P01_bm25'),('A02_pretrained','P02_pretrained')]:
    oldrows=read(ROOT/'results'/old/'predictions.json')
    baseline_checks[new]={'same_rankings':all(a['top10']==b['top10'] for a,b in zip(pred[new],oldrows)),
                         'same_metrics':ms[runs.index(new)]['metrics']==read(ROOT/'results'/old/'metrics.json')['metrics']}
paired=[];diffs=[]
for seed in (42,43,44):
    rr=f'A{3+2*(seed-42):02}_random_seed{seed}';hr=f'A{4+2*(seed-42):02}_bm25_seed{seed}'
    rc=read(R/rr/'config.json');hc=read(R/hr/'config.json')
    assert rc['schedule_sha256']==hc['schedule_sha256'] and rc['negative_manifest_sha256']==hc['negative_manifest_sha256']
    d=np.array([b['recall@5']-a['recall@5'] for a,b in zip(pred[rr],pred[hr])]);diffs.append(d)
    paired.append({'seed':seed,'random_run':rr,'hard_run':hr,'delta_recall5':float(d.mean()),
                   'wins':int(sum(d>0)),'ties':int(sum(d==0)),'losses':int(sum(d<0))})
avgdiff=np.mean(diffs,axis=0);rng=np.random.default_rng(50042)
boot=np.array([avgdiff[rng.integers(0,len(avgdiff),len(avgdiff))].mean() for _ in range(5000)])
groups={}
for policy in ('random','bm25'):
    relevant=[m for m in ms if m['training'] and m['training']['policy']==policy]
    groups[policy]={k:{'mean':float(np.mean([m['metrics'][k] for m in relevant])),
                       'sample_sd':float(np.std([m['metrics'][k] for m in relevant],ddof=1))} for k in ms[0]['metrics']}
target=ms[1]['metrics']['recall@10'];lengths=read(P/'full_raw_tool_token_lengths.json');budgets=[]
for condition,selected in [('BM25',[runs[0]]),('Pretrained',[runs[1]]),('Random',runs[2::2]),('Hard',runs[3::2])]:
    subset=[m for m in ms if m['run_id'] in selected]
    k=next((k for k in [1,3,5,10] if np.mean([m['metrics'][f'recall@{k}'] for m in subset])>=target),None)
    budgets.append({'condition':condition,'target':target,'selection':'mean development recall across three seeds for trained policies',
        'k':k,'reaches_target':k is not None,'mean_full_tool_tokens':float(np.mean([sum(lengths[t] for t in row['top10'][:k]) for run in selected for row in pred[run]])) if k else None,
        'per_run_k':{m['run_id']:next((j for j in [1,3,5,10] if m['metrics'][f'recall@{j}']>=target),None) for m in subset},
        'official_test_scored':False})
out={'phase':'human-reviewed pilot; fixed 1024/128 split, three paired seeds','runs':ms,'groups':groups,
     'paired_seeds':paired,'mean_paired_delta_recall5':float(avgdiff.mean()),
     'sample_sd_paired_delta_recall5':float(np.std([x['delta_recall5'] for x in paired],ddof=1)),
     'query_bootstrap_95':np.quantile(boot,[.025,.975]).tolist(),'bootstrap_seed':50042,'bootstrap_replicates':5000,
     'bootstrap_scope':'128 query differences averaged over three trained seed pairs; conditional query uncertainty, not all training variability; near-duplicate dependence unresolved',
     'candidate_budget':budgets,'baseline_reproduction':baseline_checks,
     'total_training_seconds':sum(m['training']['train_seconds'] for m in ms if m['training']),
     'total_evaluation_seconds':sum(m['total_evaluation_seconds'] for m in ms),
     'audit':read(ROOT/'results/human_audit_20261025/pool_statistics.json'),
     'data_changes':read(A/'changes.json')}
old=read(ROOT/'results/summary.json')
out['seed42_before_after']={policy:{'before':old['runs'][i]['metrics']['recall@5'],'after':ms[i]['metrics']['recall@5']} for policy,i in [('random',2),('bm25',3)]}
out['before_after_limitation']='Audit changes both positive registry and negative samples. One seed-42 comparison cannot isolate causal benefit of exclusions or establish population-wide cleaning.'
dump(R/'summary.json',out)
dump(R/'validation.json',{'saved_prediction_metrics_recomputed':checks,'all_finite_losses':True,'all_weights_changed':True,'paired_schedule_hashes_equal':True,'baseline_reproduction':baseline_checks})
dump(R/'error_examples.json',[{'id':dev[i]['id'],'query':dev[i]['query'],'mean_hard_minus_random_recall5':float(avgdiff[i]),'per_seed_delta':[float(d[i]) for d in diffs]} for i in list(np.argsort(avgdiff)[:5])+list(np.argsort(-avgdiff)[:5])])
with (R/'experiment_log.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fields=['run_id','finished_at','seed','policy','train_queries','dev_queries','candidate_tools','recall@1','recall@3','recall@5','recall@10','mrr@10','epochs','steps','train_seconds','peak_allocated_GiB','latency_ms_median','latency_ms_p95','schedule_sha256','negative_manifest_sha256','lr','effective_batch','temperature','model_revision','dataset_revision','preprocessing','training_precision','evaluation','audit_snapshot']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for m in ms:
        t=m['training'] or {};row={k:m.get(k,t.get(k)) for k in fields};row.update(m['metrics'])
        row.update(train_queries=1024 if t else 0,dev_queries=m['n'],lr=2e-5 if t else '',epochs=2 if t else 0,
                   effective_batch=32 if t else '',temperature=.05 if t else '',
                   model_revision=read(ROOT/'data/raw/model_metadata.json')['sha'] if 'bm25' not in m['run_id'] or t else '',
                   dataset_revision='fdf5a317455b1e60785de7ba587496aa6cc878e4',
                   preprocessing='exact normalized groups; provisional Latin filter; name/description/parameter types; q128/d384',
                   training_precision='bfloat16 mixed' if t else '',evaluation='128 dev; exact float32/stable ties; original labels',audit_snapshot='data/audited_pilot_20261025')
        w.writerow(row)
dump(R/'rng_settings.json',{str(seed):{'model_seed':seed,'query_order_seed':seed,'positive_seed':1000+seed,'random_negative_seed':2000+seed,'hard_negative_seed':3000+seed} for seed in (42,43,44)})
if not (R/'config_recorded_at_start.json').exists():shutil.copy2(R/'config.json',R/'config_recorded_at_start.json')
cfg=read(R/'config_recorded_at_start.json')
for k in ['positive_rng_seed','random_negative_rng_seed','hard_negative_rng_seed']:cfg.pop(k,None)
cfg['per_seed_rng_settings']=read(R/'rng_settings.json')
cfg['additional_negative_mask']='Registered positives, identical serialized positive inputs, and all reviewed unresolved query-tool pairs; no global semantic propagation'
cfg['metadata_clarification']='Legacy seed-42-only RNG fields replaced by the actual per-seed settings; startup config preserved. This is a metadata correction, not a run change.'
dump(R/'config.json',cfg)
old_schedule=read(P/'shared_schedule_seed42.json');new_schedule=read(A/'shared_schedule_seed42.json')
assert [(x['query_id'],x['epoch']) for x in old_schedule]==[(x['query_id'],x['epoch']) for x in new_schedule]
dump(R/'schedule_comparison.json',{'same_seed42_query_order':True,'seed42_changed_positive_exposures':sum(a['positive']!=b['positive'] for a,b in zip(old_schedule,new_schedule)),
    'note':'Positive registry edits can change RNG consumption and subsequent choices. Both new policies still use exactly the same saved schedule.'})
print(json.dumps({'paired':paired,'mean_delta':out['mean_paired_delta_recall5'],'sd_delta':out['sample_sd_paired_delta_recall5'],'query_ci':out['query_bootstrap_95'],'groups':groups,'budgets':budgets,'validation':baseline_checks},indent=2))
