"""Finish the already-running experiment, then evaluate and validate its outputs."""
import json,pathlib,subprocess,sys,time
R=pathlib.Path(__file__).resolve().parents[1]
state=R/'logs/main_training_engine_process_status.json'
start=time.monotonic()
while True:
    try:s=json.loads(state.read_text())
    except (FileNotFoundError,json.JSONDecodeError):s={}
    if s.get('status')=='completed':break
    if s.get('status') in ('failed','interrupted'):raise RuntimeError('Training failed; downstream evaluation was not started')
    if time.monotonic()-start>7200:raise TimeoutError('Training monitor exceeded two hours; inspect process state')
    time.sleep(5)
for script in ['validate_main_snapshot.py','evaluate_main_test.py','analyze_main_study.py']:
    print('Starting',script,flush=True);subprocess.run([sys.executable,str(R/'scripts'/script)],cwd=R,check=True)
print('Expanded training, official evaluation and metric validation complete',flush=True)
