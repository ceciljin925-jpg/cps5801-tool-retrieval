from download_resources import *
jobs=[]
for name in ['ToolRet-Queries','ToolRet-Tools']:
    m=json.loads((RAW/f'{name}-metadata.json').read_text(encoding='utf-8-sig'))
    for s in m['siblings']:
        f=s['rfilename']
        if f.endswith('.parquet') or f=='README.md':
            jobs.append((f'https://huggingface.co/datasets/mangopy/{name}/resolve/{m["sha"]}/{f}',RAW/name/f))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
    manifest=list(ex.map(lambda j:get(*j),jobs))
(RAW/'eval_download_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
