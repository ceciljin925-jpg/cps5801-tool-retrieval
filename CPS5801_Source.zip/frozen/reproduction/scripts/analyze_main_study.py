"""Recompute every saved metric and summarize paired development/test results."""
import collections,csv,datetime,hashlib,math
from common import *
P=ROOT/'data/main_20261025';R=ROOT/'results/main_20261025'
RUNS=['M01_bm25','M02_pretrained']+[f'M{3+2*(s-42)+(p=="bm25"):02}_{p}_seed{s}' for s in (42,43,44) for p in ('random','bm25')]
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def summarize(folder,queries,corpus):
    models=[];pred={};text={x['id']:x['text'] for x in corpus};valid=set(text)
    for run in RUNS:
        m=read(folder/run/'metrics.json');rows=read(folder/run/'predictions.json');assert len(rows)==len(queries)
        for x,g in zip(rows,queries):
            assert x['id']==g['id'] and x['positives']==g['positives']
            assert len(set(x['top10']))==10 and set(x['top10'])<=valid
            assert all(math.isfinite(v) for v in x['scores']) and all(a>=b for a,b in zip(x['scores'],x['scores'][1:]))
            assert all(x['top10'][i]<=x['top10'][i+1] for i in range(9) if x['scores'][i]==x['scores'][i+1])
            truth=set(g['positives']);calc={f'recall@{k}':sum(t in truth for t in x['top10'][:k])/len(truth) for k in (1,3,5,10)}
            positions=[i+1 for i,t in enumerate(x['top10']) if t in truth];calc['mrr@10']=1/min(positions) if positions else 0
            assert all(abs(calc[k]-x[k])<1e-12 for k in calc)
        assert all(abs(np.mean([x[k] for x in rows])-m['metrics'][k])<1e-12 for k in m['metrics'])
        models.append(m);pred[run]=rows
    groups={}
    for name,runs in {'BM25':RUNS[:1],'Pretrained':RUNS[1:2],'Random':RUNS[2::2],'Hard':RUNS[3::2]}.items():
        ms=[models[RUNS.index(r)] for r in runs]
        groups[name]={k:{'mean':float(np.mean([m['metrics'][k] for m in ms])),'sample_sd':float(np.std([m['metrics'][k] for m in ms],ddof=1)) if len(ms)>1 else None} for k in models[0]['metrics']}
    differences=np.array([[b['recall@5']-a['recall@5'] for a,b in zip(pred[rr],pred[hr])] for rr,hr in zip(RUNS[2::2],RUNS[3::2])]);delta=differences.mean(axis=0)
    rng=np.random.default_rng(50042);boot=[float(delta[rng.integers(0,len(delta),len(delta))].mean()) for _ in range(5000)]
    strata={}
    for label,mask in [('one positive',np.array([len(g['positives'])==1 for g in queries])),('multiple positives',np.array([len(g['positives'])>1 for g in queries]))]:
        strata[label]={'n':int(mask.sum()),'random':float(np.mean([[x['recall@5'] for x,m in zip(pred[r],mask) if m] for r in RUNS[2::2]])),'hard':float(np.mean([[x['recall@5'] for x,m in zip(pred[r],mask) if m] for r in RUNS[3::2]])),'delta':float(delta[mask].mean())}
    representation={}
    for label,runs in [('Random',RUNS[2::2]),('Hard',RUNS[3::2])]:
        cover=[];distinct=[]
        for r in runs:
            for x in pred[r]:
                got={text[t] for t in x['top10'][:5]};cover.append(sum(text[t] in got for t in x['positives'])/len(x['positives']));distinct.append(len(got))
        representation[label]={'input_equivalent_coverage5':float(np.mean(cover)),'mean_distinct_inputs_top5':float(np.mean(distinct))}
    tracks={}
    for track in sorted({g.get('track','development') for g in queries}):
        ix=[i for i,g in enumerate(queries) if g.get('track','development')==track]
        tracks[track]={'n':len(ix),'delta':float(delta[ix].mean()),**{name:float(np.mean([[pred[r][i]['recall@5'] for i in ix] for r in runs])) for name,runs in {'BM25':RUNS[:1],'Pretrained':RUNS[1:2],'Random':RUNS[2::2],'Hard':RUNS[3::2]}.items()}}
    paired=[dict(seed=s,random=models[2+2*i]['metrics']['recall@5'],hard=models[3+2*i]['metrics']['recall@5'],delta=float(differences[i].mean()),wins=int((differences[i]>0).sum()),ties=int((differences[i]==0).sum()),losses=int((differences[i]<0).sum())) for i,s in enumerate((42,43,44))]
    normalized=collections.defaultdict(list)
    for i,g in enumerate(queries):normalized[norm(g['query'])].append(i)
    cluster_ci=None
    if len(normalized)<len(queries):
        sums=np.array([delta[ix].sum() for ix in normalized.values()]);sizes=np.array([len(ix) for ix in normalized.values()]);rng=np.random.default_rng(50043);cb=[]
        for _ in range(5000):ix=rng.integers(0,len(sizes),len(sizes));cb.append(float(sums[ix].sum()/sizes[ix].sum()))
        cluster_ci=np.quantile(cb,[.025,.975]).tolist()
    out=dict(runs=models,groups=groups,paired_seeds=paired,mean_paired_delta_recall5=float(delta.mean()),sample_sd_paired_delta_recall5=float(np.std(differences.mean(axis=1),ddof=1)),query_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),query_bootstrap_seed=50042,bootstrap_replicates=5000,normalized_query_cluster_bootstrap_95=cluster_ci,normalized_query_groups=len(normalized),positive_count_strata=strata,representation=representation,tracks=tracks,query_uncertainty_scope='Conditional on the three fitted seed pairs; does not include label errors or general semantic dependence')
    dump(folder/'summary.json',out)
    chosen=list(np.argsort(delta)[:6])+list(np.argsort(-delta)[:6])
    dump(folder/'error_examples.json',[dict(id=queries[i]['id'],query=queries[i]['query'],positives=queries[i]['positives'],delta=float(delta[i]),random_seed42=pred[RUNS[2]][i]['top10'],hard_seed42=pred[RUNS[3]][i]['top10']) for i in chosen])
    return out,pred
def main():
    for f,h in read(P/'freeze_manifest.json')['files'].items():assert digest(ROOT/f)==h,f
    dev,dp=summarize(R,read(P/'dev.json'),read(P/'corpus.json'));test,tp=summarize(R/'official_test',read(P/'test.json'),read(P/'test_corpus.json'))
    trainings=[]
    for run in RUNS[2:]:
        t=read(R/run/'training.json');loss=[json.loads(x) for x in (R/run/'loss.jsonl').read_text().splitlines()]
        assert len(loss)==t['steps']==625 and t['embedding_weight_change_l2']>0
        assert all(math.isfinite(x['loss']) and math.isfinite(x['grad_norm']) for x in loss)
        assert t['snapshot_manifest_sha256']==digest(P/'freeze_manifest.json');trainings.append(t)
    for a,b in zip(trainings[::2],trainings[1::2]):assert a['schedule_sha256']==b['schedule_sha256'] and a['negative_manifest_sha256']==b['negative_manifest_sha256']
    selection=read(R/'official_test/development_selection.json');lengths=read(R/'test_tools_full_raw_token_lengths.json');budget=[]
    selected_at=datetime.datetime.fromisoformat(selection['frozen_at'])
    assert max(datetime.datetime.fromisoformat(m['finished_at']) for m in dev['runs'])<=selected_at
    assert all(selected_at<=datetime.datetime.fromisoformat(m['finished_at']) and m['selection_sha256']==digest(R/'official_test/development_selection.json') for m in test['runs'])
    assert datetime.datetime.fromisoformat(read(R/'analysis_addendum_pretest.json')['recorded_at'])<=selected_at
    for name,sel in selection['groups'].items():
        k=sel['selected_k'];runs=sel['runs']
        budget.append(dict(condition=name,selected_k=k,target_development_recall10=selection['target'],test_recall_at_selected_k=float(np.mean([row[f'recall@{k}'] for r in runs for row in tp[r]])) if k else None,mean_test_tool_tokens=float(np.mean([sum(lengths[t] for t in row['top10'][:k]) for r in runs for row in tp[r]])) if k else None,proxy='Raw JSON encoded with fixed E5 tokenizer; no system/query prompt, provider bill or agent execution included'))
    out=dict(development=dev,official_test=test,candidate_budget=budget,training=trainings,total_training_seconds=sum(t['train_seconds'] for t in trainings),audit=read(ROOT/'results/main_human_audit_20261025/pool_statistics.json'),data_changes=read(P/'changes.json'),representation_stats=read(R/'representation_stats.json'),snapshot_validation=read(R/'snapshot_validation.json'))
    dump(R/'study_summary.json',out)
    fields=['run_id','split','finished_at','seed','policy','train_queries','eval_queries','candidate_tools','recall@1','recall@3','recall@5','recall@10','mrr@10','epochs','steps','train_seconds','peak_train_GiB','index_seconds','search_seconds','latency_ms_median','latency_ms_p95','model_revision','dataset_revision','schedule_sha256','negative_manifest_sha256','snapshot_sha256','lr','microbatch','accumulation','temperature','precision','serialization']
    with (R/'experiment_log.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for split,s in [('development',dev),('official_test_pooled',test)]:
            for m in s['runs']:
                t=next((x for x in trainings if x['run_id']==m['run_id']),{})
                row={k:m.get(k,t.get(k,'')) for k in fields};row.update(m['metrics']);row.update(split=split,train_queries=10000 if t else 0,eval_queries=m['n'],peak_train_GiB=t.get('peak_allocated_GiB',''),model_revision='ffb93f3bd4047442299a41ebb6fa998a38507c52' if m['run_id']!='M01_bm25' else '',dataset_revision='fdf5a317455b1e60785de7ba587496aa6cc878e4',snapshot_sha256=digest(P/'freeze_manifest.json'),lr=2e-5 if t else '',microbatch=8 if t else '',accumulation=4 if t else '',temperature=.05 if t else '',precision='bf16 training / fp32 evaluation' if t else 'fp32 evaluation',serialization='main_common.py; q128/d384')
                writer.writerow(row)
    dump(R/'validation.json',dict(all_16_prediction_files_recomputed=True,paired_schedule_hashes_equal=True,six_finite_training_logs=True,six_changed_checkpoints=True,snapshot_hashes_match=True,test_selection_frozen_before_scores=True))
    cfg=read(R/'config.json');cfg.update(pilot=False,per_seed_rng_settings={str(s):{'model':s,'order':s,'positive':1000+s,'random_negative':2000+s,'hard_negative':3000+s} for s in (42,43,44)},additional_negative_mask='All query-specific registered positives, identical serialized positive inputs and reviewed unresolved pairs',main_audit_sampling_seed=20261026,main_split_seed_label='20261025',official_test_evaluation='Completed under separate frozen pooled protocol')
    for k in ['positive_rng_seed','random_negative_rng_seed','hard_negative_rng_seed','audit_rng_seed','sampling_seed']:cfg.pop(k,None)
    cfg['metadata_clarification']='Original config.json is preserved as written at startup. This companion removes inherited pilot-only flags/RNG fields and describes the actual expanded frozen schedules; it does not change any run.'
    dump(R/'config_clarified.json',cfg)
    print(json.dumps({'development_delta':dev['mean_paired_delta_recall5'],'test_delta':test['mean_paired_delta_recall5'],'test_ci':test['query_bootstrap_95'],'training_seconds':out['total_training_seconds']}))
if __name__=='__main__':main()
