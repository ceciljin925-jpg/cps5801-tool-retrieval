import random, time
from common import *
P=ROOT/'data/prepared'
def event(kind,**kw):print(kind,kw,flush=True)
def make_schedule(train,corpus,train_ids):
    tool_ids=[t['id'] for t in corpus if t['id'] in train_ids];texts=[t['text'] for t in corpus if t['id'] in train_ids]
    from collections import defaultdict
    same_text=defaultdict(set);lookup_text={t['id']:t['text'] for t in corpus}
    for tid,txt in zip(tool_ids,texts):same_text[txt].add(tid)
    forbidden={g['id']:set(g['positives']).union(*(same_text[lookup_text[x]] for x in g['positives'])) for g in train}
    dump(P/'input_identical_exclusion_ids.json',{q:sorted(xs) for q,xs in forbidden.items()})
    t=time.perf_counter();bm=BM25(texts);index_s=time.perf_counter()-t;t=time.perf_counter()
    pools={};keep=[];drops=[]
    for g in train:
        ix,_=bm.top(g['query'],50);pool=[tool_ids[j] for j in ix if tool_ids[j] not in forbidden[g['id']]]
        if len(pool)<4:drops.append(g['id']);continue
        pools[g['id']]=pool;keep.append(g)
    dump(P/'bm25_top50_eligible.json',pools);dump(P/'pool_dropped_queries.json',drops)
    rng_order=random.Random(42);rng_pos=random.Random(1042);rng_r=random.Random(2042);rng_h=random.Random(3042)
    neg={};schedule=[]
    for g in keep:
        picked=[]
        while len(picked)<4:
            x=rng_r.choice(tool_ids)
            if x not in forbidden[g['id']] and x not in picked:picked.append(x)
        neg[g['id']]={'random':picked,'bm25':rng_h.sample(pools[g['id']],4)}
    for epoch in range(2):
        order=list(range(len(keep)));rng_order.shuffle(order)
        schedule += [{'epoch':epoch,'query_id':keep[i]['id'],'positive':rng_pos.choice(keep[i]['positives'])} for i in order]
    dump(P/'shared_schedule_seed42.json',schedule);dump(P/'negatives_seed42.json',neg)
    # Uniform pairs from each original eligible pool. Pool identity is in a separate key.
    byid={g['id']:g for g in keep};lookup={t['id']:t for t in corpus};ar=random.Random(4042)
    hp=[(q,x) for q,xs in pools.items() for x in xs];rp=set()
    while len(rp)<100:
        g=ar.choice(keep);x=ar.choice(tool_ids)
        if x not in forbidden[g['id']]:rp.add((g['id'],x))
    sample={'random':sorted(rp),'bm25':ar.sample(hp,100)}
    pairs=sorted(set(sample['random'])|set(sample['bm25']),key=lambda p:sha('audit'+str(p)))
    blind=[];key=[]
    for i,(q,x) in enumerate(pairs):
        pid=f'A{i+1:03d}';blind.append({'pair_id':pid,'query':byid[q]['query'],'tool':lookup[x]['raw'],'label':'','evidence':'','reviewer':'','reviewed_at':''})
        key.append({'pair_id':pid,'query_id':q,'tool_id':x,'pools':[s for s,ps in sample.items() if (q,x) in ps]})
    dump(P/'human_audit_blind.json',blind);dump(P/'human_audit_key.json',key)
    info={'training_corpus_bm25_index_seconds':index_s,'mining_schedule_audit_seconds':time.perf_counter()-t,
        'kept_queries':len(keep),'dropped':len(drops),'human_audit_status':'pending; pilot masks known positives and identical serialized inputs',
        'random_pool_pairs':sum(len(tool_ids)-len(forbidden[g['id']] & train_ids) for g in keep),'hard_pool_pairs':len(hp),'audit_unique_pairs':len(pairs),
        'input_identical_excluded_pairs_beyond_known_positives':sum(len(forbidden[g['id']]-set(g['positives'])) for g in keep),
        'collision_rule':'exclude input-identical positives from both negative policies; do not add relevance labels or infer functional equivalence'}
    dump(P/'mining.json',info);event('mining_completed',**info)
    return keep,schedule,neg

if __name__=='__main__':
    make_schedule(read(P/'train.json'),read(P/'corpus.json'),set(read(P/'train_tool_ids.json')))
