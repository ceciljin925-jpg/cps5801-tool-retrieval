"""Data-leakage, audit propagation and exact-interval checks before GPU work."""
import hashlib, unittest
from common import *
from prepare_audited_pilot import finite_interval
from scipy.stats import hypergeom
P=ROOT/'data/prepared';A=ROOT/'data/audited_pilot_20261025'

class Controls(unittest.TestCase):
    def test_frozen_bytes(self):
        for name, expected in read(A/'freeze_manifest.json')['files'].items():
            with (ROOT/name).open('rb') as f: self.assertEqual(hashlib.file_digest(f,'sha256').hexdigest(),expected,name)

    def test_human_attestation(self):
        p=read(ROOT/'results/human_audit_20261025/confirmed_review.json')
        self.assertEqual(p['human_confirmed_count'],200)
        self.assertFalse(p['human_attestation']['independent_double_annotation'])
        self.assertTrue(all(x['human_review']['status']=='confirmed' and x['human_review']['label']==x['suggestion']['label'] for x in p['items']))

    def test_query_isolation_and_registry(self):
        old={g['id']:g for g in read(P/'train.json')};new={g['id']:g for g in read(A/'train.json')}
        self.assertEqual(set(old),set(new));self.assertFalse(set(new)&{g['id'] for g in read(P/'dev.json')})
        registry=read(A/'positive_registry_updates.json')
        additions={(x['query_id'],x['tool_id']) for x in registry if x['add_to_positive_registry']}
        actual={(q,t) for q,g in new.items() for t in set(g['positives'])-set(old[q]['positives'])}
        self.assertEqual(actual,additions);self.assertEqual(len(actual),8)

    def test_all_seeds_no_excluded_exposure(self):
        train={g['id']:g for g in read(A/'train.json')};tools=set(read(P/'train_tool_ids.json'))
        masks={q:set(v) for q,v in read(A/'forbidden_ids.json').items()};hard=read(A/'bm25_top50_eligible.json')
        for seed in (42,43,44):
            neg=read(A/f'negatives_seed{seed}.json');sched=read(A/f'shared_schedule_seed{seed}.json')
            self.assertEqual(set(neg),set(train));self.assertEqual(len(sched),2*len(train))
            for epoch in (0,1):self.assertEqual(sorted(s['query_id'] for s in sched if s['epoch']==epoch),sorted(train))
            for s in sched:self.assertIn(s['positive'],train[s['query_id']]['positives'])
            for q,ns in neg.items():
                for policy in ('random','bm25'):
                    self.assertEqual(len(ns[policy]),4);self.assertEqual(len(set(ns[policy])),4)
                    self.assertTrue(set(ns[policy])<=tools);self.assertFalse(set(ns[policy])&masks[q])
                self.assertTrue(set(ns['bm25'])<=set(hard[q]))

    def test_interval_matches_exhaustive_inversion(self):
        for population,sample in [(20,5),(10,10),(100,1)]:
            for x in range(sample+1):
                accepted=[k for k in range(population+1) if hypergeom.sf(x-1,population,k,sample)>=.025 and hypergeom.cdf(x,population,k,sample)>=.025]
                self.assertEqual(finite_interval(population,sample,x)['count_bounds'],[min(accepted),max(accepted)])

    def test_original_results_unchanged(self):
        for row in read(ROOT/'artifact_manifest.json'):
            # This status document is intentionally advanced after the chat attestation.
            if row['path']=='protocol.json':
                self.assertTrue(read(ROOT/'protocol.json')['human_review']['status'].startswith('completed'))
                self.assertEqual(read(ROOT/'results/human_audit_20261025/protocol_before_confirmation.json')['human_review']['status'],'pending')
                continue
            path=ROOT/row['path']
            with path.open('rb') as f:self.assertEqual(hashlib.file_digest(f,'sha256').hexdigest(),row['sha256'],row['path'])

if __name__=='__main__':unittest.main(verbosity=2)
