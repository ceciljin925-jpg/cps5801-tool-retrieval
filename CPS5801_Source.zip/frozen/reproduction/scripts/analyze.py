import csv, collections, hashlib, platform, subprocess
from common import *
P=ROOT/'data/prepared';R=ROOT/'results'
runs=['P01_bm25','P02_pretrained','P03_random_seed42','P04_bm25_seed42']
ms=[read(R/r/'metrics.json') for r in runs]
preds={r:read(R/r/'predictions.json') for r in runs}
dev=read(P/'dev.json');queries={g['id']:g for g in dev}
assert all([x['id'] for x in preds[r]]==[g['id'] for g in dev] for r in runs)
a=np.array([x['recall@5'] for x in preds[runs[2]]]);b=np.array([x['recall@5'] for x in preds[runs[3]]]);diff=b-a
rng=np.random.default_rng(50042);boot=np.array([diff[rng.integers(0,len(diff),len(diff))].mean() for _ in range(5000)])
paired={'hard_minus_random_recall5':float(diff.mean()),'query_bootstrap_95':np.quantile(boot,[.025,.975]).tolist(),
    'bootstrap_replicates':5000,'bootstrap_seed':50042,'training_seeds':1,'wins':int(sum(diff>0)),'ties':int(sum(diff==0)),'losses':int(sum(diff<0)),
    'interpretation':'exploratory development-query uncertainty conditional on one training seed; near-duplicate dependence unresolved; not final test or seed uncertainty'}
dump(R/'paired_analysis.json',paired)
target=ms[1]['metrics']['recall@10'];costs=[];lens=read(P/'full_serialized_tool_token_lengths.json')
raw_lens=read(P/'full_raw_tool_token_lengths.json')
for r,m in zip(runs,ms):
    k=next((k for k in [1,3,5,10] if m['metrics'][f'recall@{k}']>=target),None)
    costs.append({'run':r,'validation_target':target,'selected_k':k,'reaches_target':k is not None,
        'mean_untruncated_serialized_input_tokens':float(np.mean([sum(lens[x] for x in p['top10'][:k]) for p in preds[r]])) if k else None,
        'mean_full_raw_tool_tokens':float(np.mean([sum(raw_lens[x] for x in p['top10'][:k]) for p in preds[r]])) if k else None,
        'token_scope':'full raw tool JSON, sorted keys, E5 tokenizer without special tokens; serialized input tokens also retained separately; not API dollars'})
dump(R/'pilot_candidate_budget.json',costs)
examples=[]
for i in list(np.argsort(diff)[:3])+list(np.argsort(-diff)[:3]):
    g=dev[int(i)];examples.append({'id':g['id'],'query':g['query'],'n_positives':len(g['positives']),'random_recall5':float(a[i]),'hard_recall5':float(b[i]),'delta':float(diff[i])})
dump(R/'error_examples.json',examples)
corpus=read(P/'corpus.json');counts=collections.Counter(x['text'] for x in corpus);lookup={x['id']:x['text'] for x in corpus}
train={g['id']:g for g in read(P/'train.json')};neg=read(P/'negatives_seed42.json');collisions={}
for policy in ['random','bm25']:
    hits=[]
    for q,ns in neg.items():
        ps={lookup[x] for x in train[q]['positives']}
        hits += [(q,x) for x in ns[policy] if lookup[x] in ps]
    collisions[policy]={'input_identical_negative_pairs':len(hits),'pairs':hits}
dump(R/'input_collision_audit.json',{'serialized_text_groups_with_multiple_ids':sum(n>1 for n in counts.values()),'tools_in_those_groups':sum(n for n in counts.values() if n>1),'negative_exposure':collisions})
diagnostic={}
for r in runs:
    diagnostic[r]={}
    for k in [1,3,5,10]:
        vals=[]
        for row in preds[r]:
            returned={lookup[x] for x in row['top10'][:k]}
            vals.append(sum(lookup[x] in returned for x in row['positives'])/len(row['positives']))
        diagnostic[r][f'input_equivalent_coverage@{k}']=float(np.mean(vals))
dump(R/'representation_diagnostic.json',{'warning':'Input equivalence is not established functional equivalence. Diagnostic only; does not modify official positive labels or main Recall.','conditions':diagnostic})
with (R/'experiment_log.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fields=['run_id','finished_at','split','n','candidate_tools','recall@1','recall@3','recall@5','recall@10','mrr@10','train_seconds','steps','index_seconds','latency_ms_median','latency_ms_p95']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for m in ms:
        row={k:m.get(k) for k in fields};row.update(m['metrics']);row.update({k:(m.get('training') or {}).get(k) for k in ['train_seconds','steps']});w.writerow(row)
dump(R/'summary.json',{'runs':ms,'paired':paired,'candidate_budget':costs})
manifest=[]
for folder in ['scripts','results','data/prepared']:
    for p in sorted((ROOT/folder).rglob('*')):
        if p.is_file() and '__pycache__' not in str(p) and p.name!='artifact_manifest.json':
            with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
            manifest.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':h})
dump(ROOT/'artifact_manifest.json',manifest)
print(json.dumps({'paired':paired,'results':[{ 'run':m['run_id'],**m['metrics']} for m in ms]},indent=2))
