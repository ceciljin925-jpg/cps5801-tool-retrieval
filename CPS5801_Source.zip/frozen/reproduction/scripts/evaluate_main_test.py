"""One frozen pooled-catalogue test pass after development-only k selection."""
import collections,hashlib,json,math,random,time
import experiment as base
from common import *
P=ROOT/'data/main_20261025';R=ROOT/'results/main_20261025';T=R/'official_test';torch=base.torch
RUNS=['M01_bm25','M02_pretrained']+[f'M{3+2*(s-42)+(p=="bm25"):02}_{p}_seed{s}' for s in (42,43,44) for p in ('random','bm25')]
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def event(kind,**kw):
    row={'time':base.now(),'event':kind,**kw}
    with (ROOT/'logs/main_test_events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
    print(kind,kw,flush=True)
def evaluate(run,model,tok,corpus,test,bm=None):
    out=T/run;out.mkdir(parents=True,exist_ok=True)
    if (out/'metrics.json').exists():return read(out/'metrics.json')
    rows=[];t0=time.perf_counter();ids=[d['id'] for d in corpus]
    latency_idx=sorted(random.Random(50142).sample(range(len(test)),128));lat=[]
    if bm is None:
        torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize()
        emb=base.encode(model,tok,[x['text'] for x in corpus],'passage: ',384).cuda();torch.cuda.synchronize();index_s=time.perf_counter()-t0
        t1=time.perf_counter();queries=base.encode(model,tok,[g['query'] for g in test],'query: ',128).cuda();torch.cuda.synchronize();query_s=time.perf_counter()-t1
        t1=time.perf_counter()
        for lo in range(0,len(test),256):
            scores=(queries[lo:lo+256]@emb.T).cpu().numpy()
            for j,g in enumerate(test[lo:lo+256]):
                ix=np.argsort(-scores[j],kind='stable')[:10];top=[ids[k] for k in ix]
                rows.append(dict(id=g['id'],positives=g['positives'],top10=top,scores=scores[j,ix].tolist(),**metrics(top,g['positives'])))
        search_s=time.perf_counter()-t1
        for i in list(latency_idx[:5])+latency_idx:
            torch.cuda.synchronize();t=time.perf_counter();ts=tok('query: '+test[i]['query'],truncation=True,max_length=128,return_tensors='pt').to('cuda')
            with torch.inference_mode():q=base.pooling(model,ts);torch.topk(q@emb.T,10)
            torch.cuda.synchronize();lat.append(1000*(time.perf_counter()-t))
        peak=torch.cuda.max_memory_allocated()/2**30;del emb,queries
    else:
        index_s=bm[1];index=bm[0];query_s=0;t1=time.perf_counter()
        for g in test:
            ix,s=index.top(g['query'],10);top=[ids[k] for k in ix]
            rows.append(dict(id=g['id'],positives=g['positives'],top10=top,scores=s.tolist(),**metrics(top,g['positives'])))
        search_s=time.perf_counter()-t1
        for i in list(latency_idx[:5])+latency_idx:
            t=time.perf_counter();index.top(test[i]['query'],10);lat.append(1000*(time.perf_counter()-t))
        peak=0
    lat=lat[5:];assert len(lat)==128
    m=dict(run_id=run,finished_at=base.now(),split='official test, pooled catalogue',n=len(test),candidate_tools=len(corpus),metrics={k:float(np.mean([r[k] for r in rows])) for k in metrics([],['x'])},index_seconds=index_s,query_encoding_seconds=query_s,search_seconds=search_s,total_evaluation_seconds=time.perf_counter()-t0,latency_ms_median=float(np.median(lat)),latency_ms_p95=float(np.percentile(lat,95)),latency_boundary='128 fixed test queries, five warmups, batch one. Dense: tokenize+encode+exact score+topk; BM25: tokenize+score+stable sort. Prediction rankings separately use stable full sort.',peak_eval_allocated_GiB=peak,latency_query_ids=[test[i]['id'] for i in latency_idx],test_snapshot_sha256=digest(P/'test.json'),test_corpus_sha256=digest(P/'test_corpus.json'),evaluation_code_sha256=digest(pathlib.Path(__file__)),selection_sha256=digest(T/'development_selection.json'))
    dump(out/'predictions.json',rows);dump(out/'latency_ms.json',lat);dump(out/'metrics.json',m);event('test_evaluation_completed',run=run,metrics=m['metrics'])
    return m
def main():
    T.mkdir(parents=True,exist_ok=True)
    assert read(ROOT/'logs/main_training_engine_process_status.json')['status']=='completed'
    for f,h in read(P/'freeze_manifest.json')['files'].items():assert digest(ROOT/f)==h,f
    dev=[read(R/run/'metrics.json') for run in RUNS];target=dev[1]['metrics']['recall@10'];groups={'BM25':RUNS[:1],'Pretrained':RUNS[1:2],'Random':RUNS[2::2],'Hard':RUNS[3::2]}
    selection=dict(frozen_at=base.now(),target=target,rule='Smallest k in [1,3,5,10] reaching pretrained development recall@10, mean over three seeds for trained policies',groups={})
    for name,runs in groups.items():
        ms=[dev[RUNS.index(r)] for r in runs]
        k=next((k for k in (1,3,5,10) if np.mean([m['metrics'][f'recall@{k}'] for m in ms])>=target),None)
        selection['groups'][name]={'runs':runs,'selected_k':k}
    if (T/'development_selection.json').exists():
        old=read(T/'development_selection.json');assert old['groups']==selection['groups'] and old['target']==target
    else:
        assert not list(T.glob('M*/metrics.json'))
        dump(T/'development_selection.json',selection)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    test=read(P/'test.json');corpus=read(P/'test_corpus.json');assert len(test)==7961 and len(corpus)==44453
    tok=base.AutoTokenizer.from_pretrained(base.MODEL,local_files_only=True)
    if not (T/'M01_bm25/metrics.json').exists():
        start=time.perf_counter();bm=BM25([d['text'] for d in corpus]);index_s=time.perf_counter()-start
        evaluate('M01_bm25',None,tok,corpus,test,(bm,index_s));del bm
    for run in RUNS[1:]:
        if (T/run/'metrics.json').exists():continue
        model=base.load_model() if run=='M02_pretrained' else base.AutoModel.from_pretrained(R/run/'checkpoint',local_files_only=True,attn_implementation='eager').cuda()
        evaluate(run,model,tok,corpus,test);del model;torch.cuda.empty_cache()
    event('official_test_complete',runs=len(RUNS),queries=len(test),candidate_tools=len(corpus))
if __name__=='__main__':main()
