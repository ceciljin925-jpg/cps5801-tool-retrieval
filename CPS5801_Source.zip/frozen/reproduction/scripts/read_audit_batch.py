"""Display blinded pairs without policy/rank; omit bulky response examples and defaults."""
import json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(__file__).resolve().parents[1]
a=json.loads((root/'data/prepared/human_audit_blind.json').read_text(encoding='utf-8'))
def clean(x):
    if isinstance(x,dict):return {k:clean(v) for k,v in x.items() if k not in ['default','template_response']}
    if isinstance(x,list):return [clean(v) for v in x]
    return x
for x in a[int(sys.argv[1])-1:int(sys.argv[2])]:
    print(x['pair_id'],'QUERY:',x['query']);print('TOOL:',json.dumps(clean(x['tool']),ensure_ascii=False,separators=(',',':')))
