"""Durable exit-state wrapper; use with Start-Process -WindowStyle Hidden."""
import datetime, json, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parents[1]
target=sys.argv[1];state=root/'logs'/f'{pathlib.Path(target).stem}_process_status.json'
now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
start=now();state.write_text(json.dumps({'script':target,'started_at':start,'status':'running'}))
try:
    code=subprocess.call([sys.executable,target,*sys.argv[2:]],cwd=root)
    state.write_text(json.dumps({'script':target,'started_at':start,'finished_at':now(),'status':'completed' if code==0 else 'failed','exit_code':code}))
except BaseException as e:
    state.write_text(json.dumps({'script':target,'started_at':start,'finished_at':now(),'status':'interrupted','error':repr(e)}));raise
sys.exit(code)
