"""Package individually reasoned suggestions; never create human attestations."""
import collections
import hashlib
import json
import pathlib
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'results/ai_audit_20261025'
OUT = ROOT / 'output'
SOURCE = ROOT / 'data/prepared/human_audit_blind.json'
LABELS = {'N': 'defensible negative', 'V': 'valid alternative',
          'C': 'omitted jointly-required component', 'U': 'unresolved'}

def read_tsv(path):
    rows = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        pid, code, confidence, evidence = line.split('\t')
        assert pid not in rows and code in LABELS and evidence
        rows[pid] = dict(code=code, label=LABELS[code], confidence=confidence, evidence=evidence)
    return rows

protocol = json.loads((AUDIT / 'protocol.json').read_text(encoding='utf-8'))
source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert source_hash == protocol['source_sha256'], 'Original blinded file changed'
source = json.loads(SOURCE.read_text(encoding='utf-8'))
first = {}
for path in sorted(AUDIT.glob('batch_*.tsv')):
    rows = read_tsv(path)
    assert not first.keys() & rows.keys()
    first.update(rows)
second = read_tsv(AUDIT / 'second_pass.tsv')
assert set(first) == {f'A{i:03}' for i in range(1, 201)}
assert set(second) <= set(first)
train = {x['query']: x for x in json.loads((ROOT / 'data/prepared/train.json').read_text(encoding='utf-8'))}
corpus = {x['id']: x for x in json.loads((ROOT / 'data/prepared/corpus.json').read_text(encoding='utf-8'))}
stamp = datetime.now(timezone.utc).isoformat()
items = []
for row in source:
    assert all(not row[k] for k in ('label', 'evidence', 'reviewer', 'reviewed_at'))
    pid = row['pair_id']
    items.append(dict(pair_id=pid, query=row['query'], tool=row['tool'],
        initial_suggestion=first[pid], suggestion=second.get(pid, first[pid]),
        second_pass=pid in second,
        known_positive_context=[dict(id=tid, tool=corpus[tid]['raw']) for tid in train[row['query']]['positives']] if pid in second else [],
        human_review=dict(status='pending', label='', evidence='', reviewer='', reviewed_at='')))
counts = dict(collections.Counter(x['suggestion']['label'] for x in items))
package = dict(title='CPS5801 Human Review', packaged_at=stamp,
    source_sha256=source_hash, suggestion_author='Codex AI assistant',
    blinding=protocol['blinding'],
    limitations=['Metadata-based judgments only; external APIs were not executed.',
                'Confidence is qualitative, not a calibrated probability.',
                'Suggested alternatives are query-component-specific, not global tool equivalence.',
                'Known-positive annotations are context, not unquestionable ground truth.',
                'Human confirmations are pending and must be entered by the reviewer.',
                'Suggestion exposure can anchor human decisions; this is not independent double annotation.'],
    suggested_counts=counts, human_confirmed_count=0, items=items)
payload = json.dumps(package, ensure_ascii=False, indent=2)
(AUDIT / 'review_package.json').write_text(payload, encoding='utf-8')
(OUT / 'CPS5801_human_review.json').write_text(payload, encoding='utf-8')
digest = hashlib.sha256(payload.encode()).hexdigest()
(AUDIT / 'freeze_manifest.json').write_text(json.dumps(dict(
    created_at=stamp, review_package_sha256=digest, source_sha256=source_hash,
    policy_key_opened=False, human_confirmed_count=0,
    annotation_effect='No training pools, checkpoints, metrics or original human labels changed.'
), indent=2), encoding='utf-8')

page = r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>CPS5801 人工审查</title>
<style>body{max-width:1100px;margin:30px auto;padding:0 20px;font:16px/1.65 system-ui;color:#203044;background:#f6f8fb}h1{font-size:28px}section,.bar{background:white;border:1px solid #d6dfeb;border-radius:10px;padding:20px;margin:16px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.5 Consolas,monospace;max-height:450px;overflow:auto}button,input,select,textarea{font:inherit;padding:8px;margin:4px;border:1px solid #aebccd;border-radius:5px}button{cursor:pointer;background:white}button.primary{background:#174d83;color:white}textarea{width:95%;min-height:95px}label{display:block}small{color:#556579}.pill{padding:3px 9px;background:#e9f0f8;border-radius:4px}.warn{color:#8a4510}#message{min-height:1.6em}.toolbar{position:sticky;top:0;background:#f6f8fb;padding:8px;z-index:2;border-bottom:1px solid #ccd6e2}</style>
<h1>CPS5801 人工审查</h1>
<p>共 200 条查询—候选工具配对。逐条核对查询、工具说明和判断依据，再确认或修改结论。策略和排名保持隐藏。</p>
<p><small>初始判断和整理：Codex。人工审核者及确认时间单独记录。查看页面或切换条目不会计为已审核；本页面无外部请求，答案仅保存在当前浏览器，请及时导出。此流程含建议提示，不能描述为独立双人标注。</small></p>
<div class="toolbar"><span id="progress"></span><br><button id="prev">上一条</button><input id="number" type="number" min="1" max="200" value="1" style="width:75px"><button id="next">下一条</button><button id="attention">下一个替代／疑难项</button><button id="export" class="primary">导出审核记录</button></div>
<div class="bar"><label>审核署名 <input id="reviewer" autocomplete="off" placeholder="填写你的姓名或署名"></label><small>待确认条目可使用当前署名；已经确认的条目保留各自的原署名。</small><div id="message" class="warn" role="status"></div></div>
<section><h2 id="pair"></h2><b>查询 / Query</b><p id="query"></p><details open><summary>候选工具原始说明</summary><pre id="tool"></pre></details><details id="positiveDetails"><summary>第二遍复核所用的已有正例（不保证标注完整）</summary><pre id="positives"></pre></details></section>
<section><b>初始建议：<span id="suggestion" class="pill"></span></b><p id="reason"></p><small id="confidence"></small><details><summary>判定规则</summary><p>N：有依据的负例，不满足所需功能。V：能替代查询中某项功能，不能据此推断整个工具全局等价。C：能完成已有正例遗漏的另一项必要功能。U：资料不足、描述冲突或替代／共同必要的关系不明。</p><p>仅依据提供的工具元数据，未实际调用 API。U 不等于已证实的假负例。中／高置信度是定性判断。</p></details></section>
<section><h2>你的审核结论</h2><label>结论 <select id="label"><option value="">请选择</option><option value="defensible negative">N — 有依据的负例</option><option value="valid alternative">V — 有效替代工具</option><option value="omitted jointly-required component">C — 遗漏的共同必要组件</option><option value="unresolved">U — 暂无法确定</option></select></label><label>依据（可以保留或修改）<textarea id="evidence"></textarea></label><button id="confirm" class="primary">确认本条已核对</button><button id="undo">撤销本条确认</button><p id="humanStatus"></p></section>
<script type="application/json" id="data">__DATA__</script>
<script>
const el=id=>document.getElementById(id),original=JSON.parse(el('data').textContent);
const key='cps5801-human-review-__HASH__';let pkg=original,i=0;
try{const saved=JSON.parse(localStorage.getItem(key));if(saved&&saved.source_sha256===original.source_sha256&&saved.items.length===200&&saved.items.every((x,j)=>x.pair_id===original.items[j].pair_id)){original.items.forEach((x,j)=>x.human_review=saved.items[j].human_review);}}catch{}
const short={'defensible negative':'N — 有依据的负例','valid alternative':'V — 有效替代工具','omitted jointly-required component':'C — 遗漏的共同必要组件','unresolved':'U — 暂无法确定'};
function persist(){pkg.human_confirmed_count=pkg.items.filter(x=>x.human_review.status==='confirmed').length;try{localStorage.setItem(key,JSON.stringify(pkg));}catch{el('message').textContent='浏览器保存失败，请立即导出记录。';}progress();}
function progress(){el('progress').textContent=`人工已确认 ${pkg.items.filter(x=>x.human_review.status==='confirmed').length} / 200；当前 ${i+1} / 200`;}
function show(){const x=pkg.items[i],h=x.human_review;el('number').value=i+1;el('pair').textContent=x.pair_id;el('query').textContent=x.query;el('tool').textContent=JSON.stringify(x.tool,null,2);el('positiveDetails').hidden=!x.known_positive_context.length;el('positives').textContent=JSON.stringify(x.known_positive_context,null,2);el('suggestion').textContent=short[x.suggestion.label];el('reason').textContent=x.suggestion.evidence;el('confidence').textContent='定性置信度：'+x.suggestion.confidence+'；'+(x.second_pass?'已做第二遍复核':'第一遍逐条判断');el('label').value=h.label||x.suggestion.label;el('evidence').value=h.evidence||x.suggestion.evidence;if(h.reviewer)el('reviewer').value=h.reviewer;el('humanStatus').textContent=h.status==='confirmed'?`已确认：${h.reviewer} / ${h.reviewed_at}`:'尚未人工确认';progress();}
function draft(){const h=pkg.items[i].human_review;if(h.status!=='confirmed'){h.label=el('label').value;h.evidence=el('evidence').value;}persist();}
function changed(){const h=pkg.items[i].human_review;h.status='pending';h.reviewed_at='';h.label=el('label').value;h.evidence=el('evidence').value;el('humanStatus').textContent='已修改，需重新确认';persist();}
el('label').onchange=changed;el('evidence').oninput=changed;
el('confirm').onclick=()=>{const name=el('reviewer').value.trim(),label=el('label').value,evidence=el('evidence').value.trim();if(!name||!label||!evidence){el('message').textContent='请填写署名、结论和依据后确认。';return;}pkg.items[i].human_review={status:'confirmed',label,evidence,reviewer:name,reviewed_at:new Date().toISOString()};el('message').textContent='已记录本条人工确认。';persist();show();};
el('undo').onclick=()=>{pkg.items[i].human_review.status='pending';pkg.items[i].human_review.reviewed_at='';persist();show();};
el('prev').onclick=()=>{draft();i=Math.max(0,i-1);show();};el('next').onclick=()=>{draft();i=Math.min(199,i+1);show();};
el('number').onchange=()=>{draft();const n=Number(el('number').value);i=Number.isFinite(n)?Math.max(0,Math.min(199,Math.trunc(n)-1)):i;show();};
el('attention').onclick=()=>{draft();for(let d=1;d<=200;d++){const j=(i+d)%200;if(pkg.items[j].suggestion.code!=='N'){i=j;break;}}show();};
el('export').onclick=()=>{draft();pkg.exported_at=new Date().toISOString();const url=URL.createObjectURL(new Blob([JSON.stringify(pkg,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='CPS5801_human_review_confirmed.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};show();
</script></html>'''
page = page.replace('__DATA__', payload.replace('</', '<\\/')).replace('__HASH__', digest[:16])
(OUT / 'CPS5801_人工审查.html').write_text(page, encoding='utf-8')
summary = f'''CPS5801 人工审查材料说明

200 条样本已经逐条形成初始判断；其中 30 条保留了第二遍复核记录（29 条疑难项及 1 条资料稀疏项）。
建议分布：N 有依据的负例 {counts.get('defensible negative',0)}；V 有效替代 {counts.get('valid alternative',0)}；C 遗漏共同必要组件 {counts.get('omitted jointly-required component',0)}；U 暂无法确定 {counts.get('unresolved',0)}。
人工确认状态：本次生成时尚无逐条确认记录。用户表示会参与查看，不能据此推定所有条目已经核对。

“人工审查”是最终人工审核环节及材料标题。初始判断由 Codex 完成；确认人、最终标签、依据和时间在页面中单独记录。AI Disclosure 应如实保留这一分工。
打开同目录 CPS5801_人工审查.html，可以逐条确认或修改；点击“下一个替代／疑难项”可优先检查高风险项。及时导出审核记录，页面本身不会改写磁盘上的 JSON。

关键例子：A068 二维码生成、A095 Hacker News 条目读取，属于某个查询组件的有效替代；A057 国家首都查询也与已有正例的 capital 字段重合。A012 则因 YouTube/TikTok 平台不匹配而可判为负例。A054 名称与描述冲突；A143 电影 ID 命名空间不明；A159 列车时刻表可能相关，但正例说明不足以判断替代还是遗漏组件。

这些判断来自提供的工具说明与参数，没有实际调用外部 API。已有正例也可能不完整或有误。暂无法确定不能计作已证实假负例；不能把本样本比例直接推广到整个数据集。
建议后续人审确认后，按 query-tool 配对屏蔽 V/C，并暂时隔离 U；不要据此合并全局工具 ID。当前训练池、模型、评测结果及原空白人工标注文件保持不变。
本次未读取策略/排名映射，保持策略盲审；审核者已知总体实验结果，不能称完全实验盲审。带建议的人工复核也不构成独立双人标注。

English audit disclosure for the eventual report:
Codex produced initial metadata-based judgments for 200 blinded query-tool pairs and revisited 30 cases. The student reviewed [insert confirmed scope] and was responsible for the final human labels. Policy membership and ranks were withheld; project-level pilot outcomes were known. No external tool APIs were executed. This was assisted human verification, not independent double annotation. Until the student confirms the scope, human review remains pending.

Frozen suggestion package SHA-256: {digest}
Original blinded source SHA-256: {source_hash}
'''
(OUT / '人工审查说明_中文.txt').write_text(summary, encoding='utf-8')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash
print(json.dumps({'items':len(items),'second_pass':len(second),'suggested_counts':counts,'human_confirmed':0,'sha256':digest},ensure_ascii=True))
