import hashlib, json, pathlib, re, unicodedata
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
def dump(path,obj):
    path=pathlib.Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def read(path):return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))
def sha(x):return hashlib.sha256(x.encode()).hexdigest()
def norm(x):return ' '.join(re.findall(r'\w+',unicodedata.normalize('NFKC',x).casefold()))
def words(x):return re.findall(r'[a-z0-9]+',x.lower())
def parse_tool(x):
    if isinstance(x,str):x=json.loads(x)
    if not isinstance(x,dict):raise ValueError('tool is not an object')
    return x
def serialize(d):
    d=d.get('function',d)
    name=d.get('name',d.get('api_name',''))
    desc=d.get('description',d.get('api_description',''))
    params=d.get('parameters',{})
    fields=[]
    if isinstance(params,dict):
        p=params.get('properties',params)
        for k,v in sorted(p.items()):
            if isinstance(v,dict):fields.append(f'{k}: {v.get("type","unknown")}')
    elif isinstance(params,list):
        fields += [f'{p.get("name","")}: {p.get("type","unknown")}' for p in params if isinstance(p,dict)]
    for key in ['required_parameters','optional_parameters']:
        fields += [f'{p.get("name","")}: {p.get("type","unknown")}' for p in d.get(key,[]) if isinstance(p,dict)]
    if not name or not desc:raise ValueError('missing tool name or description')
    return f'name: {name}\ndescription: {desc}\nparameters: '+ '; '.join(sorted(set(fields)))
def metrics(top,positive):
    p=set(positive); assert p
    out={f'recall@{k}':len(set(top[:k])&p)/len(p) for k in (1,3,5,10)}
    out['mrr@10']=next((1/(i+1) for i,x in enumerate(top[:10]) if x in p),0.)
    return out
class BM25:
    """Sparse exact BM25, positive Robertson IDF, k1=1.5 b=.75."""
    def __init__(self,texts,k1=1.5,b=.75):
        from scipy.sparse import csc_matrix
        from collections import Counter
        self.vocab={}; rows=[]; cols=[]; values=[]; lens=[]
        for i,t in enumerate(texts):
            c=Counter(words(t)); lens.append(sum(c.values()))
            for w,v in c.items():
                j=self.vocab.setdefault(w,len(self.vocab)); rows.append(i);cols.append(j);values.append(v)
        mat=csc_matrix((np.array(values,dtype=np.float32),(rows,cols)),shape=(len(texts),len(self.vocab)))
        df=np.diff(mat.indptr); idf=np.log1p((len(texts)-df+.5)/(df+.5))
        lengths=np.asarray(lens); avg=lengths.mean()
        for j in range(mat.shape[1]):
            a,z=mat.indptr[j:j+2]; tf=mat.data[a:z];dl=lengths[mat.indices[a:z]]
            mat.data[a:z]=idf[j]*tf*(k1+1)/(tf+k1*(1-b+b*dl/avg))
        self.mat=mat
    def scores(self,q):
        js=[self.vocab[w] for w in set(words(q)) if w in self.vocab]
        return np.asarray(self.mat[:,js].sum(axis=1)).ravel()
    def top(self,q,k):
        s=self.scores(q)
        # Corpus is sorted by stable ID; stable sort gives deterministic ties.
        ix=np.argsort(-s,kind='stable')[:k]
        return ix,s[ix]
