"""Freeze metadata judgments while retaining pending human status and policy blinding."""
import ast,collections,hashlib,json,pathlib
from datetime import datetime,timezone
R=pathlib.Path(__file__).resolve().parents[1]; A=R/'results/main_audit_20261025'; S=R/'data/main_20261025/audit_blind.json'
labels={'N':'defensible negative','V':'valid alternative','C':'omitted jointly-required component','U':'unresolved'}
first={}
for f in sorted(A.glob('batch_*.tsv')):
    for line in f.read_text(encoding='utf-8').splitlines():
        p,c,e=line.split('\t');assert p not in first and c in labels
        first[p]={'code':c,'label':labels[c],'evidence':e,'confidence':'not calibrated'}
assert set(first)=={f'M{i:03}' for i in range(1,201)}
second={p:dict(x) for p,x in first.items() if x['code']!='N'}
second['M139']={'code':'N','label':labels['N'],'confidence':'not calibrated','evidence':'The complete response schema lists state identifiers, names, codes and coordinates but no capital field. It does not enumerate states or territories, and does not provide kitten images.'}
for p in ('M075','M188'):
    second[p]['evidence']='The full response schema explicitly includes info.rate and source/destination currencies, directly supplying the requested exchange-rate component. No claim of live API availability is made.'
def write(p,x):p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
write(A/'second_pass.json',second)
items=[]
for x in json.loads(S.read_text(encoding='utf-8')):
    p=x['pair_id'];items.append(dict(pair_id=p,query=x['query'],tool=x['tool'],initial_suggestion=first[p],suggestion=second.get(p,first[p]),second_pass=p in second,known_positive_context=x['known_positives'],human_review=dict(status='pending',label='',evidence='',reviewer='',reviewed_at='')))
stamp=datetime.now(timezone.utc).isoformat();sh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pkg=dict(title='CPS5801 expanded human review',packaged_at=stamp,source_sha256=sh(S),suggestion_author='Codex AI assistant',human_confirmed_count=0,blinding='Candidate policy and rank key was not opened. Earlier pilot results were known. This is policy-blinded, not outcome-blinded or independent double annotation.',limitations=['Metadata judgments only; APIs were not called.','V is a query-component alternative, not global tool equivalence.','U is uncertainty, not a confirmed false negative.','Student confirmation of the earlier A001-A200 does not cover M001-M200.'],suggested_counts=dict(collections.Counter(x['suggestion']['label'] for x in items)),items=items)
write(A/'review_package.json',pkg)
write(A/'freeze_manifest.json',dict(created_at=stamp,review_package_sha256=sh(A/'review_package.json'),source_sha256=sh(S),policy_key_opened=False,human_confirmed_count=0))
tree=ast.parse((R/'scripts/finalize_review.py').read_text(encoding='utf-8'))
template=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='page' for t in n.targets) and isinstance(n.value,ast.Constant))
payload=(A/'review_package.json').read_text(encoding='utf-8')
template=template.replace('CPS5801 人工审查','CPS5801 扩展实验人工审查').replace('共 200 条查询','新增 M001–M200，共 200 条查询').replace('第二遍复核所用的已有正例','已有正例上下文').replace('CPS5801_human_review_confirmed.json','CPS5801_main_human_review_confirmed.json')
template=template.replace('__DATA__',payload.replace('</','<\\/')).replace('__HASH__',sh(A/'review_package.json')[:16])
(R/'output/CPS5801_扩展实验_人工审查.html').write_bytes(template.encode('utf-8'))
print(json.dumps({'counts':pkg['suggested_counts'],'second_pass':len(second),'human_confirmed':0,'hash':sh(A/'review_package.json')}))
