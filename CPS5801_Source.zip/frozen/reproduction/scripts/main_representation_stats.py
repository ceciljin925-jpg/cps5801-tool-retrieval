"""CPU-only representation statistics, without model or test relevance scores."""
import collections,os
os.environ['TOKENIZERS_PARALLELISM']='false'
from common import *
from transformers import AutoTokenizer
P=ROOT/'data/main_20261025';R=ROOT/'results/main_20261025'
tok=AutoTokenizer.from_pretrained(ROOT/'data/raw/model',local_files_only=True)
out={}
for name,filename,key,prefix,cap in [('train','train.json','query','query: ',128),('dev','dev.json','query','query: ',128),('test','test.json','query','query: ',128),('dev_tools','corpus.json','text','passage: ',384),('test_tools','test_corpus.json','text','passage: ',384)]:
    rows=read(P/filename);lens=[]
    for i in range(0,len(rows),256):lens.extend(len(x) for x in tok([prefix+x[key] for x in rows[i:i+256]],truncation=False)['input_ids'])
    out[name]=dict(n=len(rows),truncated=sum(n>cap for n in lens),cap=cap,mean_tokens=float(np.mean(lens)),max_tokens=max(lens))
    if key=='text':
        groups=collections.Counter(x['text'] for x in rows)
        out[name].update(identical_input_groups=sum(v>1 for v in groups.values()),ids_in_identical_input_groups=sum(v for v in groups.values() if v>1),unique_inputs=len(groups))
        rawlens=[]
        for i in range(0,len(rows),128):rawlens.extend(len(x) for x in tok([json.dumps(d['raw'],ensure_ascii=False,sort_keys=True) for d in rows[i:i+128]],truncation=False)['input_ids'])
        dump(R/f'{name}_full_raw_token_lengths.json',dict(zip([d['id'] for d in rows],rawlens)))
    else:
        out[name]['normalized_query_groups']=len({norm(g['query']) for g in rows})
dump(R/'representation_stats.json',out)
print(json.dumps(out))
