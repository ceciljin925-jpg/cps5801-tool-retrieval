"""Independent snapshot and schedule checks before official scoring."""
import collections,hashlib,math,random
from common import *
from main_common import serialize as main_serialize
P=ROOT/'data/main_20261025';R=ROOT/'results/main_20261025'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
checks=[]
for f,h in read(P/'freeze_manifest.json')['files'].items():assert digest(ROOT/f)==h,f
checks.append('All frozen data, audit and engine hashes match disk bytes')
train,dev,test=[read(P/f) for f in ['train.json','dev.json','test.json']]
sets=[{norm(g['query']) for g in rows} for rows in (train,dev,test)]
assert len(sets[0])==len(train) and len(sets[1])==len(dev)
assert not (sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])
assert not sets[1]&{norm(g['query']) for g in read(ROOT/'data/prepared/train.json')}
assert not sets[0]&{norm(g['query']) for g in read(ROOT/'data/prepared/dev.json')}
checks.append('Normalized exact train/dev/test query sets are disjoint; no former gradient query enters dev and no former dev query enters training')
corpus=read(P/'corpus.json');testcorpus=read(P/'test_corpus.json');bytool={t['id']:t for t in corpus};ids=set(read(P/'train_tool_ids.json'))
assert len(test)==7961 and len(testcorpus)==44453 and len({g['id'] for g in test})==7961
for rows,docs in [(train+dev,corpus),(test,testcorpus)]:
    docids={d['id'] for d in docs};assert [d['id'] for d in docs]==sorted(docids)
    assert all(g['positives'] and set(g['positives'])<=docids for g in rows)
    assert all(d['text']==main_serialize(d['raw']) for d in docs)
checks.append('Complete official query/tool mappings retained; deterministic serializer agrees with stored input strings')
assert 'description: [not provided]' in main_serialize({'name':'a'})
assert 'name: x' in main_serialize({'func_description':'Name: x\nPurpose: retain me'})
assert 'count: integer' in main_serialize({'name':'x','parameters':[{'name':'count','schema':{'type':'integer'}}]})
checks.append('Missing-field, func_description and nested-schema contracts retained')
masks={q:set(v) for q,v in read(P/'forbidden_ids.json').items()};pools=read(P/'bm25_top50_eligible.json');byq={g['id']:g for g in train}
same=collections.defaultdict(set)
for t in corpus:
    if t['id'] in ids:same[t['text']].add(t['id'])
for g in train:
    assert set(g['positives'])<=masks[g['id']]
    assert all(same[bytool[t]['text']]<=masks[g['id']] for t in g['positives'])
for seed in (42,43,44):
    schedule=read(P/f'shared_schedule_seed{seed}.json');neg=read(P/f'negatives_seed{seed}.json')
    assert len(schedule)==20000 and len(neg)==10000
    for epoch in (0,1):assert collections.Counter(s['query_id'] for s in schedule if s['epoch']==epoch)==collections.Counter(list(byq))
    assert all(s['positive'] in byq[s['query_id']]['positives'] for s in schedule)
    for q,ns in neg.items():
        for pol in ('random','bm25'):
            assert len(set(ns[pol]))==4 and set(ns[pol])<=ids and not set(ns[pol])&masks[q]
        assert set(ns['bm25'])<=set(pools[q])
checks.append('All three paired schedules cover each query once per epoch, use registered positives and four distinct eligible negatives, and mask input aliases')
for r in read(P/'positive_registry.json')['expanded']:
    q,t=r['query_id'],r['tool_id']
    if r['label']!='defensible negative':assert t in masks[q]
    if r['label']=='valid alternative':assert t in byq[q]['positives']
checks.append('All newly confirmed alternatives and unresolved cases correctly applied')
assert read(ROOT/'results/main_human_audit_20261025/confirmed_review.json')['human_confirmed_count']==200
out=dict(checks=checks,passed=len(checks),train=len(train),development=len(dev),test=len(test),test_normalized_groups=len(sets[2]),test_duplicate_normalized_rows=len(test)-len(sets[2]),snapshot_manifest_sha256=digest(P/'freeze_manifest.json'))
dump(R/'snapshot_validation.json',out);print(json.dumps(out,indent=2))
