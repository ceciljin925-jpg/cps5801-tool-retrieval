"""Read blinded cases without policy or rank, retaining complete descriptions."""
import sys
from common import *
sys.stdout.reconfigure(encoding='utf-8')
rows=read(ROOT/'data/main_20261025/audit_blind.json')
for x in rows[int(sys.argv[1])-1:int(sys.argv[2])]:
    t=x['tool'];t=t.get('function',t)
    print('\n'+x['pair_id']+' Q '+x['query'])
    print('TOOL',t.get('name',t.get('api_name','')),'DESC',t.get('description',t.get('api_description',t.get('func_description',''))))
    print('PARAMETERS',json.dumps(t.get('parameters',t.get('required_parameters',[])),ensure_ascii=False))
    print('GOLD',[(z.get('name',z.get('api_name','')),z.get('description',z.get('api_description',''))) for z in x['known_positives']])
