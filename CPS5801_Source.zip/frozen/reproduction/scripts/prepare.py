"""Pilot data preparation; exact duplicate isolation, not a final near-duplicate audit."""
import collections, datetime, hashlib, json, time
import pyarrow.parquet as pq
from common import *
t0=time.perf_counter(); raw=ROOT/'data/raw'; out=ROOT/'data/prepared';out.mkdir(exist_ok=True)
test_norm=set(); test_count=0
for p in sorted((raw/'ToolRet-Queries').glob('*/*.parquet')):
    for batch in pq.ParquetFile(p).iter_batches(batch_size=256):
        for row in batch.to_pylist():
            test_count+=1;test_norm.add(norm(row['query']))
assert len(list((raw/'ToolRet-Queries').glob('*/*.parquet'))) == len([s for s in read(raw/'ToolRet-Queries-metadata.json')['siblings'] if s['rfilename'].endswith('.parquet')])
groups={}; stats=collections.Counter(); excluded=[]
files=sorted((raw/'training/ToolRet-Training-20w').glob('*.parquet'));assert len(files)==6
metadata=read(raw/'training_file_metadata.json')
for m in metadata:
    fp=raw/'training'/m['path']
    with fp.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==m['lfs']['oid'],f'corrupt input: {fp}'
for p in files:
    for batch in pq.ParquetFile(p).iter_batches(batch_size=512,columns=['id','query','positive']):
        for row in batch.to_pylist():
            stats['raw_rows']+=1;n=norm(row['query'])
            if n in test_norm:stats['test_overlap_rows']+=1;excluded.append([row['id'],'normalized_test_overlap']);continue
            alpha=[c for c in row['query'] if c.isalpha()]
            if not alpha or sum(ord(c)<128 for c in alpha)/len(alpha)<.95:
                stats['language_heuristic_excluded']+=1;excluded.append([row['id'],'non_latin_heuristic']);continue
            try:
                pos=[]
                for x in row['positive']:
                    d=parse_tool(x);serialize(d);pos.append(sha(json.dumps(d,sort_keys=True,ensure_ascii=False)))
                if not pos:raise ValueError('no positive')
            except Exception:
                stats['invalid_positive_rows']+=1;excluded.append([row['id'],'invalid_positive']);continue
            if n not in groups:groups[n]={'id':row['id'],'query':row['query'],'positives':set(),'source_ids':[],'group':sha(n),'provenance':'unknown'}
            g=groups[n];g['positives'].update(pos);g['source_ids'].append(row['id'])
    print('query scan',p.name,stats['raw_rows'],flush=True)
ordered=sorted(groups.values(),key=lambda g:sha('20261025:'+g['group']))
dev=ordered[:128];train=ordered[128:1152]
dev_ids={i for g in dev for i in g['source_ids']}
retained_ids={i for g in ordered[128:] for i in g['source_ids']}
tools={}; train_tool_ids=set();dev_tool_ids=set()
for p in files:
    for batch in pq.ParquetFile(p).iter_batches(batch_size=256,columns=['id','positive','negative']):
        for row in batch.to_pylist():
            is_train=row['id'] in retained_ids;is_dev=row['id'] in dev_ids
            if not(is_train or is_dev):continue
            for kind in (['positive','negative'] if is_train else ['positive']):
                for x in row[kind]:
                    try:
                        d=parse_tool(x);text=serialize(d); canonical=json.dumps(d,sort_keys=True,ensure_ascii=False);tid=sha(canonical)
                    except Exception:stats['invalid_tool_occurrences']+=1;continue
                    if tid not in tools:tools[tid]={'id':tid,'text':text,'raw':d}
                    (train_tool_ids if is_train else dev_tool_ids).add(tid)
    print('tool scan',p.name,len(tools),flush=True)
for split in [train,dev]:
    for g in split:g['positives']=sorted(g['positives']);assert set(g['positives'])<=set(tools)
corpus=[tools[k] for k in sorted(tools)]
dump(out/'corpus.json',corpus);dump(out/'train_tool_ids.json',sorted(train_tool_ids))
dump(out/'train.json',train);dump(out/'dev.json',dev);dump(out/'excluded.json',excluded)
stats.update(unique_normalized_eligible_queries=len(groups),duplicate_rows=sum(len(g['source_ids'])-1 for g in ordered),train_queries=len(train),dev_queries=len(dev),train_tools=len(train_tool_ids),dev_added_positive_tools=len(dev_tool_ids-train_tool_ids),validation_tools=len(tools),test_queries_checked=test_count)
dump(out/'audit.json',{'counts':dict(stats),'elapsed_seconds':time.perf_counter()-t0,'split_seed':20261025,'scope':'pilot, all six shards; exact normalization only; English heuristic not validated; near duplicates pending','provenance':'row-level source absent; unknown; no inferred source stratification','relations':'all official positives retained; alternatives versus jointly-required unknown','serialization':'name/api_name + description/api_description + sorted parameter names/types; exact full-JSON aliases only; serialized collisions retained','test_scores_inspected':False})
print(json.dumps(dict(stats)),flush=True)
