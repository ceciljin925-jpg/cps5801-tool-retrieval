"""Descriptive diagnostics on the completed pilot; main labels remain untouched."""
import collections, random
from common import *
P=ROOT/'data/prepared';R=ROOT/'results/audited_pilot_20261025';OUT=ROOT/'results/paper_diagnostics'
corpus={x['id']:x for x in read(P/'corpus.json')};dev=read(P/'dev.json');summary=read(R/'summary.json')
conditions={'random':[f'A{3+2*(s-42):02}_random_seed{s}' for s in (42,43,44)],'hard':[f'A{4+2*(s-42):02}_bm25_seed{s}' for s in (42,43,44)]}
preds={run:read(R/run/'predictions.json') for runs in conditions.values() for run in runs}
diagnostics={};rows=[]
for label,runs in conditions.items():
    raw=[];equiv=[];unique=[]
    for run in runs:
        a=[];b=[];u=[]
        for row in preds[run]:
            pos=row['positives'];top=row['top10'][:5];texts={corpus[t]['text'] for t in top}
            a.append(row['recall@5']);b.append(sum(corpus[t]['text'] in texts for t in pos)/len(pos));u.append(len(texts))
        raw.append(a);equiv.append(b);unique.append(u)
    diagnostics[label]={'raw_id_recall5':float(np.mean(raw)),'input_equivalent_coverage5':float(np.mean(equiv)),
                        'mean_distinct_serializations_in_top5':float(np.mean(unique)),
                        'note':'Input-equivalent coverage is a representation diagnostic, not semantic relevance or a replacement for primary recall.'}
for i,g in enumerate(dev):
    vals={label:float(np.mean([preds[run][i]['recall@5'] for run in runs])) for label,runs in conditions.items()}
    d=vals['hard']-vals['random'];rows.append(dict(id=g['id'],query=g['query'],n_positives=len(g['positives']),**vals,delta=d))
strata={}
for name,predicate in [('one positive',lambda r:r['n_positives']==1),('multiple positives',lambda r:r['n_positives']>1)]:
    selected=[r for r in rows if predicate(r)];strata[name]={'n':len(selected),**{k:float(np.mean([r[k] for r in selected])) for k in ['random','hard','delta']}}
rng=random.Random(60042);sample=[]
for name,predicate in [('hard_wins',lambda x:x['delta']>0),('hard_losses',lambda x:x['delta']<0),('ties',lambda x:x['delta']==0)]:
    pool=[x for x in rows if predicate(x)]
    for row in rng.sample(pool,min(8,len(pool))):
        g=next(g for g in dev if g['id']==row['id']);i=dev.index(g)
        sample.append({**row,'stratum':name,'selection_seed':60042,
            'positive_tools':[{'id':t,'text':corpus[t]['text']} for t in g['positives']],
            'random_top5_seed42':[{'id':t,'text':corpus[t]['text'],'labelled_positive':t in g['positives']} for t in preds[conditions['random'][0]][i]['top10'][:5]],
            'hard_top5_seed42':[{'id':t,'text':corpus[t]['text'],'labelled_positive':t in g['positives']} for t in preds[conditions['hard'][0]][i]['top10'][:5]],
            'review_status':'assistant qualitative interpretation pending; not human-verified relevance relabeling'})
dump(OUT/'representation_and_strata.json',{'diagnostics':diagnostics,'positive_count_strata':strata,'n_queries':len(dev),
    'limits':'Post-hoc descriptive analysis; no inference of joint necessity from positive count. Seed-42 tools illustrate queries stratified by seed-average effect, not all three rankings.'})
dump(OUT/'error_review_sample.json',sample)
print(json.dumps({'diagnostics':diagnostics,'strata':strata,'sample_size':len(sample)},indent=2))
