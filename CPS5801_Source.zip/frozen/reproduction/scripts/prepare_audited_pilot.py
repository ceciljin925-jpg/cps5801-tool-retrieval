"""Record the student's explicit attestation and freeze a new paired-seed snapshot."""
import collections, copy, datetime, hashlib, json, random, re
from common import *
from scipy.stats import hypergeom

P = ROOT / 'data/prepared'
OUT = ROOT / 'data/audited_pilot_20261025'
HUMAN = ROOT / 'results/human_audit_20261025'

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def finite_interval(population, sample, observed):
    """Invert both exact hypergeometric tails, inclusive equal-tailed 95% set."""
    assert 0 <= observed <= sample <= population
    feasible_lo, feasible_hi = observed, population - sample + observed
    lo, hi = feasible_lo, feasible_hi
    while lo < hi:
        mid = (lo + hi) // 2
        if hypergeom.sf(observed - 1, population, mid, sample) >= .025:
            hi = mid
        else:
            lo = mid + 1
    lower = lo
    lo, hi = feasible_lo, feasible_hi
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if hypergeom.cdf(observed, population, mid, sample) >= .025:
            lo = mid
        else:
            hi = mid - 1
    return {'count_bounds': [lower, lo], 'rate_bounds': [lower / population, lo / population]}

def main():
    if (OUT / 'freeze_manifest.json').exists():
        raise RuntimeError('Snapshot already frozen; refuse overwrite')
    now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
    original = ROOT / 'results/ai_audit_20261025/review_package.json'
    freeze = read(original.parent / 'freeze_manifest.json')
    # The first-pass packager hashed its UTF-8 text before Windows newline translation.
    # Verify that exact logical-text hash, and additionally preserve the disk-byte hash.
    assert sha(original.read_text(encoding='utf-8')) == freeze['review_package_sha256']
    assert digest(P / 'human_audit_blind.json') == freeze['source_sha256']
    package = read(original)
    attestation = {
        'type': 'explicit student confirmation in chat',
        'statement': '我全部看过了，审查完毕了，审查结果和你的审查结果一致，你就直接把你的结论当作我的审查结论，你可以开始下一步了',
        'scope': 'All 200 pairs, adopting every suggested label and rationale',
        'reviewer': 'Student / project author (confirmed in chat)',
        'recorded_at': now,
        'time_semantics': 'Time confirmation was recorded; not a measured review duration or per-item observation',
        'suggestion_package_sha256': digest(original),
        'suggestion_package_logical_text_sha256': freeze['review_package_sha256'],
        'initial_assistance': 'Codex prepared initial judgments; student confirmed all judgments after review',
        'independent_double_annotation': False,
        'formal_name_provided': False,
    }
    package['human_attestation'] = attestation
    package['human_confirmed_count'] = 200
    package['limitations'] = [x for x in package['limitations'] if not x.startswith('Human confirmations are pending')]
    for row in package['items']:
        s = row['suggestion']
        row['human_review'] = {'status': 'confirmed', 'label': s['label'], 'evidence': s['evidence'],
                               'reviewer': attestation['reviewer'], 'reviewed_at': now,
                               'confirmation_method': 'explicit batch attestation in chat'}
    HUMAN.mkdir(parents=True, exist_ok=True)
    dump(HUMAN / 'attestation.json', attestation)
    dump(HUMAN / 'confirmed_review.json', package)
    dump(ROOT / 'output/CPS5801_human_review_confirmed.json', package)
    html = (ROOT / 'output/CPS5801_人工审查.html').read_text(encoding='utf-8')
    payload = json.dumps(package, ensure_ascii=False, indent=2).replace('</', '<\\/')
    html = re.sub(r'(<script type="application/json" id="data">).*?(</script>)',
                  lambda m: m[1] + payload + m[2], html, flags=re.S)
    html = html.replace('cps5801-human-review-', 'cps5801-human-confirmed-')
    html = html.replace('<h1>CPS5801 人工审查</h1>', '<h1>CPS5801 人工审查 — 200 条已确认</h1><p>用户已在对话中确认全部条目的结论与依据；记录采用该确认时间，未虚构逐条点击或审核耗时。</p>')
    (ROOT / 'output/CPS5801_人工审查_已确认.html').write_text(html, encoding='utf-8')

    # Unblind only after the suggestion freeze and explicit student attestation.
    key = {x['pair_id']: x for x in read(P / 'human_audit_key.json')}
    train = read(P / 'train.json'); corpus = read(P / 'corpus.json')
    train_ids = set(read(P / 'train_tool_ids.json'))
    byq = {g['id']: g for g in train}; bytool = {x['id']: x for x in corpus}
    pools = read(P / 'bm25_top50_eligible.json')
    before_mask = {q: set(xs) for q, xs in read(P / 'input_identical_exclusion_ids.json').items()}
    registry = []; exclude = collections.defaultdict(set); add = collections.defaultdict(set)
    for row in package['items']:
        k = key[row['pair_id']]; q, t = k['query_id'], k['tool_id']
        assert row['query'] == byq[q]['query'] and row['tool'] == bytool[t]['raw']
        label = row['human_review']['label']
        if label != 'defensible negative':
            exclude[q].add(t)
        if label in ['valid alternative', 'omitted jointly-required component']:
            add[q].add(t)
        registry.append(dict(**k, label=label, evidence=row['human_review']['evidence'],
            relation_scope='this query and capability component only',
            add_to_positive_registry=t in add[q], exclude_from_negatives=t in exclude[q]))
    same_text = collections.defaultdict(set)
    for t in corpus:
        if t['id'] in train_ids: same_text[t['text']].add(t['id'])
    revised = copy.deepcopy(train); masks = {}; kept = []; dropped = []; after_pools = {}
    for g in revised:
        q = g['id']; g['original_positives'] = list(g['positives'])
        g['positives'] = sorted(set(g['positives']) | add[q])
        masks[q] = set(g['positives']) | exclude[q]
        for t in g['positives']: masks[q].update(same_text[bytool[t]['text']])
        after_pools[q] = [t for t in pools[q] if t not in masks[q]]
        if len(after_pools[q]) < 4 or len(train_ids - masks[q]) < 4:
            dropped.append(q)
        else:
            kept.append(g)
    OUT.mkdir(parents=True, exist_ok=True)
    dump(OUT / 'train.json', kept)
    dump(OUT / 'positive_registry_updates.json', registry)
    dump(OUT / 'forbidden_ids.json', {q: sorted(v) for q,v in masks.items()})
    dump(OUT / 'bm25_top50_eligible.json', after_pools)
    dump(OUT / 'dropped_queries.json', dropped)
    ids = [t['id'] for t in corpus if t['id'] in train_ids]
    seed_stats = {}
    for seed in (42, 43, 44):
        order_rng, pos_rng = random.Random(seed), random.Random(1000+seed)
        random_rng, hard_rng = random.Random(2000+seed), random.Random(3000+seed)
        negatives = {}; schedule = []
        for g in kept:
            q=g['id']; ns=[]
            while len(ns) < 4:
                t=random_rng.choice(ids)
                if t not in masks[q] and t not in ns: ns.append(t)
            negatives[q]={'random':ns,'bm25':hard_rng.sample(after_pools[q],4)}
        for epoch in range(2):
            order=list(range(len(kept)));order_rng.shuffle(order)
            schedule += [dict(epoch=epoch,query_id=kept[j]['id'],positive=pos_rng.choice(kept[j]['positives'])) for j in order]
        dump(OUT / f'negatives_seed{seed}.json',negatives)
        dump(OUT / f'shared_schedule_seed{seed}.json',schedule)
        seed_stats[str(seed)]={'schedule_examples':len(schedule), 'steps':(len(schedule)+31)//32,
            'new_positive_exposures':sum(s['positive'] in add[s['query_id']] for s in schedule)}
    direct={(q,t) for q,ts in exclude.items() for t in ts}
    extra={(q,t) for q,ts in masks.items() for t in ts-before_mask[q]} - direct
    audit_stats={}
    for policy in ('random','bm25'):
        sampled=[x for x in registry if policy in x['pools']]
        counts=collections.Counter(x['label'] for x in sampled)
        N=sum(len(train_ids-before_mask[g['id']]) for g in train) if policy=='random' else sum(map(len,pools.values()))
        M=sum(len(train_ids-masks[g['id']]) for g in kept) if policy=='random' else sum(len(after_pools[g['id']]) for g in kept)
        D=sum((t in train_ids and t not in before_mask[q]) if policy=='random' else t in pools[q] for q,t in direct)
        rates={}
        for name, count in [('alternative',counts['valid alternative']), ('unresolved',counts['unresolved']),
                            ('joint_component',counts['omitted jointly-required component']),
                            ('combined_ambiguity',len(sampled)-counts['defensible negative'])]:
            rates[name]=dict(count=count,rate=count/len(sampled),**finite_interval(N,len(sampled),count))
        U=rates['combined_ambiguity']['rate_bounds'][1]
        audit_stats[policy]=dict(original_population=N, sampled=len(sampled),label_counts=dict(counts),rates=rates,
            directly_removed_ambiguous_pairs=D,remaining_population=M,
            residual_ambiguity_upper_bound=min(1,max(0,(U*N-D)/M)) if M else None)
    audit_stats['method']='Exact equal-tailed 95% hypergeometric-tail inversion for original SRSWOR pair pools; residual bound uses original upper limit, observed direct ambiguity removals, and actual remaining pool size. Not simultaneous coverage or label-error uncertainty.'
    audit_stats['implementation_reference']='https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.hypergeom.html'
    audit_stats['limits']='One human reviewer accepted AI suggestions; no independent double annotation. Pair ambiguity does not equal training exposure or true functional relevance.'
    dump(HUMAN / 'pool_statistics.json',audit_stats)
    changes=dict(created_at=now,phase='human-reviewed development pilot, three paired seeds; not final 10k study',
        human_reviewed_pairs=200, added_positive_pairs=sum(map(len,add.values())), direct_excluded_pairs=len(direct),
        extra_input_identical_positive_exclusions=len(extra), extra_pairs=sorted(extra), synchronized_query_drops=dropped,
        train_queries=len(kept),development_queries=len(read(P/'dev.json')), seeds=seed_stats,
        semantic_equivalence_propagation=0, rationale='Only reviewed query-tool pairs added as positives; extra serialized-input collisions are masked, never labelled relevant. No other-query propagation.',
        evaluation_labels_changed=False, corpus_changed=False, final_prerequisites_still_pending=['expanded split','English validation','near-duplicate review','provenance/upstream terms'])
    old_neg=read(P/'negatives_seed42.json');new_neg=read(OUT/'negatives_seed42.json')
    changes['seed42_original_direct_ambiguity_exposures']={policy:sum(t in exclude[q] for q,ns in old_neg.items() for t in ns[policy]) for policy in ['random','bm25']}
    changes['seed42_changed_negative_queries']={policy:sum(old_neg[q][policy]!=ns[policy] for q,ns in new_neg.items()) for policy in ['random','bm25']}
    dump(OUT/'changes.json',changes)
    manifest={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(OUT.glob('*.json'))}
    for path in [P/'corpus.json',P/'dev.json',P/'train_tool_ids.json',HUMAN/'confirmed_review.json',HUMAN/'pool_statistics.json',ROOT/'scripts/prepare_audited_pilot.py']:
        manifest[path.relative_to(ROOT).as_posix()]=digest(path)
    dump(OUT/'freeze_manifest.json',dict(frozen_at=now,files=manifest,official_test_scored=False))
    original_protocol=read(ROOT/'protocol.json')
    dump(HUMAN/'protocol_before_confirmation.json',original_protocol)
    original_protocol['phase']=changes['phase']
    original_protocol['human_review'].update(status='completed: 200/200 confirmed by student in chat',record='results/human_audit_20261025/confirmed_review.json')
    original_protocol['final_prerequisites']=[x for x in original_protocol['final_prerequisites'] if x!='human pair review']
    original_protocol['final_prerequisites'].append('audit coverage for any expanded final candidate pool')
    original_protocol['active_snapshot']='data/audited_pilot_20261025'
    dump(ROOT/'protocol.json',original_protocol)
    print(json.dumps(changes,ensure_ascii=True,indent=2))
    print(json.dumps({p:{'counts':audit_stats[p]['label_counts'],'residual_upper':audit_stats[p]['residual_ambiguity_upper_bound']} for p in ['random','bm25']},indent=2))

if __name__=='__main__': main()
