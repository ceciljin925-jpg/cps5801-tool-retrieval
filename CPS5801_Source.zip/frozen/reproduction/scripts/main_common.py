"""Field-preserving schema adaptation for the expanded study, without tool-ID merging."""
import re

def serialize(d):
    d=d.get('function',d)
    name=d.get('name') or d.get('api_name') or '[not provided]'
    description=d.get('description') or d.get('api_description') or d.get('func_description') or '[not provided]'
    if name=='[not provided]' and d.get('func_description'):
        m=re.search(r'(?m)^Name:\s*([^\n]+)',d['func_description'])
        if m:name=m.group(1).strip()
    if not isinstance(name,str) or not isinstance(description,str):raise ValueError('non-string name/description')
    fields=[];params=d.get('parameters',{})
    def ptype(p):return p.get('type') or (p.get('schema') or {}).get('type') or 'unknown'
    if isinstance(params,dict):
        for k,v in sorted(params.get('properties',params).items()):
            if isinstance(v,dict):fields.append(f'{k}: {ptype(v)}')
    elif isinstance(params,list):
        fields += [f'{p.get("name","")}: {ptype(p)}' for p in params if isinstance(p,dict)]
    for key in ['required_parameters','optional_parameters']:
        fields += [f'{p.get("name","")}: {ptype(p)}' for p in d.get(key,[]) if isinstance(p,dict)]
    return f'name: {name}\ndescription: {description}\nparameters: '+'; '.join(sorted(set(fields)))
