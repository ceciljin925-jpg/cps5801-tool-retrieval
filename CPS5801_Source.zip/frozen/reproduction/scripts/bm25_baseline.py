import datetime, time
from common import *
out=ROOT/'results/P01_bm25';out.mkdir(exist_ok=True)
if (out/'metrics.json').exists():raise SystemExit('Completed BM25 run already exists; preserved.')
corpus=read(ROOT/'data/prepared/corpus.json');dev=read(ROOT/'data/prepared/dev.json');ids=[x['id'] for x in corpus]
t0=time.perf_counter();bm=BM25([x['text'] for x in corpus]);index_s=time.perf_counter()-t0;t=time.perf_counter();rows=[]
for g in dev:
    ix,s=bm.top(g['query'],10);top=[ids[j] for j in ix]
    rows.append({'id':g['id'],'positives':g['positives'],'top10':top,'scores':s.tolist(),**metrics(top,g['positives'])})
search_s=time.perf_counter()-t;lat=[]
for i in range(len(dev)+5):
    t=time.perf_counter();bm.top(dev[i%len(dev)]['query'],10)
    if i>=5:lat.append(1000*(time.perf_counter()-t))
result={'run_id':'P01_bm25','finished_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
    'split':'development pilot','n':len(dev),'candidate_tools':len(corpus),'metrics':{k:float(np.mean([r[k] for r in rows])) for k in metrics([],['x'])},
    'index_seconds':index_s,'search_seconds':search_s,'total_evaluation_seconds':time.perf_counter()-t0,
    'latency_ms_median':float(np.median(lat)),'latency_ms_p95':float(np.percentile(lat,95)),
    'latency_boundary':'batch1 tokenization+BM25 score+stable full sort; 5 warmups, 128 measurements',
    'peak_eval_allocated_GiB':0,'training':None}
dump(out/'metrics.json',result);dump(out/'predictions.json',rows);dump(out/'latency_ms.json',lat);print(json.dumps(result,indent=2))
