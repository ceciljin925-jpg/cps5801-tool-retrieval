"""Independent post-run checks on saved predictions and matched budgets."""
import math, pathlib, json, hashlib
root=pathlib.Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
runs=['P01_bm25','P02_pretrained','P03_random_seed42','P04_bm25_seed42'];ids=None
for name in runs:
    p=root/'results'/name; rows=read(p/'predictions.json');m=read(p/'metrics.json')
    if ids is None:ids=[r['id'] for r in rows]
    assert [r['id'] for r in rows]==ids
    totals={f'recall@{k}':0. for k in (1,3,5,10)};totals['mrr@10']=0.
    for r in rows:
        assert len(r['top10'])==len(set(r['top10']))==10
        assert all(math.isfinite(x) for x in r['scores'])
        assert all(a>=b for a,b in zip(r['scores'],r['scores'][1:]))
        pos=set(r['positives'])
        for k in (1,3,5,10):totals[f'recall@{k}']+=sum(x in pos for x in r['top10'][:k])/len(pos)
        matches=[i+1 for i,x in enumerate(r['top10']) if x in pos]
        totals['mrr@10']+=1/min(matches) if matches else 0
    for key,total in totals.items():assert abs(total/len(rows)-m['metrics'][key])<1e-12,(name,key)
    if m['training']:
        t=m['training'];assert t['steps']==64 and t['queries']==1024 and t['epochs']==2
        assert t['embedding_weight_change_l2']>0 and t['trainable_parameters']>30_000_000
        losses=[json.loads(x) for x in (p/'loss.jsonl').read_text().splitlines()]
        assert [x['step'] for x in losses]==list(range(1,65))
        assert all(math.isfinite(x['loss']) and math.isfinite(x['grad_norm']) for x in losses)
    print(name,'independent metrics and run checks passed')
assert len(ids)==128
(root/'logs/output_validation.json').write_text(json.dumps({'status':'passed','runs':runs,'queries':128,'independent_metric_recomputation':True,'paired_training_steps':64,'finite_training_losses':True,'weights_changed':True},indent=2))
