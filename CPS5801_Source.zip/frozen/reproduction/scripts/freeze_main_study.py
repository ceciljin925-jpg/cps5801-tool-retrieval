"""Apply the student's explicit expanded-review confirmation and freeze paired runs."""
import collections,copy,datetime,hashlib,json,random,re
from common import *
from prepare_audited_pilot import finite_interval
P=ROOT/'data/main_20261025';H=ROOT/'results/main_human_audit_20261025'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    assert not (P/'freeze_manifest.json').exists(),'Refuse to overwrite final snapshot'
    for f,h in read(P/'preaudit_manifest.json')['files'].items():assert digest(P/f)==h,f
    src=ROOT/'results/main_audit_20261025/review_package.json';frozen=read(src.parent/'freeze_manifest.json')
    assert digest(src)==frozen['review_package_sha256'] and digest(P/'audit_blind.json')==frozen['source_sha256']
    now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
    pkg=read(src);att=dict(statement='已全部复核，并同意这批结论',scope='All M001-M200 labels and rationales in the displayed expanded review package',recorded_at=now,reviewer='Student / project author (confirmed in chat)',initial_assistance='Codex prepared initial judgments; student confirmed after review',independent_double_annotation=False,suggestion_package_sha256=digest(src),time_semantics='Chat confirmation recording time, not item review durations')
    pkg['human_attestation']=att;pkg['human_confirmed_count']=200
    for row in pkg['items']:
        row['human_review']=dict(status='confirmed',label=row['suggestion']['label'],evidence=row['suggestion']['evidence'],reviewer=att['reviewer'],reviewed_at=now,confirmation_method='explicit batch confirmation in chat')
    H.mkdir(parents=True,exist_ok=True);dump(H/'attestation.json',att);dump(H/'confirmed_review.json',pkg)
    html=(ROOT/'output/CPS5801_扩展实验_人工审查.html').read_text(encoding='utf-8')
    html=re.sub(r'(<script type="application/json" id="data">).*?(</script>)',lambda m:m[1]+json.dumps(pkg,ensure_ascii=False).replace('</','<\\/')+m[2],html,flags=re.S)
    html=html.replace('cps5801-human-review-','cps5801-main-human-confirmed-').replace('<h1>CPS5801 扩展实验人工审查</h1>','<h1>CPS5801 扩展实验人工审查 - 200 条已确认</h1>')
    (ROOT/'output/CPS5801_扩展实验_人工审查_已确认.html').write_text(html,encoding='utf-8')
    # Only now open the policy key, after frozen suggestions and explicit confirmation.
    key={x['pair_id']:x for x in read(P/'audit_key.json')};train=read(P/'train_preaudit.json');docs=read(P/'corpus.json')
    byq={g['id']:g for g in train};bytool={x['id']:x for x in docs};ids=read(P/'train_tool_ids.json');idsset=set(ids)
    before={q:set(v) for q,v in read(P/'forbidden_preaudit.json').items()};pools=read(P/'hard_pool_preaudit.json')
    add=collections.defaultdict(set);exclude=collections.defaultdict(set);registry=[]
    for x in pkg['items']:
        k=key[x['pair_id']];q,t=k['query_id'],k['tool_id'];assert x['query']==byq[q]['query'] and x['tool']==bytool[t]['raw']
        lab=x['human_review']['label']
        if lab!='defensible negative':exclude[q].add(t)
        if lab in ('valid alternative','omitted jointly-required component'):add[q].add(t)
        registry.append(dict(**k,label=lab,evidence=x['human_review']['evidence'],relation_scope='query component only'))
    same=collections.defaultdict(set)
    for t in ids:same[bytool[t]['text']].add(t)
    masks=copy.deepcopy(before);kept=[];drops=[];newpools={}
    for g in train:
        q=g['id'];g['positives']=sorted(set(g['positives'])|add[q]);masks[q].update(g['positives']);masks[q].update(exclude[q])
        for t in g['positives']:masks[q].update(same[bytool[t]['text']])
        newpools[q]=[t for t in pools[q] if t not in masks[q]]
        if len(newpools[q])<4 or len(idsset-masks[q])<4:drops.append(q)
        else:kept.append(g)
    dump(P/'train.json',kept);dump(P/'positive_registry.json',{'inherited':read(P/'inherited_review.json'),'expanded':registry})
    dump(P/'exclusions.json',{'direct_new':{q:sorted(v) for q,v in exclude.items()},'forbidden':{q:sorted(v) for q,v in masks.items()},'synchronized_query_drops':drops})
    dump(P/'forbidden_ids.json',{q:sorted(v) for q,v in masks.items()});dump(P/'bm25_top50_eligible.json',newpools)
    for seed in (42,43,44):
        order_rng,pos_rng,random_rng,hard_rng=[random.Random(n+seed) for n in (0,1000,2000,3000)];neg={};schedule=[]
        for g in kept:
            q=g['id'];ns=[]
            while len(ns)<4:
                t=random_rng.choice(ids)
                if t not in masks[q] and t not in ns:ns.append(t)
            neg[q]={'random':ns,'bm25':hard_rng.sample(newpools[q],4)}
            assert all(len(set(v))==4 and not set(v)&masks[q] for v in neg[q].values())
        for epoch in range(2):
            order=list(range(len(kept)));order_rng.shuffle(order)
            schedule.extend(dict(epoch=epoch,query_id=kept[i]['id'],positive=pos_rng.choice(kept[i]['positives'])) for i in order)
        assert len(schedule)==2*len(kept)
        dump(P/f'negatives_seed{seed}.json',neg);dump(P/f'shared_schedule_seed{seed}.json',schedule)
    stats={}
    direct={(q,t) for q,ts in exclude.items() for t in ts}
    for pol in ('random','bm25'):
        sample=[x for x in registry if pol in x['pools']];counts=collections.Counter(x['label'] for x in sample)
        n=sum(len(idsset-before[g['id']]) for g in train) if pol=='random' else sum(len(pools[g['id']]) for g in train)
        m=sum(len(idsset-masks[g['id']]) for g in kept) if pol=='random' else sum(len(newpools[g['id']]) for g in kept)
        ambiguity=len(sample)-counts['defensible negative'];interval=finite_interval(n,len(sample),ambiguity)
        removed=sum((t in idsset and t not in before[q]) if pol=='random' else t in pools[q] for q,t in direct)
        stats[pol]=dict(population_before_fresh_review=n,remaining_population=m,sample=len(sample),counts=dict(counts),combined_ambiguity=ambiguity/len(sample),interval=interval,direct_ambiguity_removals=removed,residual_ambiguity_upper=min(1,max(0,(interval['count_bounds'][1]-removed)/m)))
    stats['limits']='SRSWOR candidate-pair ambiguity after inherited masks; metadata judgments, one student reviewer following suggestions; not false-negative prevalence or independent double annotation. Per-pool intervals exclude annotation error.'
    dump(H/'pool_statistics.json',stats)
    changes=dict(frozen_at=now,training_queries=len(kept),development_queries=len(read(P/'dev.json')),inherited_human_pairs=200,new_human_pairs=200,new_positive_pairs=sum(map(len,add.values())),new_direct_exclusions=len(direct),new_input_equivalence_exclusions=sum(len(masks[q]-before[q]-exclude[q]) for q in masks),synchronized_drops=drops,steps_per_run=(2*len(kept)+31)//32,official_test_scored=False)
    dump(P/'changes.json',changes)
    plan=dict(frozen_at=now,primary='Macro recall@5 over original test positive IDs',secondary=['recall@1','recall@3','recall@10','mrr@10'],candidate_scope='Same pooled 44453-tool official catalogue for all eight checkpoints/baselines; not official track-specific leaderboard comparability',train_budget='Two epochs, 625 updates at 10000 queries, no best-epoch selection',checkpoint_selection='Final epoch only; seeds 42,43,44 all reported',candidate_budget='Before test, smallest k in [1,3,5,10] whose mean development recall reaches pretrained development recall@10; failures retained',uncertainty='Paired query bootstrap 5000 draws, seed 50042, average per-query effects across three seeds; separately report paired seed SD',confirmatory_followup='Single-labelled-positive versus multiple-labelled-positive strata, motivated by post-hoc pilot; do not equate label count to joint necessity',test_policy='One frozen evaluation per method; no test-driven tuning. No official scores seen at protocol freeze.',latency='Full development batch-one timing; independent fixed test subset can be used if declared; embedding and mining costs reported separately',unresolved='Unknown row provenance, non-exhaustive relevance, semantic overlap and external API functionality remain unverified')
    dump(P/'analysis_plan.json',plan)
    files={f.relative_to(ROOT).as_posix():digest(f) for f in sorted(P.glob('*.json'))}
    for f in [H/'confirmed_review.json',H/'pool_statistics.json',ROOT/'scripts/freeze_main_study.py',ROOT/'scripts/main_common.py',ROOT/'scripts/main_training_engine.py']:files[f.relative_to(ROOT).as_posix()]=digest(f)
    dump(P/'freeze_manifest.json',dict(frozen_at=now,training_authorized=True,human_confirmed_new_pairs=200,files=files))
    print(json.dumps({'changes':changes,'audit':stats},ensure_ascii=True,indent=2))
if __name__=='__main__':main()
