"""Inspect actual truncated encoder inputs without changing the frozen experiment."""
import collections,hashlib,os
os.environ['TOKENIZERS_PARALLELISM']='false'
from common import *
from transformers import AutoTokenizer
P=ROOT/'data/main_20261025';R=ROOT/'results/main_20261025'
tok=AutoTokenizer.from_pretrained(ROOT/'data/raw/model',local_files_only=True)
corpus=read(P/'corpus.json');sign={};groups=collections.defaultdict(list)
for lo in range(0,len(corpus),256):
    rows=corpus[lo:lo+256];encoded=tok(['passage: '+x['text'] for x in rows],truncation=True,max_length=384)['input_ids']
    for x,ids in zip(rows,encoded):
        signature=tuple(ids);sign[x['id']]=signature;groups[signature].append(x)
expanded=[xs for xs in groups.values() if len({x['text'] for x in xs})>1]
train=read(P/'train.json');positive={g['id']:{sign[t] for t in g['positives']} for g in train};counts={};cases=[]
for seed in (42,43,44):
    neg=read(P/f'negatives_seed{seed}.json')
    for pol in ('random','bm25'):
        found=[{'query_id':q,'tool_id':t} for q,ns in neg.items() for t in ns[pol] if sign[t] in positive[q]]
        counts[f'{pol}_{seed}']=len(found)
        cases.extend(dict(seed=seed,policy=pol,**x) for x in found)
test=read(P/'test_corpus.json');training_texts={x['text'] for x in corpus};canonical={sha(json.dumps(x['raw'],ensure_ascii=False,sort_keys=True)) for x in corpus}
overlap={'test_ids_with_identical_training_serialization':sum(x['text'] in training_texts for x in test),'test_ids_with_identical_canonical_raw_record':sum(sha(json.dumps(x['raw'],ensure_ascii=False,sort_keys=True)) in canonical for x in test),'total_test_tools':len(test),'interpretation':'Strict overlap diagnostics, not functional equivalence or unseen-tool guarantees. Training catalogue includes tools beyond gradient-positive IDs.'}
dump(R/'encoder_collision_check.json',{'nonidentical_serializations_sharing_truncated_token_inputs':len(expanded),'sampled_negative_collisions_by_run':counts,'collision_cases':cases,'strict_catalogue_overlap':overlap})
print(json.dumps({'groups':len(expanded),'sampled_collisions':counts,'overlap':overlap},indent=2))
