from download_resources import *
metadata=json.loads((RAW/'training_file_metadata.json').read_text(encoding='utf-8-sig'))
checks=[]
for m in metadata:
    p=RAW/'training'/m['path'];expected=m['lfs']['oid']
    with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    if actual!=expected:
        backup=p.with_suffix('.invalid_download')
        if backup.exists():raise RuntimeError('Repeated corrupt download; original evidence retained')
        p.rename(backup)
        revision=json.loads((RAW/'training_metadata.json').read_text(encoding='utf-8-sig'))['sha']
        get(f'https://huggingface.co/datasets/mangopy/ToolRet-Training-20w/resolve/{revision}/{m["path"]}',p)
        with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    assert actual==expected,(p,actual,expected)
    checks.append({'path':m['path'],'bytes':p.stat().st_size,'sha256':actual,'official_sha256_match':True})
(RAW/'training_integrity_verified.json').write_text(json.dumps(checks,indent=2))
print('ALL SIX SHARDS VERIFIED',flush=True)
