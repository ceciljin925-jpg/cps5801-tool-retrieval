import json, platform, pathlib, sys
import torch, transformers, numpy, pyarrow, scipy
root=pathlib.Path(__file__).resolve().parents[1]
assert torch.cuda.is_available()
x=torch.randn(512,512,device='cuda',requires_grad=True)
with torch.autocast('cuda',dtype=torch.bfloat16):loss=(x@x.T).float().square().mean()
loss.backward();torch.cuda.synchronize();assert torch.isfinite(x.grad).all()
out={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'torch':torch.__version__,
    'transformers':transformers.__version__,'numpy':numpy.__version__,'pyarrow':pyarrow.__version__,'scipy':scipy.__version__,
    'cuda_runtime':torch.version.cuda,'gpu':torch.cuda.get_device_name(),'gpu_total_bytes':torch.cuda.get_device_properties(0).total_memory,
    'bf16_supported':torch.cuda.is_bf16_supported(),'gpu_backward_smoke_passed':True}
(root/'logs/environment.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
