import unittest
from common import *
class Checks(unittest.TestCase):
    def test_fractional_recall(self):
        self.assertEqual(metrics(['a','z'],['a','b'])['recall@5'],.5)
        self.assertEqual(metrics(['z','b'],['a','b'])['mrr@10'],.5)
    def test_missing_and_duplicates(self):
        self.assertEqual(metrics(['a','a'],['a','b'])['recall@5'],.5)
        self.assertEqual(metrics(['c'],['a'])['mrr@10'],0)
    def test_schema_variants(self):
        a=serialize({'api_name':'f','api_description':'desc','required_parameters':[{'name':'n','type':'INT'}]})
        self.assertIn('n: INT',a)
        b=serialize({'name':'f','description':'desc','parameters':{'type':'object','properties':{'n':{'type':'int'}}}})
        self.assertIn('n: int',b)
    def test_bm25_tie_and_direction(self):
        b=BM25(['weather forecast','weather forecast','calculate sum'])
        self.assertEqual(b.top('weather',3)[0].tolist(),[0,1,2])
        self.assertEqual(b.top('sum',1)[0].tolist(),[2])
    def test_bm25_against_formula(self):
        import math
        b=BM25(['a a b','b c','c'])
        idf=math.log(1+(3-1+.5)/(1+.5))
        expected=idf*(2*2.5)/(2+1.5*(.25+.75*3/2))
        self.assertAlmostEqual(float(b.scores('a')[0]),expected,places=6)
        self.assertEqual(float(b.scores('missing')[0]),0)
    def test_saved_controls(self):
        p=ROOT/'data/prepared'
        if not (p/'shared_schedule_seed42.json').exists():self.skipTest('schedule not generated')
        gs={g['id']:g for g in read(p/'train.json')};neg=read(p/'negatives_seed42.json');pool=read(p/'bm25_top50_eligible.json')
        for q,ns in neg.items():
            for policy,xs in ns.items():self.assertEqual(len(set(xs)),4);self.assertFalse(set(xs)&set(gs[q]['positives']))
            self.assertTrue(set(ns['bm25'])<=set(pool[q]))
            banned=read(p/'input_identical_exclusion_ids.json')[q]
            self.assertFalse(set(ns['random'])&set(banned));self.assertFalse(set(ns['bm25'])&set(banned))
        for s in read(p/'shared_schedule_seed42.json'):self.assertIn(s['positive'],gs[s['query_id']]['positives'])
        self.assertFalse({g['group'] for g in gs.values()}&{g['group'] for g in read(p/'dev.json')})
if __name__=='__main__':unittest.main()
