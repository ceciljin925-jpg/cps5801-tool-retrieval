"""Four-condition, held-out-development pilot. Never evaluates official test scores."""
import argparse, collections, datetime, math, os, random, sys, time, traceback
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TOKENIZERS_PARALLELISM']='false'
import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer
from common import *
P=ROOT/'data/prepared'; R=ROOT/'results'; MODEL=ROOT/'data/raw/model'
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def event(kind,**kw):
    with (ROOT/'logs/events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'time':now(),'event':kind,**kw})+'\n')
    print(kind,kw,flush=True)
def pooling(model,tokens):
    h=model(**tokens).last_hidden_state.float();mask=tokens['attention_mask'].unsqueeze(-1)
    return torch.nn.functional.normalize((h*mask).sum(1)/mask.sum(1),dim=-1)
def load_model():return AutoModel.from_pretrained(MODEL,local_files_only=True,attn_implementation='eager').cuda()
def encode(model,tok,texts,prefix,maxlen,batch=64):
    model.eval(); all_emb=[]
    with torch.inference_mode():
        for i in range(0,len(texts),batch):
            ts=tok([prefix+x for x in texts[i:i+batch]],padding=True,truncation=True,max_length=maxlen,return_tensors='pt').to('cuda')
            # Float32 indexing/evaluation for consistent scores; no approximate index.
            all_emb.append(pooling(model,ts).cpu())
            if i and i%(batch*250)==0:print('encoded',i,'/',len(texts),flush=True)
    return torch.cat(all_emb)
def evaluate(run,model,tok,corpus,dev,bm25=None,train_stats=None):
    out=R/run;out.mkdir(parents=True,exist_ok=True)
    if (out/'metrics.json').exists():
        event('reuse_completed_evaluation',run=run);return read(out/'metrics.json')
    rows=[];t0=time.perf_counter()
    tool_ids=[x['id'] for x in corpus];lat=[]
    if bm25 is None:
        torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize()
        emb=encode(model,tok,[x['text'] for x in corpus],'passage: ',384).cuda()
        torch.cuda.synchronize();index_s=time.perf_counter()-t0
        queries=encode(model,tok,[x['query'] for x in dev],'query: ',128).cuda()
        torch.cuda.synchronize();qt=time.perf_counter()
        scores=(queries@emb.T).cpu().numpy()
        for i,g in enumerate(dev):
            ix=np.argsort(-scores[i],kind='stable')[:10];top=[tool_ids[j] for j in ix]
            rows.append({'id':g['id'],'positives':g['positives'],'top10':top,'scores':scores[i,ix].tolist(),**metrics(top,g['positives'])})
        search_s=time.perf_counter()-qt
        # Warm up five times, then each development query once, batch one.
        for i in range(len(dev)+5):
            g=dev[i%len(dev)];torch.cuda.synchronize();t=time.perf_counter()
            ts=tok('query: '+g['query'],truncation=True,max_length=128,return_tensors='pt').to('cuda')
            with torch.inference_mode():q=pooling(model,ts);torch.topk(q@emb.T,10)
            torch.cuda.synchronize()
            if i>=5:lat.append(1000*(time.perf_counter()-t))
        peak=torch.cuda.max_memory_allocated()/2**30
        del emb,queries
    else:
        index_s=0;qt=time.perf_counter()
        for g in dev:
            ix,s=bm25.top(g['query'],10);top=[tool_ids[j] for j in ix]
            rows.append({'id':g['id'],'positives':g['positives'],'top10':top,'scores':s.tolist(),**metrics(top,g['positives'])})
        search_s=time.perf_counter()-qt
        for i in range(len(dev)+5):
            t=time.perf_counter();bm25.top(dev[i%len(dev)]['query'],10)
            if i>=5:lat.append(1000*(time.perf_counter()-t))
        peak=0
    result={'run_id':run,'finished_at':now(),'split':'development pilot','n':len(dev),'candidate_tools':len(corpus),
        'metrics':{k:float(np.mean([x[k] for x in rows])) for k in metrics([],['x'])},
        'index_seconds':index_s,'search_seconds':search_s,'total_evaluation_seconds':time.perf_counter()-t0,
        'latency_ms_median':float(np.median(lat)),'latency_ms_p95':float(np.percentile(lat,95)),
        'latency_boundary':'batch1 tokenization+encoding+exact score+topk; BM25 tokenization+score+stable full sort; 5 warmups, 128 measurements',
        'peak_eval_allocated_GiB':peak,'training':train_stats}
    dump(out/'metrics.json',result);dump(out/'predictions.json',rows);dump(out/'latency_ms.json',lat)
    event('evaluation_completed',**result);return result
def train_run(policy,tok,train,corpus,schedule,neg):
    run=f'P03_{policy}_seed42' if policy=='random' else f'P04_{policy}_seed42'
    out=R/run;out.mkdir(exist_ok=True)
    if (out/'training.json').exists() and (out/'checkpoint/config.json').exists():
        event('reuse_completed_checkpoint',run=run)
        return run,AutoModel.from_pretrained(out/'checkpoint',local_files_only=True,attn_implementation='eager').cuda(),read(out/'training.json')
    if (out/'loss.jsonl').exists():
        raise RuntimeError(f'Partial training at {out}; preserve it under a failed-attempt ID before restarting. Per-step optimizer resume is not implemented.')
    torch.manual_seed(42);torch.cuda.manual_seed_all(42);np.random.seed(42);random.seed(42)
    model=load_model();model.train();optimizer=torch.optim.AdamW(model.parameters(),lr=2e-5,weight_decay=.01,betas=(.9,.999),eps=1e-8)
    initial_embedding=model.get_input_embeddings().weight.detach().clone()
    gs={g['id']:g for g in train};docs={x['id']:x['text'] for x in corpus}
    qtok={g['id']:tok('query: '+g['query'],truncation=True,max_length=128) for g in train}
    used=sorted({s['positive'] for s in schedule}|{x for ns in neg.values() for x in ns[policy]})
    dtok={x:tok('passage: '+docs[x],truncation=True,max_length=384) for x in used}
    torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter();losses=[];steps=0
    event('training_started',run=run,examples=len(schedule),audit='not human reviewed')
    for offset in range(0,len(schedule),32):
        batch=schedule[offset:offset+32];optimizer.zero_grad(set_to_none=True);weighted_loss=0
        for a in range(0,len(batch),8):
            mb=batch[a:a+8]
            qs=tok.pad([qtok[s['query_id']] for s in mb],padding=True,return_tensors='pt').to('cuda')
            ids=[x for s in mb for x in [s['positive']]+neg[s['query_id']][policy]]
            ds=tok.pad([dtok[x] for x in ids],padding=True,return_tensors='pt').to('cuda')
            with torch.autocast('cuda',dtype=torch.bfloat16):
                q=pooling(model,qs);d=pooling(model,ds).view(len(mb),5,-1)
                logits=(q[:,None,:]*d).sum(-1)/.05
                loss=torch.nn.functional.cross_entropy(logits,torch.zeros(len(mb),dtype=torch.long,device='cuda'))
            if not torch.isfinite(loss):raise RuntimeError('nonfinite loss')
            (loss*len(mb)/len(batch)).backward();weighted_loss+=loss.item()*len(mb)/len(batch)
        grad=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.0));optimizer.step();steps+=1
        row={'step':steps,'epoch':batch[0]['epoch']+1,'loss':weighted_loss,'grad_norm':grad,'elapsed_seconds':time.perf_counter()-start}
        losses.append(row)
        with (out/'loss.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        if steps%8==0:event('training_progress',run=run,**row)
    torch.cuda.synchronize();elapsed=time.perf_counter()-start
    stats={'seed':42,'steps':steps,'epochs':2,'queries':len(train),'train_seconds':elapsed,'seconds_per_step':elapsed/steps,
        'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
        'embedding_weight_change_l2':float((model.get_input_embeddings().weight.detach()-initial_embedding).norm()),
        'peak_allocated_GiB':torch.cuda.max_memory_allocated()/2**30,'first_loss':losses[0]['loss'],'last_loss':losses[-1]['loss'],
        'mean_loss':float(np.mean([x['loss'] for x in losses])),'checkpoint':'final epoch 2','audit':'not human reviewed'}
    model.save_pretrained(out/'checkpoint');tok.save_pretrained(out/'checkpoint');dump(out/'training.json',stats)
    event('training_completed',run=run,**stats)
    return run,model,stats
def main():
    R.mkdir(exist_ok=True);torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    assert torch.cuda.is_available();assert torch.cuda.is_bf16_supported()
    corpus=read(P/'corpus.json');train=read(P/'train.json');dev=read(P/'dev.json');train_ids=set(read(P/'train_tool_ids.json'))
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
    trunc={}
    for split,texts,prefix,cap in [('train_query',[g['query'] for g in train],'query: ',128),('dev_query',[g['query'] for g in dev],'query: ',128),('tool',[x['text'] for x in corpus],'passage: ',384)]:
        lens=[]
        for i in range(0,len(texts),512):lens += [len(x) for x in tok([prefix+x for x in texts[i:i+512]],truncation=False)['input_ids']]
        trunc[split]={'n':len(lens),'truncated':sum(n>cap for n in lens),'cap':cap,'max':max(lens),'mean':float(np.mean(lens))}
        if split=='tool':dump(P/'full_serialized_tool_token_lengths.json',dict(zip([x['id'] for x in corpus],lens)))
    dump(R/'truncation.json',trunc)
    raw_lens=[]
    for i in range(0,len(corpus),256):
        texts=[json.dumps(x['raw'],sort_keys=True,ensure_ascii=False) for x in corpus[i:i+256]]
        raw_lens += [len(x) for x in tok(texts,truncation=False,add_special_tokens=False)['input_ids']]
    dump(P/'full_raw_tool_token_lengths.json',dict(zip([x['id'] for x in corpus],raw_lens)))
    from mine import make_schedule
    if not (P/'shared_schedule_seed42.json').exists():make_schedule(train,corpus,train_ids)
    schedule=read(P/'shared_schedule_seed42.json');neg=read(P/'negatives_seed42.json')
    train=[g for g in train if g['id'] in neg]
    config={'pilot':True,'seed':42,'sampling_seed':20261025,'model_revision':read(ROOT/'data/raw/model_metadata.json')['sha'],
        'shared_schedule_sha256':sha((P/'shared_schedule_seed42.json').read_text(encoding='utf-8')),
        'negative_manifest_sha256':sha((P/'negatives_seed42.json').read_text(encoding='utf-8')),
        'experiment_code_sha256':sha(pathlib.Path(__file__).read_text(encoding='utf-8')),
        'positive_rng_seed':1042,'random_negative_rng_seed':2042,'hard_negative_rng_seed':3042,'audit_rng_seed':4042,
        'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,'cuda_runtime':torch.version.cuda,'python':sys.version,
        'epochs':2,'effective_batch':32,'microbatch':8,'accumulation':4,'temperature':.05,'lr':2e-5,'weight_decay':.01,
        'lr_schedule':'constant; no warmup','clip_grad_norm':1.,'precision':'bfloat16 mixed training; float32 eval','in_batch_negatives':False,
        'negative_per_query':4,'query_max_tokens':128,'tool_max_tokens':384,'evaluation':'exact float32 inner product; stable tool-ID ties',
        'bm25':'positive Robertson IDF; k1=1.5 b=.75; lowercase regex [a-z0-9]+; no stemming; top50 then mask known positives',
        'human_audit':'pending','additional_negative_mask':'same serialized input as any known positive; no relevance-label propagation','official_test_evaluation':False}
    dump(R/'config.json',config)
    if not (R/'P01_bm25/metrics.json').exists():
        t=time.perf_counter();bm=BM25([x['text'] for x in corpus]);bm_time=time.perf_counter()-t
        a=evaluate('P01_bm25',None,tok,corpus,dev,bm25=bm);a['index_seconds']=bm_time;dump(R/'P01_bm25/metrics.json',a);del bm
    model=load_model();a=evaluate('P02_pretrained',model,tok,corpus,dev);del model;torch.cuda.empty_cache()
    target=a['metrics']['recall@10'];dump(R/'pilot_target.json',{'pretrained_dev_recall10':target,'official_test_scores_seen':False})
    for policy in ['random','bm25']:
        run,model,stats=train_run(policy,tok,train,corpus,schedule,neg)
        evaluate(run,model,tok,corpus,dev,train_stats=stats);del model;torch.cuda.empty_cache()
    event('pilot_completed')
if __name__=='__main__':
    try:main()
    except Exception as e:
        event('failed',error=repr(e),traceback=traceback.format_exc());raise
