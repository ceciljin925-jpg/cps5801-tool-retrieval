"""Public, revision-pinned downloads. No account or API key required."""
import concurrent.futures, hashlib, json, pathlib, time, urllib.request
ROOT = pathlib.Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw'
def get(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=120) as r, dest.with_suffix(dest.suffix+'.part').open('wb') as w:
                    expected=int(r.headers.get('Content-Length',0)); count=0
                    while chunk := r.read(2**20): w.write(chunk); count+=len(chunk)
                if expected and count!=expected:raise IOError(f'truncated download: {count}/{expected}')
                dest.with_suffix(dest.suffix+'.part').replace(dest)
                break
            except Exception as e:
                print('RETRY', url, repr(e), flush=True)
                if attempt == 2: raise
                time.sleep(2)
    h=hashlib.file_digest(dest.open('rb'),'sha256').hexdigest()
    print('OK',dest.name,dest.stat().st_size,h,flush=True)
    return {'url':url,'path':str(dest.relative_to(ROOT)),'bytes':dest.stat().st_size,'sha256':h}
if __name__=='__main__':
    jobs=[]
    for typ, repo, meta, folder in [('datasets','mangopy/ToolRet-Training-20w','training_metadata.json','training'),('','intfloat/e5-small-v2','model_metadata.json','model')]:
        m=json.loads((RAW/meta).read_text(encoding='utf-8-sig'))
        for s in m['siblings']:
            f=s['rfilename']
            if folder=='training' and not(f.endswith('.parquet') or f=='README.md'):continue
            if folder=='model' and f not in ['config.json','model.safetensors','tokenizer.json','tokenizer_config.json','special_tokens_map.json','vocab.txt','README.md']:continue
            jobs.append((f'https://huggingface.co/{typ+"/" if typ else ""}{repo}/resolve/{m["sha"]}/{f}',RAW/folder/f))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        manifest=list(ex.map(lambda j:get(*j),jobs))
    (RAW/'download_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
