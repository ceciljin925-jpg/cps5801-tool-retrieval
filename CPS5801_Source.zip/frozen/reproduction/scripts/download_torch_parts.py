"""Resume range downloads; verify against official PyTorch wheel-index SHA256."""
import concurrent.futures, hashlib, pathlib, shutil, time, urllib.request
root=pathlib.Path(__file__).resolve().parents[1]
url='https://download-r2.pytorch.org/whl/cu128/torch-2.7.1%2Bcu128-cp312-cp312-win_amd64.whl'
total=3273024349; size=64*1024**2;folder=root/'wheels/torch_parts';folder.mkdir(parents=True,exist_ok=True)
def part(i):
    a=i*size;b=min(total,(i+1)*size)-1;p=folder/f'{i:03d}.part'
    if p.exists() and p.stat().st_size==b-a+1:return p
    for attempt in range(4):
        try:
            req=urllib.request.Request(url,headers={'Range':f'bytes={a}-{b}'})
            with urllib.request.urlopen(req,timeout=180) as r,p.open('wb') as f:
                assert r.status==206 and r.headers.get('Content-Range','').startswith(f'bytes {a}-{b}/')
                shutil.copyfileobj(r,f,1024**2)
            assert p.stat().st_size==b-a+1
            print('part',i,'done',flush=True);return p
        except Exception as e:
            print('retry',i,repr(e),flush=True)
            if attempt==3:raise
            time.sleep(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:parts=list(ex.map(part,range((total+size-1)//size)))
wheel=root/'wheels/torch-2.7.1+cu128-cp312-cp312-win_amd64.whl'
with wheel.open('wb') as w:
    for p in parts:
        with p.open('rb') as f:shutil.copyfileobj(f,w)
with wheel.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
assert h=='2bb8c05d48ba815b316879a18195d53a6472a03e297d971e916753f8e1053d30',h
print('VERIFIED',h,flush=True)
