"""Prepare expanded disjoint splits, provenance and fresh audit; no test scoring."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import collections, datetime, hashlib, math, random, time
import pyarrow.parquet as pq
import langid
from common import *
from main_common import serialize
P=ROOT/'data/main_20261025';OLD=ROOT/'data/prepared';RAW=ROOT/'data/raw'
def event(*x):print(*x,flush=True)

def main():
    start=time.perf_counter();P.mkdir(parents=True,exist_ok=True)
    if (P/'preaudit_manifest.json').exists():raise RuntimeError('Prepared snapshot exists; refuse overwrite')
    files=sorted((RAW/'training/ToolRet-Training-20w').glob('*.parquet'))
    for m in read(RAW/'training_file_metadata.json'):
        with (RAW/'training'/m['path']).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==m['lfs']['oid']
    test=[];testnorm=set();testtools={};test_bad=[]
    for fp in sorted((RAW/'ToolRet-Tools').glob('*/*.parquet')):
        for row in pq.read_table(fp).to_pylist():
            try:
                d=parse_tool(row['documentation']);txt=serialize(d)
            except Exception as e:test_bad.append({'id':row['id'],'reason':str(e)});continue
            assert row['id'] not in testtools
            testtools[row['id']]={'id':row['id'],'text':txt,'raw':d,'category':fp.parent.name}
    test_query_excluded=[]
    for fp in sorted((RAW/'ToolRet-Queries').glob('*/*.parquet')):
        for row in pq.read_table(fp).to_pylist():
            testnorm.add(norm(row['query']))
            labels=json.loads(row['labels']) if isinstance(row['labels'],str) else row['labels']
            positives=sorted({x['id'] for x in labels if x.get('relevance',1)>0})
            if not positives or not set(positives)<=set(testtools):
                test_query_excluded.append({'id':row['id'],'reason':'unparseable/missing positive mapping'});continue
            test.append({'id':row['id'],'query':row['query'],'positives':positives,'track':fp.parent.name,'category':row['category']})
    dump(P/'test.json',test);dump(P/'test_corpus.json',[testtools[k] for k in sorted(testtools)])
    dump(P/'test_exclusions.json',{'tools':test_bad,'queries':test_query_excluded})
    groups={};counts=collections.Counter();parse_cache={}
    def tool(x):
        # Cache repeated raw strings; canonical IDs and input fields match the pilot.
        key=x if isinstance(x,str) else json.dumps(x,sort_keys=True,ensure_ascii=False)
        if key not in parse_cache:
            d=parse_tool(x);text=serialize(d);tid=sha(json.dumps(d,sort_keys=True,ensure_ascii=False))
            parse_cache[key]={'id':tid,'text':text,'raw':d}
        return parse_cache[key]
    for fp in files:
        for batch in pq.ParquetFile(fp).iter_batches(batch_size=512,columns=['id','query','positive']):
            for row in batch.to_pylist():
                counts['raw_rows']+=1;n=norm(row['query'])
                if n in testnorm:counts['exact_test_overlap_rows']+=1;continue
                alpha=[c for c in row['query'] if c.isalpha()]
                if not alpha or sum(ord(c)<128 for c in alpha)/len(alpha)<.95:counts['latin_filter_excluded']+=1;continue
                try:pos={tool(x)['id'] for x in row['positive']};assert pos
                except Exception:counts['invalid_positive_rows']+=1;continue
                if n not in groups:groups[n]={'id':row['id'],'query':row['query'],'positives':set(),'source_ids':[],'group':sha(n),'provenance':'unknown'}
                groups[n]['positives'].update(pos);groups[n]['source_ids'].append(row['id'])
        event('query_shard',fp.name,counts['raw_rows'])
    ordered=sorted(groups.values(),key=lambda g:sha('20261025:'+g['group']))
    previous_train={g['group'] for g in read(OLD/'train.json')}
    previous_dev={g['group'] for g in read(OLD/'dev.json')}
    # Test queries are only read for text overlap, never used to select based on scores.
    anchor_sets=[];anchor_ids=[];index=collections.defaultdict(set);frequency=collections.Counter()
    for g in test:frequency.update(set(words(g['query'])))
    for g in ordered[:20000]:frequency.update(set(words(g['query'])))
    def add_anchor(qid,tokens):
        i=len(anchor_sets);anchor_sets.append(tokens);anchor_ids.append(qid)
        for w in tokens:index[w].add(i)
    for g in test:add_anchor('test:'+g['id'],set(words(g['query'])))
    def close_match(tokens):
        if not tokens:return None
        # Prefix filtering is exact for the stated token-set Jaccard threshold.
        ordered_tokens=sorted(tokens,key=lambda w:(frequency[w],w));length=len(tokens)
        prefix=ordered_tokens[:length-math.ceil(.85*length)+1];candidates=set()
        for w in prefix:candidates.update(index.get(w,()))
        for j in sorted(candidates):
            other=anchor_sets[j]
            if min(len(other),length)<.85*max(len(other),length):continue
            score=len(tokens&other)/len(tokens|other)
            if score>=.85:return {'anchor':anchor_ids[j],'jaccard':score}
        return None
    selected_dev=[];selected_train=[];language_records=[];excluded=[]
    def choose(candidates,n,label):
        selected=[]
        for g in candidates:
            lng,score=langid.classify(g['query']);language_records.append({'id':g['id'],'prediction':lng,'raw_score':score,'query':g['query']})
            reviewed_english={'train_83165','train_39213','train_78167','train_29284','train_130982','train_166842','train_32110'}
            if lng!='en' and g['id'] not in reviewed_english:excluded.append({'id':g['id'],'reason':'langid_not_en','prediction':lng});continue
            tokens=set(words(g['query']));match=close_match(tokens)
            if match:excluded.append({'id':g['id'],'reason':'token_jaccard_ge_085',**match});continue
            g['positives']=sorted(g['positives']);selected.append(g);add_anchor(label+':'+g['id'],tokens)
            if len(selected)%500==0:event(label,len(selected))
            if len(selected)==n:break
        return selected
    # Never move a previously gradient-trained query into development.
    selected_dev=choose((g for g in ordered if g['group'] not in previous_train),1000,'dev')
    dev_groups={g['group'] for g in selected_dev};dev_rows={i for g in selected_dev for i in g['source_ids']}
    # Keep former development queries out of all gradient updates even when screened out.
    selected_train=choose((g for g in ordered if g['group'] not in dev_groups|previous_dev),10000,'train')
    assert len(selected_dev)==1000 and len(selected_train)==10000
    selected_ids={g['id'] for g in selected_train};selected_by_id={g['id']:g for g in selected_train}
    corpus={};train_tools=set();eligible_rows={i for g in ordered if g['group'] not in dev_groups|previous_dev for i in g['source_ids']}
    for fp in files:
        for batch in pq.ParquetFile(fp).iter_batches(batch_size=256,columns=['id','positive','negative']):
            for row in batch.to_pylist():
                train_row=row['id'] in eligible_rows
                if not train_row and row['id'] not in dev_rows:continue
                for kind in (['positive','negative'] if train_row else ['positive']):
                    for raw in row[kind]:
                        try:t=tool(raw)
                        except Exception:counts['invalid_tool_occurrences']+=1;continue
                        corpus[t['id']]=t
                        if train_row:train_tools.add(t['id'])
        event('corpus_shard',fp.name,len(corpus))
    docs=[corpus[k] for k in sorted(corpus)]
    for g in selected_train+selected_dev:assert set(g['positives'])<=set(corpus)
    dump(P/'train_base.json',selected_train);dump(P/'dev.json',selected_dev);dump(P/'corpus.json',docs);dump(P/'train_tool_ids.json',sorted(train_tools))
    dump(P/'language_checks.json',language_records);dump(P/'split_exclusions.json',excluded)
    old_review=read(ROOT/'results/human_audit_20261025/confirmed_review.json')
    old_key={x['pair_id']:x for x in read(OLD/'human_audit_key.json')}
    inherited=[];added=collections.defaultdict(set);blocked=collections.defaultdict(set)
    for row in old_review['items']:
        k=old_key[row['pair_id']];q,t=k['query_id'],k['tool_id']
        if q not in selected_ids or t not in train_tools:continue
        label=row['human_review']['label'];inherited.append(dict(**k,label=label,evidence=row['human_review']['evidence']))
        if label in ['valid alternative','omitted jointly-required component']:added[q].add(t)
        if label!='defensible negative':blocked[q].add(t)
    train_ids=[t['id'] for t in docs if t['id'] in train_tools];texts=[corpus[t]['text'] for t in train_ids]
    equal=collections.defaultdict(set)
    for t in train_ids:equal[corpus[t]['text']].add(t)
    masks={};pools={};eligible=[];pooldrops=[]
    t0=time.perf_counter();bm=BM25(texts);index_seconds=time.perf_counter()-t0;t0=time.perf_counter()
    for g in selected_train:
        q=g['id'];g['original_positives']=list(g['positives']);g['positives']=sorted(set(g['positives'])|added[q])
        masks[q]=set(g['positives'])|blocked[q]
        for t in g['positives']:masks[q].update(equal[corpus[t]['text']])
        ix,_=bm.top(g['query'],50);pools[q]=[train_ids[i] for i in ix if train_ids[i] not in masks[q]]
        if len(pools[q])<4:pooldrops.append(q)
        else:eligible.append(g)
    mining_seconds=time.perf_counter()-t0
    dump(P/'train_preaudit.json',eligible);dump(P/'inherited_review.json',inherited)
    dump(P/'forbidden_preaudit.json',{q:sorted(v) for q,v in masks.items()});dump(P/'hard_pool_preaudit.json',pools);dump(P/'pool_drops_preaudit.json',pooldrops)
    rng=random.Random(20261026);hp=[(g['id'],t) for g in eligible for t in pools[g['id']]];rp=set()
    while len(rp)<100:
        g=rng.choice(eligible);t=rng.choice(train_ids)
        if t not in masks[g['id']]:rp.add((g['id'],t))
    samples={'random':sorted(rp),'bm25':rng.sample(hp,100)}
    pairs=sorted(set(samples['random'])|set(samples['bm25']),key=lambda x:sha('main-audit:'+str(x)))
    blind=[];key=[]
    for i,(q,t) in enumerate(pairs):
        pid=f'M{i+1:03}';blind.append({'pair_id':pid,'query':selected_by_id[q]['query'],'tool':corpus[t]['raw'],
                                     'known_positives':[corpus[z]['raw'] for z in selected_by_id[q]['positives']]})
        key.append({'pair_id':pid,'query_id':q,'tool_id':t,'pools':[p for p,xs in samples.items() if (q,t) in xs]})
    dump(P/'audit_blind.json',blind);dump(P/'audit_key.json',key)
    # A reproducible accepted-language sample and every language rejection are retained for inspection.
    lrng=random.Random(20261027);accepted=[x for x in language_records if x['prediction']=='en']
    dump(P/'language_review_sample.json',{'accepted_sample':lrng.sample(accepted,min(100,len(accepted))),'rejected':[x for x in language_records if x['prediction']!='en']})
    summary={'counts':dict(counts),'eligible_groups_before_language_screen':len(groups),'train':len(eligible),'development':len(selected_dev),
        'official_test':len(test),'test_tools':len(testtools),'candidate_tools':len(docs),'train_tools':len(train_tools),
        'split_exclusions':dict(collections.Counter(x['reason'] for x in excluded)),
        'retained_previous_train':sum(g['group'] in previous_train for g in eligible),'retained_previous_dev':sum(g['group'] in previous_dev for g in selected_dev),
        'inherited_human_pairs':len(inherited),'fresh_audit_pairs':len(blind),'fresh_human_review_status':'pending',
        'preaudit_random_population':sum(len(train_tools-masks[g['id']]) for g in eligible),'preaudit_hard_population':len(hp),
        'bm25_index_seconds':index_seconds,'mining_seconds':mining_seconds,'preparation_seconds':time.perf_counter()-start,
        'near_duplicate_policy':'Conservative exclusion at exact token-set Jaccard >=0.85; test priority, then dev, then train. No semantic equivalence/positive merging inferred. Screening covers selected gradient/development queries versus all test queries and previously accepted selected queries, not all corpus-contributor queries.',
        'language_policy':'Latin heuristic plus langid 1.1.6 en argmax, with 7 explicitly inspected English short-query overrides. Overrides were reviewed by Codex, not counted as student human tool-pair review. Raw scores are not calibrated confidence.',
        'serialization_policy':'Missing fields retained with explicit not-provided markers; func_description retained; nested schema.type read. No test query is excluded merely for missing description/name. Version main_common.py.',
        'source_provenance':'unknown; no unverifiable proportional source sampling', 'test_scores_seen':False}
    dump(P/'preparation.json',summary)
    manifest={}
    for fp in P.glob('*.json'):
        with fp.open('rb') as f:manifest[fp.name]=hashlib.file_digest(f,'sha256').hexdigest()
    dump(P/'preaudit_manifest.json',{'created_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'files':manifest})
    event('prepared',json.dumps(summary))
if __name__=='__main__':main()
