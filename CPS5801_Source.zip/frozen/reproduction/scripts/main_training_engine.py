"""Expanded study engine adapted from the preserved audited pilot."""
import datetime, hashlib, json, math, pathlib, random, sys, time, traceback
import experiment as base
from common import *
torch=base.torch
P=ROOT/'data/main_20261025';A=P;R=ROOT/'results/main_20261025'
RUN_AUDIT='200 inherited plus 200 expanded pairs confirmed by student after metadata suggestions; residual uncertainty remains'

def event(kind,**kw):
    row={'time':base.now(),'event':kind,**kw}
    with (ROOT/'logs/main_events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
    print(kind,kw,flush=True)

def digest(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def train_run(policy,seed,tok,train,corpus,schedule,neg):
    run=f'M{3+2*(seed-42)+(policy=="bm25"):02}_{policy}_seed{seed}'
    out=R/run;out.mkdir(parents=True,exist_ok=True)
    if (out/'training.json').exists() and (out/'checkpoint/config.json').exists():
        stats=read(out/'training.json');assert stats['schedule_sha256']==digest(A/f'shared_schedule_seed{seed}.json')
        event('reuse_completed_checkpoint',run=run)
        return run,base.AutoModel.from_pretrained(out/'checkpoint',local_files_only=True,attn_implementation='eager').cuda(),stats
    if (out/'loss.jsonl').exists():raise RuntimeError(f'Partial run {run}; preserve and restart under a new attempt ID.')
    torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);np.random.seed(seed);random.seed(seed)
    model=base.load_model();model.train()
    optimizer=torch.optim.AdamW(model.parameters(),lr=2e-5,weight_decay=.01,betas=(.9,.999),eps=1e-8)
    initial=model.get_input_embeddings().weight.detach().clone()
    docs={x['id']:x['text'] for x in corpus}
    qtok={g['id']:tok('query: '+g['query'],truncation=True,max_length=128) for g in train}
    used=sorted({s['positive'] for s in schedule}|{t for ns in neg.values() for t in ns[policy]})
    dtok={t:tok('passage: '+docs[t],truncation=True,max_length=384) for t in used}
    config={'run_id':run,'policy':policy,'seed':seed,'schedule_sha256':digest(A/f'shared_schedule_seed{seed}.json'),
        'negative_manifest_sha256':digest(A/f'negatives_seed{seed}.json'),'snapshot_manifest_sha256':digest(A/'freeze_manifest.json'),
        'experiment_code_sha256':digest(__file__),'evaluation_code_sha256':digest(ROOT/'scripts/experiment.py'),
        'start':base.now(),'audit':RUN_AUDIT}
    dump(out/'config.json',config)
    torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter();losses=[]
    event('training_started',run=run,examples=len(schedule),audit=RUN_AUDIT)
    for offset in range(0,len(schedule),32):
        batch=schedule[offset:offset+32];optimizer.zero_grad(set_to_none=True);weighted=0
        for a in range(0,len(batch),8):
            mb=batch[a:a+8]
            qs=tok.pad([qtok[s['query_id']] for s in mb],padding=True,return_tensors='pt').to('cuda')
            ids=[t for s in mb for t in [s['positive']]+neg[s['query_id']][policy]]
            ds=tok.pad([dtok[t] for t in ids],padding=True,return_tensors='pt').to('cuda')
            with torch.autocast('cuda',dtype=torch.bfloat16):
                q=base.pooling(model,qs);d=base.pooling(model,ds).view(len(mb),5,-1)
                logits=(q[:,None,:]*d).sum(-1)/.05
                loss=torch.nn.functional.cross_entropy(logits,torch.zeros(len(mb),dtype=torch.long,device='cuda'))
            if not torch.isfinite(loss):raise RuntimeError('Nonfinite loss')
            (loss*len(mb)/len(batch)).backward();weighted+=loss.item()*len(mb)/len(batch)
        grad=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.0))
        if not math.isfinite(grad):raise RuntimeError('Nonfinite gradient norm')
        optimizer.step()
        row={'step':len(losses)+1,'epoch':batch[0]['epoch']+1,'loss':weighted,'grad_norm':grad,'elapsed_seconds':time.perf_counter()-start}
        losses.append(row)
        with (out/'loss.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        if len(losses)%16==0:event('training_progress',run=run,**row)
    torch.cuda.synchronize();elapsed=time.perf_counter()-start
    stats={'seed':seed,'steps':len(losses),'epochs':2,'queries':len(train),'train_seconds':elapsed,
        'seconds_per_step':elapsed/len(losses),'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
        'embedding_weight_change_l2':float((model.get_input_embeddings().weight.detach()-initial).norm()),
        'peak_allocated_GiB':torch.cuda.max_memory_allocated()/2**30,'first_loss':losses[0]['loss'],
        'last_loss':losses[-1]['loss'],'mean_loss':float(np.mean([x['loss'] for x in losses])),
        'checkpoint':'final epoch 2','audit':RUN_AUDIT,**config}
    model.save_pretrained(out/'checkpoint');tok.save_pretrained(out/'checkpoint');dump(out/'training.json',stats)
    event('training_completed',run=run,steps=len(losses),train_seconds=elapsed,peak_GiB=stats['peak_allocated_GiB'])
    return run,model,stats

def main():
    R.mkdir(parents=True,exist_ok=True);base.R=R;base.event=event
    for file,expected in read(A/'freeze_manifest.json')['files'].items():assert digest(ROOT/file)==expected,file
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    corpus=read(P/'corpus.json');dev=read(P/'dev.json');train=read(A/'train.json')
    tok=base.AutoTokenizer.from_pretrained(base.MODEL,local_files_only=True)
    cfg=read(ROOT/'results/config.json')
    cfg.update(phase='expanded controlled study',seeds=[42,43,44],human_audit=RUN_AUDIT,
        positive_registry='See final positive_registry.json and exclusions.json in the main snapshot',
        snapshot_manifest_sha256=digest(A/'freeze_manifest.json'),experiment_code_sha256=digest(__file__),
        evaluation_code_sha256=digest(ROOT/'scripts/experiment.py'),train_queries=len(train),dev_queries=len(dev),
        official_test_evaluation=False,created_at=base.now(),gpu=torch.cuda.get_device_name())
    cfg.pop('seed',None);cfg.pop('shared_schedule_sha256',None);cfg.pop('negative_manifest_sha256',None)
    dump(R/'config.json',cfg)
    if not (R/'M01_bm25/metrics.json').exists():
        start=time.perf_counter();bm=BM25([x['text'] for x in corpus]);seconds=time.perf_counter()-start
        m=base.evaluate('M01_bm25',None,tok,corpus,dev,bm25=bm);m['index_seconds']=seconds;dump(R/'M01_bm25/metrics.json',m);del bm
    if not (R/'M02_pretrained/metrics.json').exists():
        model=base.load_model();base.evaluate('M02_pretrained',model,tok,corpus,dev);del model;torch.cuda.empty_cache()
    for seed in (42,43,44):
        schedule=read(A/f'shared_schedule_seed{seed}.json');neg=read(A/f'negatives_seed{seed}.json')
        for policy in ('random','bm25'):
            run,model,stats=train_run(policy,seed,tok,train,corpus,schedule,neg)
            m=base.evaluate(run,model,tok,corpus,dev,train_stats=stats)
            m['split']='expanded development';m['latency_boundary']='batch-one tokenization+encoding+exact score+topk; 5 warmups, 1000 measurements'
            dump(R/run/'metrics.json',m);del model;torch.cuda.empty_cache()
    event('expanded_training_completed',trained_runs=6,seeds=[42,43,44],official_test_scored=False)

if __name__=='__main__':
    assert read(A/'freeze_manifest.json').get('training_authorized') is True, 'Main freeze incomplete'
    try:main()
    except Exception as e:event('failed',error=repr(e),traceback=traceback.format_exc());raise
