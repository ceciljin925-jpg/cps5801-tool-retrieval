"""Offline, blinded human-review form. Does not prefill any relevance labels."""
import hashlib, json, pathlib
root=pathlib.Path(__file__).resolve().parents[1]
source=root/'data/prepared/human_audit_blind.json';data=source.read_text(encoding='utf-8')
key='cps5801-audit-'+hashlib.sha256(data.encode()).hexdigest()[:16]
page=r'''<!doctype html><html lang="en"><meta charset="utf-8"><title>CPS5801 blinded negative audit</title>
<style>body{max-width:1000px;margin:35px auto;padding:0 22px;font:16px/1.55 system-ui;color:#222;background:#fafafa}h1{font-size:25px}section{background:white;border:1px solid #ddd;padding:20px;margin:20px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.45 Consolas,monospace;max-height:420px;overflow:auto}textarea{width:95%;height:100px}select,input,button{font:inherit;padding:7px;margin:4px}label{display:block}small{color:#555}.status{font-weight:bold}</style>
<h1>CPS5801: blinded human negative review</h1><p>请根据查询与工具能力判断，必须留下依据。策略名称和排名已隐藏。相同输入不代表功能等价；多个正例也不自动代表共同必需。</p>
<p><small>This form contains 200 unlabelled pairs. AI-generated assessments must not be recorded as human review. Nothing is sent to a server. Browser storage is a convenience only: export your answers regularly.</small></p>
<label>Reviewer / 审核者 <input id="reviewer" placeholder="Your name"></label><div class="status" id="status"></div>
<button id="prev">Previous</button><input id="number" type="number" min="1" max="200" value="1" style="width:70px"><button id="next">Next</button><button id="export">Export reviewed JSON</button>
<section><h2 id="pair"></h2><b>Query</b><p id="query"></p><b>Candidate tool</b><pre id="tool"></pre></section>
<label>Label <select id="label"><option value="">Not reviewed / 未审核</option>defensible negative</option><option>valid alternative</option><option>omitted jointly-required component</option><option>unresolved</option></select></label>
<label>Evidence / 判断依据 <textarea id="evidence" placeholder="Explain the capability match or mismatch; do not guess equivalence."></textarea></label>
<p><small>defensible negative = 能力不满足查询；valid alternative = 可独立替代某项所需能力；omitted jointly-required component = 查询还需要此工具提供的另一组件；unresolved = 无法确认。实际审核时间会随保存记录。请勿打开 human_audit_key.json 后再声称盲审。</small></p>
<script type="application/json" id="data">__DATA__</script><script>
const key='__KEY__';let items=JSON.parse(document.getElementById('data').textContent),i=0;
try{const saved=JSON.parse(localStorage.getItem(key));if(saved&&saved.length===items.length)items=saved;}catch{}
const el=id=>document.getElementById(id);
function save(){let x=items[i];x.label=el('label').value;x.evidence=el('evidence').value;x.reviewer=el('reviewer').value;if(x.label)x.reviewed_at=new Date().toISOString();else x.reviewed_at='';localStorage.setItem(key,JSON.stringify(items));status();}
function status(){el('status').textContent=`${items.filter(x=>x.label&&x.evidence&&x.reviewer).length} / ${items.length} pairs with label, evidence and reviewer`;}
function show(){const x=items[i];el('pair').textContent=x.pair_id;el('query').textContent=x.query;el('tool').textContent=JSON.stringify(x.tool,null,2);el('label').value=x.label;el('evidence').value=x.evidence;el('reviewer').value=x.reviewer||el('reviewer').value;el('number').value=i+1;status();}
el('label').onchange=save;el('evidence').oninput=save;el('reviewer').onchange=save;
el('prev').onclick=()=>{save();i=Math.max(0,i-1);show()};el('next').onclick=()=>{save();i=Math.min(items.length-1,i+1);show()};
el('number').onchange=()=>{save();i=Math.max(0,Math.min(items.length-1,Number(el('number').value)-1));show()};
el('export').onclick=()=>{save();const url=URL.createObjectURL(new Blob([JSON.stringify(items,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='CPS5801_human_audit_answers.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};show();
</script></html>'''
page=page.replace('__DATA__',data.replace('</','<\\/')).replace('__KEY__',key)
(root/'output/human_audit.html').write_text(page,encoding='utf-8')
print(root/'output/human_audit.html')
