"""Flag possible near duplicates without changing the frozen pilot or scoring test data."""
import difflib, pyarrow.parquet as pq
from common import *
p=ROOT/'data/prepared';dev=read(p/'dev.json');train=read(p/'train.json')
flags=[]
# Compare gradient-training queries to development queries. This does not certify
# the full eligible population or semantic/test overlap.
for d in dev:
    a=set(words(d['query']))
    candidates=[]
    for t in train:
        b=set(words(t['query']));j=len(a&b)/max(1,len(a|b))
        if j>=.5:candidates.append((j,t))
    for j,t in sorted(candidates,key=lambda x:-x[0])[:10]:
        ratio=difflib.SequenceMatcher(None,norm(d['query']),norm(t['query']),autojunk=False).ratio()
        if j>=.8 or ratio>=.9:
            flags.append({'development_id':d['id'],'training_id':t['id'],'token_jaccard':j,'character_ratio':ratio,'development_query':d['query'],'training_query':t['query'],'human_review':'pending'})
dump(ROOT/'results/pilot_near_duplicate_flags.json',{'screen':'training1024 versus development128 only; token Jaccard>=.8 or SequenceMatcher>=.9 among token-Jaccard>=.5 candidates','flagged_pairs':flags,'flagged_development_queries':len({x['development_id'] for x in flags}),'semantic_overlap_certified':False,'split_modified':False})
print('flagged pairs',len(flags),'development queries',len({x['development_id'] for x in flags}))
