"""Inspect known-positive capability context without opening the policy key."""
import json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(__file__).resolve().parents[1];out=r/'results/ai_audit_20261025'
a={x['pair_id']:x for x in json.loads((r/'data/prepared/human_audit_blind.json').read_text(encoding='utf-8'))}
g={x['query']:x for x in json.loads((r/'data/prepared/train.json').read_text(encoding='utf-8'))}
c={x['id']:x for x in json.loads((r/'data/prepared/corpus.json').read_text(encoding='utf-8'))}
ids=[]
for f in sorted(out.glob('batch_*.tsv')):
    for line in f.read_text(encoding='utf-8').splitlines():
        row=line.split('\t');assert len(row)==4
        if row[1]=='U':ids.append(row[0])
print('UNRESOLVED TOTAL',len(ids),'IDS',','.join(ids))
for pid in ids[int(sys.argv[1]):int(sys.argv[2])]:
    x=a[pid];print('\nPAIR',pid,'QUERY',x['query'])
    print('CANDIDATE',json.dumps(x['tool'],ensure_ascii=False))
    for tid in g[x['query']]['positives']:
        t=c[tid]['raw'];print('KNOWN_POSITIVE',tid, json.dumps({k:v for k,v in t.items() if k not in ['template_response','required_parameters','optional_parameters','parameters','required']},ensure_ascii=False))
