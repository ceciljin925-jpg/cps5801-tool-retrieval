"""Baseline scores only on the expanded development set; official test untouched."""
import time
import main_training_engine as engine
from common import *
base=engine.base;torch=engine.torch;R=engine.R;P=engine.P
def main():
    assert (P/'preaudit_manifest.json').exists()
    R.mkdir(parents=True,exist_ok=True);base.R=R;base.event=engine.event
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    corpus=read(P/'corpus.json');dev=read(P/'dev.json');tok=base.AutoTokenizer.from_pretrained(base.MODEL,local_files_only=True)
    t=time.perf_counter();bm=BM25([x['text'] for x in corpus]);index=time.perf_counter()-t
    m=base.evaluate('M01_bm25',None,tok,corpus,dev,bm25=bm);m['index_seconds']=index
    m['split']='expanded development';m['latency_boundary']='batch-one BM25 scoring and stable sort; 5 warmups, 1000 measurements';dump(R/'M01_bm25/metrics.json',m);del bm
    model=base.load_model();m=base.evaluate('M02_pretrained',model,tok,corpus,dev)
    m['split']='expanded development';m['latency_boundary']='batch-one tokenize+encode+exact topk; 5 warmups, 1000 measurements';dump(R/'M02_pretrained/metrics.json',m)
    engine.event('expanded_baselines_completed',official_test_scored=False)
if __name__=='__main__':main()
