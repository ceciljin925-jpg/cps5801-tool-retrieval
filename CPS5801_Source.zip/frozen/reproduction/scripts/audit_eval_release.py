"""Read evaluation schema and mappings without computing model scores."""
import collections
import pyarrow.parquet as pq
from common import *
raw=ROOT/'data/raw';corpora={};counts={};bad_docs=[]
for p in sorted((raw/'ToolRet-Tools').glob('*/*.parquet')):
    cat=p.parent.name;rows=pq.read_table(p).to_pylist();corpora[cat]={r['id'] for r in rows};counts[cat]=len(rows)
    for r in rows:
        try:parse_tool(r['documentation'])
        except Exception:bad_docs.append(r['id'])
queries=[];missing=[];relations=collections.Counter();ids=[]
for p in sorted((raw/'ToolRet-Queries').glob('*/*.parquet')):
    rows=pq.read_table(p).to_pylist()
    for r in rows:
        labels=json.loads(r['labels']) if isinstance(r['labels'],str) else r['labels']
        pos=[x['id'] for x in labels if x.get('relevance',1)>0];category=r['category'];ids.append(r['id'])
        absent=set(pos)-corpora.get(category,set())
        if absent:missing.append({'query':r['id'],'missing':sorted(absent),'category':category})
        relations[str(len(pos))]+=1
    queries.append({'track':p.parent.name,'queries':len(rows)})
dump(ROOT/'results/evaluation_release_audit.json',{'candidate_tools_by_category':counts,'pooled_unique_tool_ids':len(set.union(*corpora.values())),
    'total_queries':len(ids),'unique_query_ids':len(set(ids)),'tracks':queries,'invalid_tool_json':bad_docs,'missing_positive_mappings':missing,
    'positive_count_distribution':dict(relations),'model_scores_computed':False,'relation_type':'unknown; positive multiplicity does not identify required versus alternative'})
print('queries',len(ids),'tools',counts,'missing mappings',len(missing))
