# Sources, attribution and third-party terms

| Component | Official source / fixed revision | Role and license boundary |
|---|---|---|
| ToolRet | [Official project](https://github.com/mangopy/ToolRet), [training](https://huggingface.co/datasets/mangopy/ToolRet-Training-20w), [queries](https://huggingface.co/datasets/mangopy/ToolRet-Queries), [tools](https://huggingface.co/datasets/mangopy/ToolRet-Tools) | Upstream training/evaluation. Exact revisions/hashes are in `configs/versions.json` and the download manifest. No full data redistribution; row-level provenance and dataset reuse rights need review. |
| BFCL | [Gorilla/BFCL](https://github.com/ShishirPatil/gorilla/tree/6ea57973c7a6097fd7c5915698c54c17c5b1b6c8/berkeley-function-call-leaderboard) | Apache-2.0 per bundled pinned upstream README/root license. Native menus and function-name labels projected to retrieval; full benchmark calls are not scored. Modified derived ID/rank views, with source attribution in `provenance/representative_results.json`. |
| ToolHop | [Official dataset](https://huggingface.co/datasets/bytedance-research/ToolHop/tree/b439d7279af359fda46e8117ae4f0245b75f5c6b) | Official README declares CC-BY-4.0 data and Apache-2.0 code. Source includes MoreHopQA provenance. No ToolHop dataset/code copied for execution here; a project conversion script and pinned download manifest are included. |
| E5-small-v2 | [Official model](https://huggingface.co/intfloat/e5-small-v2/tree/ffb93f3bd4047442299a41ebb6fa998a38507c52) | MIT model card. External weights not redistributed. |
| BGE-small-en-v1.5 | [Official model](https://huggingface.co/BAAI/bge-small-en-v1.5/tree/5c38ec7c405ec4b44b94cc5a9bb96e735b38267a) | MIT model card. External weights not redistributed. |
| Qwen3-Embedding-0.6B | [Official model](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B/tree/97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3) | Apache-2.0 model card. Inference-only reference; no generation agent. |

Libraries (PyTorch, Transformers, Tokenizers, Hugging Face Hub, NumPy, SciPy, PyArrow, Matplotlib and langid) retain their own licenses; this repository lists dependencies rather than redistributing their installed source or binaries. Consult the pinned upstream distributions for their notices.

BM25 implements the documented positive-Robertson-IDF variant (k1=1.5, b=0.75), with formula background attributed in `references.json`. E5/BGE/Qwen pooling and prompts follow the documented model-specific adapters. Publications are credited as scientific sources; that does not imply their authors endorse this project or its conclusions.

All project code and packaging remain subject to `LICENSE_NOTICE.md`. The bibliography distinguishes peer-reviewed papers from preprints and separates AI metadata checks from pending student verification.
