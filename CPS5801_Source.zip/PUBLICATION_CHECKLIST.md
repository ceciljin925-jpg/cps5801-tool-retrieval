# Pending before public hosting or course submission

Local preparation is authorized and completed without publishing. The following are genuine remaining decisions/actions, not claims of completed work:

- Author: review the code, results, AI disclosure, author/contact information and final manuscript; confirm rights to publish the project code and choose a license if desired.
- Author: decide whether and under which rights any additional original ToolRet snapshot/review data can be released. This candidate provides code, pinned acquisition instructions, hashes and primary rank-only evidence; it does not expose private review forms or claim public access to the return bundle.
- Author: personally open and verify the cited sources. `references.json` records AI-assisted checks separately and leaves student verification pending.
- Author: obtain genuine independent human reviews if those analyses are to be reported. Currently 0/98; do not substitute AI output or claim agreement statistics.
- Scientific report: retain the negative primary finding, distinguish fallback recipe selection from a development winner, separate selected-recipe comparisons from fixed-recipe mechanism tests, and retain conditional interval/provenance limits.
- Hosting: create a public repository only after explicit approval, upload only the reviewed candidate files, check the public URL from a logged-out view, and replace the pending availability statement with the real URL. No URL is invented here.
- Course: the Canvas source-code assignment requires that public URL. The local candidate/ZIP is not itself the required hosted submission. No Canvas upload or submission has occurred.
- Optional replication: acquire the exact historical inputs or document a new audited snapshot; download pinned models; run the GPU entry points on a suitable machine. Packaging verification did not perform new GPU training or model inference.

Do not upload `_work/`, local virtual environments, `.env`, raw bundle contents, historical sessions, private audit forms, large checkpoint files, cached embeddings, or incomplete downloads. Check both tracked files and any intended release attachments immediately before publishing.
