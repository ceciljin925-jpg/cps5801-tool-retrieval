# AI assistance and human verification

Codex/ChatGPT assistance was used substantially for research planning, code generation and debugging, experiment orchestration, frozen-protocol drafting, data/label inspection suggestions, statistical and error analysis, bibliographic checking, and this repository packaging/documentation. The returned artifacts contain the execution evidence; AI-generated prose is not itself proof that an experiment occurred. The exact model/version of every historical interaction has not been established and is not invented here.

The project author authorized the study and GPU work. The original 400 sampled review pairs have recorded student batch confirmation of AI-assisted judgments. This does not establish independent item-level double annotation, independent second-human review, or measured annotation agreement. The prepared independent-review forms currently contain 0 completed reviews out of 98 requested pairs. The 60 qualitative error cases (114 pairs) were reviewed by AI with outcomes visible and are exploratory interpretations. AI review must never fill a human reviewer identity.

During this packaging task, the assistant verified source hashes, configuration coverage, actual saved ranking consistency, CPU main-table regeneration, and bibliography metadata against recorded sources. A separate intake audit checked the packaged BFCL source-to-label structural projection. These are automated/AI-assisted verifications, not a claim that the student personally performed each check or read every cited paper.

Student personally verified bibliography entries remain explicitly pending in `references.json`. Before submission, the author must review the manuscript, sources, code ownership and results, understand the decisions and limitations, and identify any work personally performed without AI. This repository does not invent a list of wholly student-written components.

`frozen/` preserves executed code bytes. `scripts/` and the release documentation are new AI-assisted packaging adapters, not evidence that the historical GPU session executed those adapters. Path sanitization is recorded separately; no historical metric, frozen label or scientific selection is changed by packaging.

No original chat transcripts or private review forms are publicly bundled. No public repository has been created by this task, no code has been uploaded, and no coursework submission has been made.
