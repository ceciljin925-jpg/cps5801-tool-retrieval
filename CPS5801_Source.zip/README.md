# Negative Sampling Controls for Tool Retrieval

Course research implementation for *Static Negative Sources and Loss Candidate Sets in Tool Retrieval with Small Dense Encoders*. This repository contains the original comparison described below and the subsequent [candidate-set experiment](followup/README.md). The latter includes the 20 portable configurations, training and evaluation code, 100 evaluation summaries and a small CPU-only reconstruction of the primary interaction.

This project compares random, static BM25, mixed, static dense and exact-input-duplicate-repaired negative policies under recorded training controls. The final confirmation compares random (`R_ID`), static BM25 (`B_ID`) and duplicate-repaired BM25 (`B_UNIQUE`) with five seeds in each of E5-small-v2 and BGE-small-en-v1.5. Qwen3-Embedding-0.6B is an inference-only reference. No agent or real tool API is executed.

The received execution contains 84 fresh training jobs, 260 final retrieval evaluations and 80 profiling records. This repository packages the executed scientific source and portable entry points; it does **not** claim that all GPU jobs have been rerun on this packaging computer. Three pairs of S1/S3 B_UNIQUE jobs had identical weights; 84 jobs are not 84 independent fitted models.

## What can be reproduced immediately

Use Python 3.12 for the historical environment. The standard-library checks also passed on Python 3.13.15. From the repository root:

```sh
python scripts/check_repository.py
python scripts/rebuild_primary_tables.py --output _work/primary_stdlib --no-bootstrap
```

These commands do not install packages, use a GPU, access a network, or read benchmark text. They verify frozen-source hashes, compile the packaged source, test synthetic ranking/uncertainty fixtures, validate all 31,500 saved native-menu rankings, and recompute means, seed variation and paired effects. The synthetic fixture is explicitly separate from research results.

For the **actual 5,000-replicate, query-weighted group-bootstrap intervals**:

```sh
python -m pip install -r requirements/analysis-minimal.txt
python scripts/rebuild_primary_tables.py --output _work/primary_with_intervals
```

Use a new empty output directory each time. The program imports the unchanged `publication_statistics.py`, recomputes scores from complete rankings and frozen relevant-ID sets, and checks regenerated values against historical reference values with absolute tolerance 1e-12. The reference values are comparison targets, never calculation inputs. `results/expected_tables/` contains a successful local regeneration of the CSV tables. `validation/` records the checks performed during packaging.

This small package covers the primary BFCL live confirmation: 1,050 queries, 220 frozen proxy groups, two encoder families, three strategies and five paired seeds. It is **not** a replacement for the complete 260-evaluation archive. Full native menus are retained as IDs; query/tool text and raw scores are omitted. A separate intake audit verified retained BFCL query/context/menu structure and function-name gold projection against the **packaged pinned official source files**; no new semantic adjudication or tool execution was performed.

## Main result and interpretation

For BFCL live MRR, B_UNIQUE minus random is -0.033960 for E5 and -0.011670 for BGE. B_UNIQUE minus ordinary BM25 is +0.008281 and +0.004571 respectively, with both pointwise group-bootstrap intervals crossing zero. All five seed differences against random are negative in both families. The intended improvement is unsupported.

The selected B_UNIQUE recipe was a prespecified fallback after the development improvement gate failed; it was not the best development strategy. Final recipes can differ in learning rate and update count. Those comparisons concern complete selected recipes. The separate fixed-recipe E5 comparison is required for a narrower negative-policy interpretation.

Intervals condition on these fitted models, fixed labels and the evaluation sample. Seed standard deviation is reported separately. Intervals are pointwise, not simultaneous, and do not establish training-population uncertainty or significance after multiple testing. BFCL scores measure function-name retrieval over each native menu, **not** the official function-call or agent leaderboard. ToolHop pooled reference-ID results are a stress diagnostic with incomplete relevance judgments. Original training-row provenance and pretraining exposure are unknown; the external data are collision-screened, not proven source-disjoint.

## Repository organization

| Path | Purpose |
|---|---|
| `frozen/publication/extensions/` | All 48 original extension scripts, byte-for-byte preserved |
| `frozen/reproduction/scripts/` | Original preparation, training, retrieval, audit and analysis source |
| `frozen/publication/analysis_tools/` | Two received post-lock CPU compatibility adapters |
| `scripts/` | New packaging adapters; distinct from the executed frozen source |
| `configs/training/` | 78 actual S1–S5 configurations with portable path views |
| `configs/experiment_matrix.json` | Original 84-job design; S0 uses the original six-run engine |
| `configs/protocol/` | Scientific locks as private-path-sanitized views; not original lock bytes |
| `configs/upstream/`, `configs/download_assets.json` | Official pinned URLs, versions and file hashes |
| `provenance/` | Original-source SHA256s and every result projection’s lineage |
| `fixtures/` | Clearly labeled synthetic engineering data |
| `results/representative/` | Real primary confirmation rankings and labels, without text |
| `references.json` | Verified bibliographic metadata; student verification still pending |
| `AI_DISCLOSURE.md`, `THIRD_PARTY_NOTICES.md` | Authorship, AI, sources and rights boundaries |

Frozen historical helper scripts are evidence, not interchangeable public entry points. In particular, **do not run** `frozen/publication/extensions/rebuild_research.py`: that old entry has a known S0 metadata-alias issue. Use `scripts/rebuild_full_bundle.py` for the received complete archive. Do not run the historical `freeze_main_study.py` or `finalize_review.py` as a generic review workflow: they encode one-time recorded student batch confirmation and must never be used to manufacture a new human review.

## Environment and model downloads

The historical GPU run used Python 3.12, PyTorch 2.7.1+cu128, Transformers 4.57.1, NumPy 2.2.6, and one NVIDIA RTX A5000. Training used bf16 autocast; retrieval used float32 with TF32 disabled. Install in a separate environment:

```sh
python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements/observed-training-without-torch.txt
```

The official CUDA wheel requires compatible NVIDIA hardware/drivers. The full observed lists are records of the completed environment, not a promise that every platform can install those versions. `requirements/preparation-extras.txt` is needed if rebuilding the original raw-data preparation. `requirements/observed-analysis.txt` supports complete CPU analysis including plots. Small-table regeneration needs only the minimal analysis requirement.

Inspect downloads before fetching, then choose an ignored private workspace:

```sh
python scripts/download_assets.py --group e5 --list
python scripts/download_assets.py --group e5 --workspace _work/run01
python scripts/download_assets.py --group bge --workspace _work/run01
python scripts/download_assets.py --group qwen --workspace _work/run01
```

Each file is pinned to an upstream revision and checked against recorded SHA256 or Git blob identity. Qwen weights are about 1.19 GB and are not needed for E5/BGE training. No weights, cached embeddings, environments or incomplete download fragments are included here. Downloaded ToolHop code is never executed by these adapters.

## Exact historical training inputs

The exact main snapshot includes audited positive/exclusion records, 10,000 training queries, 1,000 development queries, paired schedules and frozen negative pools. These are **not publicly distributed by this candidate repository**. A public upstream download alone cannot reconstruct the historical human/AI review decisions. Row-level upstream provenance and redistribution clearance are unresolved. Do not silently recreate labels or claim a newly generated snapshot is identical.

If you have the separately received **local extracted result bundle**, stage only allowlisted inputs. Replace `/path/to/received_bundle` with its local location; it is not an Internet address. Staging must precede downloads because its destination must be new:

```sh
python scripts/stage_private_inputs.py --bundle /path/to/received_bundle --workspace _work/run01 --check-only
python scripts/stage_private_inputs.py --bundle /path/to/received_bundle --workspace _work/run01
python scripts/download_assets.py --group e5 --workspace _work/run01
python scripts/download_assets.py --group bge --workspace _work/run01
```

The importer verifies `configs/private_input_manifest.json` and the original freeze hashes. It copies no historical checkpoints, predictions, sessions or process logs. The staged workspace can contain historical review records and must remain private. Running the earlier download-only example creates its workspace; use a different new path if subsequently staging exact inputs.

For public upstream acquisition:

```sh
python scripts/download_assets.py --group toolret --workspace _work/raw_inputs
python scripts/download_assets.py --group bfcl --workspace _work/raw_inputs
python scripts/download_assets.py --group toolhop --workspace _work/raw_inputs
```

The raw ToolRet preparation source is preserved in `prepare.py`, `prepare_audited_pilot.py`, `prepare_main_study.py`, and `freeze_main_study.py`; the extension conversion is in `external_prepare.py`. Download metadata is under `configs/upstream/`. Those historical scripts depend on protocol files and review artifacts that cannot be inferred from upstream text. They are documented source for an audited reconstruction, **not a fully automated public raw-to-identical-snapshot claim**. For a new dataset/review, record a new protocol and new freeze instead of reusing historical attestation code.

## Training and development evaluation

After staging exact inputs and downloading base models:

```sh
python scripts/run_training.py --workspace _work/run01 --stage S0 --check-only
python scripts/run_training.py --workspace _work/run01 --stage S0
python scripts/run_training.py --workspace _work/run01 --stage S1
python scripts/run_training.py --workspace _work/run01 --stage S2
python scripts/run_training.py --workspace _work/run01 --stage S3
python scripts/run_training.py --workspace _work/run01 --stage S4
python scripts/run_training.py --workspace _work/run01 --stage S5
```

**These are real GPU training commands.** S0 runs six original paired jobs; S1–S5 run 12/24/15/12/15 jobs respectively. `--run-id` restricts S1–S5 to an existing named configuration, and `--check-only` checks local inputs without training. New output directories are required; completed results are never silently reused. There is no automatic training execution during repository checks.

These commands replay the recorded historical configurations. They do not redo a new blinded development selection. The preserved `select_on_dev.py` and selection locks specify the original selection procedure. Any fresh selection study needs new output registries and freezes, retains all seeds, and must not use external scores for tuning.

Training uses per-query softmax over one positive and four explicit negatives, microbatch 8 × four accumulation steps = 32 queries per update, AdamW, constant learning rate, clip norm 1.0, query/tool caps 128/384 and fixed update milestones. This is **not an in-batch-negative loss**. Checkpoint-time development evaluation occurs in a separate process.

To regenerate policy inputs from an already verified main snapshot, use `scripts/prepare_training_inputs.py --workspace ... --stage schedules`, then `signatures`, `mine`, and `negatives`. Dense mining needs a GPU. Use a fresh policy-output directory; an imported historical manifest can contain machine-specific metadata, so do not mix new generation with imported frozen outputs.

For retrieval, write an explicit local evaluation config using `configs/examples/development_evaluation.json` and call:

```sh
python scripts/run_evaluation.py --config /path/to/local_evaluation.json --output _work/dev_eval01 --check-only
python scripts/run_evaluation.py --config /path/to/local_evaluation.json --output _work/dev_eval01
```

The example’s paths must be replaced. External confirmation requires a compatible final lock binding checkpoint and input hashes. The adapter retains the original gate. Freshly trained checkpoint bytes may differ across hardware; never remove the gate or claim they are the historical confirmation. Record a new replication lock and mark it as replication of an already observed benchmark.

## Optional complete archive analysis

With the separate local returned bundle and the observed analysis dependencies:

```sh
python scripts/rebuild_full_bundle.py --bundle /path/to/received_bundle --output /path/to/new_cpu_rebuild
```

This checks the frozen source identity and calls the bundle’s canonical `publication/analysis_tools/rebuild_research.py`. It rebuilds research, legacy, efficiency and negative-input tables without model execution. It uses the two received post-lock adapters that repair six S0 metadata aliases in memory; neither original scores nor scientific rules are changed. The original bundle and output directory must be separate.

Large trained weights, optimizer states and full embedding arrays were not supplied in the return archive. Some manifests reference them by historical hashes. Full training resume and independent checkpoint inference therefore require the original assets or a new documented rerun. A rebuilt table is not a new training experiment.

## Integrity and release status

Independent human review is **0/98 completed**. The prior 400 pairs were AI-assisted and batch-confirmed by the student; they were not independently double-annotated. The 60 error cases/114 pairs are AI-only, outcome-unblinded qualitative analysis. Do not relabel those as human results. Review status, missing evidence and uncertain mechanisms remain explicit.

See `AI_DISCLOSURE.md`, `LICENSE_NOTICE.md`, and `PUBLICATION_CHECKLIST.md`. The public repository URL and public data-availability statement remain pending author approval and actual publication. The Canvas code assignment requires a public repository URL; this local ZIP alone does not fulfill that final hosting requirement.
