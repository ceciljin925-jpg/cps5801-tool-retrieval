# License and release status

This is a **local publication candidate**, not a claim of open-source licensing or public availability. A license for project-authored/AI-assisted code has not yet been selected by the project owner. No blanket MIT/Apache grant is asserted for the project code. Public visibility and an open-source reuse license are separate decisions.

Before public hosting, the author must confirm authorship/ownership, choose any intended project-code license, retain upstream notices, and review derived-data redistribution. See `THIRD_PARTY_NOTICES.md` for component-specific rights. Upstream software/model/data licenses are not replaced by a future project-code license.

BFCL-derived candidate/relevance IDs and model rankings in `results/representative/` are attributed to the upstream Apache-2.0 source. The upstream license is included as `licenses/BFCL-Apache-2.0.txt`. The accompanying metadata identifies the fixed source revision and the local transformations. No full ToolRet or ToolHop dataset is redistributed here. ToolRet row-level lineage and redistribution rights remain to be resolved before publishing any fuller snapshot.

The synthetic engineering fixture is project-generated example data, not copied benchmark content. The frozen code contains historical one-time review helpers; preserving them does not grant permission to fabricate reviewer attestations or to represent AI judgments as human review.
